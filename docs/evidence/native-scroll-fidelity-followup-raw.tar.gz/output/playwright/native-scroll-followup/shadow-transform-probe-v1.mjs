import { chromium, firefox, webkit } from 'playwright'
import { mkdir, writeFile, readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
const out = new URL('./transform-controls/', import.meta.url)
await mkdir(out, { recursive: true })
const modes = ['plain', 'svg-flip-y', 'foreign-flip-y', 'html-flip-y', 'svg-rotate-180', 'svg-flip-x', 'canvas-flip-y-raster', 'bitmap', 'nested-image']
const cases = [
  ['top', 'inset 0 10px blue'],
  ['bottom', 'inset 0 -10px blue'],
  ['left', 'inset 10px 0 blue'],
  ['top-blur', 'inset 0 10px 2px blue'],
  ['bottom-blur', 'inset 0 -10px 6px blue'],
  ['diagonal', 'inset 5px 10px 2px rgba(0,0,255,.7)'],
  ['multiple', 'inset 0 10px 2px blue,inset 7px -8px 3px red'],
  ['radius', 'inset 0 10px 2px blue', 'border-radius:7px'],
  ['border', 'inset 0 10px 2px blue', 'border:3px solid black;box-sizing:border-box'],
]
const before = execFileSync('git', ['status','--porcelain'], {encoding:'utf8'})
const receipt = { at:new Date().toISOString(), head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), libraryUsed:false, scope:'independently authored HTML/SVG; transform representation and SVG-to-canvas controls', engines:[] }
for (const [engine, type] of Object.entries({chromium,firefox,webkit})) {
  const browser = await type.launch({headless:true})
  try {
    const page = await browser.newPage({viewport:{width:400,height:250},deviceScaleFactor:1})
    await page.setContent('<!doctype html><meta charset="utf-8"><body style="margin:0">')
    const record = {engine,version:browser.version(),userAgent:await page.evaluate(()=>navigator.userAgent),cases:[]}
    for (const [name,shadow,extra=''] of cases) {
      const css = `width:40px;height:40px;background:green;box-shadow:${shadow};${extra}`
      await page.evaluate(css=>{ document.body.innerHTML='<div id="source" style="position:absolute;left:0;top:0;'+css+'"></div>' },css)
      const native=await page.locator('#source').screenshot({scale:'css'})
      await writeFile(new URL(`${engine}-${name}-native.png`,out),native)
      const result = await page.evaluate(async ({css,native,modes})=>{
        const load=async src=>{ const img=new Image(); img.src=src; await img.decode(); return img }
        const context=()=>{const c=document.createElement('canvas');c.width=c.height=40;return c.getContext('2d')}
        const expected=context();expected.drawImage(await load('data:image/png;base64,'+native),0,0)
        const pixels=expected.getImageData(0,0,40,40).data
        const diff=ctx=>{const a=ctx.getImageData(0,0,40,40).data;let channels=0,maxDelta=0;for(let i=0;i<a.length;i++){channels+=a[i]!==pixels[i];maxDelta=Math.max(maxDelta,Math.abs(a[i]-pixels[i]))}return {channels,maxDelta}}
        const results=[]
        for(const mode of modes){
          let html=`<div xmlns="http://www.w3.org/1999/xhtml" style="${css}"></div>`
          if(mode==='html-flip-y') html=`<div xmlns="http://www.w3.org/1999/xhtml" style="width:40px;height:40px;transform:translateY(40px) scaleY(-1);transform-origin:0 0">${html}</div>`
          let body=`<foreignObject width="40" height="40"${mode==='foreign-flip-y'?' transform="translate(0 40) scale(1 -1)"':''}>${html}</foreignObject>`
          const transform=mode==='svg-flip-y'?'translate(0 40) scale(1 -1)':mode==='svg-flip-x'?'translate(40 0) scale(-1 1)':mode==='svg-rotate-180'?'translate(40 40) scale(-1 -1)':null
          if(transform)body=`<g transform="${transform}">${body}</g>`
          let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">${body}</svg>`
          if(mode==='nested-image')svg=`<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><image width="40" height="40" href="data:image/svg+xml,${encodeURIComponent(svg)}"/></svg>`
          try{
            const image=await load('data:image/svg+xml,'+encodeURIComponent(svg))
            const ctx=context()
            if(['svg-flip-y','foreign-flip-y','html-flip-y','canvas-flip-y-raster'].includes(mode))ctx.setTransform(1,0,0,-1,0,40)
            if(mode==='svg-flip-x')ctx.setTransform(-1,0,0,1,40,0)
            if(mode==='svg-rotate-180')ctx.setTransform(-1,0,0,-1,40,40)
            let bitmap
            if(mode==='bitmap'){bitmap=await createImageBitmap(image);ctx.drawImage(bitmap,0,0);bitmap.close()}
            else ctx.drawImage(image,0,0)
            let final=ctx
            if(mode==='canvas-flip-y-raster'){final=context();final.setTransform(1,0,0,-1,0,40);final.drawImage(ctx.canvas,0,0)}
            const delta=diff(final)
            results.push({mode,...delta,png:final.canvas.toDataURL().split(',')[1],svg})
          }catch(error){results.push({mode,error:String(error),svg})}
        }
        return results
      },{css,native:native.toString('base64'),modes})
      for (const r of result) {
        if(r.png){await writeFile(new URL(`${engine}-${name}-${r.mode}.png`,out),Buffer.from(r.png,'base64'));delete r.png}
        await writeFile(new URL(`${engine}-${name}-${r.mode}.svg`,out),r.svg);delete r.svg
      }
      record.cases.push({name,shadow,extra,results:result})
      console.log(engine,name,JSON.stringify(result.map(({mode,channels,error})=>({mode,channels,error}))))
    }
    receipt.engines.push(record)
    await writeFile(new URL('results.json',out),JSON.stringify(receipt,null,2)+'\n')
  } finally {await browser.close()}
}
receipt.workingTreeUnchanged=before===execFileSync('git',['status','--porcelain'],{encoding:'utf8'})
receipt.scriptSha256=createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex')
await writeFile(new URL('results.json',out),JSON.stringify(receipt,null,2)+'\n')
