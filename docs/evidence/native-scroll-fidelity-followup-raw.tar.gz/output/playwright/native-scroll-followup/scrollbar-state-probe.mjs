import { chromium, webkit } from 'playwright'
import ts from 'typescript'
import {execFileSync} from 'node:child_process'
import {mkdir,writeFile} from 'node:fs/promises'
const folder=new URL('./scrollbar-states/',import.meta.url);await mkdir(folder,{recursive:true})
const prototype=execFileSync('git',['rev-parse','codex/native-scroll-snapshot-v2'],{encoding:'utf8'}).trim()
let source=execFileSync('git',['show',prototype+':src/clone-scrollbars.ts'],{encoding:'utf8'})
source=source.replace(/^import .*\n/gm,'').replace('export function cloneScrollbarStyles','function cloneScrollbarStyles')
source='const getTask=()=>undefined;const uuid=()=>"frozen-scrollbar";const getStyleProperties=(computed,selected)=>Array.from(computed).filter(x=>!selected||selected.includes(x));\n'+source
const helper=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2017,module:ts.ModuleKind.None}}).outputText
await writeFile(new URL('prototype-helper.js',folder),helper)
const result={at:new Date().toISOString(),prototype,libraryUsed:false,scope:'Original prototype scrollbar style copier against independently authored SVG/CSS with actual native scroll state',engines:[]}
for(const [engine,type] of Object.entries({chromium,webkit})){
 const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})})
 try{
  const page=await browser.newPage({viewport:{width:400,height:300},deviceScaleFactor:1})
  await page.setContent('<!doctype html><meta charset="utf-8"><body style="margin:0">')
  await page.addScriptTag({content:helper+'\nwindow.copyProbeScrollbar=cloneScrollbarStyles;'})
  const row={engine,version:browser.version(),cases:[]}
  for(const variant of ['base','orientation','track-piece','hidden-buttons'])for(const scrolled of [false,true]){
   const id=variant+'-'+(scrolled?'scrolled':'zero')
   const css=`#panel::-webkit-scrollbar{width:11px;height:7px;background:red}#panel::-webkit-scrollbar-track{background:red}#panel::-webkit-scrollbar-thumb{background:black;border-radius:0}#panel::-webkit-scrollbar-corner{background:blue}`+
    (variant==='orientation'?'#panel::-webkit-scrollbar-thumb:horizontal{background:yellow}#panel::-webkit-scrollbar-thumb:vertical{background:black}':'')+
    (variant==='track-piece'?'#panel::-webkit-scrollbar-track-piece:start{background:cyan}#panel::-webkit-scrollbar-track-piece:end{background:red}':'')+
    (variant==='hidden-buttons'?'#panel::-webkit-scrollbar-button:single-button{display:none}':'')
   const control=await page.evaluate(({css,scrolled})=>{
    document.body.innerHTML='<style id="rules"></style><div id="source" style="position:absolute;left:0;top:0;width:100px;height:100px;background:white;overflow:hidden"><div id="panel" style="position:relative;width:100px;height:100px;overflow:scroll;background:green"><div style="position:relative;width:240px;height:300px;background:green"><div style="position:absolute;left:45px;top:55px;width:4px;height:4px;background:blue"></div></div></div></div>'
    document.querySelector('#rules').textContent=css
    const p=document.querySelector('#panel');if(scrolled){p.scrollLeft=40;p.scrollTop=50}
    return {offset:[p.scrollLeft,p.scrollTop],client:[p.clientWidth,p.clientHeight],before:document.querySelector('#source').outerHTML}
   },{css,scrolled})
   const native=await page.locator('#source').screenshot({scale:'css'})
   await writeFile(new URL(`${engine}-${id}-native.png`,folder),native)
   const outputs=await page.evaluate(async({css,native,scrolled})=>{
    const original=document.querySelector('#source');const panel=document.querySelector('#panel')
    const load=async src=>{const i=new Image();i.src=src;await i.decode();return i}
    const ctx=()=>{const c=document.createElement('canvas');c.width=c.height=100;return c.getContext('2d')}
    const reference=ctx();reference.drawImage(await load('data:image/png;base64,'+native),0,0);const expected=reference.getImageData(0,0,100,100).data
    const colors=data=>{const count={red:0,black:0,yellow:0,cyan:0,blue:0};const wanted={'255,0,0,255':'red','0,0,0,255':'black','255,255,0,255':'yellow','0,255,255,255':'cyan','0,0,255,255':'blue'};for(let n=0;n<data.length;n+=4){const k=wanted[Array.from(data.slice(n,n+4)).join()];if(k)count[k]++}return count}
    const outputs=[]
    for(const mode of ['prototype','authored']){
     const copy=original.cloneNode(true),cp=copy.querySelector('#panel')
     if(mode==='prototype')window.copyProbeScrollbar(panel,cp,{})
     else {const style=document.createElement('style');style.textContent=css;copy.append(style)}
     if(scrolled){
      cp.style.setProperty('scroll-snap-type','both mandatory','important');cp.style.setProperty('scroll-padding','0px','important')
      const style=document.createElement('style');style.textContent='#panel::before{all:initial!important;content:""!important;position:absolute!important;left:0!important;top:0!important;width:100%!important;height:100%!important;margin:0!important;scroll-snap-align:start start!important;scroll-margin-left:-40px!important;scroll-margin-right:40px!important;scroll-margin-top:-50px!important;scroll-margin-bottom:50px!important}'
      copy.append(style)
     }
     copy.style.position='static';const html=new XMLSerializer().serializeToString(copy)
     const svg='<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><foreignObject width="100" height="100">'+html+'</foreignObject></svg>'
     const c=ctx();c.drawImage(await load('data:image/svg+xml,'+encodeURIComponent(svg)),0,0)
     const actual=c.getImageData(0,0,100,100).data;let differentChannels=0,maxDelta=0;for(let n=0;n<actual.length;n++){differentChannels+=actual[n]!==expected[n];maxDelta=Math.max(maxDelta,Math.abs(actual[n]-expected[n]))}
     outputs.push({mode,differentChannels,maxDelta,nativeColors:colors(expected),captureColors:colors(actual),svg,png:c.canvas.toDataURL().split(',')[1]})
    }
    return {outputs,sourceAfter:original.outerHTML,offsetAfter:[panel.scrollLeft,panel.scrollTop]}
   },{css,native:native.toString('base64'),scrolled})
   for(const x of outputs.outputs){await writeFile(new URL(`${engine}-${id}-${x.mode}.svg`,folder),x.svg);delete x.svg;await writeFile(new URL(`${engine}-${id}-${x.mode}.png`,folder),Buffer.from(x.png,'base64'));delete x.png}
   const sourceUnchanged=control.before===outputs.sourceAfter&&JSON.stringify(control.offset)===JSON.stringify(outputs.offsetAfter)
   const r={id,css,...control,before:undefined,sourceUnchanged,...outputs,sourceAfter:undefined}
   row.cases.push(r);console.log(engine,id,JSON.stringify({client:r.client,offset:r.offset,sourceUnchanged,outputs:r.outputs}))
  }
  result.engines.push(row);await writeFile(new URL('results.json',folder),JSON.stringify(result,null,2)+'\n')
 }finally{await browser.close()}
}
