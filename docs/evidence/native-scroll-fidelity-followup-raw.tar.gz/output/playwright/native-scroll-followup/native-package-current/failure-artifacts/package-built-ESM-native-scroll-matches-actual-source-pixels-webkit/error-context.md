# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: package.test.ts >> built ESM: native scroll matches actual source pixels
- Location: test/browser/package.test.ts:59:9

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 20

- Array []
+ Array [
+   Object {
+     "error": "checkNativeScroll@http://127.0.0.1:4173/test/browser/fixtures/native-scroll.mjs:219:26
+ @
+ @",
+     "kind": "visible-text",
+   },
+   Object {
+     "error": "checkNativeScroll@http://127.0.0.1:4173/test/browser/fixtures/native-scroll.mjs:219:26
+ @
+ @",
+     "kind": "fractional",
+   },
+   Object {
+     "error": "checkNativeScroll@http://127.0.0.1:4173/test/browser/fixtures/native-scroll.mjs:219:26
+ @
+ @",
+     "kind": "padding-shadow",
+   },
+ ]
```

# Test source

```ts
  66  |             timeout: 5000,
  67  |           })
  68  |         ).toString('base64'),
  69  |       )
  70  |       await page.goto('/test/browser/umd.html')
  71  |       if (format === 'UMD')
  72  |         await page.addScriptTag({ url: '/dist/html-to-image.js' })
  73  |       const report = await page.evaluate(
  74  |         async ({ format, group }) => {
  75  |           const scope = window as typeof window & {
  76  |             htmlToImage: typeof import('../../src')
  77  |             __nativeScrollSourcePNG(id: string): Promise<string>
  78  |           }
  79  |           const apiURL = '/es/index.js'
  80  |           const api =
  81  |             format === 'UMD' ? scope.htmlToImage : await import(apiURL)
  82  |           if (!api?.createRenderer)
  83  |             throw new Error(`${format} createRenderer export is missing`)
  84  |           const fixtureURL = `/test/browser/fixtures/native-${group}.mjs`
  85  |           const fixture = await import(fixtureURL)
  86  |           const kinds: string[] =
  87  |             group === 'scroll'
  88  |               ? fixture.nativeScrollCases
  89  |               : fixture.nativeScrollbarCases
  90  |           const check =
  91  |             group === 'scroll'
  92  |               ? fixture.checkNativeScroll
  93  |               : fixture.checkNativeScrollbars
  94  |           const readNative = async (id: string) => {
  95  |             const png = await scope.__nativeScrollSourcePNG(id)
  96  |             const image = new Image()
  97  |             image.src = 'data:image/png;base64,' + png
  98  |             await image.decode()
  99  |             const canvas = document.createElement('canvas')
  100 |             canvas.width = image.naturalWidth
  101 |             canvas.height = image.naturalHeight
  102 |             const context = canvas.getContext('2d')!
  103 |             context.drawImage(image, 0, 0)
  104 |             return context.getImageData(0, 0, canvas.width, canvas.height)
  105 |           }
  106 |           const supportsLegacy = CSS.supports('selector(::-webkit-scrollbar)')
  107 |           const report = {
  108 |             format,
  109 |             group,
  110 |             userAgent: navigator.userAgent,
  111 |             dpr: devicePixelRatio,
  112 |             listed: kinds.length,
  113 |             executed: [] as string[],
  114 |             passed: [] as string[],
  115 |             failed: [] as { kind: string; error: string }[],
  116 |             unsupported: [] as { kind: string; reason: string }[],
  117 |           }
  118 |           for (const kind of kinds) {
  119 |             if (
  120 |               group === 'scrollbars' &&
  121 |               kind.startsWith('legacy') &&
  122 |               !supportsLegacy
  123 |             ) {
  124 |               report.unsupported.push({
  125 |                 kind,
  126 |                 reason: 'CSS.supports(selector(::-webkit-scrollbar)) is false',
  127 |               })
  128 |               continue
  129 |             }
  130 |             report.executed.push(kind)
  131 |             try {
  132 |               // Run every supported case even if another case fails. A warmed
  133 |               // replay or a successful later case never replaces its verdict.
  134 |               // eslint-disable-next-line no-await-in-loop
  135 |               await check(api, kind, readNative)
  136 |               report.passed.push(kind)
  137 |             } catch (error) {
  138 |               report.failed.push({
  139 |                 kind,
  140 |                 error: String((error as Error).stack || error),
  141 |               })
  142 |             }
  143 |           }
  144 |           return report
  145 |         },
  146 |         { format, group },
  147 |       )
  148 |       await testInfo.attach('native-source-pixel-verdicts', {
  149 |         body: JSON.stringify(report, null, 2),
  150 |         contentType: 'application/json',
  151 |       })
  152 |       report.unsupported.forEach(({ kind, reason }) => {
  153 |         testInfo.annotations.push({
  154 |           type: 'unsupported fixture',
  155 |           description: `${kind}: ${reason}`,
  156 |         })
  157 |       })
  158 |       expect(report.listed).toBeGreaterThan(0)
  159 |       expect(report.executed.length).toBeGreaterThan(0)
  160 |       expect(report.executed.length + report.unsupported.length).toBe(
  161 |         report.listed,
  162 |       )
  163 |       expect(report.passed.length + report.failed.length).toBe(
  164 |         report.executed.length,
  165 |       )
> 166 |       expect(report.failed).toEqual([])
      |                             ^ Error: expect(received).toEqual(expected) // deep equality
  167 |     })
  168 |   })
  169 | })
  170 | 
  171 | test('the full mobile smoke page completes without a hidden failure', async ({
  172 |   page,
  173 | }) => {
  174 |   await page.goto('/test/browser/smoke.html')
  175 |   const results = page.locator('#results')
  176 |   await expect(results).toContainText('REPORT SAVED', { timeout: 90000 })
  177 |   const text = await results.textContent()
  178 |   cases.forEach((name) => expect(text).toContain(`PASS ${name}`))
  179 |   expect(text).not.toContain('FAIL')
  180 |   expect(text).toContain('DPR=')
  181 |   const id = text?.match(/REPORT SAVED ([a-f0-9-]{36})/)?.[1]
  182 |   expect(id).toBeDefined()
  183 |   const report = JSON.parse(
  184 |     await readFile(`test-results/mobile-smoke-reports/${id}.json`, 'utf8'),
  185 |   )
  186 |   expect(report.id).toBe(id)
  187 |   expect(report.complete).toBe(true)
  188 |   expect(report.userAgent).toBeTruthy()
  189 |   expect(report.gitHead).toBe(
  190 |     execFileSync('git', ['rev-parse', 'HEAD']).toString().trim(),
  191 |   )
  192 |   expect(report.verdicts).toHaveLength(cases.length + 2)
  193 |   const rejected = await page.request.post(
  194 |     '/test/browser/mobile-smoke-report',
  195 |     { data: { complete: true } },
  196 |   )
  197 |   expect(rejected.status()).toBe(403)
  198 | })
  199 | 
  200 | test('built UMD global renders pixels in a browser', async ({ page }) => {
  201 |   await page.goto('/test/browser/umd.html')
  202 |   await page.addScriptTag({ url: '/dist/html-to-image.js' })
  203 |   const result = await page.evaluate(async () => {
  204 |     const node = document.getElementById('capture')!
  205 |     const api = (
  206 |       window as typeof window & {
  207 |         htmlToImage?: {
  208 |           toImageData: (
  209 |             node: HTMLElement,
  210 |             options: { pixelRatio: number; skipFonts: boolean },
  211 |           ) => Promise<ImageData>
  212 |         }
  213 |       }
  214 |     ).htmlToImage
  215 |     if (!api) throw new Error('UMD global missing')
  216 |     const image = await api.toImageData(node, {
  217 |       pixelRatio: 1,
  218 |       skipFonts: true,
  219 |     })
  220 |     const offset = 4 * (16 * image.width + 16)
  221 |     return {
  222 |       width: image.width,
  223 |       height: image.height,
  224 |       pixel: Array.from(image.data.slice(offset, offset + 4)),
  225 |     }
  226 |   })
  227 |   expect(result).toEqual({ width: 32, height: 32, pixel: [255, 0, 0, 255] })
  228 | })
  229 | 
  230 | test('built UMD validates explicit dimensions and preserves the scaled pixel buffer', async ({
  231 |   page,
  232 | }) => {
  233 |   await page.goto('/test/browser/umd.html')
  234 |   await page.addScriptTag({ url: '/dist/html-to-image.js' })
  235 |   const result = await page.evaluate(async () => {
  236 |     const api = (
  237 |       window as typeof window & {
  238 |         htmlToImage: typeof import('../../src')
  239 |       }
  240 |     ).htmlToImage
  241 |     const node = document.createElement('div')
  242 |     node.style.cssText = 'width:16px;height:12px;background:red'
  243 |     document.body.append(node)
  244 |     const renderer = api.createRenderer({ skipFonts: true, pixelRatio: 2 })
  245 |     try {
  246 |       const canvas = await renderer.toCanvas(node, {
  247 |         width: 24,
  248 |         height: 18,
  249 |         canvasWidth: 40,
  250 |         canvasHeight: 30,
  251 |       })
  252 |       const zeros = []
  253 |       const invalid = []
  254 |       const dimensions = ['width', 'height'] as const
  255 |       for (let i = 0; i < dimensions.length; i += 1) {
  256 |         const dimension = dimensions[i]
  257 |         // eslint-disable-next-line no-await-in-loop
  258 |         const capture = await renderer.capture(node, { [dimension]: 0 })
  259 |         let rasterError = ''
  260 |         try {
  261 |           // eslint-disable-next-line no-await-in-loop
  262 |           await capture.toCanvas()
  263 |         } catch (error) {
  264 |           rasterError = (error as Error).message
  265 |         }
  266 |         // eslint-disable-next-line no-await-in-loop
```