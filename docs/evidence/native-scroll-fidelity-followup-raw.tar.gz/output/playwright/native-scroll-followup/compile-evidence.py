from pathlib import Path
import hashlib,json,tarfile,gzip,io,datetime

base=Path('output/playwright')
folders=['native-scroll-followup','svg-followup-20261125','webkit-followup-20261125','scrollbar-review-20261125','scrollbar-resource-plan-20261125']
files=[]
excluded=[]
for folder in folders:
    for path in sorted((base/folder).rglob('*')):
        if not path.is_file():continue
        # Browser engine downloads are optional source references, not local
        # empirical inputs. Keep their pinned provenance, omit duplicate code.
        if 'upstream-source' in path.parts or path.suffix=='.cpp':
            excluded.append(str(path));continue
        if folder=='scrollbar-resource-plan-20261125' and not (path.parent.name.startswith('http-proof') or path.name in {'http-reader-proof.mjs','http-reader-proof-initial.mjs','proof.log','proof-v2.log'}):continue
        files.append(path)
entries=[{'path':str(p),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
dest=Path('docs/evidence');dest.mkdir(exist_ok=True)
archive=dest/'native-scroll-fidelity-followup-raw.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for p in files:
                body=p.read_bytes();info=tarfile.TarInfo(str(p));info.size=len(body);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(entries)
    expected={x['path']:x for x in entries}
    for member in members:
        body=tar.extractfile(member).read();entry=expected[member.name]
        assert len(body)==entry['size'] and hashlib.sha256(body).hexdigest()==entry['sha256']
index={'schemaVersion':1,'scope':'2026-11-25 native scroll and scrollbar candidate plus parallel SVG/renderer investigation; original failures preserved','fileCount':len(entries),'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'excludedOptionalEngineSourceCopies':excluded,'files':entries}
(dest/'native-scroll-fidelity-followup-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
source='f3a00b069fadea920606b805221f1996711f09a9'
record={
 'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'incomplete prototype; default workflow and native package strict pixel gates fail; not ready for merge',
 'sourceCommit':source,'parent':'25e83810cb7d1865b6a2108c67f195b6a09a05e3','branch':'codex/native-scroll-fidelity','previousPrototype':'439709c04bc7e11941f8a06819591b50b7bd1b8c',
 'relatedPRs':[376,407,408,585,427],'relatedIssues':[81,345],
 'requirement':'Current browser live-page fidelity, including native scrollbar track/thumb size, color and position. Existing requirements are not a pending scope choice.',
 'change':{'nativeScroll':'Retain native overflow and encode supported scroll state with a snap target; keep existing external-absolute fallback and gutter-origin correction.','scrollbarStyles':'Preserve qualified native-part selectors, source prefix specificity through a never-matching :is branch, priorities, layer order, active media/supports and URL provenance.','lifetime':'Imported DOM/CSS operations use the existing reflective DOM access helpers. Bounded static audit finds zero direct accesses in the audited interface families.','remainingInThisCandidate':['partially unreadable stylesheet overrides','actual native-part hover state','strict WebKit glyph/shadow/fractional image composition'],'newPublicAPI':False},
 'frozenComparison':{'before':{'engines':['chromium','webkit'],'failed':12,'passed':10},'after':{'engines':['chromium','firefox','webkit'],'passed':24,'unsupportedLegacyFirefox':9},'onlyChangedMeasuredInput':'src/clone-scrollbars.ts','unchangedInputCountPerRun':422,'evidence':['output/playwright/native-scroll-followup/qualified-before-frozen/receipt.json','output/playwright/native-scroll-followup/qualified-after-frozen/receipt.json']},
 'validation':{
  'sourceScrollFamily':{'passed':430,'failed':2,'skipped':12,'failureCases':['WebKit visible-text','WebKit padding-shadow'],'skipBreakdown':{'firefoxLegacyScrollbars':9,'existingFirefoxLegacyScrollbarBox':2,'existingChromiumHorizontalThumbBoundary':1}},
  'defaultPnpmTest':{'coveragePassed':1397,'coverageFailed':2,'coverageSkipped':13,'sourcePhase':'not run because coverage failed','packagePhase':'not part of pnpm test; independently checked below','existingSkips':4,'newFeatureUnsupportedLegacyFirefoxSkips':9,'inputCount':434,'inputsUnchanged':True},
  'nativeBuiltPackages':{'formats':['ESM','UMD'],'groupTestsPassed':10,'groupTestsFailed':2,'fixtureListed':174,'fixtureExecuted':156,'fixturePassed':150,'fixtureFailed':6,'fixtureUnsupported':18,'failureCasesPerWebKitFormat':['visible-text','fractional','padding-shadow'],'dpr':{'chromium':1,'firefox':1,'webkit':2},'inputCount':434,'inputsUnchanged':True,'fullPackageSuite':'not executed for this prototype'},
  'lint':'passed after correcting package test index loop; initial lint failure preserved','buildESMCJSUMD':'passed','packageContractAndConsumers':'passed','browserTypes':'passed','staticDOMAuditDirectProperties':0,
  'commitInputIdentity':{'all434MeasuredInputsMatchSavedCommitAndGeneratedBytes':True,'receipt':'output/playwright/native-scroll-followup/candidate-input-identity.json'},
  'remoteCI':'not run for this unsubmitted native prototype; parent PR #650 checks are a different scope',
  'physicalDevice':'deferred at user request; prior 112/112 UMD result belongs to parent source and does not validate this prototype'},
 'parallelFindings':{
  'externalSVG':{'assessment':'output/playwright/svg-followup-20261125/assessment.json','result':'Relative attribute/inline paint is absolutized during import/getComputedStyle. Native HTTP controls reject xml:base as a repair. Distinct query bytes prove query identity survives while page/file directory selection differs by engine. No runtime repair claimed.'},
  'webKit':{'assessment':'output/playwright/webkit-followup-20261125/assessment.json','result':'DPR2 fractional mismatch also exists in a no-library/no-scroll 40px box. Same-size device PNG comparison and native SVG-image screenshot retain the failure. Transform and zoom controls introduce counterexamples; no generic fix adopted. Used-font SVG decode separates the font-URL cache dependency from HTML/FontFace preload, without proving a default repair.'},
  'scrollbarReview':{'assessment':'output/playwright/scrollbar-review-20261125/assessment.json','result':'Missing opaque stylesheet overrides and actual native hover state are separate reproduced failures; base and qualified computed-style reads cannot recover orientation/part hover. Positive Document/ShadowRoot controls retained.'},
  'stylesheetResourceProof':{'evidence':'output/playwright/scrollbar-resource-plan-20261125/http-proof-v2/results.json','result':'Independent HTTP/CORS/resolver controls preserve imports/layers/priorities and redirected URL bases. Even readable CSSOM retains pre-redirect href. Missing CSS without readable transport remains an explicit failure, not pixel acceptance. Production integration is subsequent unvalidated work.'}},
 'remaining':['Complete stylesheet resource integration and before/after real HTTP regressions.','Resolve or precisely delimit native part interaction data and WebKit image compositor boundaries without weakening existing pixel gates.','Run complete exact-source checks, final-head remote CI, and deferred real-device acceptance before completion.','Retain original Windows/Edge and unavailable #81 fixture boundaries; do not treat current desktop controls as whole-original-application verification.'],
 'oldPRCommentOrClosureActions':0,'npmPublished':False,'macNetworkConfigurationChanged':False,
 'rawEvidence':{'index':'native-scroll-fidelity-followup-index.json','archive':archive.name,'fileCount':len(entries),'allArchivedMemberHashesVerified':True},
 'replay':'Extract archive from repository root. Inspect source-checkpoint and candidate-input-identity first; source measurements used saved dirty bytes from parent HEAD, now identical to f3a00b0. Checkout the recorded source before build/test replay. Independent probes include their original scripts and assertions; earlier missing-browser, lint and failed paths are retained, not acceptance. Do not change the strict WebKit pixel gates or default DPR.'
}
(dest/'native-scroll-fidelity-followup.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(entries),'archiveBytes':archive.stat().st_size,'sha256':index['archive']['sha256'],'allMemberHashesVerified':True}))
