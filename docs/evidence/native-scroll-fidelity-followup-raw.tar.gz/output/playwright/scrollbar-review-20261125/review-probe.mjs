import { chromium, webkit } from 'playwright'
import ts from 'typescript'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {createHash} from 'node:crypto'
const folder=new URL('./results/',import.meta.url);await mkdir(folder,{recursive:true})
const source=await readFile('src/clone-scrollbars.ts','utf8')
let js=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2017,module:ts.ModuleKind.ESNext}}).outputText
js=js.replace(/^import[\s\S]*?from ['"][^'"]+['"];\s*/gm,'').replace('export function cloneScrollbarStyles','function cloneScrollbarStyles')
const stubs=`const readDOMProperty=(o,k)=>o[k], readDOMMethod=(o,k)=>(...a)=>Reflect.apply(o[k],o,a), hasDOMProperty=(k,o)=>k in o, writeDOMProperty=(o,k,v)=>o[k]=v;const getTask=()=>undefined,uuid=()=>"copied-bar",getStyleProperties=(s,p)=>Array.from(s).filter(x=>!p||p.includes(x)),rewriteSVGStyleURLs=(s)=>s;`
await writeFile(new URL('helper.js',folder),stubs+js)
const results={sourceSha256:createHash('sha256').update(source).digest('hex'),scope:'isolated direct snapshot of current scrollbar style copier, not a built library claim',engines:[]}
for(const [engine,type] of Object.entries({chromium,webkit})){
 const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})})
 try{
  const page=await browser.newPage({viewport:{width:400,height:300},deviceScaleFactor:1})
  await page.route('https://fixture.invalid/**',r=>r.fulfill({contentType:'text/html',body:'<!doctype html><body style="margin:0">'}))
  await page.route('https://cdn.invalid/**',r=>r.fulfill({contentType:'text/css',body:r.request().url().endsWith('orientation.css')?'#panel::-webkit-scrollbar-thumb:horizontal{background:blue!important}':'#panel::-webkit-scrollbar-thumb{background:blue!important}'}))
  const row={engine,version:browser.version(),cases:[]}
  for(const kind of ['document','shadow-simple','shadow-host','partial-unreadable','partial-unreadable-orientation','hover']){
   await page.goto('https://fixture.invalid/')
   await page.addScriptTag({content:stubs+js+';window.copyScrollbar=cloneScrollbarStyles'})
   const setup=await page.evaluate(async kind=>{
    const source=document.createElement('div');source.id='source';source.style.cssText='position:absolute;left:0;top:0;width:100px;height:100px;background:white;overflow:hidden'
    let root=document
    if(kind.startsWith('shadow')){source.className='theme';root=source.attachShadow({mode:'open'})}
    const panel=document.createElement('div');panel.id='panel';panel.className='panel';panel.style.cssText='width:100px;height:100px;background:green;overflow:scroll';panel.innerHTML='<div style="width:240px;height:300px;background:green"></div>'
    const rules=document.createElement('style');rules.textContent='.panel::-webkit-scrollbar{width:10px;height:10px;background:red}.panel::-webkit-scrollbar-track{background:red}.panel::-webkit-scrollbar-thumb{background:black;border-radius:0}.panel::-webkit-scrollbar-corner{background:blue}'
    if(kind==='shadow-host')rules.textContent+=':host(.theme) .panel::-webkit-scrollbar-thumb{background:blue!important}'
    if(kind==='hover')rules.textContent+='.panel::-webkit-scrollbar-thumb:hover{background:blue!important}'
    if(root===document){document.head.append(rules);source.append(panel)}else root.append(rules,panel)
    document.body.append(source)
    if(kind.startsWith('partial-unreadable')){
     const link=document.createElement('link');link.rel='stylesheet';link.href=kind.endsWith('orientation')?'https://cdn.invalid/orientation.css':'https://cdn.invalid/base.css';const ready=new Promise((resolve,reject)=>{link.onload=resolve;link.onerror=reject});document.head.append(link);await ready
    }
    const inaccessible=Array.from(document.styleSheets).map(s=>{try{return {href:s.href,rules:s.cssRules.length}}catch(e){return {href:s.href,error:String(e)}}})
    const p={sourceHTML:source.outerHTML,shadowHTML:source.shadowRoot?.innerHTML,client:[panel.clientWidth,panel.clientHeight],hostMatches:panel.matches(':host(.theme) .panel'),baseThumb:getComputedStyle(panel,'::-webkit-scrollbar-thumb').backgroundColor,inaccessible}
    window.reviewPanel=panel;return p
   },kind)
   if(kind==='hover'){await page.mouse.move(95,10);await page.waitForTimeout(100)}
   const native=await page.locator('#source').screenshot({scale:'css'})
   await writeFile(new URL(`${engine}-${kind}-native.png`,folder),native)
   const actual=await page.evaluate(async({kind,native})=>{
    const source=document.querySelector('#source'),panel=window.reviewPanel
    const clone=panel.cloneNode(true);window.copyScrollbar(panel,clone,{})
    const html=new XMLSerializer().serializeToString(clone)
    const svg='<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><foreignObject width="100" height="100">'+html+'</foreignObject></svg>'
    const load=async url=>{const i=new Image();i.src=url;await i.decode();return i}
    const canvas=()=>{const c=document.createElement('canvas');c.width=c.height=100;return c.getContext('2d')}
    const a=canvas(),b=canvas();a.drawImage(await load('data:image/png;base64,'+native),0,0);b.drawImage(await load('data:image/svg+xml,'+encodeURIComponent(svg)),0,0)
    const x=a.getImageData(0,0,100,100).data,y=b.getImageData(0,0,100,100).data
    let different=0;for(let n=0;n<x.length;n++)different+=x[n]!==y[n]
    const count=p=>{const o={blue:0,black:0,red:0};for(let n=0;n<p.length;n+=4){if(p[n]===0&&p[n+1]===0&&p[n+2]===255&&p[n+3]===255)o.blue++;if(p[n]===0&&p[n+1]===0&&p[n+2]===0&&p[n+3]===255)o.black++;if(p[n]===255&&p[n+1]===0&&p[n+2]===0&&p[n+3]===255)o.red++}return o}
    return {differentChannels:different,nativeColors:count(x),captureColors:count(y),copiedCSS:clone.querySelector('style')?.textContent,sourceHTMLAfter:source.outerHTML,shadowHTMLAfter:source.shadowRoot?.innerHTML,svg,png:b.canvas.toDataURL().split(',')[1]}
   },{kind,native:native.toString('base64')})
   await writeFile(new URL(`${engine}-${kind}.svg`,folder),actual.svg);delete actual.svg;await writeFile(new URL(`${engine}-${kind}-capture.png`,folder),Buffer.from(actual.png,'base64'));delete actual.png
   actual.sourceUnchanged=setup.sourceHTML===actual.sourceHTMLAfter&&setup.shadowHTML===actual.shadowHTMLAfter;delete actual.sourceHTMLAfter;delete actual.shadowHTMLAfter
   row.cases.push({kind,...setup,...actual});console.log(engine,kind,JSON.stringify(actual))
  }
  results.engines.push(row);await writeFile(new URL('results.json',folder),JSON.stringify(results,null,2)+'\n')
 }finally{await browser.close()}
}
