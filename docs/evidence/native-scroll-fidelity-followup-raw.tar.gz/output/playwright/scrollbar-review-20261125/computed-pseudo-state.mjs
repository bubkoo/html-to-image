import { chromium, webkit } from 'playwright'
import {mkdir,writeFile} from 'node:fs/promises'
const out=new URL('./computed-state/',import.meta.url);await mkdir(out,{recursive:true})
const report={at:new Date().toISOString(),scope:'unmodified native CSSOM scrollbar pseudo access before/after actual pointer hover',engines:[]}
for(const [engine,type] of Object.entries({chromium,webkit})){
 const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})})
 try{
  const page=await browser.newPage({viewport:{width:300,height:240},deviceScaleFactor:1})
  const row={engine,version:browser.version(),cases:[]}
  for(const kind of ['hover','orientation']){
   await page.setContent(`<!doctype html><body style="margin:0"><style>#panel::-webkit-scrollbar{width:10px;height:10px;background:red}#panel::-webkit-scrollbar-track{background:red}#panel::-webkit-scrollbar-thumb{background:black;border-radius:0}#panel::-webkit-scrollbar-corner{background:blue}${kind==='hover'?'#panel::-webkit-scrollbar-thumb:hover{background:blue!important}':'#panel::-webkit-scrollbar-thumb:horizontal{background:yellow}#panel::-webkit-scrollbar-thumb:vertical{background:black}'}</style><div id="panel" style="position:absolute;left:0;top:0;width:100px;height:100px;overflow:scroll;background:green"><div style="width:240px;height:300px;background:green"></div></div>`)
   const read=()=>page.evaluate(()=>{
    const p=document.querySelector('#panel');const values={}
    for(const pseudo of ['::-webkit-scrollbar-thumb','::-webkit-scrollbar-thumb:hover','::-webkit-scrollbar-thumb:horizontal','::-webkit-scrollbar-thumb:vertical']){
     try{const s=getComputedStyle(p,pseudo);values[pseudo]={length:s.length,color:s.backgroundColor,width:s.width,height:s.height,cssText:s.cssText}}catch(e){values[pseudo]={error:String(e)}}
    }
    return {source:p.outerHTML,hover:p.matches(':hover'),point:document.elementFromPoint(95,10)?.id,values}
   })
   await page.mouse.move(250,180)
   const before=await read();await page.locator('#panel').screenshot({scale:'css',path:new URL(`${engine}-${kind}-before.png`,out).pathname})
   await page.mouse.move(50,50);await page.waitForTimeout(100)
   const content=await read();await page.locator('#panel').screenshot({scale:'css',path:new URL(`${engine}-${kind}-content-hover.png`,out).pathname})
   await page.mouse.move(95,10);await page.waitForTimeout(100)
   const vertical=await read();await page.locator('#panel').screenshot({scale:'css',path:new URL(`${engine}-${kind}-vertical-hover.png`,out).pathname})
   await page.mouse.move(10,95);await page.waitForTimeout(100)
   const horizontal=await read();await page.locator('#panel').screenshot({scale:'css',path:new URL(`${engine}-${kind}-horizontal-hover.png`,out).pathname})
   const entry={kind,before,content,vertical,horizontal,sourceUnchanged:before.source===content.source&&before.source===vertical.source&&before.source===horizontal.source}
   row.cases.push(entry);console.log(engine,kind,JSON.stringify(entry))
  }
  report.engines.push(row);await writeFile(new URL('results.json',out),JSON.stringify(report,null,2)+'\n')
 }finally{await browser.close()}
}
