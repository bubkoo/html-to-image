import {webkit} from 'playwright'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
const dir=new URL('./fractional-zoom/',import.meta.url);await mkdir(dir,{recursive:true})
const svg=await readFile(new URL('./fractional-dpr/page2-export2.svg',import.meta.url),'utf8')
const native=(await readFile(new URL('./fractional-dpr/page2-export2-source-device.png',import.meta.url))).toString('base64')
const browser=await webkit.launch({headless:true});const result={at:new Date().toISOString(),version:browser.version(),cases:[]}
try{for(const mode of ['plain','zoom-root','zoom-wrapper','transform-wrapper']){
 const context=await browser.newContext({viewport:{width:400,height:250},deviceScaleFactor:2});const page=await context.newPage()
 try{
  await page.setContent('<!doctype html><meta charset="utf-8"><body style="margin:0">')
  const r=await page.evaluate(async({svg,native,mode})=>{
   const doc=new DOMParser().parseFromString(svg,'image/svg+xml'),root=doc.documentElement,foreign=doc.querySelector('foreignObject')
   if(mode!=='plain'){
    root.setAttribute('viewBox','0 0 80 80');foreign.setAttribute('width','80');foreign.setAttribute('height','80')
    if(mode==='zoom-root')foreign.firstElementChild.style.setProperty('zoom','2','important')
    else{const wrapper=doc.createElementNS('http://www.w3.org/1999/xhtml','div');wrapper.setAttribute('style',mode==='zoom-wrapper'?'zoom:2;width:40px;height:40px':'transform:scale(2);transform-origin:0 0;width:40px;height:40px');for(const child of Array.from(foreign.childNodes))wrapper.append(child);foreign.append(wrapper)}
   }
   const xml=new XMLSerializer().serializeToString(root)
   const load=async src=>{const i=new Image();i.src=src;await i.decode();return i}
   const image=await load('data:image/svg+xml,'+encodeURIComponent(xml));image.id='rendered';image.style.cssText='width:40px;height:40px;position:absolute;left:0;top:0';document.body.append(image)
   const source=await load('data:image/png;base64,'+native);const make=()=>{const c=document.createElement('canvas');c.width=c.height=80;return c.getContext('2d')}
   const ctx=make(),reference=make();ctx.drawImage(image,0,0,80,80);reference.drawImage(source,0,0);const a=ctx.getImageData(0,0,80,80).data,b=reference.getImageData(0,0,80,80).data;let channels=0,maxDelta=0;const points=[];for(let n=0;n<a.length;n++){if(a[n]!==b[n]){channels++;if(points.length<8)points.push([Math.floor(n/4)%80,Math.floor(n/4/80),n%4,a[n],b[n]])}maxDelta=Math.max(maxDelta,Math.abs(a[n]-b[n]))}
   return {channels,maxDelta,points,xml,png:ctx.canvas.toDataURL().split(',')[1]}
  },{svg,native,mode})
  await writeFile(new URL(mode+'.svg',dir),r.xml);delete r.xml;await writeFile(new URL(mode+'.png',dir),Buffer.from(r.png,'base64'));delete r.png
  await page.locator('#rendered').screenshot({path:new URL(mode+'-native.png',dir).pathname,scale:'device'})
  result.cases.push({mode,...r});console.log(mode,r);await writeFile(new URL('results.json',dir),JSON.stringify(result,null,2)+'\n')
 }finally{await context.close()}
}}finally{await browser.close()}
