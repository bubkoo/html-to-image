import { webkit } from 'playwright'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
const out=new URL('./font-preparation/',import.meta.url);await mkdir(out,{recursive:true})
const modes=['plain','svg-face-unused','svg-face-html-text','svg-face-svg-text','svg-face-html-text-software','svg-face-original-metric','svg-face-original-metric-software','face-url-preload']
const browser=await webkit.launch({headless:true})
const receipt={at:new Date().toISOString(),version:browser.version(),libraryUsed:false,modeOrder:modes,scope:'Fresh browser context per original frozen SVG/mode; full RGBA comparison against saved native source PNG',cases:[]}
try{
for(const kind of ['visible-text']){
 const record=JSON.parse(await readFile(new URL(`./original/webkit-native-${kind}.json`,import.meta.url),'utf8'))
 const native=(await readFile(new URL(`./original/webkit-native-${kind}-native.png`,import.meta.url))).toString('base64')
 for(const mode of modes){
  const context=await browser.newContext({viewport:{width:400,height:300},deviceScaleFactor:1});const page=await context.newPage()
  try{
   await page.setContent('<!doctype html><meta charset="utf-8"><body style="margin:0">')
   const r=await page.evaluate(async({svg,native,mode})=>{
    const expectedImage=new Image();expectedImage.src='data:image/png;base64,'+native;await expectedImage.decode()
    const create=(software=false)=>{const c=document.createElement('canvas');c.width=c.height=40;return c.getContext('2d',{willReadFrequently:software})}
    const expected=create();expected.drawImage(expectedImage,0,0);const e=expected.getImageData(0,0,40,40).data
    if(mode.startsWith('svg-face')){
      const doc=new DOMParser().parseFromString(svg,'image/svg+xml')
      const style=Array.from(doc.querySelectorAll('style')).map(x=>x.textContent).filter(x=>x.includes('@font-face')).join('\n')
      const glyph=mode==='svg-face-unused'?'':mode==='svg-face-svg-text'?'<text x="0" y="12" font-family="Native Scroll Metrics" font-size="10">AAAAAA</text>':'<foreignObject width="40" height="40"><div xmlns="http://www.w3.org/1999/xhtml" style="font:10px/20px Native Scroll Metrics">AAAAAA</div></foreignObject>'
      const warm=mode.includes('original-metric')?doc.querySelector('foreignObject').outerHTML.replace(/scroll-snap-type: both mandatory/g,'scroll-snap-type: none') :glyph
      const preload='<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><style>'+style+'</style>'+warm+'</svg>'
      const img=new Image();img.src='data:image/svg+xml,'+encodeURIComponent(preload);await img.decode();create().drawImage(img,0,0)
      await new Promise(r=>setTimeout(r,20))
    }
    if(mode==='face-url-preload'){
      const url=Array.from(svg.matchAll(/url\(["']?(data:[^\s"')]+)["']?\)/g),x=>x[1])[0]
      const data=await (await fetch(url)).arrayBuffer();const f=new FontFace('Native Scroll Metrics',data);await f.load();document.fonts.add(f);await document.fonts.ready
    }
    if(mode==='opacity-group')svg=svg.replace('<foreignObject','<g opacity="0.99999999"><foreignObject').replace('</foreignObject>','</foreignObject></g>')
    if(mode==='blend-group')svg=svg.replace('<foreignObject','<g style="mix-blend-mode:multiply"><foreignObject').replace('</foreignObject>','</foreignObject></g>')
    if(mode==='filter-brightness')svg=svg.replace('<foreignObject','<foreignObject style="filter:brightness(0.9999999)"')
    if(mode==='filter-opacity')svg=svg.replace('<foreignObject','<foreignObject style="filter:opacity(0.9999999)"')
    const image=new Image();image.decoding='sync';image.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);await image.decode()
    if(mode==='attached'){image.style.cssText='position:absolute;left:80px;top:0;width:40px;height:40px';document.body.append(image);await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))}
    let input=image,bitmap
    if(mode.startsWith('bitmap')){bitmap=await createImageBitmap(image);input=bitmap}
    const ctx=create(mode.includes('software'));ctx.drawImage(input,0,0);bitmap?.close()
    const a=ctx.getImageData(0,0,40,40).data;let channels=0,maxDelta=0;for(let n=0;n<a.length;n++){channels+=a[n]!==e[n];maxDelta=Math.max(maxDelta,Math.abs(a[n]-e[n]))}
    return {channels,maxDelta,png:ctx.canvas.toDataURL().split(',')[1],svg}
   },{svg:record.frozenSvg,native,mode})
   await writeFile(new URL(`${kind}-${mode}.png`,out),Buffer.from(r.png,'base64'));delete r.png
   await writeFile(new URL(`${kind}-${mode}.svg`,out),r.svg);delete r.svg
   receipt.cases.push({kind,mode,...r});console.log(kind,mode,r)
  }catch(error){receipt.cases.push({kind,mode,error:String(error)});console.log(kind,mode,String(error))}
  finally{await context.close()}
  await writeFile(new URL('results.json',out),JSON.stringify(receipt,null,2)+'\n')
 }
}
}finally{await browser.close()}
