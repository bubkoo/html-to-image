import {chromium,firefox,webkit} from 'playwright'
import {mkdir,writeFile} from 'node:fs/promises'
const out=new URL('./fractional-minimal/',import.meta.url);await mkdir(out,{recursive:true})
const result={at:new Date().toISOString(),libraryUsed:false,cases:[]}
for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
 const browser=await type.launch({headless:true})
 try{for(const dpr of [1,2]){
  const context=await browser.newContext({viewport:{width:250,height:250},deviceScaleFactor:dpr});const page=await context.newPage()
  try{
   await page.setContent('<!doctype html><meta charset="utf-8"><body style="margin:0"><div id="source" style="width:40px;height:40px;background:green;position:absolute;left:0;top:0"><div style="position:absolute;left:4.5px;top:4.5px;width:4px;height:4px;background:blue"></div></div>')
   const native=await page.locator('#source').screenshot({scale:'device'});await writeFile(new URL(`${engine}-dpr${dpr}-native.png`,out),native)
   const outputs=await page.evaluate(async({native,dpr})=>{
    const load=async src=>{const i=new Image();i.src=src;await i.decode();return i}
    const create=()=>{const c=document.createElement('canvas');c.width=c.height=40*dpr;return c.getContext('2d')}
    const expected=create();expected.drawImage(await load('data:image/png;base64,'+native),0,0);const e=expected.getImageData(0,0,40*dpr,40*dpr).data
    const outputs=[]
    for(const mode of ['plain','identity-transform','fractional-transform','svg-rect','media-resolution']){
     const childStyle=mode==='identity-transform'?'transform:translate(0,0)':mode==='fractional-transform'?'left:4px;top:4px;transform:translate(.5px,.5px)':''
     let body='<foreignObject width="40" height="40"><div xmlns="http://www.w3.org/1999/xhtml" style="width:40px;height:40px;background:green;position:relative"><div style="position:absolute;left:4.5px;top:4.5px;width:4px;height:4px;background:blue;'+childStyle+'"></div></div></foreignObject>'
     if(mode==='svg-rect')body='<rect width="40" height="40" fill="green"/><rect x="4.5" y="4.5" width="4" height="4" fill="blue"/>'
     if(mode==='media-resolution')body='<style>rect{fill:red}@media(min-resolution:2dppx){rect{fill:green}}</style><rect width="40" height="40"/>'
     const svg='<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40">'+body+'</svg>'
     const ctx=create();ctx.drawImage(await load('data:image/svg+xml,'+encodeURIComponent(svg)),0,0,40*dpr,40*dpr);const a=ctx.getImageData(0,0,40*dpr,40*dpr).data;let channels=0,maxDelta=0;for(let n=0;n<a.length;n++){channels+=a[n]!==e[n];maxDelta=Math.max(maxDelta,Math.abs(a[n]-e[n]))}
     outputs.push({mode,channels,maxDelta,center:Array.from(a.slice(0,4)),png:ctx.canvas.toDataURL().split(',')[1],svg})
    }
    return outputs
   },{native:native.toString('base64'),dpr})
   for(const r of outputs){await writeFile(new URL(`${engine}-dpr${dpr}-${r.mode}.png`,out),Buffer.from(r.png,'base64'));delete r.png;await writeFile(new URL(`${engine}-dpr${dpr}-${r.mode}.svg`,out),r.svg);delete r.svg}
   const row={engine,version:browser.version(),dpr,outputs};result.cases.push(row);console.log(JSON.stringify(row));await writeFile(new URL('results.json',out),JSON.stringify(result,null,2)+'\n')
  }finally{await context.close()}
 }}finally{await browser.close()}
}
