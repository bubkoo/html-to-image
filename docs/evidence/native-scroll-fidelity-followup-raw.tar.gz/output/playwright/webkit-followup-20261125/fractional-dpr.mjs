import {webkit} from 'playwright'
import {spawn} from 'node:child_process'
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import net from 'node:net'
const folder=new URL('./fractional-dpr/',import.meta.url);await mkdir(folder,{recursive:true})
const hash=async()=>{const rows={};async function walk(dir){for(const d of await readdir(dir,{withFileTypes:true})){const p=dir+'/'+d.name;if(d.isDirectory())await walk(p);else if(d.isFile())rows[p]=createHash('sha256').update(await readFile(p)).digest('hex')}}for(const d of ['src','es','lib','dist'])await walk(d);rows['test/browser/fixtures/native-scroll.mjs']=createHash('sha256').update(await readFile('test/browser/fixtures/native-scroll.mjs')).digest('hex');return rows}
const before=await hash();await writeFile(new URL('inputs-before.json',folder),JSON.stringify(before,null,2)+'\n')
const port=4487
for(const p of [port,port+1])await new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(p,'127.0.0.1',()=>s.close(resolve))})
const server=spawn(process.execPath,['test/browser/server.mjs'],{env:{...process.env,HTML_TO_IMAGE_SMOKE_PORT:String(port)},stdio:['ignore','pipe','pipe']})
let logs='';server.stdout.on('data',x=>logs+=x);server.stderr.on('data',x=>logs+=x)
let browser
const results={at:new Date().toISOString(),kind:'fractional',cases:[]}
try{
 for(let n=0;n<60;n++){try{if((await fetch(`http://127.0.0.1:${port}/test/browser/umd.html`)).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 browser=await webkit.launch({headless:true});results.version=browser.version()
 for(const dpr of [1,2])for(const ratio of [1,2]){
  const context=await browser.newContext({viewport:{width:414,height:896},deviceScaleFactor:dpr});const page=await context.newPage()
  try{
   await page.goto(`http://127.0.0.1:${port}/test/browser/umd.html`)
   const scene=await page.evaluate(async()=>{
    const fixture=await import('/test/browser/fixtures/native-scroll.mjs');const {root,panel}=await fixture.createNativeScrollScene('fractional');window.__fractional={root,panel};panel.scrollLeft=40.5;panel.scrollTop=40.5;await new Promise(r=>requestAnimationFrame(r));return {id:root.id,outerHTML:root.outerHTML,dpr:devicePixelRatio,offset:[panel.scrollLeft,panel.scrollTop],marker:root.querySelector('[id$="-marker"]').getBoundingClientRect().toJSON(),dot:root.querySelector('[id$="-marker"]').lastElementChild.getBoundingClientRect().toJSON()}
   })
   const prefix=`page${dpr}-export${ratio}`
   const sourceCSS=await page.locator('#'+scene.id).screenshot({scale:'css'}),sourceDevice=await page.locator('#'+scene.id).screenshot({scale:'device'})
   await writeFile(new URL(`${prefix}-source-css.png`,folder),sourceCSS);await writeFile(new URL(`${prefix}-source-device.png`,folder),sourceDevice)
   const capture=await page.evaluate(async ratio=>{
    const api=await import('/es/index.js');const {root,panel}=window.__fractional;const renderer=api.createRenderer({pixelRatio:ratio,skipFonts:true});const capture=await renderer.capture(root)
    try{const image=await capture.toImageData();const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;canvas.getContext('2d').putImageData(image,0,0);const svg=await capture.toSvg();const img=new Image();img.id='svg-copy';img.style.cssText='position:absolute;left:100px;top:0;width:40px;height:40px';img.src=svg;await img.decode();document.body.append(img);return{width:image.width,height:image.height,png:canvas.toDataURL().split(',')[1],svg,sourceAfter:root.outerHTML,offsetAfter:[panel.scrollLeft,panel.scrollTop]}}
    finally{capture.dispose();renderer.dispose()}
   },ratio)
   const svgCSS=await page.locator('#svg-copy').screenshot({scale:'css'}),svgDevice=await page.locator('#svg-copy').screenshot({scale:'device'})
   await writeFile(new URL(`${prefix}-svg-css.png`,folder),svgCSS);await writeFile(new URL(`${prefix}-svg-device.png`,folder),svgDevice)
   await writeFile(new URL(`${prefix}-capture.png`,folder),Buffer.from(capture.png,'base64'));await writeFile(new URL(`${prefix}.svg`,folder),decodeURIComponent(capture.svg.slice(capture.svg.indexOf(',')+1)))
   const compare=await page.evaluate(async({actual,sourceCSS,sourceDevice,svgCSS,svgDevice})=>{
    const load=async s=>{const i=new Image();i.src='data:image/png;base64,'+s;await i.decode();const c=document.createElement('canvas');c.width=i.naturalWidth;c.height=i.naturalHeight;c.getContext('2d').drawImage(i,0,0);return c.getContext('2d').getImageData(0,0,c.width,c.height)}
    const rows={};for(const [name,data]of Object.entries({actual,sourceCSS,sourceDevice,svgCSS,svgDevice}))rows[name]=await load(data)
    const diff=(a,b)=>{if(a.width!==b.width||a.height!==b.height)return{sizeMismatch:[[a.width,a.height],[b.width,b.height]]};let channels=0,maxDelta=0;for(let n=0;n<a.data.length;n++){channels+=a.data[n]!==b.data[n];maxDelta=Math.max(maxDelta,Math.abs(a.data[n]-b.data[n]))}return{channels,maxDelta}}
    return{sourceCSSActual:diff(rows.sourceCSS,rows.actual),sourceDeviceActual:diff(rows.sourceDevice,rows.actual),sourceCSSSVG:diff(rows.sourceCSS,rows.svgCSS),sourceDeviceSVG:diff(rows.sourceDevice,rows.svgDevice)}
   },{actual:capture.png,sourceCSS:sourceCSS.toString('base64'),sourceDevice:sourceDevice.toString('base64'),svgCSS:svgCSS.toString('base64'),svgDevice:svgDevice.toString('base64')})
   const record={dpr,ratio,scene:{...scene,outerHTML:undefined},sourceUnchanged:scene.outerHTML===capture.sourceAfter&&JSON.stringify(scene.offset)===JSON.stringify(capture.offsetAfter),captureSize:[capture.width,capture.height],compare}
   results.cases.push(record);console.log(JSON.stringify(record));await writeFile(new URL('results.json',folder),JSON.stringify(results,null,2)+'\n')
  }finally{await context.close()}
 }
}finally{
 await browser?.close();server.kill('SIGTERM');await new Promise(r=>server.once('exit',r));await writeFile(new URL('server.log',folder),logs)
 const after=await hash();await writeFile(new URL('inputs-after.json',folder),JSON.stringify(after,null,2)+'\n');results.inputsUnchanged=JSON.stringify(before)===JSON.stringify(after);results.inputCount=Object.keys(before).length;results.serverEnded=true;await writeFile(new URL('results.json',folder),JSON.stringify(results,null,2)+'\n')
 if(!results.inputsUnchanged)throw Error('Measured runtime changed')
}
