# WebKit rendering boundary followup, 2026-11-25

The entry point is `assessment.json`. `sha256-index.json` covers every preserved file except the index itself. No production code or existing test was changed by this investigation. All contexts and browsers are closed and ports 4487/4488 are free; see `cleanup.json`.

Use the repository's installed Playwright 1.64.1 browsers. From the checkout root:

```sh
node output/playwright/webkit-followup-20261125/fractional-minimal.mjs
node output/playwright/webkit-followup-20261125/frozen-render-paths.mjs
node output/playwright/webkit-followup-20261125/decode-sequences.mjs
node output/playwright/webkit-followup-20261125/font-preparation.mjs
node output/playwright/webkit-followup-20261125/font-trigger-controls.mjs
node output/playwright/webkit-followup-20261125/font-url-control.mjs
node output/playwright/webkit-followup-20261125/fractional-zoom.mjs
```

These probes run on self-contained copied SVG/PNG or independently authored scenes and do not start an HTTP server. Replaying them overwrites their corresponding result folders; copy the evidence directory first if preserving this exact run.

`fractional-minimal.html` is a self-contained visual reproducer, with no library, font or scroll container. Open it at devicePixelRatio 2 to compare the HTML, SVG image and canvas. Exact assertions belong to the companion script and its native PNGs, rather than a hard-coded approximation to a screenshot.

To replay the real fixture against a built ESM bundle:

```sh
node output/playwright/webkit-followup-20261125/fractional-dpr.mjs
```

This verifies that 4487/4488 are initially free, temporarily runs the repository test server on those two loopback ports, and stops its own server. It hashes `src`, `es`, `lib`, `dist` and the exact fixture before/after; do not build or edit those inputs during measurement. It uses the built files already present and does not build them itself. It does not touch Wi-Fi, proxy, routing or interface configuration.

The first `font-trigger-controls` attempt at an equivalent URL used a backslash-n change that did not establish valid equivalent input. That single case is rejected and must not be cited as the URL-identity proof. `font-url-control` replaces it with a percent-encoded, valid URL variant; both fonts load, and `font-bytes.json` verifies the decoded bytes are identical.

`learning-draft.md` is provided for the main agent's `.learnings` record. It has not been installed or committed by this child agent.
