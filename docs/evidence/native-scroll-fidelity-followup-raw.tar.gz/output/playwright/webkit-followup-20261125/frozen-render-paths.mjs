import { webkit } from 'playwright'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
const out=new URL('./frozen-paths/',import.meta.url);await mkdir(out,{recursive:true})
const modes=['plain','software','bitmap','bitmap-software','preload-font','attached','opacity-group','filter-brightness','filter-opacity','blend-group']
const browser=await webkit.launch({headless:true})
const receipt={at:new Date().toISOString(),version:browser.version(),libraryUsed:false,modeOrder:modes,scope:'Fresh browser context per original frozen SVG/mode; full RGBA comparison against saved native source PNG',cases:[]}
try{
for(const kind of ['visible-text','padding-shadow']){
 const record=JSON.parse(await readFile(new URL(`./original/webkit-native-${kind}.json`,import.meta.url),'utf8'))
 const native=(await readFile(new URL(`./original/webkit-native-${kind}-native.png`,import.meta.url))).toString('base64')
 for(const mode of modes){
  const context=await browser.newContext({viewport:{width:400,height:300},deviceScaleFactor:1});const page=await context.newPage()
  try{
   await page.setContent('<!doctype html><meta charset="utf-8"><body style="margin:0">')
   const r=await page.evaluate(async({svg,native,mode})=>{
    const expectedImage=new Image();expectedImage.src='data:image/png;base64,'+native;await expectedImage.decode()
    const create=(software=false)=>{const c=document.createElement('canvas');c.width=c.height=40;return c.getContext('2d',{willReadFrequently:software})}
    const expected=create();expected.drawImage(expectedImage,0,0);const e=expected.getImageData(0,0,40,40).data
    if(mode==='preload-font'){
      const urls=Array.from(svg.matchAll(/url\(["']?(data:[^\s"')]+)["']?\)/g),x=>x[1])
      for(const u of urls){const f=new FontFace('Native Scroll Metrics',`url("${u}")`);await f.load();document.fonts.add(f)}
      await document.fonts.ready
    }
    if(mode==='opacity-group')svg=svg.replace('<foreignObject','<g opacity="0.99999999"><foreignObject').replace('</foreignObject>','</foreignObject></g>')
    if(mode==='blend-group')svg=svg.replace('<foreignObject','<g style="mix-blend-mode:multiply"><foreignObject').replace('</foreignObject>','</foreignObject></g>')
    if(mode==='filter-brightness')svg=svg.replace('<foreignObject','<foreignObject style="filter:brightness(0.9999999)"')
    if(mode==='filter-opacity')svg=svg.replace('<foreignObject','<foreignObject style="filter:opacity(0.9999999)"')
    const image=new Image();image.decoding='sync';image.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);await image.decode()
    if(mode==='attached'){image.style.cssText='position:absolute;left:80px;top:0;width:40px;height:40px';document.body.append(image);await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))}
    let input=image,bitmap
    if(mode.startsWith('bitmap')){bitmap=await createImageBitmap(image);input=bitmap}
    const ctx=create(mode==='software'||mode==='bitmap-software');ctx.drawImage(input,0,0);bitmap?.close()
    const a=ctx.getImageData(0,0,40,40).data;let channels=0,maxDelta=0;for(let n=0;n<a.length;n++){channels+=a[n]!==e[n];maxDelta=Math.max(maxDelta,Math.abs(a[n]-e[n]))}
    return {channels,maxDelta,png:ctx.canvas.toDataURL().split(',')[1],svg}
   },{svg:record.frozenSvg,native,mode})
   await writeFile(new URL(`${kind}-${mode}.png`,out),Buffer.from(r.png,'base64'));delete r.png
   await writeFile(new URL(`${kind}-${mode}.svg`,out),r.svg);delete r.svg
   receipt.cases.push({kind,mode,...r});console.log(kind,mode,r)
  }catch(error){receipt.cases.push({kind,mode,error:String(error)});console.log(kind,mode,String(error))}
  finally{await context.close()}
  await writeFile(new URL('results.json',out),JSON.stringify(receipt,null,2)+'\n')
 }
}
}finally{await browser.close()}
