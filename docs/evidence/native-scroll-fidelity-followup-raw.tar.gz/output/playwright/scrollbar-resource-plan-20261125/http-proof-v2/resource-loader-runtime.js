const readDocumentProperty=(d,k)=>d[k];async function resolveWithAbort(resolver, request, context) {
    const { signal } = context;
    let abort;
    const cancelled = new Promise((resolve, reject) => {
        abort = () => reject(signal.reason);
        signal.addEventListener('abort', abort, { once: true });
        if (signal.aborted)
            abort();
    });
    const pending = Promise.resolve().then(() => {
        if (signal.aborted)
            throw signal.reason;
        return resolver(request, context);
    });
    try {
        return await Promise.race([pending, cancelled]);
    }
    finally {
        signal.removeEventListener('abort', abort);
    }
}
class ResourceResolverError extends Error {
    constructor(cause) {
        super('Custom resource resolver failed');
        this.cause = cause;
        this.name = 'ResourceResolverError';
        Object.setPrototypeOf(this, ResourceResolverError.prototype);
    }
}
function firstMediaType(type) {
    let quoted = false;
    let escaped = false;
    for (let i = 0; i < type.length; i += 1) {
        const char = type[i];
        if (escaped)
            escaped = false;
        else if (quoted && char === '\\')
            escaped = true;
        else if (char === '"')
            quoted = !quoted;
        else if (char === ',' && !quoted)
            return type.slice(0, i).trim();
    }
    return type;
}
function blobToDataURL(blob) {
    return new Promise((resolve, reject) => {
        // FileReader copies Blob.type into the data URL. A repeated Content-Type
        // header may arrive as "image/png, image/png", which is not a data URL MIME.
        const mediaType = firstMediaType(blob.type);
        const readable = mediaType === blob.type ? blob : blob.slice(0, blob.size, mediaType);
        const reader = new FileReader();
        reader.onerror = () => reject(reader.error);
        reader.onload = () => resolve(reader.result);
        reader.readAsDataURL(readable);
    });
}
class ResourceLoader {
    constructor(options, context, warn = () => { }) {
        this.options = options;
        this.context = context;
        this.warn = warn;
        this.pending = new Map();
        this.responseURLs = new Map();
        this.customResponses = new Set();
    }
    key(url, kind, contentType) {
        // Full URLs identify resources by default. The legacy option remains opt-in.
        const identity = this.options.includeQueryParams === false ? url.replace(/\?.*/, '') : url;
        return JSON.stringify([identity, kind, contentType]);
    }
    responseURL(url, kind, contentType) {
        return this.responseURLs.get(this.key(url, kind, contentType)) || url;
    }
    isCustomResponse(url, kind, contentType) {
        return this.customResponses.has(this.key(url, kind, contentType));
    }
    load(url, kind, contentType) {
        const key = this.key(url, kind, contentType);
        const existing = this.pending.get(key);
        if (existing)
            return existing;
        const request = this.fetch(url, kind, contentType).then((result) => {
            if (this.pending.get(key) === request) {
                this.responseURLs.set(key, result.url);
                if (result.custom)
                    this.customResponses.add(key);
            }
            return result.blob;
        });
        this.pending.set(key, request);
        request.catch(() => {
            if (this.pending.get(key) === request)
                this.pending.delete(key);
        });
        return request;
    }
    async fetch(url, kind, contentType) {
        var _a;
        const { signal } = this.context;
        if (signal.aborted)
            throw signal.reason;
        const request = Object.freeze({ url, kind, contentType });
        const resolvers = [
            (_a = this.options.resources) === null || _a === void 0 ? void 0 : _a.resolve,
            ...(this.options.plugins || []).map((plugin) => plugin.resolveResource),
        ];
        for (let i = 0; i < resolvers.length; i += 1) {
            const resolve = resolvers[i];
            if (resolve) {
                let result;
                try {
                    // eslint-disable-next-line no-await-in-loop
                    result = await resolveWithAbort(resolve, request, this.context);
                }
                catch (error) {
                    if (signal.aborted)
                        throw signal.reason;
                    throw new ResourceResolverError(error);
                }
                if (signal.aborted)
                    throw signal.reason;
                if (result !== undefined) {
                    if (result == null || typeof result.arrayBuffer !== 'function') {
                        throw new ResourceResolverError(new TypeError('Resource resolvers must return a Blob or undefined'));
                    }
                    return { blob: result, url, custom: true };
                }
            }
        }
        const requestURL = new URL(url, readDocumentProperty(document, 'baseURI'));
        requestURL.hash = '';
        const originalURL = requestURL.href;
        const originalNonce = requestURL.searchParams.getAll('_htmlToImage');
        let nonce;
        if (this.options.cacheBust) {
            nonce = String(Date.now());
            requestURL.searchParams.set('_htmlToImage', nonce);
        }
        const response = await fetch(requestURL.href, Object.assign(Object.assign({}, this.options.fetchRequestInit), { signal }));
        if (!response.ok) {
            throw new Error(`Resource request failed (${response.status}): ${url}`);
        }
        const finalURL = new URL(response.url || requestURL.href);
        if (nonce && finalURL.searchParams.get('_htmlToImage') === nonce) {
            finalURL.searchParams.delete('_htmlToImage');
            originalNonce.forEach((value) => finalURL.searchParams.append('_htmlToImage', value));
        }
        return {
            blob: await response.blob(),
            // A transport cache-buster is not part of the SVG document identity.
            url: response.url === requestURL.href ? originalURL : finalURL.href,
            custom: false,
        };
    }
    clear() {
        this.pending.clear();
        this.responseURLs.clear();
        this.customResponses.clear();
    }
}
;window.ProofResourceLoader=ResourceLoader;