import {chromium,webkit} from 'playwright'
import {createServer} from 'node:http'
import ts from 'typescript'
import {mkdir,writeFile,readFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
const out=new URL('./http-proof-v2/',import.meta.url);await mkdir(out,{recursive:true})
const loaderSource=await readFile('src/resource-loader.ts','utf8')
let loaderJS=ts.transpileModule(loaderSource,{compilerOptions:{target:ts.ScriptTarget.ES2017,module:ts.ModuleKind.ESNext}}).outputText.replace(/^import[\s\S]*?from ['"][^'"]+['"];\s*/gm,'').replace(/\bexport /g,'')
loaderJS='const readDocumentProperty=(d,k)=>d[k];'+loaderJS+';window.ProofResourceLoader=ResourceLoader;'
await writeFile(new URL('resource-loader-reviewed.ts',out),loaderSource)
await writeFile(new URL('resource-loader-runtime.js',out),loaderJS)
const requests=[];let originA,originB
const cssFor=path=>path.endsWith('/theme.css')?'@layer first,second;@import url("./sub.css") layer(first) supports(display:grid);#panel::-webkit-scrollbar{width:10px;height:10px;background:red}#panel::-webkit-scrollbar-track{background:red;background-image:url("./stripe.svg")}#panel::-webkit-scrollbar-thumb{background:black;border-radius:0}#panel::-webkit-scrollbar-corner{background:blue}@layer second{#panel::-webkit-scrollbar-thumb:horizontal{background:blue!important}}':path.endsWith('/sub.css')?'#panel::-webkit-scrollbar-thumb:horizontal{background:yellow!important}':''
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="2" height="2"><rect width="2" height="2" fill="red"/></svg>'
const a=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html','Cache-Control':'no-store'});res.end('<!doctype html><body style="margin:0">')})
const b=createServer((req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname
 requests.push({path,origin:req.headers.origin,method:req.method})
 const headers={'Cache-Control':'no-store'}
 if(path.startsWith('/allow/')){headers['Access-Control-Allow-Origin']=originA;headers['Access-Control-Allow-Credentials']='true'}
 if(path.endsWith('/entry.css')){res.writeHead(302,{...headers,Location:path.replace('/entry.css','/assets/theme.css')});res.end();return}
 if(path.endsWith('.css')){res.writeHead(200,{...headers,'Content-Type':'text/css'});res.end(cssFor(path));return}
 if(path.endsWith('/stripe.svg')){res.writeHead(200,{...headers,'Content-Type':'image/svg+xml'});res.end(svg);return}
 res.writeHead(404,headers);res.end()
})
await new Promise(r=>a.listen(0,'127.0.0.1',r));await new Promise(r=>b.listen(0,'127.0.0.1',r))
originA='http://127.0.0.1:'+a.address().port;originB='http://127.0.0.1:'+b.address().port
const report={at:new Date().toISOString(),resourceLoaderSha256:createHash('sha256').update(loaderSource).digest('hex'),scope:'separate immutable source-transpiled ResourceLoader plus standalone inert stylesheet reader; no library/source changes',engines:[]}
try{
 for(const [engine,type] of Object.entries({chromium,webkit})){
  const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})})
  try{
   const page=await browser.newPage({viewport:{width:300,height:240},deviceScaleFactor:1})
   const row={engine,version:browser.version(),cases:[]}
   for(const mode of ['allow','allow-readable','deny','custom']){
    await page.goto(originA);await page.addScriptTag({content:loaderJS})
    const url=originB+'/'+(mode.startsWith('allow')?'allow':'deny')+'/entry.css'
    const nativeInfo=await page.evaluate(async ({url,mode})=>{
     document.body.innerHTML='<div id="panel" style="position:absolute;left:0;top:0;width:100px;height:100px;overflow:scroll;background:green"><div style="width:240px;height:300px;background:green"></div></div>'
     const link=document.createElement('link');link.rel='stylesheet';link.href=url;if(mode==='allow-readable')link.crossOrigin='anonymous';const ready=new Promise((r,j)=>{link.onload=r;link.onerror=j});document.head.append(link);await ready
     let readability;try{readability={rules:link.sheet.cssRules.length,css:Array.from(link.sheet.cssRules,r=>r.cssText)}}catch(e){readability={error:String(e)}}
     return {requested:url,sheetHref:link.sheet.href,readability,source:document.querySelector('#panel').outerHTML}
    },{url,mode})
    const native=await page.locator('#panel').screenshot({scale:'css'});await writeFile(new URL(`${engine}-${mode}-native.png`,out),native)
    const result=await page.evaluate(async({url,mode,native,cssEntries})=>{
     const events=[],warnings=[],controller=new AbortController()
     const resolver=(request)=>{events.push({url:request.url,kind:request.kind,contentType:request.contentType});if(mode==='custom'&&request.kind==='stylesheet')return new Blob([cssEntries[new URL(request.url).pathname]],{type:'text/css'});if(mode==='custom'&&request.kind==='image')return new Blob(['<svg xmlns="http://www.w3.org/2000/svg" width="2" height="2"><rect width="2" height="2" fill="red"/></svg>'],{type:'image/svg+xml'})}
     const loader=new window.ProofResourceLoader({resources:{resolve:resolver}},{signal:controller.signal},x=>warnings.push(x))
     const parserDocument=document.implementation.createHTMLDocument()
     const cache=new Map(),importFacts=[]
     const get=async requested=>{
      if(!cache.has(requested))cache.set(requested,(async()=>{
       const blob=await loader.load(requested,'stylesheet');if(controller.signal.aborted)throw controller.signal.reason
       const base=loader.responseURL(requested,'stylesheet');const style=parserDocument.createElement('style');style.textContent=await blob.text();parserDocument.head.append(style)
       return {base,style,rules:style.sheet.cssRules,custom:loader.isCustomResponse(requested,'stylesheet')}
      })())
      return await cache.get(requested)
     }
     const resolveURLs=(text,base)=>text.replace(/url\(["']?([^"')]+)["']?\)/g,(_,u)=>'url('+JSON.stringify(new URL(u,base).href)+')')
     const expand=async(requested,active=new Set())=>{
      const parsed=await get(requested);if(active.has(parsed.base))return ''
      active.add(parsed.base)
      const visit=async rules=>{
       const parts=[]
       for(let i=0;i<rules.length;i++){
        const r=rules[i]
        if(r.type===CSSRule.IMPORT_RULE){
         const support=r.supportsText;importFacts.push({href:r.href,supportsText:support,supportsDirect:support?CSS.supports(support):true,supportsWrapped:support?CSS.supports('('+support+')'):true,media:r.media.mediaText,layer:r.layerName,parentBase:parsed.base})
         if(support&&!CSS.supports(support)&&!CSS.supports('('+support+')'))continue
         if(r.media.mediaText&&!matchMedia(r.media.mediaText).matches)continue
         let value=await expand(new URL(r.href,parsed.base).href,active)
         if(r.layerName!=null)value='@layer '+r.layerName+'{'+value+'}'
         parts.push(value)
        }else if(r.type===CSSRule.STYLE_RULE){parts.push(resolveURLs(r.cssText,parsed.base))}
        else if('cssRules'in r){const inner=await visit(r.cssRules);parts.push(r.cssText.slice(0,r.cssText.indexOf('{'))+'{'+inner+'}')}
        else parts.push(resolveURLs(r.cssText,parsed.base))
       }
       return parts.join('\n')
      }
      try{return await visit(parsed.rules)}finally{active.delete(parsed.base)}
     }
     let css='',error
     try{const both=await Promise.all([expand(url),expand(url)]);if(both[0]!==both[1])throw Error('Nonidentical concurrent stylesheet snapshots');css=both[0]}
     catch(e){error={name:e.name,message:e.message};warnings.push({code:'resource-error',resource:url,message:e.message})}
     const bases=Array.from(cache,([request,pending])=>({request,pending}))
     const metadata=[];for(let i=0;i<bases.length;i++){try{const p=await bases[i].pending;metadata.push({request:bases[i].request,base:p.base,custom:p.custom})}catch{}}
     const normalizedCSS=css
     const images=Array.from(new Set(Array.from(css.matchAll(/url\("([^"]+)"\)/g),x=>x[1])))
     for(let i=0;i<images.length;i++){
      const u=images[i];const blob=await loader.load(u,'image');const data=await new Promise((r,j)=>{const reader=new FileReader();reader.onload=()=>r(reader.result);reader.onerror=j;reader.readAsDataURL(blob)});css=css.split(u).join(data)
     }
     let comparison
     if(css){
      const clone=document.querySelector('#panel').cloneNode(true);clone.style.position='static';const style=document.createElement('style');style.textContent=css;clone.append(style)
      const svg='<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><foreignObject width="100" height="100">'+new XMLSerializer().serializeToString(clone)+'</foreignObject></svg>'
      const load=async u=>{const i=new Image();i.src=u;await i.decode();return i};const canvas=()=>{const c=document.createElement('canvas');c.width=c.height=100;return c.getContext('2d')}
      const a=canvas(),b=canvas();a.drawImage(await load('data:image/png;base64,'+native),0,0);b.drawImage(await load('data:image/svg+xml,'+encodeURIComponent(svg)),0,0)
      const x=a.getImageData(0,0,100,100).data,y=b.getImageData(0,0,100,100).data;let delta=0;for(let i=0;i<x.length;i++)delta+=x[i]!==y[i]
      comparison={differentChannels:delta,png:b.canvas.toDataURL().split(',')[1],svg}
     }
     cache.clear();parserDocument.head.textContent='';loader.clear()
     return {events,warnings,error,metadata,normalizedCSS,importFacts,images,comparison,sourceAfter:document.querySelector('#panel').outerHTML,parserNodesAfter:parserDocument.head.childElementCount}
    },{url,mode,native:native.toString('base64'),cssEntries:Object.fromEntries(['/deny/entry.css','/deny/assets/theme.css','/deny/sub.css','/deny/assets/sub.css'].map(p=>[p,cssFor(p.endsWith('/entry.css')?p.replace('/entry.css','/assets/theme.css'):p)]))})
    if(result.comparison){await writeFile(new URL(`${engine}-${mode}-capture.png`,out),Buffer.from(result.comparison.png,'base64'));delete result.comparison.png;await writeFile(new URL(`${engine}-${mode}.svg`,out),result.comparison.svg);delete result.comparison.svg}
    result.sourceUnchanged=nativeInfo.source===result.sourceAfter;delete result.sourceAfter
    row.cases.push({mode,nativeInfo,...result});console.log(engine,mode,JSON.stringify({metadata:result.metadata,events:result.events,importFacts:result.importFacts,comparison:result.comparison,error:result.error,sourceUnchanged:result.sourceUnchanged}))
   }
   report.engines.push(row);await writeFile(new URL('results.json',out),JSON.stringify(report,null,2)+'\n')
  }finally{await browser.close()}
 }
}finally{await Promise.all([new Promise(r=>a.close(r)),new Promise(r=>b.close(r))]);await writeFile(new URL('server-requests.json',out),JSON.stringify(requests,null,2)+'\n')}
