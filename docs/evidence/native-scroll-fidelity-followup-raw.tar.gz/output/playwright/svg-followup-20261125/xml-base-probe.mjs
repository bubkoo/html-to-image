import {createServer} from 'node:http'
import {mkdir,writeFile} from 'node:fs/promises'
import {chromium,firefox,webkit} from 'playwright'
const folder=new URL('./xml-base/',import.meta.url);await mkdir(folder,{recursive:true})
const trace=[]
const svg=color=>`<svg xmlns="http://www.w3.org/2000/svg"><defs><pattern id="paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="${color}"/></pattern></defs><symbol id="attr" viewBox="0 0 20 20"><rect width="20" height="20" fill="url(sprite.svg#paint) purple"/></symbol><symbol id="inline" viewBox="0 0 20 20"><rect width="20" height="20" style="fill:url(sprite.svg#paint) purple"/></symbol></svg>`
const server=createServer((req,res)=>{
 const url=new URL(req.url,'http://localhost');trace.push(url.pathname+url.search)
 if(url.pathname.endsWith('/page.html')){res.setHeader('Content-Type','text/html');res.end('<!doctype html><style>html,body{margin:0;background:white}</style>');return}
 if(url.pathname.endsWith('/sprite.svg')){res.setHeader('Content-Type','image/svg+xml');res.setHeader('Cache-Control','no-store');res.end(svg(url.pathname.includes('/assets/')?'green':'red'));return}
 res.writeHead(404).end()
})
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port
const results={at:new Date().toISOString(),scope:'Native HTTP/inline SVG only; no library or production mutation',origin,engines:[]}
try{
 for(const [engine,type] of Object.entries({chromium,firefox,webkit})){
  const browser=await type.launch({headless:true})
  try{
   const page=await browser.newPage({deviceScaleFactor:1,viewport:{width:400,height:200}})
   await page.goto(origin+'/probe/page.html')
   const values=await page.evaluate(async()=>{
    const ns='http://www.w3.org/2000/svg',xml='http://www.w3.org/XML/1998/namespace'
    const root=document.createElement('div');root.id='matrix';root.style.cssText='display:flex;width:160px;height:20px;background:white'
    const rows=[]
    for(const kind of ['native-attr','native-inline','bare-attr','bare-inline','xml-attr','xml-inline','base-attr','base-inline']){
     const svg=document.createElementNS(ns,'svg');svg.setAttribute('width','20');svg.setAttribute('height','20');svg.style.flex='none'
     if(kind.startsWith('native')){svg.innerHTML=`<use href="/probe/assets/sprite.svg#${kind.endsWith('attr')?'attr':'inline'}" width="20" height="20"/>`}
     else{
      const rect=document.createElementNS(ns,'rect');rect.setAttribute('width','20');rect.setAttribute('height','20')
      if(kind.endsWith('attr'))rect.setAttribute('fill','url(sprite.svg#paint) purple');else rect.style.fill='url(sprite.svg#paint) purple'
      if(kind.startsWith('xml'))rect.setAttributeNS(xml,'xml:base',location.origin+'/probe/assets/sprite.svg')
      if(kind.startsWith('base'))svg.setAttributeNS(xml,'xml:base',location.origin+'/probe/assets/sprite.svg')
      svg.append(rect);rows.push({kind,baseURI:rect.baseURI,fill:getComputedStyle(rect).fill})
     }
     root.append(svg)
    }
    document.body.append(root)
    for(let i=0;i<root.children.length;i++){const svg=root.children[i],rect=svg.querySelector('rect');if(rect)rows.find(r=>r.kind===['native-attr','native-inline','bare-attr','bare-inline','xml-attr','xml-inline','base-attr','base-inline'][i]).computedAfter=getComputedStyle(rect).fill}
    return rows
   })
   await page.waitForFunction(()=>Array.from(document.querySelectorAll('use')).every(x=>x.getBBox().width===20))
   await page.waitForLoadState('networkidle')
   const png=await page.locator('#matrix').screenshot({scale:'css'});await writeFile(new URL(engine+'.png',folder),png)
   const pixels=await page.evaluate(async base64=>{const i=new Image();i.src='data:image/png;base64,'+base64;await i.decode();const c=document.createElement('canvas');c.width=160;c.height=20;const ctx=c.getContext('2d');ctx.drawImage(i,0,0);const d=ctx.getImageData(0,0,160,20).data;return Array.from({length:8},(_,x)=>Array.from(d.slice(4*(10*160+x*20+10),4*(10*160+x*20+10)+4)))},png.toString('base64'))
   results.engines.push({engine,version:browser.version(),dpr:await page.evaluate(()=>devicePixelRatio),values,pixels});console.log(engine,JSON.stringify({values,pixels}))
  }finally{await browser.close()}
 }
}finally{await new Promise(r=>server.close(r))}
results.trace=trace;await writeFile(new URL('result.json',folder),JSON.stringify(results,null,2)+'\n')
