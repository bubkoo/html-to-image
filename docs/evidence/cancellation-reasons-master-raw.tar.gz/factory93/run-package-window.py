from pathlib import Path
import subprocess,json,hashlib,time,datetime,os,socket,shutil,sys
root=Path('/Users/bytedance/.codex/worktrees/svg-style-cancellation/html-to-image');assert Path.cwd().resolve()==root
folder=root/'output/playwright/svg-style-cancellation-master-20261125'
if '--root-granted-window' not in sys.argv:raise SystemExit('Prepared only. Do not launch until root explicitly grants this package stage.')
candidate=json.loads((folder/'candidate-commit.json').read_text());expected=json.loads((folder/'candidate-default-test/inputs-after.json').read_text())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def manifest():
    paths={p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0') if p}
    for name in ['es','lib','dist']:paths.update(str(f.relative_to(root)) for f in (root/name).rglob('*') if f.is_file())
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==candidate['head']
before=manifest();assert before==expected
for port in [4197,4198]:
    check=socket.socket();check.settimeout(1);busy=check.connect_ex(('127.0.0.1',port))==0;check.close()
    if busy:raise SystemExit('Port busy; no test launched and no owner stopped: '+str(port))
out=folder/'candidate-browser-package';out.mkdir();(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');started=now();clock=time.monotonic();command=['pnpm','run','test:browser:package'];env={**os.environ,'HTML_TO_IMAGE_SMOKE_PORT':'4197'}
print('START',started,command,flush=True)
with (out/'run.log').open('w') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
ended=now();after=manifest();(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
if (root/'test-results').exists():shutil.copytree(root/'test-results',out/'test-results',dirs_exist_ok=True)
if (root/'playwright-report').exists():shutil.copytree(root/'playwright-report',out/'playwright-report',dirs_exist_ok=True)
receipt={'stage':'candidate-browser-package','command':command,'startUTC':started,'endUTC':ended,'durationSeconds':time.monotonic()-clock,'exitCode':result.returncode,'base':candidate['parent'],'head':candidate['head'],'headAfter':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'branch':'codex/svg-style-cancellation-master','inputCount':len(before),'inputsStable':before==after==expected,'testSHA256':after['test/browser-unit/svg-style-environment.test.ts'],'productionSHA256':after['src/svg-style-scope.ts'],'oldBranchStill':subprocess.check_output(['git','rev-parse','codex/svg-style-cancellation'],cwd=root,text=True).strip(),'rootExplicitlyGrantedThisPhase':True,'continuousProcessMonitoring':False,'environment':{k:env.get(k) for k in ['CI','TEST_SUITE','TEST_BROWSER','HTML_TO_IMAGE_SMOKE_PORT']},'originalAssertionsTimeoutsFlagsRetriesAndSkips':True,'sourceOrDefaultTestsRepeated':False,'noOtherServiceStopped':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('END',json.dumps(receipt),flush=True);assert receipt['inputsStable'] and receipt['headAfter']==candidate['head'];raise SystemExit(result.returncode)
