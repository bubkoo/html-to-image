# Independent master SVG cancellation repair

Base `f8d1c4b1abb7decf143fdf418ad08fa8b22bd309`; candidate `a42344630f2f1df2948da3decd1dfbe6ff0bb392`; tree `fda14e12756eafe59cc841ea3c420cd0a7f51080`; branch `codex/svg-style-cancellation-master`.

The existing clean managed worktree was reused by creating a normal new branch at the exact master base. Old `codex/svg-style-cancellation` remains at `3c0ec0930cd1d4da97a4cb68e46630f35e7b194f`; no reset, force, push, PR creation, merge or old-PR closure was performed. Its red CI and static ownership report remain separate evidence.

Only the cancellation logic inside master's existing `createSVGStyleEnvironment` factory changed. Master's direct DOM access remains direct; no #650 reflection helpers or native feature entered the patch. The regression test is byte-identical to the old source blob `08c7a0ae96339be187c66e31c2df8a91f3c7bc3d`, SHA256 `e1a936433d7f4d80dc85b1b4431b6ea2297fbb782395df574d331c7fadd3a720`. `review.patch` contains precisely the production factory change and that added test.

The default frozen install and a fresh original-master build ran first. That build removed ignored compiled helpers left from the previous branch. With the final test and the original master production file, the actual result was **60 failed / 33 passed** across three engines. Only `src/svg-style-scope.ts` then changed, and the identical test produced **93/93 passed**. Source, tests, configuration and generated bundles were otherwise byte-identical across the transition. The production change was committed after this control without altering measured bytes.

Candidate checks use this master branch's own code and rebuilt outputs:

```sh
pnpm run lint:check
pnpm run build
pnpm run test:package
pnpm run test:browser:types
pnpm test
HTML_TO_IMAGE_SMOKE_PORT=4197 pnpm run test:browser:package
```

All passed. Published-package checking includes real packed ESM/CJS/UMD consumers and TypeScript 4.9/current. The first candidate default passed coverage **1327 with 4 inherited skips**, then source **1208 with 4 inherited skips**. Full browser package passed **162/162**. No default rerun was made. Local Node is 22.17.0 and pnpm is 10.34.9; this is not a claim about remote Node 24 CI.

Every phase retains its actual command UTC start/end, command/environment/exit and source/test/config/bundle before/after manifests. There are 995 inputs after the fresh master build. Existing `capture-lifetime` GC remains unchanged at three commands; the 93 cancellation tests are not themselves GC experiments. No assertion, timeout, retry, skip or browser flag changed. The factory's original 5000ms readiness deadline is retained.

The first controller stopped before package launch because 4197 was occupied. Its exit 1 is a port precondition result, not a product failure. The peer security package command started at `20:53:42.905247Z` and reportedly ran 136.033s, so the earlier candidate default may overlap that command envelope. Do not infer a cause for any other branch's failure or call that earlier period continuously exclusive. After root explicitly granted the final package phase, its actual command ran `20:56:42.584377Z`–`20:58:51.192522Z`. A read-only process point at `20:57:21.089398Z` recorded its process tree and no other observed automation. Individual browser launch/close times were not collected.

At `20:59:10.730717Z`, 4197/4198 both refused connections and no owned driver remained. The unrelated user preview on 4173 was never stopped, opened or captured. Workspace Git status is clean and the old branch is intact. Root owns any future delivery decision; none of #650, #651 or #652's unresolved gates is reclassified by these results.

`before-after-summary.json` maps all 60 logged failures. The framework reuses a case screenshot pathname across engines: 20 PNG paths survive, not 60 engine-distinct images. Preserve that provenance rather than guessing the engine of an overwritten screenshot. Duplicate later copies are excluded from the portable selection.

Use `public-evidence-files.json` and its `copyAlso` metadata when moving evidence. `sha256-index.json` verifies the selected payload and allowlist. Full source copies used locally to prepare the patch, dependencies, Git objects, duplicate images and HTML reports are excluded. Do not recursively archive the whole output directory.
