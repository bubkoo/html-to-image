from pathlib import Path
import subprocess,json,hashlib,time,datetime,os,re,shutil,socket
root=Path('/Users/bytedance/.codex/worktrees/svg-style-cancellation/html-to-image');assert Path.cwd().resolve()==root
folder=root/'output/playwright/svg-style-cancellation-master-20261125';base='f8d1c4b1abb7decf143fdf418ad08fa8b22bd309';old='3c0ec0930cd1d4da97a4cb68e46630f35e7b194f';production='src/svg-style-scope.ts';testfile='test/browser-unit/svg-style-environment.test.ts'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def manifest():
    paths={p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0') if p}
    for name in ['es','lib','dist']:paths.update(str(f.relative_to(root)) for f in (root/name).rglob('*') if f.is_file())
    return {p:sha(root/p) for p in sorted(paths)}
prepare=json.loads((folder/'preparation.json').read_text());assert git('rev-parse','HEAD')==base and git('rev-parse','codex/svg-style-cancellation')==old
assert sha(root/production)==prepare['baselineSHA256'] and sha(root/testfile)==prepare['testSHA256']
tracked_initial={p:v for p,v in manifest().items() if not p.startswith(('es/','lib/','dist/'))};receipts=[]
gc_test=(root/'test/browser-unit/capture-lifetime.test.ts').read_text();assert gc_test.count('await commands.collectGarbage()')==3
save(folder/'master-identity.json',{'base':base,'branch':git('branch','--show-current'),'oldBranch':old,'testBlob':prepare['testGitBlob'],'testSHA256':prepare['testSHA256'],'originalProductionSHA256':prepare['baselineSHA256'],'candidateProductionSHA256':prepare['candidateSHA256'],'node':subprocess.check_output(['node','--version'],cwd=root,text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],cwd=root,text=True).strip(),'gcCommandCountInOriginalTest':3,'gcTestSHA256':sha(root/'test/browser-unit/capture-lifetime.test.ts'),'vitestConfigSHA256':sha(root/'vitest.browser.config.mts'),'playwrightConfigSHA256':sha(root/'playwright.config.ts'),'createdAtUTC':now(),'testNotCommittedAtBeforeStage':True})
def stage(name,command,env_changes=None,generated=False):
    out=folder/name;out.mkdir();before=manifest();save(out/'inputs-before.json',before);started=now();clock=time.monotonic();env={**os.environ,**(env_changes or {})};print('START',name,started,flush=True)
    with (out/'run.log').open('w') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    ended=now();after=manifest();save(out/'inputs-after.json',after);changed=sorted(p for p in before.keys()|after.keys() if before.get(p)!=after.get(p));unexpected=[p for p in changed if not generated or not p.startswith(('es/','lib/','dist/'))]
    if (root/'.vitest/attachments').exists():shutil.copytree(root/'.vitest/attachments',out/'vitest-attachments',dirs_exist_ok=True)
    if name=='candidate-browser-package' and (root/'test-results').exists():shutil.copytree(root/'test-results',out/'test-results',dirs_exist_ok=True)
    record={'stage':name,'command':command,'environment':{k:env.get(k) for k in ['CI','TEST_SUITE','TEST_BROWSER','HTML_TO_IMAGE_SMOKE_PORT']},'startUTC':started,'endUTC':ended,'durationSeconds':time.monotonic()-clock,'exitCode':result.returncode,'base':base,'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'testSHA256':sha(root/testfile),'productionSHA256':sha(root/production),'inputCountBefore':len(before),'inputCountAfter':len(after),'inputsStable':before==after,'onlyExpectedGeneratedChanges':not unexpected,'changedPaths':changed,'originalGCCommandCount':3,'noAssertionTimeoutFlagRetryOrSkipChange':True}
    save(out/'receipt.json',record);receipts.append(record);save(folder/'stage-receipts.json',receipts);print('END',name,json.dumps(record),flush=True)
    assert not unexpected,unexpected
    assert sha(root/testfile)==prepare['testSHA256']
    return result.returncode
try:
    assert stage('master-frozen-install',['pnpm','install','--frozen-lockfile','--ignore-scripts'])==0
    assert stage('master-fresh-build',['pnpm','run','build'],generated=True)==0
    before_cmd=['pnpm','exec','vitest','run','--config','vitest.browser.config.mts',testfile]
    before_code=stage('master-before-93',before_cmd)
    before_text=re.sub(r'\x1b\[[0-9;]*m','',(folder/'master-before-93/run.log').read_text())
    assert before_code!=0 and re.search(r'Tests\s+60 failed\s*\|\s*33 passed',before_text), 'Before must record actual60fail/33pass'
    before=manifest();assert sha(root/production)==prepare['baselineSHA256']
    (root/production).write_bytes((folder/'candidate-svg-style-scope.ts').read_bytes())
    after=manifest();changed=sorted(p for p in before.keys()|after.keys() if before.get(p)!=after.get(p));assert changed==[production],changed
    save(folder/'single-factory-transition.json',{'atUTC':now(),'before':before,'after':after,'changedPaths':changed,'allSourceTestsConfigAndBundlesOtherwiseIdentical':True,'testSHA256':sha(root/testfile),'oldBranchStill':git('rev-parse','codex/svg-style-cancellation')})
    after_code=stage('master-after-93',before_cmd);after_text=re.sub(r'\x1b\[[0-9;]*m','',(folder/'master-after-93/run.log').read_text());assert after_code==0 and re.search(r'Tests\s+93 passed',after_text)
    frozen=manifest();subprocess.run(['git','add','--',production,testfile],cwd=root,check=True);subprocess.run(['git','commit','-C','d2501695c9aceafd7e301486bb1468631b50a5f4'],cwd=root,check=True);assert frozen==manifest(),'Commit hooks changed measured inputs'
    save(folder/'candidate-commit.json',{'atUTC':now(),'head':git('rev-parse','HEAD'),'parent':git('rev-parse','HEAD^'),'tree':git('rev-parse','HEAD^{tree}'),'changedFiles':git('diff','--name-status',base,'HEAD'),'testBlob':git('rev-parse','HEAD:'+testfile),'productionBlob':git('rev-parse','HEAD:'+production),'oldBranchStill':git('rev-parse','codex/svg-style-cancellation'),'commitDidNotChangeMeasuredBytes':True,'pushOrPR':False})
    stage('candidate-lint',['pnpm','run','lint:check'])
    built=stage('candidate-build',['pnpm','run','build'],generated=True)==0
    if built:stage('candidate-package-consumers',['pnpm','run','test:package'])
    stage('candidate-browser-types',['pnpm','run','test:browser:types'])
    default_code=stage('candidate-default-test',['pnpm','test'])
    default_text=(folder/'candidate-default-test/run.log').read_text()
    if default_code and '> vitest run --config vitest.browser.config.mts\n' not in default_text:stage('candidate-source-unreached',['pnpm','run','test:browser:source'])
    if built:
        for port in [4197,4198]:
            s=socket.socket();s.settimeout(1);busy=s.connect_ex(('127.0.0.1',port))==0;s.close()
            if busy:raise RuntimeError('Package4197pair busy; no other owner stopped')
        stage('candidate-browser-package',['pnpm','run','test:browser:package'],{'HTML_TO_IMAGE_SMOKE_PORT':'4197'})
finally:
    save(folder/'final-receipt.json',{'atUTC':now(),'base':base,'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'oldBranchStill':git('rev-parse','codex/svg-style-cancellation'),'old3cFailurePreserved':True,'testByteIdentityKept':sha(root/testfile)==prepare['testSHA256'],'productionSHA256':sha(root/production),'gitStatus':git('status','--porcelain=v1'),'receipts':receipts,'defaultBlindRerun':False,'pushOrPR':False,'otherWorkspacesWritten':False})
