from pathlib import Path
import subprocess,json,hashlib,time,datetime,os,re,shutil,socket,sys
root=Path.cwd();folder=root/'output/playwright/cancellation-reason-public-master-20261125'
base='a42344630f2f1df2948da3decd1dfbe6ff0bb392';testfile='test/browser-unit/cancellation-reasons.test.ts'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def manifest():
 paths={p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0') if p}
 for n in ['es','lib','dist']:paths.update(str(p.relative_to(root)) for p in (root/n).rglob('*') if p.is_file())
 return {p:sha(root/p) for p in sorted(paths)}
assert git('rev-parse','HEAD')==base
factory='test/browser-unit/svg-style-environment.test.ts';factory_sha='e1a936433d7f4d80dc85b1b4431b6ea2297fbb782395df574d331c7fadd3a720'
assert sha(root/factory)==factory_sha
identity=folder/'identity.json'
if not identity.exists():
 save(identity,{'createdUTC':now(),'base':base,'branch':git('branch','--show-current'),'oldBranch':git('rev-parse','codex/svg-style-cancellation'),'newTestSHA256':sha(root/testfile),'factoryTestSHA256':factory_sha,'node':subprocess.check_output(['node','--version'],text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],text=True).strip(),'gcCount':(root/'test/browser-unit/capture-lifetime.test.ts').read_text().count('await commands.collectGarbage()'),'enumeration':subprocess.check_output(['rg','-n',r'\.reason','src'],text=True),'exclusiveGrant':'Root granted after other browser controls terminal 2026-11-24T21:00:23.564Z','newCases':28,'factoryCasesRemainSeparate':31,'defaultTimeoutsAssertionsRetriesFlagsUnchanged':True})
ident=json.loads(identity.read_text());assert sha(root/testfile)==ident['newTestSHA256']
def stage(name,cmd,env_change=None,generated=False):
 out=folder/name;out.mkdir();before=manifest();save(out/'inputs-before.json',before);start=now();clock=time.monotonic();env={**os.environ,**(env_change or {})};print('START',name,start,flush=True)
 with (out/'run.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 after=manifest();save(out/'inputs-after.json',after);changes=[p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)];unexpected=[p for p in changes if not generated or not p.startswith(('es/','lib/','dist/'))]
 if '.vitest' in cmd or 'vitest' in ' '.join(cmd):
  if (root/'.vitest/attachments').exists():shutil.copytree(root/'.vitest/attachments',out/'vitest-attachments',dirs_exist_ok=True)
 if 'test:browser:package' in cmd and (root/'test-results').exists():shutil.copytree(root/'test-results',out/'test-results',dirs_exist_ok=True)
 receipt={'stage':name,'command':cmd,'environment':{k:env.get(k) for k in ['CI','TEST_SUITE','TEST_BROWSER','HTML_TO_IMAGE_SMOKE_PORT']},'startUTC':start,'endUTC':now(),'durationSeconds':time.monotonic()-clock,'exitCode':r.returncode,'head':git('rev-parse','HEAD'),'inputCountBefore':len(before),'inputCountAfter':len(after),'inputsStable':before==after,'changedPaths':changes,'unexpectedChangedPaths':unexpected,'testSHA256':sha(root/testfile),'factorySHA256':sha(root/factory)};save(out/'receipt.json',receipt);print('END',name,json.dumps(receipt),flush=True);assert not unexpected;assert sha(root/testfile)==ident['newTestSHA256'];assert sha(root/factory)==factory_sha;return r.returncode
mode=sys.argv[1]
small=['pnpm','exec','vitest','run','--config','vitest.browser.config.mts',testfile]
if mode=='before':
 assert stage('tests-types',['pnpm','run','test:browser:types'])==0
 code=stage('public-before-84',small);log=re.sub(r'\x1b\[[0-9;]*m','',(folder/'public-before-84/run.log').read_text());assert code!=0;save(folder/'before-result.json',{'exitCode':code,'testsSummary':re.findall(r'Tests[^\n]+',log),'unchangedProductionSHA256':{p:sha(root/p) for p in ['src/task.ts','src/renderer.ts','src/util.ts']}})
elif mode=='after':
 assert stage('public-after-84',small)==0
 # Existing full renderer regression includes independent cancellation, pending
 # disposal, later capture usability, and usable-decode rejection controls.
 assert stage('existing-renderer-controls',['pnpm','exec','vitest','run','--config','vitest.browser.config.mts','test/spec/renderer.test.ts'],{'TEST_SUITE':'coverage'})==0
 assert stage('candidate-lint',['pnpm','run','lint:check'])==0
 assert stage('candidate-build',['pnpm','run','build'],generated=True)==0
 assert stage('candidate-package-consumers',['pnpm','run','test:package'])==0
 assert stage('candidate-browser-types',['pnpm','run','test:browser:types'])==0
 code=stage('candidate-default-test',['pnpm','test'])
 log=(folder/'candidate-default-test/run.log').read_text()
 if code and '> vitest run --config vitest.browser.config.mts\n' not in log:stage('source-unreached',['pnpm','run','test:browser:source'])
 for port in [4197,4198]:
  s=socket.socket();s.settimeout(1);busy=s.connect_ex(('127.0.0.1',port))==0;s.close();assert not busy,port
 stage('candidate-browser-package',['pnpm','run','test:browser:package'],{'HTML_TO_IMAGE_SMOKE_PORT':'4197'})
