import fs from 'node:fs'
import crypto from 'node:crypto'
import ts from 'typescript'
const folder='output/playwright/cancellation-reason-public-master-20261125/'
const before=JSON.parse(fs.readFileSync(folder+'runtime-before-format.json','utf8'))
const hash=x=>crypto.createHash('sha256').update(x).digest('hex')
function syntax(source,path){
 let parentheses=0
 function visit(node){
  if(ts.isParenthesizedExpression(node)){parentheses++;return visit(node.expression)}
  const children=[];ts.forEachChild(node,child=>{children.push(visit(child))})
  const text=ts.isIdentifier(node)?node.escapedText:ts.isLiteralExpression(node)?node.text:undefined
  return text===undefined?[node.kind,children]:[node.kind,text,children]
 }
 const tree=visit(ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true))
 return {sha256:hash(JSON.stringify(tree)),parentheses}
}
const after={}
for(const path of Object.keys(before))after[path]={sha256:hash(fs.readFileSync(path)),normalizedAST:syntax(fs.readFileSync(path,'utf8'),path)}
const byteChanged=Object.keys(before).filter(p=>before[p].sha256!==after[p].sha256)
const normalizedASTChanged=Object.keys(before).filter(p=>before[p].normalizedAST.sha256!==after[p].normalizedAST.sha256)
const umdBytesIdentical=Object.keys(before).filter(p=>p.startsWith('dist/')).every(p=>before[p].sha256===after[p].sha256)
const result={atUTC:new Date().toISOString(),before,after,byteChanged,normalizedASTChanged,umdBytesIdentical,normalization:'Only ParenthesizedExpression wrappers ignored; source positions/trivia not included'}
fs.writeFileSync(folder+'runtime-format-comparison.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({byteChanged,normalizedASTChanged,umdBytesIdentical}))
if(normalizedASTChanged.length||!umdBytesIdentical)process.exit(1)
