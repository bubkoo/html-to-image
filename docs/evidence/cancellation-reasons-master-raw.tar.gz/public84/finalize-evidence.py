from pathlib import Path
import subprocess,json,hashlib,datetime,socket,re
root=Path.cwd();folder=root/'output/playwright/cancellation-reason-public-master-20261125'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,x):(folder/n).write_text(json.dumps(x,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base='f8d1c4b1abb7decf143fdf418ad08fa8b22bd309';pairbase='a42344630f2f1df2948da3decd1dfbe6ff0bb392';old='3c0ec0930cd1d4da97a4cb68e46630f35e7b194f'
paths=['src/svg-style-scope.ts','src/task.ts','src/renderer.ts','src/util.ts','test/browser-unit/svg-style-environment.test.ts','test/browser-unit/cancellation-reasons.test.ts']
assert git('rev-parse','HEAD')==pairbase and git('rev-parse','codex/svg-style-cancellation')==old
assert sha(root/paths[-2])=='e1a936433d7f4d80dc85b1b4431b6ea2297fbb782395df574d331c7fadd3a720'
assert sha(root/paths[-1])=='9e14bea0b883242d0f623932ff2d31cd4c457e4310e67774935a0fd5ebbcff6a'
assert (root/'test/browser-unit/capture-lifetime.test.ts').read_text().count('await commands.collectGarbage()')==3
identity={'atUTC':now(),'masterBase':base,'factoryCommit':pairbase,'HEAD':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'oldBranchPreserved':git('rev-parse','codex/svg-style-cancellation'),'notYetCommittedPublicPatch':True,'expectedScope':paths,'files':{p:{'sha256':sha(root/p),'gitBlob':git('hash-object',p),'bytes':(root/p).stat().st_size} for p in paths},'status':git('status','--porcelain'),'originalGCCommandCount':3,'gcTestSHA256':sha(root/'test/browser-unit/capture-lifetime.test.ts'),'vitestConfigSHA256':sha(root/'vitest.browser.config.mts'),'playwrightConfigSHA256':sha(root/'playwright.config.ts'),'packageSHA256':sha(root/'package.json'),'lockSHA256':sha(root/'pnpm-lock.yaml'),'noPushOrPR':True}
save('final-source-identity.json',identity)
patch=subprocess.check_output(['git','diff','--binary',base],text=True)
r=subprocess.run(['git','diff','--binary','--no-index','--','/dev/null',paths[-1]],stdout=subprocess.PIPE,text=True);assert r.returncode==1
(folder/'review.patch').write_text(patch+r.stdout)
receipts=[json.loads(p.read_text()) for p in sorted(folder.glob('*/receipt.json'))];assert all(not r['unexpectedChangedPaths'] for r in receipts)
save('stage-receipts.json',receipts)
ports={}
for port in [4197,4198]:
 s=socket.socket();s.settimeout(1);ports[str(port)]={'connectEx':s.connect_ex(('127.0.0.1',port))};s.close()
raw=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True)
automation=[line for line in raw.splitlines() if str(root) in line and any(x in line for x in ['/playwright/cli.js test','vitest.mjs','run-checks.py after','run-formatted.py'])]
save('cleanup.json',{'atUTC':now(),'ports':ports,'ownAutomationObserved':automation,'pointObservationOnly':True,'lastBrowserTestEndUTC':json.loads((folder/'formatted-renderer-controls/receipt.json').read_text())['endUTC'],'allHeldExecSessionsTerminal':[10919,82234,20983],'user4173ServiceNeverStoppedOrVisited':True,'noNetworkSettingsChanged':True,'oldBranchUnchanged':True,'sourceFrozen':True,'noMoreBrowsersPlanned':True})
# Exact filenames may be overwritten between engines by the framework; preserve
# what actually persists without assigning engine provenance to those bytes.
shots=sorted((folder/'public-before-84/vitest-attachments/failure-screenshots/cancellation-reasons.test.ts').glob('*.png'))
assert len(shots)==16
save('first-failure-artifacts.json',{'persistedPNGCount':len(shots),'logicalBeforeFailures':48,'frameworkUsesSameCasePathAcrossEngines':True,'engineForEachPersistedPNGNotProven':True,'files':[{'path':str(p.relative_to(folder)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in shots],'fixtureContent':'Synthetic unattached green DIV / 2x2 green data SVG; no user page or screenshot used'})
normalized=json.loads((folder/'runtime-format-comparison.json').read_text());assert normalized['normalizedASTChanged']==[] and normalized['umdBytesIdentical']
assessment={'atUTC':now(),'outcome':'Four remaining falsy cancellation reason fallbacks corrected; public and image paths now preserve exact native signal.reason identity. Factory fix remains independently measured.','separatePairs':[{'productionBaseline':base,'testVersion':'original factory93 blob 08c7a0ae96339be187c66e31c2df8a91f3c7bc3d','before':'60fail/33pass','after':'93pass','evidence':'../svg-style-cancellation-master-20261125/'},{'productionBaseline':pairbase,'testVersionSHA256':identity['files'][paths[-1]]['sha256'],'cases':'28 cases x 3 engines = 84','phases':['public pre-aborted','public real pending onClone barrier','Image pre-aborted','Image real native load + instance decode barrier'],'reasons':['null','false','0','','frozen object','non-stringifiable object','Error'],'before':'48fail/36pass','after':'84pass','unchangedOriginalFactory93':True}],'fullChecksPrefmt':{'lint':0,'build':0,'packedESMCJSUMDConsumersAndTS49Current':0,'types':0,'defaultExitCode':0,'coverage':'1411pass/4skip','source':'1292pass/4skip','completeBrowserPackage':'162pass','packageExitCode':0,'inputs':996,'allRuntimeMeasurementInputsStableWithinEachPhase':True},'finalFormattedChecks':{'sourceAST':'Equivalent after removing only one redundant ParenthesizedExpression wrapper/trivia','runtimeAST':'All es/lib/dist runtime AST fingerprints equal under same normalization','runtimeBytesChanged':normalized['byteChanged'],'umdRuntimeBytesIdentical':True,'mapBytesChanged':['es/renderer.js.map','lib/renderer.js.map','dist/html-to-image.js.map'],'freshBuild':0,'public84':0,'existingChromiumRenderer40':0,'packedConsumers':0,'lint':0,'types':0,'prettier':0,'fullSuiteNotRepeatedAfterFormat':True,'fullGreenBelongsToPrefmtFingerprints':True},'boundaries':['No counted-microtask final-delivery coverage claim; existing real pending disposal/cancellation controls retained.','Instance decode is controlled only for the real Image test and restored in finally; native load occurs before barrier.','No assertions, retries, timeouts, skips, browser flags or exact3GC policy changed.','Old #652 head3c red CI and all original evidence remain preserved.','No native feature / DOM reflection helpers imported from #650 or #651.','No push/PR/merge; final public patch remains uncommitted for root review.','No conclusion about unresolved #651 glyph/shadow/fractional gates.']}
save('assessment.json',assessment)
(folder/'replay.md').write_text('Public cancellation evidence uses master f8d as final base and factory-only a423 as its new regression baseline.\n\nThe original factory93 before/after pair remains in ../svg-style-cancellation-master-20261125/. Do not combine those different test versions/baselines into one pair.\n\nRun-checks.py before was run with frozen new tests and unmodified a423 production; after only three production files changed at the four enumerated branches. Final default and package checks used the pre-format candidate. The only subsequent source formatting removed one redundant throw-parenthesized ternary; normalized AST and all runtime fingerprints are in format-ast-proof.json / runtime-format-comparison.json. Fresh build changed two renderer JS bytestrings and three sourcemaps, while UMD bytes stayed identical. Final targeted84, existing renderer40, consumers/lint/types/format passed.\n\nThe two new tests paths use real event barriers and native data-image load, no timers/network fixtures. Actual defaults and three-GC rule retained. Stage receipts preserve commands, environment, UTC and before/after inputs. Public before contains actual48fail, all first16 persisted screenshots; the framework did not provide per-engine filenames.\n\nSource patch is not committed or pushed. Apply review.patch to exact f8d only after root review; its six-file scope includes the original factory93 regression and fix.\n')
# Portable allowlist: explicit top-level artifacts and each exact receipt/log/
# manifest, plus only newly relevant first-failure screenshots. No dependency,
# Git-object, report tree, stale attachments or full source archive.
top=['run-checks.py','run-formatted.py','format-after-terminal.mjs','compare-formatted-runtime.mjs','finalize-evidence.py','identity.json','before-result.json','production-transition.json','format-source-transition.json','format-ast-proof.json','runtime-before-format.json','runtime-format-comparison.json','process-observation.json','final-source-identity.json','review.patch','stage-receipts.json','cleanup.json','first-failure-artifacts.json','assessment.json','replay.md','task.ts.before','renderer.ts.before','util.ts.before','renderer.measured.ts']
allow=[folder/p for p in top]
for d in sorted(folder.iterdir()):
 if d.is_dir() and (d/'receipt.json').exists():allow.extend(d/p for p in ['receipt.json','run.log','inputs-before.json','inputs-after.json'])
allow+=shots
assert all(p.is_file() for p in allow)
content='\n'.join(p.read_text(errors='ignore') for p in allow if p.suffix not in ['.png'])
scan=re.findall(r'(?:[?&](?:X-Amz-Signature|X-Amz-Credential|access_token|refresh_token|token)=)[^\s"<>]+|(?:github_pat_|ghp_)[A-Za-z0-9_]+',content,re.I)
assert not scan
save('portable-privacy-review.json',{'atUTC':now(),'credentialOrSignedURLMatches':scan,'firstFailurePNGsAreSynthetic':True,'excluded':'Dependencies, Git objects, source archives, duplicated report trees, stale failure attachments from unrelated cases, formatter preview duplicate','scanDoesNotClaimUniversalSecretDetection':True})
allow.append(folder/'portable-privacy-review.json');relative=sorted(str(p.relative_to(folder)) for p in allow)
save('public-evidence-files.json',{'root':str(folder),'payloadFiles':relative,'copyAlso':['public-evidence-files.json','sha256-index.json'],'excludeAllOtherPaths':True})
allow.append(folder/'public-evidence-files.json');index=[{'path':str(p.relative_to(folder)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(allow)]
save('sha256-index.json',{'createdUTC':now(),'files':index,'totalIndexedBytes':sum(x['bytes'] for x in index),'selfNotIncluded':True})
print(json.dumps({'indexedFiles':len(index),'payloadFiles':len(relative),'totalIndexedBytes':sum(x['bytes'] for x in index),'ports':ports,'ownAutomationObserved':automation,'scope':paths,'gitStatus':identity['status']},indent=2))
