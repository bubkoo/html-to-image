Public cancellation evidence uses master f8d as final base and factory-only a423 as its new regression baseline.

The original factory93 before/after pair remains in ../svg-style-cancellation-master-20261125/. Do not combine those different test versions/baselines into one pair.

Run-checks.py before was run with frozen new tests and unmodified a423 production; after only three production files changed at the four enumerated branches. Final default and package checks used the pre-format candidate. The only subsequent source formatting removed one redundant throw-parenthesized ternary; normalized AST and all runtime fingerprints are in format-ast-proof.json / runtime-format-comparison.json. Fresh build changed two renderer JS bytestrings and three sourcemaps, while UMD bytes stayed identical. Final targeted84, existing renderer40, consumers/lint/types/format passed.

The two new tests paths use real event barriers and native data-image load, no timers/network fixtures. Actual defaults and three-GC rule retained. Stage receipts preserve commands, environment, UTC and before/after inputs. Public before contains actual48fail, all first16 persisted screenshots; the framework did not provide per-engine filenames.

Source patch is not committed or pushed. Apply review.patch to exact f8d only after root review; its six-file scope includes the original factory93 regression and fix.
