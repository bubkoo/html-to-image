import fs from 'node:fs'
import crypto from 'node:crypto'
import ts from 'typescript'
import prettier from 'prettier'
const folder='output/playwright/cancellation-reason-public-master-20261125/'
const path='src/renderer.ts'
const before=fs.readFileSync(path,'utf8')
const after=await prettier.format(before,{...(await prettier.resolveConfig(path)),filepath:path})
const hash=x=>crypto.createHash('sha256').update(x).digest('hex')
function syntax(source,stripParentheses,fileName=path){
 let parentheses=0
 function visit(node){
  if(ts.isParenthesizedExpression(node)){parentheses++;if(stripParentheses)return visit(node.expression)}
  const children=[];ts.forEachChild(node,child=>{children.push(visit(child))})
  const text=ts.isIdentifier(node)?node.escapedText:ts.isLiteralExpression(node)?node.text:undefined
  return text===undefined?[node.kind,children]:[node.kind,text,children]
 }
 const tree=visit(ts.createSourceFile(fileName,source,ts.ScriptTarget.Latest,true))
 return {sha256:hash(JSON.stringify(tree)),parentheses}
}
function runtimes(){
 const files={}
 function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const p=dir+'/'+entry.name;if(entry.isDirectory())walk(p);else if(p.endsWith('.js'))files[p]={sha256:hash(fs.readFileSync(p)),normalizedAST:syntax(fs.readFileSync(p,'utf8'),true,p)}}}
 for(const dir of ['es','lib','dist'])walk(dir)
 return files
}
fs.writeFileSync(folder+'renderer.measured.ts',before)
fs.writeFileSync(folder+'runtime-before-format.json',JSON.stringify(runtimes(),null,2)+'\n')
const proof={atUTC:new Date().toISOString(),sourceBeforeSHA256:hash(before),sourceAfterSHA256:hash(after),rawASTBefore:syntax(before,false),rawASTAfter:syntax(after,false),parenthesesNormalizedASTBefore:syntax(before,true),parenthesesNormalizedASTAfter:syntax(after,true),normalization:'Only ParenthesizedExpression wrapper nodes ignored; identifiers/literals/operator child nodes retained; no operand reordering or statement filtering'}
if(proof.parenthesesNormalizedASTBefore.sha256!==proof.parenthesesNormalizedASTAfter.sha256)throw new Error('AST semantics differ')
fs.writeFileSync(folder+'format-ast-proof.json',JSON.stringify(proof,null,2)+'\n')
fs.writeFileSync(path,after)
