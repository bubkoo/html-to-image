import fs from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {chromium,firefox,webkit} from 'playwright'
const dir=new URL('./',import.meta.url),sha=x=>createHash('sha256').update(x).digest('hex'),css='rect{fill:blue!important}',cssURL='data:text/css,'+encodeURIComponent(css),root=inner=>'<svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 8 8">'+inner+'<rect width="8" height="8" fill="red"/></svg>',cases={A:root(''),B:root('<style>'+css+'</style>'),C:'<?xml-stylesheet type="text/css" href="'+cssURL+'"?>'+root('')},plan={createdUTC:new Date().toISOString(),engines:['chromium','firefox','webkit'],cases:{A:'NoCSS red negative',B:'Inline SVG STYLE sameCSS blue!important positive',C:'SameCSS data:text/css XML processing instruction preceding SVG root, no added Element'},guardMS:2500,sourceCSS:css,scope:'Single finite primitive SVGImage capability test only. Image.decode then Canvas exact pixels. No frame, SVG script, HTTP server, retry or production source changes.'};await fs.writeFile(new URL('plan.json',dir),JSON.stringify(plan,null,2));const report={startedUTC:new Date().toISOString(),plan,cases:[],cleanup:{}}
const save=()=>fs.writeFile(new URL('results.json',dir),JSON.stringify(report,null,2))
for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
 const browser=await type.launch({headless:true})
 try{for(const[mode,svg]of Object.entries(cases)){
  const context=await browser.newContext({viewport:{width:64,height:64},deviceScaleFactor:1}),page=await context.newPage(),row={engine,mode,version:browser.version(),svgSHA256:sha(svg),http:[],events:[],console:[],errors:[]};report.cases.push(row);await fs.writeFile(new URL(engine+'-'+mode+'.svg',dir),svg);page.on('request',r=>{row.events.push({kind:'request',method:r.method(),url:r.url()});if(/^https?:/.test(r.url()))row.http.push(r.url())});page.on('console',m=>row.console.push({kind:m.type(),text:m.text()}));page.on('pageerror',e=>row.errors.push(String(e)))
  try{
   row.image=await page.evaluate(async svg=>{
    const image=new Image(),events=[],start=performance.now();let timer;const loaded=()=>events.push({kind:'load',elapsedMS:performance.now()-start}),failed=()=>events.push({kind:'error',elapsedMS:performance.now()-start});image.addEventListener('load',loaded);image.addEventListener('error',failed)
    try{
     image.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)
     const decode=image.decode();void decode.catch(()=>{})
     await Promise.race([decode,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('2500ms SVGImage decode guard expired')),2500)})])
     const canvas=document.createElement('canvas');canvas.width=8;canvas.height=8;const ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);const pixels=ctx.getImageData(0,0,8,8).data,colors={};for(let i=0;i<pixels.length;i+=4){const key=Array.from(pixels.slice(i,i+4)).join(',');colors[key]=(colors[key]||0)+1}return{decoded:true,width:image.naturalWidth,height:image.naturalHeight,colors,firstPixel:Array.from(pixels.slice(0,4)),png:canvas.toDataURL(),imageEvents:events,elapsedMS:performance.now()-start,framesAfter:document.querySelectorAll('iframe').length}
    }catch(e){return{decoded:false,error:String(e),imageEvents:events,elapsedMS:performance.now()-start,width:image.naturalWidth,height:image.naturalHeight}}
    finally{clearTimeout(timer);image.removeEventListener('load',loaded);image.removeEventListener('error',failed);image.src=''}
   },svg)
   if(row.image.png){await fs.writeFile(new URL(engine+'-'+mode+'.png',dir),Buffer.from(row.image.png.split(',')[1],'base64'));delete row.image.png}
   console.log(JSON.stringify({engine,mode,...row.image,http:row.http.length}))
  }catch(e){row.error=String(e);row.stack=e.stack;console.log(JSON.stringify({engine,mode,error:row.error}))}
  finally{await context.close();row.closedUTC=new Date().toISOString();await save()}
 }}finally{await browser.close();report.cleanup[engine]={browserClosed:true,at:new Date().toISOString()};await save()}
}
report.completedUTC=new Date().toISOString();report.allBrowsersClosed=Object.values(report.cleanup).every(x=>x.browserClosed);await save()
