from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
j=json.loads((p/'results.json').read_text())
assert len(j['cases'])==15
positive=[r for r in j['cases'] if not r['mode'].startswith('negative')]
negative=[r for r in j['cases'] if r['mode'].startswith('negative')]
assert len(positive)==9 and all(r['marker']['status']=='known' and r['markerMatchesOracle'] for r in positive)
assert len(negative)==6 and all(r['marker']['status']=='unknown' and r['marker']['coordinate'] is None for r in negative)
assert all(r['wrapperPreservesLayout'] and r['rootSubtreeUnchanged'] and not r['http'] for r in j['cases'])
assert all(x['closed'] for x in j['cleanup'].values())
old=Path('/Users/bytedance/.codex/worktrees/gc-native-release-controls/html-to-image/output/playwright/root-margin-native-20261125')
prior=json.loads((old/'results.json').read_text())
assert hashlib.sha256((old/'input/html-to-image.js').read_bytes()).hexdigest()==j['umdSHA256']
assert hashlib.sha256((old/'results.json').read_bytes()).hexdigest()==j['priorResultsSHA256']
identity={'usedUMDSHA256':j['umdSHA256'],'oldFrozenSourceInputs':prior['sourceInputs'],'prior39CasesReportPath':str(old/'results.json'),'priorReportSHA256':j['priorResultsSHA256'],'oldInputsUntouched':True,'sourceUsage':'Nine original SVG bytes copied;6negative SVGs captured using same original UMD with real onClone; no current parked candidate bundle used.'}
(p/'baseline-source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
before=json.loads(Path('output/playwright/svgimage-pi-csp-20261125/source-test-inputs-after.json').read_text())
after={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in before}
assert before==after
(p/'parked-input-guard.json').write_text(json.dumps({'referenceSeal':'PriorPI CSP phase after seal, reused unchanged','before':before,'after':after,'all272Unchanged':before==after},indent=2)+'\n')
a={'scope':'Bounded PI outline-difference coordinate prototype only. Fixed3original cases+2negative inputs×3engines. No production integration, full39rerun, root-margin correction or claim of general trusted XML activation safety.','startedUTC':j['startedUTC'],'completedUTC':j['completedUTC'],'umdSHA256':j['umdSHA256'],'positive':{'cases':9,'allExact':True,'zero-margin':{'x':0,'y':0,'width':160,'height':80},'margin-top-left16':{'x':16,'y':16,'width':160,'height':80},'collapsed-child-zero-root-margin':{'x':0,'y':24,'width':160,'height':80}},'negative':{'cases':6,'allUnknown':True,'fallbackCoordinate':None,'onCloneFinalInlineOutlineImportant':'Inline4px lime!important/offset−4px wins; black/white PI produces no differential marker.','clipOpacityCombined':'Actual onClone clip-path:inset(8px) +opacity0 makes marker unobservable. Combined negative, not an isolated attribution to clip versus opacity.'},'measurementMutation':{'PI':'BeforeSVGroot, first important @layer structural :root > foreignObject > :first-child, black/white1px outline with−1px offset','addedElements':0,'rootSubtreeAttributesURIsChanged':False,'wrapperOnlyChange':'OuterSVG160x80/viewBox160x80->224x144/viewBox224x144;FO100%x100%->absolute160x80;FO overflow visible. No translation/marker nodes/root attribute writes.','why':'Preserve original containing block size while making positive margin/collapsed extent visible for full four-side perimeter. Inset outline includes zero-margin edges inside raster.','coordinateAcceptance':'Full opaque exact black-vs-white one-pixel rectangular perimeter and unchanged trusted XML wrapper layout; absence/partial/nonopaque/changedlayout =>unknown/null.'},'oracle':{'kind':'Trusted fixed input top-level real XML data-document, Playwright parent evaluate only, no injected SVG script/iframe. Not production.','originalVersusExpanded':'All15 root−FO coordinates, childrelativepositions and serialized root subtrees exactly equal.','noOracleInferenceFromPixels':True,'originalOrExpandedSVGscripts':0,'unknownDoesNotMeanZero':True},'invariants':{'all15OriginalRootDOMUnchangedAfterPIConstruction':True,'all15NoHTTP':True,'old39ReportAndUMDIdentitiesUnchanged':True,'parked272InputSealMatches':True,'allBrowsersContextsClosed':True,'HTTPserverCreated':False,'phoneOrNetworkSettingsChanged':False,'guardMS':2500,'retries':0},'limits':['Known statuses are conditioned on this explicit trusted XML layout check. That oracle is not an allowed arbitrary-payload production fallback.','Changing outer viewport can affect responsive rules/general layouts; only these15controlled inputs were verified.','Other root inline!important outline, clipping, opacity, filtering, fractional/transformed/rounded outline, adverse CSS selectors and dynamic payloads not generalized.','No exported normalizedSVG/image repair has been implemented or tested; only coordinate readability and negative detection.']}
(p/'assessment.json').write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n')
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='sha256-index.json':files.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(p/'sha256-index.json').write_text(json.dumps({'files':files,'selfExcluded':True},indent=2)+'\n')
print(json.dumps({'files':len(files),'bytes':sum(x['bytes'] for x in files),'start':j['startedUTC'],'end':j['completedUTC'],'knownExact':9,'negativeUnknown':6,'closed':j['cleanup']}))
