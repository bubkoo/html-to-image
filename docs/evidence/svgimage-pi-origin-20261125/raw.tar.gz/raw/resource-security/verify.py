"""Offline stdlib PNG/source/server-witness verifier; no browser or network."""
from pathlib import Path
import hashlib,json,struct,zlib,xml.etree.ElementTree as ET
from html.parser import HTMLParser
from urllib.parse import unquote
def sha(data):
    return hashlib.sha256(data).hexdigest()


def png(data):
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    pos, compressed, chunks, header = 8, bytearray(), [], None
    while pos < len(data):
        size = struct.unpack('>I', data[pos:pos + 4])[0]
        kind = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + size]
        crc = struct.unpack('>I', data[pos + 8 + size:pos + 12 + size])[0]
        assert zlib.crc32(kind + body) & 0xffffffff == crc
        chunks.append(kind.decode('ascii'))
        if kind == b'IHDR':
            header = struct.unpack('>IIBBBBB', body)
        if kind == b'IDAT':
            compressed.extend(body)
        pos += size + 12
        if kind == b'IEND':
            break
    assert pos == len(data) and header is not None
    width, height, depth, color, compression, filtering, interlace = header
    assert (depth, compression, filtering, interlace) == (8, 0, 0, 0)
    assert color in (2, 6), ('unsupported PNG color type', color)
    channels = 3 if color == 2 else 4
    stride = width * channels
    decoded = zlib.decompress(bytes(compressed))
    assert len(decoded) == height * (stride + 1)
    previous = bytearray(stride)
    rgba = bytearray()
    for y in range(height):
        at = y * (stride + 1)
        method = decoded[at]
        assert 0 <= method <= 4
        row = bytearray(decoded[at + 1:at + 1 + stride])
        for x in range(stride):
            left = row[x - channels] if x >= channels else 0
            up = previous[x]
            upper_left = previous[x - channels] if x >= channels else 0
            prediction = 0
            if method == 1:
                prediction = left
            elif method == 2:
                prediction = up
            elif method == 3:
                prediction = (left + up) // 2
            elif method == 4:
                p = left + up - upper_left
                distances = (abs(p - left), abs(p - up), abs(p - upper_left))
                prediction = (left if distances[0] <= distances[1] and distances[0] <= distances[2]
                              else up if distances[1] <= distances[2] else upper_left)
            row[x] = (row[x] + prediction) & 255
        if channels == 4:
            rgba.extend(row)
        else:
            for x in range(0, stride, 3):
                rgba.extend(row[x:x + 3])
                rgba.append(255)
        previous = row
    return width, height, bytes(rgba), chunks


class HTMLChecks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.starts=[]
        self.ends=[]
    def handle_starttag(self, tag, attrs):
        self.starts.append((tag,dict(attrs)))
    def handle_endtag(self, tag):
        self.ends.append(tag)


def derive(folder):
    report=json.loads((folder/'results.json').read_text())
    plan=json.loads((folder/'plan.json').read_text())
    assert len(report['pairs'])==6 and sum(len(r['modeResults'])for r in report['pairs'])==12
    assert report['cleanup']['serverClosed']
    assert all(report['cleanup'][e]['browserClosed']for e in ['chromium','firefox','webkit'])
    ns={'svg':'http://www.w3.org/2000/svg','html':'http://www.w3.org/1999/xhtml'}
    css=plan['PIcss'];prefix='<?xml-stylesheet type="text/css" href="data:text/css,'
    pairs=[]
    for row in report['pairs']:
        identity=row['id'];assert 'error'not in row and row['contextClosed']
        assert row['headerMatches'] and row['callerBefore']==row['callerAfter']
        assert row['callerAfter']['frames']==0 and row['callerUnchanged']
        original=(folder/(identity+'-original.svg')).read_bytes()
        candidate=(folder/(identity+'-PI.svg')).read_bytes()
        blob=(folder/(identity+'-blob.html')).read_bytes()
        assert sha(original)==row['originalSHA256'] and sha(candidate)==row['candidateSHA256']
        assert candidate.endswith(original) and candidate[:-len(original)].decode().startswith(prefix)
        pi=candidate[:-len(original)].decode();assert pi.endswith('"?>')
        assert unquote(pi[len(prefix):-3])==css and sha(css.encode())==row['PIcssSHA256']
        assert row['PIOnlyChange'] and sha(blob)==row['blobHTMLSHA256']
        assert row['blob']['before']['ok']and row['blob']['before']['body'].encode()==blob
        assert row['blob']['beforeBytesMatch']and row['blob']['afterFetchRejected']
        assert row['blob']['after']['revokeCalled']and not row['blob']['after']['fetchResolved']
        assert row['blob']['created']==row['blob']['revoked']==1
        root=ET.fromstring(original)
        assert root.tag=='{'+ns['svg']+'}svg'and root.attrib['onload']
        root_style=root.find('svg:style',ns).text
        assert '@import' in root_style and '@font-face' in root_style and '/trap/font.ttf'in root_style
        assert len(root.findall('svg:image',ns))==2
        assert len(root.findall('svg:script',ns))==2
        assert len(root.findall('.//html:script',ns))==2
        assert len(root.findall('.//html:iframe',ns))==2 and len(root.findall('.//html:object',ns))==2
        assert sum(e.attrib.get('src')==row['blob']['url']for e in root.findall('.//html:iframe',ns))==1
        assert sum(e.attrib.get('data')==row['blob']['url']for e in root.findall('.//html:object',ns))==1
        h=HTMLChecks();h.feed(blob.decode());assert sum(t=='script'for t,a in h.starts)==h.ends.count('script')==2
        assert row['serverWitness']=={'status':200,'body':'owned-server-witness'}
        witnesses=[j for j in report['serverJournal']if j['path'].startswith('/case/'+identity+'/witness/')]
        assert any(j['path'].endswith('/server')for j in witnesses)
        image_receipts=[j for j in witnesses if j['path'].endswith('/host-image.png')]
        if row['policy']=='unrestricted':
            assert row['hostImageWitness']['decoded']and len(image_receipts)==1
            assert 'content-security-policy'not in row['actualHeaders']
        else:
            assert row['policy']=='strictHTTPheader'and not row['hostImageWitness']['decoded']and image_receipts==[]
            assert row['actualHeaders']['content-security-policy']==report['policies']['strictHTTPheader']
            assert any(v['directive']=='img-src'and v['blockedURI'].endswith('/witness/host-image.png')for v in row['violations'])
        traps=[j for j in report['serverJournal']if j['path'].startswith('/case/'+identity+'/trap/')]
        assert traps==row['sourceTrapReceipts']==[]
        images=[];pixels=[]
        for mode in row['modeResults']:
            image=mode['image'];assert image['decoded']and image['loaded']and image['positiveReady']
            assert image['positiveGreen']==image['positiveDataBlue']==64
            assert image['width']==image['height']==64 and image['elapsedMS']<2500
            assert any(x['event']=='load'for x in image['events'])
            assert mode['imageCleanup']=={'srcAbsent':True,'settled':True,'timerCleared':True,'listenersRemoved':True}
            width,height,rgba,chunks=png((folder/(identity+'-'+mode['mode']+'.png')).read_bytes())
            assert width==height==64
            def count_rect(x0,y0,width,height,color):
                return sum(rgba[(y*64+x)*4:(y*64+x)*4+4]==bytes(color)for y in range(y0,y0+height)for x in range(x0,x0+width))
            assert count_rect(0,0,8,8,[0,128,0,255])==count_rect(8,0,8,8,[0,0,255,255])==64
            white=sum(rgba[(y*64+x)*4:(y*64+x)*4+4]==b'\xff\xff\xff\xff'for y in range(16,48)for x in range(16,48)if x in [16,47]or y in [16,47])
            expected=0 if mode['mode']=='nativeSVGImage' else 124
            assert white==expected==image['whiteOutlinePixels']
            if expected:assert image['PIStylePositive']
            pixels.append(rgba);images.append({'mode':mode['mode'],'greenPixels':64,'dataBluePixels':64,'whiteOutlinePixels':white,'decodedAndLoaded':True,'PNGChunks':chunks})
        changed=sum(pixels[0][i:i+4]!=pixels[1][i:i+4]for i in range(0,len(pixels[0]),4))
        assert changed==124
        pairs.append({'engine':row['engine'],'version':row['version'],'policy':row['policy'],
                      'originalSHA256':sha(original),'candidateSHA256':sha(candidate),'BlobHTMLSHA256':sha(blob),
                      'PIOnlyByteAddition':True,'sourceTrapRequests':0,'serverWitnessRequests':1,
                      'hostHTTPImageRequests':len(image_receipts),'hostPolicyWitnessMatches':True,
                      'revokeAfterFetchRejected':True,'callerFramesAfter':0,'callerBodyFontsFramesUnchanged':True,
                      'contextClosed':True,'images':images,'PIOnlyChangedPixels':changed})
    assert len(report['serverJournal'])==15
    assert sum('/witness/server'in j['path']for j in report['serverJournal'])==6
    assert sum('/witness/host-image.png'in j['path']for j in report['serverJournal'])==3
    assert not any('/trap/'in j['path']for j in report['serverJournal'])
    return {'pairs':pairs,'fixedImageCases':12,'PIStylePositives':6,'sourceTrapRequests':0,
            'serverWitnessRequests':6,'allowedHostImageRequests':3,'strictHostImageRequests':0,
            'serverJournalTotal':15,'cleanup':report['cleanup']}


def main():
    folder=Path(__file__).resolve().parent
    index=json.loads((folder/'sha256-index.json').read_text())
    actual={str(f.relative_to(folder))for f in folder.rglob('*')if f.is_file()and f.name!='sha256-index.json'}
    assert actual=={r['path']for r in index['files']}
    for row in index['files']:
        content=(folder/row['path']).read_bytes()
        assert len(content)==row['bytes']and sha(content)==row['sha256']
    assert derive(folder)==json.loads((folder/'assessment.json').read_text())['independentChecks']
    print('Verified12 SVGImages with byte-identical attack payloads,6 PI124px positives,PNG/data positives,server traps0/witness9,header witnesses,revoke/fetch,cleanup and all memberSHA.')


if __name__=='__main__':
    main()
