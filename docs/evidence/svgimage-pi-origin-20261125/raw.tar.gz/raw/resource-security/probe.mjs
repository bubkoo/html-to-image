import {createServer} from 'node:http'
import {readFile,writeFile} from 'node:fs/promises'
import {createHash,randomUUID} from 'node:crypto'
import {deflateSync} from 'node:zlib'
import {chromium,firefox,webkit} from 'playwright'
const own=name=>new URL(name,import.meta.url),sha=b=>createHash('sha256').update(b).digest('hex')
const plan=JSON.parse(await readFile(own('plan.json'),'utf8')),font=await readFile(own('input-font-metrics.ttf'))
function crc32(b){let c=0xffffffff;for(const x of b){c^=x;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0)}return(c^0xffffffff)>>>0}
function chunk(kind,data){const k=Buffer.from(kind),n=Buffer.alloc(4),crc=Buffer.alloc(4);n.writeUInt32BE(data.length);crc.writeUInt32BE(crc32(Buffer.concat([k,data])));return Buffer.concat([n,k,data,crc])}
function png(r,g,b){const h=Buffer.alloc(13);h.writeUInt32BE(1,0);h.writeUInt32BE(1,4);h[8]=8;h[9]=6;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',h),chunk('IDAT',deflateSync(Buffer.from([0,r,g,b,255]))),chunk('IEND',Buffer.alloc(0))])}
const blue=png(0,0,255),green=png(0,128,0),dataBlue='data:image/png;base64,'+blue.toString('base64')
const strict="default-src 'none'; script-src 'none'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; frame-src 'none'; object-src 'none'; connect-src blob:; base-uri 'none'; form-action 'none'"
const css=plan.PIcss,PI='<?xml-stylesheet type="text/css" href="data:text/css,'+encodeURIComponent(css)+'"?>'
let origin,phase={pair:'setup',step:'setup'}
const journal=[]
const policies=new Map()
const server=createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost'),r={receivedUTC:new Date().toISOString(),path:u.pathname+u.search,method:req.method,phase:{...phase}};journal.push(r)
 res.setHeader('Cache-Control','no-store')
 if(u.pathname.startsWith('/host/')){const id=u.pathname.split('/')[2],policy=policies.get(id);res.setHeader('Content-Type','text/html');if(policy==='strictHTTPheader')res.setHeader('Content-Security-Policy',strict);res.end('<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><body><div id="caller-fixture">Controlled SVGImage host</div></body>');return}
 if(u.pathname.includes('/witness/')){if(u.pathname.endsWith('.png')){res.setHeader('Content-Type','image/png');res.end(green)}else{res.setHeader('Content-Type','text/plain');res.end('owned-server-witness')}return}
 if(u.pathname.includes('/trap/')){
  if(u.pathname.endsWith('.css')){res.setHeader('Content-Type','text/css');res.end(`.fontAttack{background-image:url(${origin}${u.pathname.replace(/\.css$/,'.nested.png')})}`);return}
  if(u.pathname.endsWith('.ttf')){res.setHeader('Content-Type','font/ttf');res.end(font);return}
  if(u.pathname.endsWith('.png')){res.setHeader('Content-Type','image/png');res.end(blue);return}
  if(u.pathname.endsWith('.js')){res.setHeader('Content-Type','text/javascript');res.end(`fetch(${JSON.stringify(origin+u.pathname+'.executed')}).catch(()=>{})`);return}
  if(u.pathname.endsWith('.html')){res.setHeader('Content-Type','text/html');res.end(`<!doctype html><img src="${origin+u.pathname+'.child.png'}"><script>fetch(${JSON.stringify(origin+u.pathname+'.executed')}).catch(()=>{})<\/script>`);return}
  res.writeHead(204).end();return
 }
 res.writeHead(404).end()
})
const report={startedUTC:new Date().toISOString(),plan,policies:{unrestricted:null,strictHTTPheader:strict},serverJournal:journal,pairs:[],cleanup:{}}
const save=()=>writeFile(own('results.json'),JSON.stringify(report,null,2)+'\n')
function payload(base,blobURL){
 const t=x=>base+'/trap/'+x
 const js=`new Image().src=${JSON.stringify(t('inline-executed.png'))};fetch(${JSON.stringify(t('inline-fetch'))}).catch(()=>{})`
 const onload=`new Image().src='${t('onload-executed.png')}'`
 const rootstyle=`@import url("${t('import.css')}");@font-face{font-family:TrapFont;src:url("${t('font.ttf')}") format("truetype")}.fontAttack{font-family:TrapFont;font-size:8px;line-height:8px;background-image:url("${t('background.png')}")}`
 const html=`<div xmlns="http://www.w3.org/1999/xhtml" id="attack-root" style="width:32px;height:32px;position:relative;background:rgb(0,128,0)"><div style="position:absolute;left:4px;top:4px;width:24px;height:24px"><span class="fontAttack">A</span><img width="2" height="2" src="${t('html-image.png')}"/><iframe width="2" height="2" style="border:0" src="${t('frame.html')}"></iframe><object width="2" height="2" data="${t('object.html')}" type="text/html"></object><script src="${t('html-script.js')}"></script><script><![CDATA[${js}]]></script><iframe width="2" height="2" style="border:0" src="${blobURL}"></iframe><object width="2" height="2" data="${blobURL}" type="text/html"></object></div></div>`
 return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="64" height="64" viewBox="0 0 64 64" onload="${onload}"><style>${rootstyle}</style><rect width="8" height="8" fill="rgb(0,128,0)"/><image x="8" width="8" height="8" href="${dataBlue}"/><image x="52" y="0" width="8" height="8" href="${t('svg-image.png')}"/><script href="${t('svg-script.js')}"></script><script><![CDATA[${js}]]></script><foreignObject x="16" y="16" width="32" height="32">${html}</foreignObject></svg>`
}
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)})
 origin='http://127.0.0.1:'+server.address().port;report.origin=origin
 await writeFile(own('input-blue.png'),blue);await writeFile(own('input-green.png'),green)
 for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
  const browser=await type.launch({headless:true});report.cleanup[engine]={version:browser.version(),browserClosed:false}
  try{for(const policy of ['unrestricted','strictHTTPheader']){
   const id=engine+'-'+policy+'-'+randomUUID(),base=origin+'/case/'+id;policies.set(id,policy)
   const row={id,engine,policy,version:browser.version(),base,modeResults:[],console:[],pageErrors:[],requests:[],violations:[]};report.pairs.push(row)
   const context=await browser.newContext({viewport:{width:160,height:160},deviceScaleFactor:1}),page=await context.newPage();let blobURL
   page.on('console',m=>row.console.push({phase:{...phase},type:m.type(),text:m.text()}));page.on('pageerror',e=>row.pageErrors.push(String(e)));page.on('request',r=>{const u=r.url();row.requests.push({phase:{...phase},method:r.method(),url:/^https?:|^blob:/.test(u)?u:undefined,urlSHA256:sha(u),scheme:u.split(':')[0]})})
   await page.exposeFunction('recordViolation',v=>row.violations.push({phase:{...phase},...v}))
   try{
    phase={pair:id,step:'caller-navigation'}
    const response=await page.goto(origin+'/host/'+id,{waitUntil:'load'});row.actualHeaders=await response.allHeaders();row.headerMatches=policy==='unrestricted'?!row.actualHeaders['content-security-policy']:row.actualHeaders['content-security-policy']===strict
    await page.evaluate(()=>document.addEventListener('securitypolicyviolation',e=>window.recordViolation({directive:e.effectiveDirective,blockedURI:e.blockedURI,originalPolicy:e.originalPolicy})))
    row.callerBefore=await page.evaluate(()=>({body:document.body.outerHTML,frames:document.querySelectorAll('iframe,object').length,fonts:document.fonts.size}))
    phase={pair:id,step:'server-witness'};const responseWitness=await context.request.get(base+'/witness/server');row.serverWitness={status:responseWitness.status(),body:await responseWitness.text()}
    phase={pair:id,step:'host-image-witness'}
    row.hostImageWitness=await page.evaluate(async src=>{const i=new Image();let timer;try{i.src=src;const decode=i.decode();void decode.catch(()=>{});await Promise.race([decode,new Promise((_,j)=>{timer=setTimeout(()=>j(Error('2500ms host witness guard')),2500)})]);return{decoded:true,width:i.naturalWidth,height:i.naturalHeight}}catch(e){return{decoded:false,error:String(e)}}finally{clearTimeout(timer);i.removeAttribute('src')}},base+'/witness/host-image.png')
    const blobHTML=`<!doctype html><style>@import url("${base}/trap/blob-import.css");</style><img src="${base}/trap/blob-image.png"><iframe src="${base}/trap/blob-frame.html"></iframe><script src="${base}/trap/blob-script.js"></script><script>fetch(${JSON.stringify(base+'/trap/blob-inline-executed')}).catch(()=>{})<\/script>`
    await writeFile(own(id+'-blob.html'),blobHTML)
    phase={pair:id,step:'blob-create-fetch-before'}
    row.blob=await page.evaluate(async html=>{const u=URL.createObjectURL(new Blob([html],{type:'text/html'}));window.__ownBlobURL=u;window.__blobRevoked=false;try{const r=await fetch(u),body=await r.text();return{url:u,before:{ok:r.ok,status:r.status,body},created:1}}catch(e){return{url:u,before:{error:String(e)},created:1}}},blobHTML);blobURL=row.blob.url
    row.blobHTMLSHA256=sha(blobHTML);row.blob.beforeBytesMatch=row.blob.before.body===blobHTML
    const original=payload(base,blobURL),candidate=PI+original;row.originalSHA256=sha(original);row.candidateSHA256=sha(candidate);row.PIOnlyChange=candidate.slice(PI.length)===original;row.PIcssSHA256=sha(css)
    await writeFile(own(id+'-original.svg'),original);await writeFile(own(id+'-PI.svg'),candidate)
    for(const[mode,xml]of Object.entries({nativeSVGImage:original,PIoutlineSVGImage:candidate})){
     phase={pair:id,step:mode};const mr={mode,startedUTC:new Date().toISOString(),svgSHA256:sha(xml),serverJournalStart:journal.length};row.modeResults.push(mr)
     mr.image=await page.evaluate(async({xml,piMode})=>{
      const i=new Image(),events=[],start=performance.now();let timer,settled=false
      const load=new Promise((resolve,reject)=>{i.onload=()=>{events.push({event:'load',elapsedMS:performance.now()-start});resolve()};i.onerror=()=>{events.push({event:'error',elapsedMS:performance.now()-start});reject(Error('Image error event'))}})
      void load.catch(()=>{})
      try{
       i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(xml)
       const decoding=i.decode();void decoding.catch(()=>{})
       await Promise.race([Promise.all([decoding,load]),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('2500ms decode+native-load guard expired')),2500)})])
       const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.drawImage(i,0,0);const d=x.getImageData(0,0,64,64).data
       const count=(x0,y0,w,h,color)=>{let n=0;for(let y=y0;y<y0+h;y++)for(let xx=x0;xx<x0+w;xx++){const at=4*(y*64+xx);if(color.every((v,k)=>d[at+k]===v))n++}return n}
       const green=count(0,0,8,8,[0,128,0,255]),blue=count(8,0,8,8,[0,0,255,255]);let whiteOutline=0,expectedOutline=124
       for(let y=16;y<48;y++)for(let xx=16;xx<48;xx++)if(xx===16||xx===47||y===16||y===47){const at=4*(y*64+xx);if([255,255,255,255].every((v,k)=>d[at+k]===v))whiteOutline++}
       settled=true
       return{decoded:true,loaded:true,width:i.naturalWidth,height:i.naturalHeight,positiveGreen:green,positiveDataBlue:blue,positiveReady:green===64&&blue===64,whiteOutlinePixels:whiteOutline,expectedOutlinePixels:expectedOutline,PIStylePositive:piMode?whiteOutline===expectedOutline:null,png:c.toDataURL(),events,elapsedMS:performance.now()-start}
      }catch(e){return{decoded:false,loaded:events.some(x=>x.event==='load'),error:String(e),events,elapsedMS:performance.now()-start,width:i.naturalWidth,height:i.naturalHeight,positiveReady:false}}
      finally{clearTimeout(timer);i.onload=i.onerror=null;i.removeAttribute('src');window.__lastImageCleanup={srcAbsent:!i.hasAttribute('src'),settled,timerCleared:true,listenersRemoved:true}}
     },{xml,piMode:mode==='PIoutlineSVGImage'})
     if(mr.image.png){await writeFile(own(id+'-'+mode+'.png'),Buffer.from(mr.image.png.split(',')[1],'base64'));delete mr.image.png}
     mr.imageCleanup=await page.evaluate(()=>window.__lastImageCleanup);mr.completedUTC=new Date().toISOString();mr.serverJournalEnd=journal.length
     // This is a receipt timing window, not a causal attribution for possible late source requests.
     mr.trapReceiptsInWindow=journal.slice(mr.serverJournalStart,mr.serverJournalEnd).filter(x=>x.path.startsWith('/case/'+id+'/trap/'))
    }
    phase={pair:id,step:'revoke-and-after-fetch'}
    row.blob.after=await page.evaluate(async()=>{const u=window.__ownBlobURL;URL.revokeObjectURL(u);window.__blobRevoked=true;try{const r=await fetch(u);return{revokeCalled:true,fetchResolved:true,status:r.status,body:await r.text()}}catch(e){return{revokeCalled:true,fetchResolved:false,error:String(e)}}})
    row.blob.revoked=1;row.blob.afterFetchRejected=row.blob.after.fetchResolved===false
    row.callerAfter=await page.evaluate(()=>({body:document.body.outerHTML,frames:document.querySelectorAll('iframe,object').length,fonts:document.fonts.size}));row.callerUnchanged=JSON.stringify(row.callerBefore)===JSON.stringify(row.callerAfter)
   }catch(e){row.error=String(e);row.stack=e.stack}
   finally{
    phase={pair:id,step:'pair-finally'}
    try{await page.evaluate(()=>{if(window.__ownBlobURL&&!window.__blobRevoked){URL.revokeObjectURL(window.__ownBlobURL);window.__blobRevoked=true}})}catch{}
    await context.close();row.contextClosed=true;row.closedUTC=new Date().toISOString();await save()
   }
   row.sourceTrapReceipts=journal.filter(x=>x.path.startsWith('/case/'+id+'/trap/'))
   row.witnessReceipts=journal.filter(x=>x.path.startsWith('/case/'+id+'/witness/'))
   console.log(JSON.stringify({engine,policy,headerMatches:row.headerMatches,hostWitness:row.hostImageWitness,modeResults:row.modeResults.map(m=>({mode:m.mode,...m.image})),trapRequests:row.sourceTrapReceipts.length,blobBefore:row.blob?.beforeBytesMatch,blobAfterRejected:row.blob?.afterFetchRejected,callerUnchanged:row.callerUnchanged,error:row.error}));await save()
  }}finally{await browser.close();report.cleanup[engine].browserClosed=true;report.cleanup[engine].closedUTC=new Date().toISOString();await save()}
 }
}finally{
 phase={pair:'cleanup',step:'server-close'}
 await new Promise(resolve=>server.close(resolve));report.cleanup.serverClosed=!server.listening
 for(const row of report.pairs){row.sourceTrapReceipts=journal.filter(x=>x.path.startsWith('/case/'+row.id+'/trap/'));row.witnessReceipts=journal.filter(x=>x.path.startsWith('/case/'+row.id+'/witness/'))}
 report.completedUTC=new Date().toISOString();await save()
}
