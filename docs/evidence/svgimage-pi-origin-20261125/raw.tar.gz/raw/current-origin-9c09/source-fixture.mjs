export const cases = [
  { name: 'zero-margin', root: 'margin:0' },
  { name: 'margin-top16', root: 'margin:16px 0 0' },
  { name: 'margin-left16', root: 'margin:0 0 0 16px' },
  { name: 'margin-top-left16', root: 'margin:16px 0 0 16px' },
  { name: 'margin-auto-horizontal', root: 'margin:0 auto' },
  { name: 'margin-auto-flex', root: 'margin:auto', parent: 'display:flex' },
  { name: 'margin-left-percentage', root: 'margin:0 0 0 10%' },
  { name: 'margin-top-percentage', root: 'margin:10% 0 0' },
  { name: 'collapse-through-parent', root: 'margin:16px 0 0', parent: 'display:block' },
  { name: 'collapsed-child-zero-root-margin', root: 'display:block;margin:0', childCollapse: true, parent: 'display:block' },
  { name: 'collapsed-child-root-margin16', root: 'display:block;margin:16px 0 0', childCollapse: true, parent: 'display:block' },
  { name: 'contained-child-margin-control', root: 'display:flow-root;margin:0', childCollapse: true },
  { name: 'negative-margin-control', root: 'margin:-8px 0 0 -8px' },
]
export const buildSource = entry => {
          document.body.style.cssText = 'margin:0;padding:32px;background:magenta'
          document.body.replaceChildren()
          const parent = document.createElement('div'); parent.id = 'source-parent'; parent.style.cssText = 'display:flow-root;width:240px;height:160px;margin:0;padding:0;' + (entry.parent || '')
          const root = document.createElement('div'); root.id = 'margin-source'; root.style.cssText = 'display:flex;width:160px;height:80px;margin:0;padding:0;border:0;background:red;' + entry.root
          if (entry.childCollapse) {
            root.innerHTML = '<div style="width:160px;height:40px;margin-top:24px;background:blue"></div><div style="width:160px;height:40px;background:red"></div>'
          } else root.innerHTML = '<div style="flex:none;width:80px;height:80px;background:red"></div><div style="flex:none;width:80px;height:80px;background:blue"></div>'
          parent.append(root); document.body.append(parent)
          const box = node => { const r = node.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height } }
          const computed = getComputedStyle(root)
          return { html: root.outerHTML, parent: parent.outerHTML, rootRect: box(root), parentRect: box(parent), childRects: Array.from(root.children, box), client: [root.clientWidth, root.clientHeight], margin: { top: computed.marginTop, right: computed.marginRight, bottom: computed.marginBottom, left: computed.marginLeft }, display: computed.display }
        }
