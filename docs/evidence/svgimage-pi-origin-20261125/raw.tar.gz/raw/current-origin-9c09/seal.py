from pathlib import Path
import json,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent
j=json.loads((p/'results.json').read_text())
root=Path('/Users/bytedance/.codex/worktrees/gc-native-release-controls/html-to-image')
identity=json.loads((p/'fixture-and-source-identity-before.json').read_text())
current={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in identity['rootSourceSHA256']}
assert current==identity['rootSourceSHA256']
assert hashlib.sha256((root/'dist/html-to-image.js').read_bytes()).hexdigest()==identity['rootBundleSHA256']==j['umdSHA256']=='9c090fc25401c32b55c80dce3acaa71c6a8e0dc538046b4abad67c584dccee1a'
(p/'fixture-and-source-identity-after.json').write_text(json.dumps({**identity,'allRootSourceAndBundleUnchanged':True},indent=2)+'\n')
old=root/'output/playwright/root-margin-native-20261125'
seals=json.loads((p/'prior-seals.json').read_text())
for n,h in seals['old39'].items():assert hashlib.sha256((old/n).read_bytes()).hexdigest()==h
old15=p.parent/'svgimage-pi-origin-marker-20261125'
for n,h in seals['prior15'].items():assert hashlib.sha256((old15/n).read_bytes()).hexdigest()==h
spec=importlib.util.spec_from_file_location('pngdecode',str(p.parent/'native-animation-css-phase-20261125/publication/verify.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
rows=j['cases'];core=[r for r in rows if not r['negative']];negative=[r for r in rows if r['negative']]
assert len(rows)==45 and len(core)==39 and len(negative)==6
assert len({(r['engine'],r['mode']) for r in rows})==45
assert all(not r.get('error') and r['sourceUnchanged'] and r['rootSubtreeUnchanged'] and r['wrapperPreservesLayout'] and not r['http'] for r in rows)
assert all(x['closed'] for x in j['cleanup'].values())
checks=[]
for r in rows:
 prefix=r['engine']+'-'+r['mode'];size,native=module.png((p/(prefix+'-native.png')).read_bytes());size2,capture=module.png((p/(prefix+'-captured.png')).read_bytes());assert size==size2==(160,80)
 baseline=sum(a!=b for a,b in zip(capture,native));assert baseline==r['baseline']['differentChannels']
 result={'engine':r['engine'],'mode':r['mode'],'negative':r['negative'],'baselineDifferentChannels':baseline,'markerStatus':r['marker']['status'],'coordinate':r['marker']['coordinate']}
 if r['marker']['status']=='known':
  assert r['markerMatchesOracle'] and r['marker']['coordinate']==r['oracle']['original']['rootRelativeFO']
  size3,normal=module.png((p/(prefix+'-normalized.png')).read_bytes());assert size3==size
  diff=sum(a!=b for a,b in zip(normal,native));assert diff==r['normalized']['differentChannels']==0
  assert r['normalized']['rootDOMURIsElementsUnchanged'];result['normalizedDifferentChannels']=diff
 else:
  assert r['marker']['coordinate'] is None and 'normalized' not in r
 checks.append(result)
known=[r for r in core if r['marker']['status']=='known'];unknown=[r for r in core if r['marker']['status']=='unknown']
assert len(known)==36 and len(unknown)==3
assert all(r['mode']=='negative-margin-control' for r in unknown)
assert all(r['marker']['status']=='unknown' and r['marker']['coordinate'] is None for r in negative)
(p/'independent-png-verification.json').write_text(json.dumps({'scope':'Python stdlib PNG CRC/filter reconstruction; native/captured for45 plus normalized36; no browser or new image capture','validCases':45,'core':39,'coreKnown':36,'coreUnknown':3,'negativeUnknown':6,'normalizedExactZero':36,'checks':checks},indent=2)+'\n')
a={'scope':'Current9c09 fresh baseline and PI origin proof using historical13fixture builder unchanged. Not production integration/root-margin fix. Earlier40b6 evidence and correction remain separate.','startedUTC':j['startedUTC'],'completedUTC':j['completedUTC'],'runtime':{'UMDSHA256':j['umdSHA256'],'sourceRoot':str(root),'sourceAndBundleGuardUnchanged':True,'historicalGeneratorReuse':'Exact case array and source-builder original byte SHA in fixture-and-source-identity-before.json, export prefix only. Fresh screenshot+actual9c09capture once per case; no historical40b6 SVG/PNG substituted.'},'core39':{'knownAndOracleExact':36,'normalizedNativeRGBAExactZero':36,'unknown':3,'unknownCases':[{'engine':r['engine'],'mode':r['mode'],'oracle':r['oracle']['original']['rootRelativeFO'],'reason':r['marker']['reason'],'baselineDifferentChannels':r['baseline']['differentChannels'],'normalizedProduced':False} for r in unknown]},'additionalNegative6':{'allUnknown':True,'outlineImportant':'ActualonClone root4pxlime!important plusoffset−4px prevents black/white override','clipOpacity':'ActualonClone clip-path inset8px plusopacity0, combined negative only','noZeroFallback':True},'measurement':{'PI':'Same first-important-layer structural selector; inset1px black/white outline, full opaque rectangular four-side perimeter required','wrapper':'Only measuringSVG outer224x144;FO absolute160x80 overflowvisible, no padding/translation for negative margin','invariants':'All45 original/expanded trueXML root−FO +childrelativepositions +serializedrootSubtree equal; root attrs/resources/elementcount unchanged byPI','bboxGate':'Completeperimeter must match originalroot width/height. Allaccepted36 coordinates match actual oracle, no guessed0.','oracle':'Trustedfixture top-level XMLdata document viaPlaywright; noSVGscript/iframe inserted. This active reference is not production acquisition.'},'normalizedOutput':{'knownOnly':36,'change':'Original160x80SVG;FOx/y=negative measuredcoordinate andoverflowvisible; width/height androotDOM/URIs/elements unchanged','pixelGate':'Fresh native borderboxPNG vs normalized nativeSVGImage Image.decode+Canvas, exact RGBA channels, no tolerance; all36 zero.','unknownOutput':'No normalizedSVG/PNG for3negative-margin +6negative controls; failure artifacts retained.'},'offlineVerification':'independent-png-verification.json independently decodes all45native+45captured+36normalized PNG viaPythonstdlib, checks baselinecounts and36zero. No browser rerun.', 'invariants':{'all45SourcesUnchanged':True,'all45RootSubtreesURIsElementsUnchangedByMeasurement':True,'HTTPRequests':0,'retries':0,'ImageDecodeGuardMS':2500,'oracleLoadGuardMS':2500,'allBrowsersContextsClosed':True,'old40b6FilesUnchanged':True,'phoneNetworkSettingsProductionChanges':False},'limits':['3of39 core negative-margin cases remain unknown due clipped perimeter at−8,−8; no solution or0fallback asserted.','Additional authoredinlineimportant/clip/opacity negative cases remainunknown; do notshippartial default based on36positive.','Wrapperlayout invariance was verified onlyfor these45fixed inputs; responsive/selectors/dynamic/fractional/rotated/rounded/filtered payloads not generalized.','Outputproof is not librarysource integration, fullproject regression/CI or physicaldevice acceptance.']}
(p/'assessment.json').write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n')
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='sha256-index.json':files.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(p/'sha256-index.json').write_text(json.dumps({'files':files,'selfExcluded':True},indent=2)+'\n')
print(json.dumps({'files':len(files),'bytes':sum(x['bytes'] for x in files),'runtime':j['umdSHA256'],'coreKnown':36,'coreUnknown':3,'negativeUnknown':6,'normalized0':36,'allBrowsersClosed':True,'start':j['startedUTC'],'end':j['completedUTC']}))
