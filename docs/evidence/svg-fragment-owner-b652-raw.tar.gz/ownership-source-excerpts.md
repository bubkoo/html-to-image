# Frozen b652 ownership excerpts

All line numbers refer to b652860210997de165e3790674eb13b06ef029fa.

## test/browser-unit/svg-fragment-lifetime.test.ts:6-54

```text
6: async function captureDocument() {
7:   const source = document.implementation.createHTMLDocument()
8:   source.body.style.cssText =
9:     'display:flex;margin:0;width:60px;height:20px;background:white'
10:   const href = new URL(
11:     '/test/browser/fixtures/svg-fragment-pattern.svg#inline',
12:     location.href,
13:   ).href
14:   source.body.innerHTML =
15:     '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute"><defs><pattern id="fragment-paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="blue"/></pattern></defs></svg><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><use href="' +
16:     href +
17:     '" width="20" height="20"/></svg><div style="width:20px;height:20px;background:blue"></div><div style="width:20px;height:20px;background:yellow"></div>'
18:   const renderer = createRenderer({
19:     width: 60,
20:     height: 20,
21:     pixelRatio: 1,
22:     skipFonts: true,
23:   })
24:   try {
25:     return {
26:       reference: new WeakRef(source),
27:       capture: await renderer.capture(source.body),
28:       renderer,
29:     }
30:   } catch (error) {
31:     renderer.dispose()
32:     throw error
33:   }
34: }
35: test('a frozen SVG host-tree capture releases its source document before rendering', async () => {
36:   const fixture = await import(/* @vite-ignore */ fixtureURL),
37:     policy = await fixture.getSVGFragmentFixturePolicy()
38:   const frames = Array.from(document.querySelectorAll('iframe'))
39:   const { reference, capture, renderer } = await captureDocument()
40:   try {
41:     await commands.collectGarbage()
42:     await commands.collectGarbage()
43:     await commands.collectGarbage()
44:     expect(reference.deref() === undefined).toBe(true)
45:     expect(Array.from(document.querySelectorAll('iframe'))).toEqual(frames)
46:     const image = await capture.toImageData(),
47:       offset = 4 * (10 * image.width + 10)
48:     expect(Array.from(image.data.slice(offset, offset + 4))).toEqual(
49:       policy.fragmentPage ? [0, 0, 255, 255] : [0, 128, 0, 255],
50:     )
51:   } finally {
52:     renderer.dispose()
53:   }
54: })
```

## src/capture.ts:23-95

```text
23: export async function createCapture(
24:   node: CaptureNode,
25:   options: Options,
26:   task: CaptureTask,
27:   release: () => void = () => {},
28: ): Promise<Capture> {
29:   try {
30:     return await task.run(async () => {
31:       const { width, height } = getImageSize(node as HTMLElement, options)
32:       const pixelRatio = options.pixelRatio ?? getPixelRatio()
33:       const canvasWidth = options.canvasWidth ?? width
34:       const canvasHeight = options.canvasHeight ?? height
35:       if (
36:         [width, height, canvasWidth, canvasHeight].some(
37:           (value) => !Number.isFinite(value) || value < 0,
38:         ) ||
39:         !Number.isFinite(pixelRatio) ||
40:         pixelRatio <= 0
41:       ) {
42:         throw new Error(
43:           'Capture dimensions must be finite and non-negative; pixelRatio must be positive',
44:         )
45:       }
46: 
47:       task.stage('clone')
48:       const root = (await cloneNode(node as HTMLElement, options, true, false))!
49:       // Retain the inert document across async resource work. WebKit can lose
50:       // a detached copy's document/base URL when only its nodes remain alive.
51:       const cloneDocument = root.ownerDocument
52:       applyStyle(root, options)
53:       task.stage('transform')
54:       const context = Object.freeze({ root, signal: task.context.signal })
55:       if (options.onClone) await options.onClone(context)
56:       const plugins = options.plugins || []
57:       for (let i = 0; i < plugins.length; i += 1) {
58:         task.check()
59:         // eslint-disable-next-line no-await-in-loop
60:         await plugins[i].transformClone?.(context)
61:       }
62:       task.stage('resources')
63:       await ensureSVGSymbols(node as HTMLElement, root, options)
64:       task.clearInheritedStyles()
65:       await embedWebFonts(root, options, node)
66:       task.clearCloneSources()
67:       task.check()
68:       await embedImages(root, options)
69:       task.stage('serialize')
70:       return fromSnapshot(
71:         {
72:           svg: await nodeToDataURL(
73:             root,
74:             width,
75:             height,
76:             cloneDocument,
77:             task.getClonedStyles(),
78:           ),
79:           width,
80:           height,
81:           canvasWidth,
82:           canvasHeight,
83:           pixelRatio,
84:         },
85:         options,
86:         task,
87:         release,
88:       )
89:     })
90:   } catch (error) {
91:     task.dispose()
92:     release()
93:     throw error
94:   }
95: }
```

## src/capture.ts:97-121

```text
97: interface Snapshot {
98:   readonly svg: string
99:   readonly width: number
100:   readonly height: number
101:   readonly canvasWidth: number
102:   readonly canvasHeight: number
103:   readonly pixelRatio: number
104: }
105: 
106: function fromSnapshot(
107:   snapshot: Snapshot,
108:   options: Options,
109:   task: CaptureTask,
110:   release: () => void,
111: ): Capture {
112:   const { width, height, canvasWidth, canvasHeight, pixelRatio } = snapshot
113:   let svg: string | null = snapshot.svg
114:   // The snapshot retains serialized content, never the live source tree.
115:   let raster: Promise<HTMLCanvasElement> | undefined
116:   let disposed = false
117: 
118:   const render = () => {
119:     task.check()
120:     if (!raster) {
121:       const source = svg!
```

## src/capture.ts:165-219

```text
165:   const capture: Capture = {
166:     width,
167:     height,
168:     get diagnostics() {
169:       return Object.freeze([...task.diagnostics])
170:     },
171:     toSvg: () => task.run(async () => svg!),
172:     toCanvas: () =>
173:       task.run(async () => {
174:         const source = await render()
175:         task.check()
176:         const canvas = source.ownerDocument.createElement('canvas')
177:         canvas.width = source.width
178:         canvas.height = source.height
179:         canvas.style.cssText = source.style.cssText
180:         getContext(canvas).drawImage(source, 0, 0)
181:         return canvas
182:       }),
183:     toPng: () => task.run(async () => (await render()).toDataURL('image/png')),
184:     toJpeg: (encoding = {}) =>
185:       task.run(async () =>
186:         (await render()).toDataURL(
187:           'image/jpeg',
188:           encoding.quality ?? options.quality ?? 1,
189:         ),
190:       ),
191:     toBlob: (encoding: EncodingOptions = {}) =>
192:       task.run(async () =>
193:         canvasToBlob(await render(), {
194:           type: encoding.type ?? options.type,
195:           quality: encoding.quality ?? options.quality,
196:         }),
197:       ),
198:     toImageData: () =>
199:       task.run(async () => {
200:         const canvas = await render()
201:         task.check()
202:         return getContext(canvas).getImageData(
203:           0,
204:           0,
205:           canvas.width,
206:           canvas.height,
207:         )
208:       }),
209:     toPixelData: async () => (await capture.toImageData()).data,
210:     dispose: () => {
211:       if (disposed) return
212:       disposed = true
213:       svg = null
214:       raster = undefined
215:       task.dispose()
216:       release()
217:     },
218:   }
219:   return Object.freeze(capture)
```

## src/renderer.ts:6-41

```text
6: export function createRenderer(defaults: Options = {}): Renderer {
7:   const configuration = copyOptions(defaults)
8:   const tasks = new Set<CaptureTask>()
9:   const captures = new Map<CaptureTask, Capture>()
10:   let disposed = false
11: 
12:   const start = (options: Options) => {
13:     if (disposed) throw new Error('Renderer has been disposed')
14:     const task = new CaptureTask(copyOptions(configuration, options))
15:     tasks.add(task)
16:     return task
17:   }
18: 
19:   const releaseTask = (task: CaptureTask) => {
20:     tasks.delete(task)
21:     captures.delete(task)
22:   }
23: 
24:   const capture = async (node: CaptureNode, options: Options = {}) => {
25:     const task = start(options)
26:     // An inline callback here can retain this call's source node in Firefox.
27:     const result = await createCapture(
28:       node,
29:       task.options,
30:       task,
31:       releaseTask.bind(undefined, task),
32:     )
33:     // Disposal can race with the final microtask of capture creation.
34:     if (disposed || task.context.signal.aborted) {
35:       result.dispose()
36:       throw task.context.signal.aborted
37:         ? task.context.signal.reason
38:         : new Error('Renderer has been disposed')
39:     }
40:     captures.set(task, result)
41:     return result
```

## src/renderer.ts:84-91

```text
84:     dispose: () => {
85:       if (disposed) return
86:       disposed = true
87:       captures.forEach((snapshot) => snapshot.dispose())
88:       tasks.forEach((task) => task.dispose())
89:       captures.clear()
90:       tasks.clear()
91:     },
```

## src/task.ts:39-105

```text
39: export class CaptureTask {
40:   readonly controller = new AbortController()
41: 
42:   readonly context: ExtensionContext
43: 
44:   readonly resources: ResourceLoader
45: 
46:   readonly diagnostics: CaptureDiagnostic[] = []
47: 
48:   private cloneSources = new WeakMap<Element, Element>()
49: 
50:   private clonedSources = new WeakSet<Element>()
51: 
52:   private clonedStyles: string[] = []
53: 
54:   addClonedStyle(rule: string) {
55:     this.clonedStyles.push(rule)
56:   }
57: 
58:   getClonedStyles() {
59:     return this.clonedStyles.join('\n')
60:   }
61: 
62:   private excludedSources = new WeakSet<Node>()
63: 
64:   excludeSource(node: Node) {
65:     this.excludedSources.add(node)
66:   }
67: 
68:   isExcludedSource(node: Node) {
69:     let current: Node | null = node
70:     while (current) {
71:       if (this.excludedSources.has(current)) return true
72:       current = current.parentNode || (current as ShadowRoot).host || null
73:     }
74:     return false
75:   }
76: 
77:   registerClone(copy: Element, source: Element) {
78:     this.cloneSources.set(copy, source)
79:     this.clonedSources.add(source)
80:   }
81: 
82:   getCloneSource(copy: Element) {
83:     return this.cloneSources.get(copy)
84:   }
85: 
86:   hasClonedSource(source: Element) {
87:     return this.clonedSources.has(source)
88:   }
89: 
90:   clearCloneSources() {
91:     this.cloneSources = new WeakMap()
92:     this.clonedSources = new WeakSet()
93:     this.excludedSources = new WeakSet()
94:   }
95: 
96:   private inheritedStyles = new WeakMap<
97:     Element,
98:     { style: CSSStyleDeclaration; values: Map<string, string> }
99:   >()
100: 
101:   private cleanups: (() => void)[] = []
102: 
103:   private disposed = false
104: 
105:   private cloneSliceStartedAt?: number
```

## src/task.ts:136-150

```text
136:     this.context = Object.freeze({ signal: this.controller.signal })
137:     this.resources = new ResourceLoader(options, this.context, (diagnostic) => {
138:       this.diagnostics.push(diagnostic)
139:       options.onEvent?.(Object.freeze({ type: 'warning', diagnostic }))
140:     })
141:     const signals = [options.signal, options.fetchRequestInit?.signal]
142:     signals.forEach((signal) => {
143:       if (!signal) return
144:       const abort = () => this.controller.abort(signal.reason)
145:       if (signal.aborted) abort()
146:       else {
147:         signal.addEventListener('abort', abort, { once: true })
148:         this.cleanups.push(() => signal.removeEventListener('abort', abort))
149:       }
150:     })
```

## src/task.ts:154-158

```text
154:   check() {
155:     if (this.disposed) throw new Error('Capture has been disposed')
156:     if (this.controller.signal.aborted) {
157:       throw this.controller.signal.reason
158:     }
```

## src/task.ts:178-183

```text
178:   clearInheritedStyles() {
179:     this.inheritedStyles = new WeakMap()
180:   }
181: 
182:   maybeYieldClone(): Promise<void> | undefined {
183:     const slice = this.options.cloneTimeSliceMs ?? 16
```

## src/task.ts:215-254

```text
215:     return new Promise<T>((resolve, reject) => {
216:       let timer: ReturnType<typeof setTimeout> | undefined
217:       const clean = () => {
218:         if (timer != null) clearTimeout(timer)
219:         signal.removeEventListener('abort', abort)
220:       }
221:       const abort = () => {
222:         clean()
223:         reject(
224:           signal.aborted
225:             ? signal.reason
226:             : new DOMException('Capture aborted', 'AbortError'),
227:         )
228:       }
229:       signal.addEventListener('abort', abort, { once: true })
230:       const timeout = this.options.timeout ?? 30000
231:       if (timeout > 0) {
232:         timer = setTimeout(() => {
233:           this.controller.abort(
234:             new DOMException('Capture timed out', 'TimeoutError'),
235:           )
236:         }, timeout)
237:       }
238:       Promise.resolve()
239:         .then(() => {
240:           this.check()
241:           return operation()
242:         })
243:         .then(
244:           (value) => {
245:             clean()
246:             if (signal.aborted) abort()
247:             else resolve(value)
248:           },
249:           (error) => {
250:             clean()
251:             reject(error)
252:           },
253:         )
254:     })
```

## src/task.ts:257-269

```text
257:   dispose() {
258:     if (this.disposed) return
259:     this.disposed = true
260:     this.controller.abort(new DOMException('Capture disposed', 'AbortError'))
261:     this.cleanups.forEach((cleanup) => cleanup())
262:     this.cleanups = []
263:     this.clearInheritedStyles()
264:     this.clearCloneSources()
265:     this.clonedStyles = []
266:     this.resources.clear()
267:     // Weak entries expire with options. Pending async stages still need to see
268:     // this disposed task so they cannot resume work after cancellation.
269:   }
```

## src/clone-node.ts:15-23

```text
15: function createCloneDocument(source: Document) {
16:   // A detached element in a browsing document can still load resources in
17:   // WebKit when styles or image loading attributes change.
18:   const copy = source.implementation.createHTMLDocument()
19:   const base = copy.createElement('base')
20:   base.href = source.baseURI
21:   copy.head.append(base)
22:   return copy
23: }
```

## src/clone-node.ts:97-116

```text
97:   if (isInstanceOfElement(node, HTMLIFrameElement)) {
98:     return cloneIFrameElement(node, options, targetDocument, resolveSymbols)
99:   }
100: 
101:   const copy = targetDocument.importNode(node, false)
102:   if (isInstanceOfElement(node, HTMLImageElement)) {
103:     // Keep the source document's URL resolution when importing iframe content.
104:     ;(copy as unknown as HTMLImageElement).src = node.src
105:   } else if (isInstanceOfElement(node, SVGImageElement)) {
106:     const href = getSVGReference(node)
107:     if (href) {
108:       try {
109:         copy.setAttribute('href', new URL(href, node.baseURI).href)
110:         copy.removeAttributeNS('http://www.w3.org/1999/xlink', 'href')
111:       } catch {
112:         // Keep malformed references for the normal resource error path.
113:       }
114:     }
115:   }
116:   return copy
```

## src/clone-node.ts:438-452

```text
438: export async function ensureSVGSymbols<T extends HTMLElement>(
439:   source: T,
440:   clone: T,
441:   options: Options,
442: ) {
443:   await embedSVGReferences(source, clone, options, (definition) =>
444:     cloneNode(
445:       definition as HTMLElement,
446:       options,
447:       true,
448:       false,
449:       clone.ownerDocument,
450:     ),
451:   )
452:   return clone
```

## src/clone-node.ts:482-510

```text
482:   const copyDocument = targetDocument || createCloneDocument(node.ownerDocument)
483:   return Promise.resolve(node)
484:     .then(
485:       (clonedNode) =>
486:         cloneSingleNode(
487:           clonedNode,
488:           options,
489:           copyDocument,
490:           resolveSymbols,
491:         ) as Promise<T>,
492:     )
493:     .then((clonedNode) => {
494:       if (isInstanceOfElement(node, Element)) {
495:         task?.registerClone(clonedNode, node)
496:       }
497:       return cloneChildren(
498:         node,
499:         clonedNode,
500:         options,
501:         copyDocument,
502:         resolveSymbols,
503:       )
504:     })
505:     .then((clonedNode) => decorate(node, clonedNode, options, isRoot))
506:     .then((clonedNode) =>
507:       isRoot && resolveSymbols
508:         ? ensureSVGSymbols(node, clonedNode, options)
509:         : clonedNode,
510:     )
```

## src/svg-references.ts:69-125

```text
69:   url: string
70:   external: boolean
71:   ids?: Map<string, Element>
72:   styleHost?: Element
73:   stylePolicy?: SVGStylePolicy
74:   custom?: boolean
75:   fragmentScope?: Scope
76: }
77: 
78: export async function embedSVGReferences(
79:   source: Element,
80:   root: Element,
81:   options: Options,
82:   cloneLocal: (node: Element) => Promise<Element | null>,
83: ) {
84:   if (
85:     root.namespaceURI !== svgNamespace &&
86:     !root.matches('[style*="url("]') &&
87:     !root.querySelector('svg,[style*="url("]')
88:   )
89:     return
90:   const task = getTask(options)
91:   const loader = getResourceLoader(options)
92:   const loadedFontFamilies: string[] = []
93:   source.ownerDocument.fonts?.forEach((font) => {
94:     if (font.status === 'loaded') loadedFontFamilies.push(font.family)
95:   })
96:   const targetDocument = root.ownerDocument
97:   const pageStyles = snapshotSVGPageStyles(
98:     source.ownerDocument,
99:     (resource, error) =>
100:       loader.warn(
101:         Object.freeze({
102:           code: 'resource-error',
103:           resource,
104:           message:
105:             'Unable to read native page CSS for an external SVG: ' +
106:             (error instanceof Error ? error.message : String(error)),
107:         }),
108:       ),
109:   )
110:   const styleEnvironment = createSVGStyleEnvironment(
111:     source.ownerDocument,
112:     task?.context.signal,
113:   )
114:   const scopes = new Map<Node, Scope>()
115:   const external = new Map<string, Promise<Scope>>()
116:   const copies = new Map<Element, Element>()
117:   const origins = new WeakMap<Element, { source: Element; scope: Scope }>()
118:   const aliases = new Map<Element, string>()
119:   const visited = new WeakSet<Element>()
120:   const primary = new WeakSet<Element>()
121:   const ids = new Set<string>()
122:   let definitions: SVGDefsElement | undefined
123:   let stylePolicy: Promise<SVGStylePolicy | undefined> | undefined
124:   const styledScopes = new Map<string, Scope>()
125:   const fragmentRoots = new WeakMap<Node, number>()
```

## src/svg-references.ts:153-195

```text
153:   const activeUses = new Map<string, Element>()
154:   const nativeStylePolicy = () => {
155:     stylePolicy ||= styleEnvironment
156:       .measurePolicy(
157:         () => task?.check(),
158:         (error) => {
159:           loader.warn(
160:             Object.freeze({
161:               code: 'resource-error',
162:               resource: 'external-svg-style-import-probe',
163:               message:
164:                 'Native SVG import capabilities could not be measured; retaining the measured base stylesheet scope: ' +
165:                 (error instanceof Error ? error.message : String(error)),
166:             }),
167:           )
168:         },
169:         (error) => {
170:           loader.warn(
171:             Object.freeze({
172:               code: 'resource-error',
173:               resource: 'external-svg-fragment-scope-probe',
174:               message:
175:                 'Native SVG fragment scope could not be measured; retaining existing fragment definitions: ' +
176:                 (error instanceof Error ? error.message : String(error)),
177:             }),
178:           )
179:         },
180:       )
181:       .catch((error) => {
182:         task?.check()
183:         // An unavailable optional probe must not discard a valid SVG resource.
184:         loader.warn(
185:           Object.freeze({
186:             code: 'resource-error',
187:             resource: 'external-svg-style-probe',
188:             message:
189:               'Native SVG stylesheet scope could not be measured; retaining existing definition styles: ' +
190:               (error instanceof Error ? error.message : String(error)),
191:           }),
192:         )
193:         return undefined
194:       })
195:     return stylePolicy
```

## src/svg-references.ts:203-242

```text
203:   const localScope = (node: Element): Scope => {
204:     const document = node.ownerDocument
205:     const tree = node.getRootNode()
206:     const root =
207:       'querySelectorAll' in tree
208:         ? (tree as Document | DocumentFragment | Element)
209:         : document
210:     let scope = scopes.get(root)
211:     if (!scope) {
212:       scope = {
213:         root,
214:         url: withoutHash(document.URL),
215:         external: false,
216:       }
217:       scopes.set(root, scope)
218:     }
219:     return scope
220:   }
221:   const find = (scope: Scope, id: string) => {
222:     if (!scope.ids) {
223:       scope.ids = new Map()
224:       const nodes = Array.from(scope.root.querySelectorAll('[id]'))
225:       if (scope.root.nodeType === Node.ELEMENT_NODE)
226:         nodes.unshift(scope.root as Element)
227:       nodes.forEach((node) => {
228:         if (node.id && !scope.ids!.has(node.id)) scope.ids!.set(node.id, node)
229:       })
230:     }
231:     return scope.ids.get(id)
232:   }
233:   const sourceScope = localScope(source)
234:   ;[root, ...Array.from(root.querySelectorAll('*'))].forEach((node) => {
235:     primary.add(node)
236:     if (node.id) ids.add(node.id)
237:     const original = task?.getCloneSource(node)
238:     if (original) {
239:       copies.set(original, node)
240:       origins.set(node, { source: original, scope: localScope(original) })
241:     }
242:   })
```

## src/svg-references.ts:276-303

```text
276:   const loadScope = (url: string) => {
277:     let pending = external.get(url)
278:     if (!pending) {
279:       pending = (async () => {
280:         const blob = await loader.load(url, 'image', getMimeType(url))
281:         const finalURL = loader.responseURL(url, 'image', getMimeType(url))
282:         const document = new DOMParser().parseFromString(
283:           await blob.text(),
284:           'image/svg+xml',
285:         )
286:         if (
287:           document.querySelector('parsererror') ||
288:           document.documentElement.namespaceURI !== svgNamespace
289:         )
290:           throw new Error(`Invalid SVG resource: ${url}`)
291:         if (!external.has(finalURL)) external.set(finalURL, pending!)
292:         return {
293:           root: document,
294:           url: finalURL,
295:           external: true,
296:           custom: loader.isCustomResponse(url, 'image', getMimeType(url)),
297:         }
298:       })()
299:       external.set(url, pending)
300:     }
301:     return pending
302:   }
303: 
```

## src/svg-references.ts:333-407

```text
333:     aliases.set(original, id)
334:     const copy = scope.external
335:       ? targetDocument.importNode(original, true)
336:       : await cloneLocal(original)
337:     if (!copy) return undefined
338:     if (scope.styleHost && scope.stylePolicy) {
339:       await freezeSVGFragmentStyles(
340:         original,
341:         copy,
342:         scope.root,
343:         scope.styleHost,
344:         await styleEnvironment.getDocument(),
345:         scope.stylePolicy,
346:         (text, style) =>
347:           rewriteSVGStyleURLs(text, (value) => {
348:             if (value.startsWith('#')) return undefined
349:             try {
350:               return new URL(value, baseFor(style, scope)).href
351:             } catch {
352:               // Keep invalid URLs and their native CSS fallback values intact.
353:               return undefined
354:             }
355:           }),
356:         pageStyles,
357:         (families) =>
358:           options.fontEmbedCSS != null
359:             ? Promise.resolve(options.fontEmbedCSS)
360:             : options.skipFonts
361:               ? Promise.resolve('')
362:               : getSVGStyleFontCSS(
363:                   families,
364:                   loadedFontFamilies,
365:                   source,
366:                   options,
367:                 ),
368:         (error) => {
369:           task?.check()
370:           loader.warn(
371:             Object.freeze({
372:               code: 'resource-error',
373:               resource: 'external-svg-font-metrics',
374:               message:
375:                 'Unable to load a source font for SVG measurement: ' +
376:                 (error instanceof Error ? error.message : String(error)),
377:             }),
378:           )
379:         },
380:         async (text) =>
381:           prepareSVGFileStyle(
382:             text,
383:             await styleEnvironment.getDocument(),
384:             scope.stylePolicy!,
385:             (url) => loader.load(url, 'stylesheet', 'text/css'),
386:             async () => {
387:               task?.check()
388:               await task?.maybeYieldClone()
389:             },
390:             (url, error) => {
391:               task?.check()
392:               if (error instanceof ResourceResolverError) throw error
393:               loader.warn(
394:                 Object.freeze({
395:                   code: 'resource-error',
396:                   resource: url,
397:                   message:
398:                     error instanceof Error ? error.message : String(error),
399:                 }),
400:               )
401:             },
402:           ),
403:       )
404:     }
405:     copy.setAttribute('id', id)
406:     const register = (native: Element, node: Element) => {
407:       const old = copies.get(native)
```

## src/svg-references.ts:475-505

```text
475:       owner = local
476:         ? scope
477:         : target.href === sourceScope.url
478:           ? sourceScope
479:           : await loadScope(target.href)
480:       if (owner.external && instance && owner !== scope) {
481:         const policy = await nativeStylePolicy()
482:         if (policy) {
483:           const fragmentScope = scope.external
484:             ? scope.fragmentScope
485:             : !owner.custom || nativeInstance(instance, value)
486:               ? scope
487:               : undefined
488:           const key = JSON.stringify([
489:             owner.url,
490:             svgStyleContextKey(instance),
491:             fragmentKey(fragmentScope),
492:           ])
493:           let styled = styledScopes.get(key)
494:           if (!styled) {
495:             styled = {
496:               ...owner,
497:               root: owner.root.cloneNode(true) as Document,
498:               ids: undefined,
499:               styleHost: instance,
500:               stylePolicy: policy,
501:               fragmentScope,
502:             }
503:             styledScopes.set(key, styled)
504:           }
505:           owner = styled
```

## src/svg-references.ts:638-649

```text
638:     const children = Array.from(node.children)
639:     for (let index = 0; index < children.length; index += 1) {
640:       // eslint-disable-next-line no-await-in-loop
641:       await visit(children[index], scope)
642:     }
643:   }
644:   try {
645:     await visit(root, sourceScope)
646:   } finally {
647:     styleEnvironment.dispose()
648:   }
649: }
```

## src/svg-style-scope.ts:133-157

```text
133: 
134: export function snapshotSVGPageStyles(
135:   document: Document,
136:   report: (url: string, error: unknown) => void,
137: ): () => string {
138:   const warnings: { url: string; error: unknown }[] = []
139:   let reported = false
140:   try {
141:     const text = pageStyleText(document, (url, error) =>
142:       warnings.push({ url, error }),
143:     )
144:     return () => {
145:       if (!reported) {
146:         reported = true
147:         warnings.forEach(({ url, error }) => report(url, error))
148:       }
149:       return text
150:     }
151:   } catch (error) {
152:     return () => {
153:       throw error
154:     }
155:   }
156: }
157: 
```

## src/svg-style-scope.ts:353-405

```text
353: export function createSVGStyleEnvironment(
354:   source: Document,
355:   signal?: AbortSignal,
356: ) {
357:   const width = source.defaultView?.innerWidth || 1024
358:   const height = source.defaultView?.innerHeight || 768
359:   const fonts: FontFace[] = []
360:   source.fonts?.forEach((font) => {
361:     if (font.status === 'loaded') fonts.push(font)
362:   })
363:   let frame: HTMLIFrameElement | undefined
364:   let pending: Promise<Document> | undefined
365:   let cancel: (() => void) | undefined
366:   let resourcesLocked = false
367:   let disposed = false
368:   const lockResources = (document: Document) => {
369:     if (resourcesLocked) return
370:     const policy = document.createElement('meta')
371:     policy.httpEquiv = 'Content-Security-Policy'
372:     policy.content = "img-src 'none'; style-src 'unsafe-inline'"
373:     document.head.append(policy)
374:     resourcesLocked = true
375:   }
376:   const dispose = () => {
377:     disposed = true
378:     signal?.removeEventListener('abort', dispose)
379:     cancel?.()
380:     frame?.remove()
381:     frame = undefined
382:     pending = undefined
383:     // Loaded FontFace wrappers can retain their source document after disposal.
384:     fonts.length = 0
385:   }
386:   signal?.addEventListener('abort', dispose, { once: true })
387:   return {
388:     dispose,
389:     async measurePolicy(
390:       check: () => void,
391:       reportImportError?: (error: unknown) => void,
392:       reportFragmentError?: (error: unknown) => void,
393:     ): Promise<SVGStylePolicy> {
394:       const document = await this.getDocument(true)
395:       try {
396:         return await detectSVGStylePolicy(
397:           document,
398:           check,
399:           reportImportError,
400:           reportFragmentError,
401:         )
402:       } finally {
403:         lockResources(document)
404:       }
405:     },
```

## src/svg-style-scope.ts:406-499

```text
406:     getDocument(trustedProbe = false): Promise<Document> {
407:       if (disposed)
408:         return Promise.reject(
409:           signal?.aborted
410:             ? signal.reason
411:             : new Error('SVG style environment has been disposed'),
412:         )
413:       if (signal?.aborted) {
414:         dispose()
415:         return Promise.reject(signal.reason)
416:       }
417:       if (!pending) {
418:         pending = new Promise<Document>((resolve, reject) => {
419:           frame = document.createElement('iframe')
420:           const ownFrame = frame
421:           ownFrame.setAttribute('sandbox', 'allow-same-origin')
422:           ownFrame.setAttribute('aria-hidden', 'true')
423:           ownFrame.style.cssText = `position:fixed!important;left:-99999px!important;top:0!important;width:${width}px!important;height:${height}px!important;opacity:0!important;border:0!important;pointer-events:none!important`
424:           let settled = false
425:           const finish = (
426:             outcome: { error: unknown } | { document: Document },
427:           ) => {
428:             if (settled) return
429:             settled = true
430:             clearTimeout(timer)
431:             signal?.removeEventListener('abort', abort)
432:             ownFrame.onload = null
433:             cancel = undefined
434:             if ('error' in outcome) {
435:               ownFrame.remove()
436:               reject(outcome.error)
437:             } else resolve(outcome.document)
438:           }
439:           const abort = () =>
440:             finish({
441:               error: signal?.aborted
442:                 ? signal.reason
443:                 : new DOMException('Capture aborted', 'AbortError'),
444:             })
445:           const timer = setTimeout(
446:             () =>
447:               finish({
448:                 error: new Error('SVG style environment did not become ready'),
449:               }),
450:             5000,
451:           )
452:           cancel = abort
453:           ownFrame.onload = () => {
454:             try {
455:               const result = ownFrame.contentDocument
456:               if (!result?.querySelector('meta[data-svg-style-policy]')) return
457:               const fontSet = result.fonts as FontFaceSet & {
458:                 add(font: FontFace): FontFaceSet
459:               }
460:               fonts.forEach((font) => {
461:                 try {
462:                   fontSet.add(font)
463:                 } catch (error) {
464:                   // Some engines keep CSS-connected faces in their owner document.
465:                   // Their resource embedding remains with the existing font pipeline.
466:                   if (
467:                     (error as DOMException | null)?.name !==
468:                     'InvalidModificationError'
469:                   )
470:                     throw error
471:                 }
472:               })
473:               finish({ document: result })
474:             } catch (error) {
475:               finish({ error })
476:             }
477:           }
478:           signal?.addEventListener('abort', abort, { once: true })
479:           if (signal?.aborted) {
480:             abort()
481:             return
482:           }
483:           ownFrame.srcdoc = `<!doctype html><meta data-svg-style-policy http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'none'; style-src 'unsafe-inline' data:; img-src blob:; font-src data:; base-uri 'none'; form-action 'none'"><style>html,body{margin:0;overflow:hidden}</style><body></body>`
484:           document.documentElement.append(ownFrame)
485:         })
486:       }
487:       return trustedProbe
488:         ? pending
489:         : pending.then((document) => {
490:             if (disposed || signal?.aborted)
491:               throw signal?.aborted
492:                 ? signal.reason
493:                 : new Error('SVG style environment has been disposed')
494:             lockResources(document)
495:             return document
496:           })
497:     },
498:   }
499: }
```

## src/svg-style-scope.ts:575-636

```text
575:   let fragment = document.importNode(original, true)
576:   const neutralizeStyles = (root: Element) =>
577:     root.querySelectorAll('style').forEach((node) => {
578:       if (node.textContent)
579:         node.textContent = '/* stylesheet evaluated in the native scope */'
580:     })
581:   fragment.querySelectorAll('style').forEach((node) => node.remove())
582:   shadow.append(fragment)
583:   document.documentElement.append(container)
584:   try {
585:     let sources = [fragment, ...Array.from(fragment.querySelectorAll('*'))]
586:     const targets = [copy, ...Array.from(copy.querySelectorAll('*'))].filter(
587:       (node) => node.localName !== 'style',
588:     )
589:     const fontCSS = await prepareFonts(
590:       sources.map((source) => view.getComputedStyle(source).fontFamily),
591:     )
592:     if (fontCSS) {
593:       let installed = installedFontCSS.get(document)
594:       if (!installed) {
595:         installed = new Set()
596:         installedFontCSS.set(document, installed)
597:       }
598:       if (!installed.has(fontCSS)) {
599:         const fonts = document.createElement('style')
600:         fonts.textContent = fontCSS
601:         document.head.append(fonts)
602:         installed.add(fontCSS)
603:       }
604:       const requested = new Set(
605:         sources.map((source) => {
606:           const style = view.getComputedStyle(source)
607:           return style.font || `${style.fontSize} ${style.fontFamily}`
608:         }),
609:       )
610:       await Promise.all(
611:         Array.from(requested, (font) =>
612:           document.fonts.load(font).catch(reportFontError),
613:         ),
614:       )
615:       // A non-rendering symbol can retain fallback metrics computed before its
616:       // face loaded. Evaluate a fresh tree only after those faces are ready.
617:       const ready = fragment.cloneNode(true) as Element
618:       fragment.replaceWith(ready)
619:       fragment = ready
620:       sources = [fragment, ...Array.from(fragment.querySelectorAll('*'))]
621:     }
622:     sources.forEach((source, index) => {
623:       const style = view.getComputedStyle(source)
624:       const target = targets[index] as HTMLElement
625:       Array.from(style).forEach((name) =>
626:         target.style.setProperty(
627:           name,
628:           style.getPropertyValue(name),
629:           'important',
630:         ),
631:       )
632:     })
633:     neutralizeStyles(copy)
634:   } finally {
635:     container.remove()
636:   }
```

## src/resource-loader.ts:68-77

```text
68: export class ResourceLoader {
69:   private pending = new Map<string, Promise<Blob>>()
70:   private responseURLs = new Map<string, string>()
71:   private customResponses = new Set<string>()
72: 
73:   constructor(
74:     private readonly options: Options,
75:     private readonly context: ExtensionContext,
76:     readonly warn: (diagnostic: CaptureDiagnostic) => void = () => {},
77:   ) {}
```

## src/resource-loader.ts:94-110

```text
94:   load(url: string, kind: ResourceKind, contentType?: string): Promise<Blob> {
95:     const key = this.key(url, kind, contentType)
96:     const existing = this.pending.get(key)
97:     if (existing) return existing
98: 
99:     const request = this.fetch(url, kind, contentType).then((result) => {
100:       if (this.pending.get(key) === request) {
101:         this.responseURLs.set(key, result.url)
102:         if (result.custom) this.customResponses.add(key)
103:       }
104:       return result.blob
105:     })
106:     this.pending.set(key, request)
107:     request.catch(() => {
108:       if (this.pending.get(key) === request) this.pending.delete(key)
109:     })
110:     return request
```

## src/resource-loader.ts:154-180

```text
154:     const response = await fetch(requestURL.href, {
155:       ...this.options.fetchRequestInit,
156:       signal,
157:     })
158:     if (!response.ok) {
159:       throw new Error(`Resource request failed (${response.status}): ${url}`)
160:     }
161:     const finalURL = new URL(response.url || requestURL.href)
162:     if (nonce && finalURL.searchParams.get('_htmlToImage') === nonce) {
163:       finalURL.searchParams.delete('_htmlToImage')
164:       originalNonce.forEach((value) =>
165:         finalURL.searchParams.append('_htmlToImage', value),
166:       )
167:     }
168:     return {
169:       blob: await response.blob(),
170:       // A transport cache-buster is not part of the SVG document identity.
171:       url: response.url === requestURL.href ? originalURL : finalURL.href,
172:       custom: false,
173:     }
174:   }
175: 
176:   clear() {
177:     this.pending.clear()
178:     this.responseURLs.clear()
179:     this.customResponses.clear()
180:   }
```

## src/embed-webfonts.ts:13-15

```text
13: // Stable per-document names let getFontEmbedCSS() be reused for the same roots.
14: // Weak keys retain neither source documents nor response/configuration caches.
15: const documentFontNames = new WeakMap<Document, string>()
```

## src/embed-webfonts.ts:429-455

```text
429: export async function embedWebFonts<T extends HTMLElement>(
430:   clonedNode: T,
431:   options: Options,
432:   styleSource: Element = clonedNode,
433: ) {
434:   if (options.skipFonts && options.fontEmbedCSS == null) return
435:   let cssText: string
436:   let scopes: FontScope[]
437:   if (options.fontEmbedCSS != null) {
438:     cssText = options.fontEmbedCSS
439:     const declared = declaredFontFamilies(cssText)
440:     scopes = collectFontScopes(clonedNode, styleSource, options)
441:     scopes.forEach((scope) => {
442:       if (scope.source.ownerDocument === styleSource.ownerDocument) return
443:       scope.used.forEach((family) => {
444:         const name = scopedFontName(scope.source.ownerDocument, family)
445:         if (declared.has(normalizeFontFamily(name)))
446:           scope.names.set(family, name)
447:       })
448:     })
449:   } else {
450:     ;({ cssText, scopes } = await prepareFontCSS(
451:       clonedNode,
452:       options,
453:       styleSource,
454:     ))
455:   }
```

## src/util.ts:229-249

```text
229: export async function svgToDataURL(svg: SVGElement): Promise<string> {
230:   return Promise.resolve()
231:     .then(() => new XMLSerializer().serializeToString(svg))
232:     .then((xml) =>
233:       // eslint-disable-next-line no-control-regex
234:       xml.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ''),
235:     )
236:     .then(encodeURIComponent)
237:     .then((html) => `data:image/svg+xml;charset=utf-8,${html}`)
238: }
239: 
240: export async function nodeToDataURL(
241:   node: HTMLElement,
242:   width: number,
243:   height: number,
244:   ownerDocument: Document = node.ownerDocument,
245:   clonedStyles = '',
246: ): Promise<string> {
247:   const xmlns = 'http://www.w3.org/2000/svg'
248:   const svg = ownerDocument.createElementNS(xmlns, 'svg')
249:   const foreignObject = ownerDocument.createElementNS(xmlns, 'foreignObject')
```

## src/util.ts:268-270

```text
268:   svg.appendChild(foreignObject)
269:   foreignObject.appendChild(node)
270:   return svgToDataURL(svg)
```

## vitest.browser.config.mts:143-149

```text
143:         async collectGarbage({ page, frame }) {
144:           const target = await frame()
145:           await page.requestGC()
146:           // Firefox's parent-process GC request can finish before child GC/CC.
147:           // Round-trip through the test frame before resuming its assertions.
148:           await target.evaluate(() => undefined)
149:         },
```
