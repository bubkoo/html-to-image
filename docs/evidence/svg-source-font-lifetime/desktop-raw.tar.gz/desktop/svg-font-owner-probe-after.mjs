import {createServer} from 'node:http'
import {readFile,writeFile} from 'node:fs/promises'
import {resolve} from 'node:path'
import {chromium,firefox,webkit} from 'playwright'
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname
 if(path==='/page.html'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><body></body>');return}
 const file=path==='/font.ttf'?'test/browser/fixtures/font-metrics.ttf':path.startsWith('/es/')?'.'+path:null
 if(file){try{res.setHeader('Content-Type',path.endsWith('.js')?'text/javascript':'font/ttf');res.end(await readFile(resolve(file)));return}catch{}}
 res.writeHead(404).end()
})
await new Promise(r=>server.listen(4496,'127.0.0.1',r))
const result={source:'7206ada plus compiled dispose-only font-list clear experiment',engines:{}}
try{
 for(const [name,engine] of Object.entries({chromium,firefox,webkit})){
  const browser=await engine.launch()
  try{
   const page=await browser.newPage();await page.goto('http://127.0.0.1:4496/page.html');const rows=[]
   for(const mode of ['plain-none','plain-held','font-none','font-held','font-dropped']){
    await page.evaluate(async mode=>{
     const {createSVGStyleEnvironment}=await import('/es/svg-style-scope.js')
     const frame=document.createElement('iframe');const ready=new Promise(r=>frame.onload=r)
     const family='OwnedFont'+crypto.randomUUID()
     frame.srcdoc='<!doctype html><style>'+ (mode.startsWith('font-')?'@font-face{font-family:"'+family+'";src:url("/font.ttf")}':'')+'</style><body>Owned font lifetime control</body>'
     document.body.append(frame);await ready;frame.onload=null
     const doc=frame.contentDocument
     if(mode.startsWith('font-')){await doc.fonts.load('20px "'+family+'"');await doc.fonts.ready}
     let owner
     if(!mode.endsWith('-none')){owner=createSVGStyleEnvironment(doc);await owner.getDocument();owner.dispose()}
     window.ownerRoots={owner:mode.endsWith('-held')?owner:undefined,reference:new WeakRef(doc)}
     frame.remove()
    },mode)
    await page.requestGC();await page.requestGC();await page.requestGC()
    rows.push({mode,collected:await page.evaluate(()=>!window.ownerRoots.reference.deref())})
    await page.evaluate(()=>{window.ownerRoots=undefined})
   }
   result.engines[name]={version:browser.version(),rows}
  }finally{await browser.close()}
 }
}finally{await new Promise(r=>server.close(r))}
await writeFile('output/playwright/svg-font-owner-probe-after.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
