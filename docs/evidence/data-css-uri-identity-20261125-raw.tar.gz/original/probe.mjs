import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const dir = path.dirname(fileURLToPath(import.meta.url))
const repo = path.resolve(dir, '../../..')
const require = createRequire(path.join(repo, 'package.json'))
const { chromium, firefox, webkit } = require('playwright')
const umd = fs.readFileSync(path.join(dir, 'html-to-image.umd.js'), 'utf8')
const css = '@keyframes identity_probe{from{opacity:1}to{opacity:1}}.box::before{content:"";position:absolute;inset:0;background:transparent;animation:identity_probe 100s linear infinite paused;animation-delay:-1s}'
const original = 'data:text/css;charset=utf-8,' + encodeURIComponent(css)
const alternate = 'data:text/css;charset=utf-8;base64,' + Buffer.from(css).toString('base64')
fs.writeFileSync(path.join(dir, 'stylesheet.css'), css)
fs.writeFileSync(path.join(dir, 'uri-inputs.json'), JSON.stringify({ css, original, alternate }, null, 2) + '\n')
const report = { at: new Date().toISOString(), cases: [], noManualWaitOrRetry: true, UMDsha256: crypto.createHash('sha256').update(umd).digest('hex') }
for (const [engine, type] of Object.entries({ chromium, firefox, webkit })) {
  const record = { engine, httpRequests: [], hooks: {} }
  report.cases.push(record)
  let browser
  try {
    record.launchRequestedUTC = new Date().toISOString()
    browser = await type.launch({ headless: true })
    record.launchResolvedUTC = new Date().toISOString()
    record.browserVersion = browser.version()
    const page = await browser.newPage({ viewport: { width: 160, height: 100 }, deviceScaleFactor: 1 })
    page.on('request', (request) => {
      if (/^https?:/.test(request.url())) record.httpRequests.push(request.url())
    })
    await page.route('http://**', (route) => route.abort())
    await page.route('https://**', (route) => route.abort())
    await page.setContent('<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0}</style></head><body></body></html>')
    await page.addScriptTag({ content: umd })
    record.prepared = await page.evaluate(async ({ original, alternate, css }) => {
      const source = document.createElement('div')
      source.id = 'source'
      source.style.cssText = 'width:40px;height:20px;margin:0;padding:0;border:0;position:relative'
      const link = document.createElement('link')
      link.rel = 'stylesheet'
      link.href = original
      const style = document.createElement('style')
      style.textContent = `link[href="${original}"] ~ .box {background:red!important} link:not([href="${original}"]) ~ .box {background:blue!important}`
      const box = document.createElement('div')
      box.className = 'box'
      box.style.cssText = 'width:40px;height:20px;margin:0;padding:0;border:0;position:relative'
      source.append(link, style, box)
      const loaded = new Promise((resolve, reject) => {
        link.onload = resolve
        link.onerror = () => reject(new Error('Source data stylesheet did not load'))
      })
      document.body.append(source)
      await loaded
      link.onload = null
      link.onerror = null
      const first = await (await fetch(original)).text()
      const second = await (await fetch(alternate)).text()
      const animations = source.getAnimations({ subtree: true })
      const pseudo = getComputedStyle(box, '::before')
      window.identitySourceBefore = source.outerHTML
      return { sameCSSBytes: first === css && second === css, uriDifferent: original !== alternate, href: link.getAttribute('href'), background: getComputedStyle(box).backgroundColor, pseudoAnimationName: pseudo.animationName, pseudoOpacity: pseudo.opacity, animationCount: animations.length, animationStates: animations.map((a) => ({ playState: a.playState, currentTime: a.currentTime })), outerHTML: source.outerHTML }
    }, { original, alternate, css })
    fs.writeFileSync(path.join(dir, `${engine}-source-before.html`), record.prepared.outerHTML)
    if (!record.prepared.sameCSSBytes || !record.prepared.uriDifferent || record.prepared.animationCount < 1 || record.prepared.background !== 'rgb(255, 0, 0)') throw new Error('Invalid native fixture/control')
    const nativePNG = await page.locator('#source').screenshot({ scale: 'css', animations: 'allow' })
    fs.writeFileSync(path.join(dir, `${engine}-native.png`), nativePNG)
    for (const variant of ['default', 'reencoded']) {
      const outcome = await page.evaluate(async ({ variant, original, alternate }) => {
        const hooks = []
        const options = { skipFonts: true, pixelRatio: 1 }
        if (variant === 'reencoded') options.onCloneNode = (_original, copy) => {
          if (copy.nodeType === 1 && copy.localName === 'link' && copy.getAttribute('href') === original) {
            const styleBefore = copy.getAttribute('style')
            const before = copy.getAttribute('href')
            copy.setAttribute('href', alternate)
            hooks.push({ before, after: copy.getAttribute('href'), inlineStyleUnchanged: styleBefore === copy.getAttribute('style') })
          }
        }
        const blob = await htmlToImage.toBlob(document.querySelector('#source'), options)
        if (!blob) throw new Error('Missing PNG Blob')
        const dataURL = await new Promise((resolve, reject) => {
          const reader = new FileReader()
          reader.onload = () => resolve(reader.result)
          reader.onerror = reject
          reader.readAsDataURL(blob)
        })
        return { dataURL, mime: blob.type, hooks }
      }, { variant, original, alternate })
      const bytes = Buffer.from(outcome.dataURL.split(',')[1], 'base64')
      fs.writeFileSync(path.join(dir, `${engine}-${variant}.png`), bytes)
      record.hooks[variant] = outcome.hooks
      record[variant] = await page.evaluate(async (url) => {
        const image = new Image()
        image.src = url
        await image.decode()
        const canvas = document.createElement('canvas')
        canvas.width = image.naturalWidth
        canvas.height = image.naturalHeight
        const context = canvas.getContext('2d')
        context.drawImage(image, 0, 0)
        return { width: canvas.width, height: canvas.height, rgba: Array.from(context.getImageData(0, 0, canvas.width, canvas.height).data) }
      }, outcome.dataURL)
    }
    record.native = await page.evaluate(async (url) => {
      const image = new Image()
      image.src = url
      await image.decode()
      const canvas = document.createElement('canvas')
      canvas.width = image.naturalWidth
      canvas.height = image.naturalHeight
      const ctx = canvas.getContext('2d')
      ctx.drawImage(image, 0, 0)
      return { width: canvas.width, height: canvas.height, rgba: Array.from(ctx.getImageData(0, 0, canvas.width, canvas.height).data) }
    }, 'data:image/png;base64,' + nativePNG.toString('base64'))
    record.after = await page.evaluate(() => {
      const source = document.querySelector('#source')
      return { outerHTML: source.outerHTML, sourceUnchanged: source.outerHTML === window.identitySourceBefore, href: source.querySelector('link').getAttribute('href'), background: getComputedStyle(source.querySelector('.box')).backgroundColor }
    })
    fs.writeFileSync(path.join(dir, `${engine}-source-after.html`), record.after.outerHTML)
    const classify = (data) => {
      let red = 0, blue = 0, other = 0
      for (let i = 0; i < data.length; i += 4) {
        if (data[i] === 255 && data[i + 1] === 0 && data[i + 2] === 0 && data[i + 3] === 255) red++
        else if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 255 && data[i + 3] === 255) blue++
        else other++
      }
      return { red, blue, other }
    }
    const diff = (left, right) => left.reduce((n, value, i) => n + (value !== right[i] ? 1 : 0), 0)
    record.summary = {
      native: classify(record.native.rgba), default: classify(record.default.rgba), reencoded: classify(record.reencoded.rgba),
      defaultNativeChannels: diff(record.default.rgba, record.native.rgba),
      reencodedNativeChannels: diff(record.reencoded.rgba, record.native.rgba),
      defaultReencodedChannels: diff(record.default.rgba, record.reencoded.rgba),
      dimensions: [record.native, record.default, record.reencoded].map((p) => [p.width, p.height]), sourceUnchanged: record.after.sourceUnchanged,
    }
    delete record.native.rgba
    delete record.default.rgba
    delete record.reencoded.rgba
  } catch (error) {
    record.error = { name: error.name, message: error.message, stack: error.stack }
    process.exitCode = 1
  } finally {
    if (browser) {
      record.closeRequestedUTC = new Date().toISOString()
      await browser.close()
      record.closeResolvedUTC = new Date().toISOString()
    }
    fs.writeFileSync(path.join(dir, 'results.json'), JSON.stringify(report, null, 2) + '\n')
  }
}
