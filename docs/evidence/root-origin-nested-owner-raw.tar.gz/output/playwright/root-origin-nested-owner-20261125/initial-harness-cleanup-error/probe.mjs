import{createServer}from'node:http'
import{readFile,writeFile}from'node:fs/promises'
import{execFileSync}from'node:child_process'
import{createHash,randomUUID}from'node:crypto'
import{chromium,firefox,webkit}from'playwright'
import ts from'typescript'
const dir=new URL('./',import.meta.url)
const dom=execFileSync('git',['show','d2501695:src/dom.ts']).toString()
const font=await readFile('test/browser/fixtures/font-metrics.ttf')
await writeFile(new URL('input/src__dom.ts',dir),dom);await writeFile(new URL('input/font-metrics.ttf',dir),font)
const fontURL='data:font/ttf;base64,'+font.toString('base64')
const scene=await readFile(new URL('scene.js',dir),'utf8')
const bootstrap='(()=>{const exports={};'+ts.transpileModule(dom,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2019}}).outputText+';window.__nestedDOM=exports})()'
const http=[]
const server=createServer((request,response)=>{
const url=new URL(request.url,'http://localhost'),path=url.pathname
const row={path,utc:new Date().toISOString(),method:request.method};http.push(row)
let body,mime
if(path==='/'){mime='text/html';body='<!doctype html><link rel="icon" href="data:,"><body><input id="focus"><div id="source"></div></body>'}
else if(path.endsWith('.ttf')){mime='font/ttf';body=font}
else if(path.endsWith('.css')){mime='text/css';body='.remote-loaded{color:red}'}
else if(path.endsWith('.js')){mime='text/javascript';body='top.__nestedScriptRuns++'}
else if(path.endsWith('.html')||path.endsWith('form')){mime='text/html';body='<!doctype html><body>Owned HTTP negative control</body>'}
else{mime='image/svg+xml';body='<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="red"/></svg>'}
row.status=200;row.mime=mime;response.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store'}).end(body)
})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
const origin=`http://127.0.0.1:${server.address().port}`
const report={at:new Date().toISOString(),inputs:{domSHA256:createHash('sha256').update(dom).digest('hex'),fontSHA256:createHash('sha256').update(font).digest('hex'),sceneSHA256:createHash('sha256').update(scene).digest('hex')},cases:[],browserTimes:[],oldSameFrameEvidence:'../root-origin-measurement-20261125/producer-security-results.json',scope:'Nested-owner security hypothesis only. New measurement-specific owner frame-src blob exception; existing environment policies and production sources remain untouched. Any actual HTTP/script/XML mismatch rejects route before coordinates.'}
const run=async(engine,type,mode)=>{
const times={engine,mode,launchRequestedUTC:new Date().toISOString()};report.browserTimes.push(times)
const browser=await type.launch({headless:true});times.launchResolvedUTC=new Date().toISOString()
const context=await browser.newContext({viewport:{width:414,height:896},deviceScaleFactor:1}),page=await context.newPage(),events=[],messages=[]
page.on('request',request=>{if(request.url().includes('/marker/'))events.push({kind:'attempt',url:request.url(),utc:new Date().toISOString()})})
page.on('requestfailed',request=>{if(request.url().includes('/marker/'))events.push({kind:'failed',url:request.url(),failure:request.failure(),utc:new Date().toISOString()})})
page.on('response',response=>{if(response.url().includes('/marker/'))events.push({kind:'response',url:response.url(),status:response.status(),mime:response.headers()['content-type'],utc:new Date().toISOString()})})
page.on('console',message=>messages.push({type:message.type(),text:message.text(),utc:new Date().toISOString()}))
const id=randomUUID()
let result
try{
await page.goto(origin);await page.addScriptTag({content:bootstrap});await page.addScriptTag({content:scene})
result=await page.evaluate(input=>runNestedOwnerScene(input),{mode,id,origin,fontURL})
}finally{times.closeRequestedUTC=new Date().toISOString();await context.close();await browser.close();times.closeResolvedUTC=new Date().toISOString()}
const serverRequests=http.filter(x=>x.path.startsWith('/marker/'+id+'/'))
const nestedBlobDenied=mode==='security'&&result.payloads?.sourceBlobURL&&messages.some(x=>x.text.includes(result.payloads.sourceBlobURL)&&/Content.Security.Policy|content security policy|violates|blocked|Refused|拒绝/i.test(x.text))
const cleanup=result.frames===0&&result.stats.activeWaits===0&&result.stats.added===result.stats.removed&&result.revoked.every(Boolean)&&result.sourceUnchanged&&result.callerBodyUnchanged&&result.focusAfter===result.focusBefore&&result.constructorsBefore===result.constructorsAfter
let passed=false
if(mode==='security')passed=result.status==='loaded'&&result.contentType==='image/svg+xml'&&result.namespace==='http://www.w3.org/2000/svg'&&result.ownerMetaRetained&&result.ownerStillHTML&&result.nestedOwnerMatches&&result.scriptRuns===0&&serverRequests.length===0&&result.security.dataFonts===1&&result.security.dataImage.join()==='4,4'&&(result.security.nestedBlob.marker||nestedBlobDenied)&&cleanup
else if(mode==='semantics')passed=result.status==='loaded'&&result.contentType==='image/svg+xml'&&result.scriptRuns===0&&serverRequests.length===0&&JSON.stringify(result.semantics.document)===JSON.stringify(result.semantics.svgImage)&&result.semantics.document.x===7&&result.semantics.document.y===23&&result.semantics.document.height===41&&cleanup
else passed=result.status==='rejected'&&result.expectedCancellation&&!result.watchdog&&serverRequests.length===0&&cleanup
const row={engine,version:browser.version(),mode,id,...result,nestedBlobDenied:!!nestedBlobDenied,serverRequests,events,messages,passed}
report.cases.push(row);console.log(JSON.stringify({engine,mode,status:row.status,contentType:row.contentType,serverRequests:serverRequests.map(x=>x.path),scripts:row.scriptRuns,nestedBlob:row.security?.nestedBlob,semantics:row.semantics,cleanup,passed}))
await writeFile(new URL(engine+'-'+mode+'.json',dir),JSON.stringify(row,null,2))
return passed
}
try{
let allSecurity=true,allSemantics=true
for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
const security=await run(engine,type,'security');allSecurity&&=security
if(security){const semantics=await run(engine,type,'semantics');allSemantics&&=semantics}else{allSemantics=false;report.cases.push({engine,mode:'semantics',notRun:true,reason:'Security gate rejected; no coordinate/semantic acceptance attempted.'})}
}
report.securityGatePassed=allSecurity;report.XMLSemanticsGatePassed=allSemantics
if(allSecurity&&allSemantics){await run('chromium',chromium,'cancel-null');await run('chromium',chromium,'dispose-pending')}else report.cancellationNotRun='Stopped at failed safety/semantic gate; no broad repeat of prior51 controls.'
report.decision=allSecurity&&allSemantics?'Minimal security/XML controls passed; no production integration or general coordinates claim.':'Reject nested-owner route for measured safety/XML failure; no coordinate integration.'
}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));report.http=http;report.cleanup={browsersClosed:true,serverClosed:true,mainlineModified:false,existingPoliciesModified:false,oldEvidenceModified:false,phoneOperated:false};await writeFile(new URL('results.json',dir),JSON.stringify(report,null,2))}
