// Test-only nested-owner hypothesis. Input is a primitive DTO, never source DOM.
window.runNestedOwnerScene = async input => {
  const {readDOMProperty:r,readDOMMethod:m,writeDOMProperty:w}=window.__nestedDOM
  const dimensions={width:160,height:80}
  const controller=new AbortController(),signal=controller.signal
  const disposedReason=new Error('Owned nested-owner scene disposed')
  const watchdogReason=new Error('Independent5s nested-owner probe watchdog')
  const stats={added:0,removed:0,stages:[],createdURLs:[],revokedURLs:[],activeWaits:0}
  const urls=new Set()
  let owner,child
  const add=listener=>{m(signal,'addEventListener')('abort',listener,{once:true});stats.added++}
  const remove=listener=>{m(signal,'removeEventListener')('abort',listener);stats.removed++}
  const stage=name=>{stats.stages.push({name,utc:new Date().toISOString(),at:performance.now()});if(input.mode==='cancel-null'&&name==='nested-navigation-started')controller.abort(null);if(input.mode==='dispose-pending'&&name==='owner-started')controller.abort(disposedReason)}
  const wait=start=>new Promise((resolve,reject)=>{
    let settled=false,nativeCleanup
    stats.activeWaits++
    const finish=(ok,value)=>{if(settled)return;settled=true;remove(abort);stats.activeWaits--;nativeCleanup?.();if(ok)resolve(value);else reject(value)}
    const abort=()=>finish(false,r(signal,'reason'))
    add(abort)
    if(r(signal,'aborted')){abort();return}
    try{const cleanup=start(value=>finish(true,value),error=>finish(false,error));if(settled)cleanup?.();else nativeCleanup=cleanup}catch(error){finish(false,error)}
  })
  const timer=setTimeout(()=>controller.abort(watchdogReason),5000)
  const policy="default-src 'none';script-src 'none';style-src 'unsafe-inline' data:;img-src data: blob:;font-src data:;frame-src blob:;object-src 'none';connect-src 'none';base-uri 'none';form-action 'none'"
  const sourceDTO=(()=>{
    if(!customElements.get('nested-owner-source-element'))customElements.define('nested-owner-source-element',class extends HTMLElement{constructor(){super();window.__nestedCtor=(window.__nestedCtor||0)+1}})
    document.getElementById('source').innerHTML='<nested-owner-source-element data-owned="source"></nested-owner-source-element>'
    document.getElementById('focus').focus()
    return{markup:document.getElementById('source').innerHTML,body:document.body.innerHTML,constructors:window.__nestedCtor,focus:document.activeElement.id}
  })()
  window.__nestedScriptRuns=0
  const path=name=>input.origin+'/marker/'+input.id+'/'+name
  const dataSVG='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="blue"/></svg>')
  const sourceHTML=`<!doctype html><meta charset="utf-8"><style>@import url("${path('blob-import.css')}");@font-face{font-family:SourceBlobRemote;src:url("${path('blob-font.ttf')}")}body{font-family:SourceBlobRemote}</style><script>top.__nestedScriptRuns++</script><script src="${path('blob-script.js')}"></script><body><span id="source-blob-html-marker">A</span><img src="${path('blob-image.svg')}" onerror="top.__nestedScriptRuns++"><iframe src="${path('blob-frame.html')}"></iframe><form action="${path('blob-form')}" method="post"><input autofocus></form></body>`
  let sourceBlobURL
  let result
  try{
    if(input.mode==='security'){
      sourceBlobURL=URL.createObjectURL(new Blob([sourceHTML],{type:'text/html'}));urls.add(sourceBlobURL);stats.createdURLs.push(sourceBlobURL)
    }
    const svg=input.mode==='security'
      ?`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>@import url("${path('direct-import.css')}");@font-face{font-family:NestedAllowed;src:url("${input.fontURL}")}@font-face{font-family:DirectRemote;src:url("${path('direct-font.ttf')}")}</style><script>top.__nestedScriptRuns++</script><script href="${path('direct-script.js')}"/><image href="${path('direct-image.svg')}" width="4" height="4"/><foreignObject width="160" height="80"><div xmlns="http://www.w3.org/1999/xhtml" id="measure" style="width:80px;height:40px;margin:16px 0 0 7px;background:red"><span style="font-family:DirectRemote">A</span>${sourceDTO.markup}<img id="allowed-data" src="${dataSVG}"/><img src="${path('direct-html-image.svg')}" onerror="top.__nestedScriptRuns++"/><iframe id="direct-http-frame" src="${path('direct-frame.html')}"></iframe><iframe id="source-blob-frame" src="${sourceBlobURL}"></iframe><form action="${path('direct-form')}" method="post"><input autofocus="autofocus"/></form></div></foreignObject></svg>`
      :`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>DIV{margin-left:43px!important}:root>foreignObject #measure{height:41px!important}@media(min-width:150px){#measure{margin-top:23px!important}}@media(min-width:300px){#measure{margin-top:33px!important}}</style><foreignObject width="160" height="80"><div xmlns="http://www.w3.org/1999/xhtml" id="measure" style="width:80px;height:40px;margin:16px 0 0 7px;background:red"></div></foreignObject></svg>`
    const ownerDoc=await wait((resolve,reject)=>{
      owner=m(document,'createElement')('iframe');const ownOwner=owner
      m(ownOwner,'setAttribute')('sandbox','allow-same-origin');m(ownOwner,'setAttribute')('inert','');m(ownOwner,'setAttribute')('tabindex','-1');m(ownOwner,'setAttribute')('aria-hidden','true')
      w(r(ownOwner,'style'),'cssText',`position:fixed;left:-99999px;top:0;width:${dimensions.width}px;height:${dimensions.height}px;opacity:0;border:0;pointer-events:none`)
      w(ownOwner,'onload',()=>{try{const doc=r(ownOwner,'contentDocument'),meta=doc&&m(doc,'querySelector')('meta[data-nested-owner-policy]');if(meta&&r(meta,'content')===policy)resolve(doc)}catch(error){reject(error)}})
      w(ownOwner,'srcdoc',`<!doctype html><meta data-nested-owner-policy http-equiv="Content-Security-Policy" content="${policy}"><style>html,body{margin:0;padding:0}</style><body></body>`)
      m(document.documentElement,'append')(ownOwner);stage('owner-started')
      return()=>w(ownOwner,'onload',null)
    })
    stats.ownerReady={URL:r(ownerDoc,'URL'),contentType:r(ownerDoc,'contentType'),metaConfirmed:r(m(ownerDoc,'querySelector')('meta[data-nested-owner-policy]'),'content')===policy,sandbox:m(owner,'getAttribute')('sandbox')}
    stage('owner-ready')
    const view=r(ownerDoc,'defaultView')
    const blob=Reflect.construct(r(view,'Blob'),[[svg],{type:'image/svg+xml'}])
    const svgURL=m(r(view,'URL'),'createObjectURL')(blob);urls.add(svgURL);stats.createdURLs.push(svgURL)
    stats.URLCreation='Borrowed restricted owner Blob/URL native methods, not a claim of actual owner-realm script execution; nested frame ownerDocument is the policy hypothesis.'
    const svgDoc=await wait((resolve,reject)=>{
      child=m(ownerDoc,'createElement')('iframe');const ownChild=child
      m(ownChild,'setAttribute')('sandbox','allow-same-origin');m(ownChild,'setAttribute')('inert','');m(ownChild,'setAttribute')('tabindex','-1')
      w(r(ownChild,'style'),'cssText','display:block;width:160px;height:80px;border:0;margin:0;padding:0')
      w(ownChild,'onload',()=>{try{const doc=r(ownChild,'contentDocument');if(!doc||r(doc,'URL')!==svgURL)return;resolve(doc)}catch(error){reject(error)}})
      w(ownChild,'src',svgURL);m(r(ownerDoc,'body'),'append')(ownChild);stage('nested-navigation-started')
      return()=>w(ownChild,'onload',null)
    })
    stage('svg-ready')
    const targetRoot=r(svgDoc,'documentElement')
    const contentType=r(svgDoc,'contentType'),namespace=r(targetRoot,'namespaceURI')
    result={status:'loaded',contentType,namespace,ownerMetaRetained:r(m(ownerDoc,'querySelector')('meta[data-nested-owner-policy]'),'content')===policy,ownerStillHTML:r(ownerDoc,'contentType')==='text/html',nestedOwnerMatches:r(child,'ownerDocument')===ownerDoc,childSandbox:m(child,'getAttribute')('sandbox'),payloads:{svg,sourceHTML:input.mode==='security'?sourceHTML:undefined,sourceBlobURL}}
    if(contentType!=='image/svg+xml'||namespace!=='http://www.w3.org/2000/svg')throw new Error('Nested target is not a real XML SVGDocument')
    if(input.mode==='security'){
      const fonts=r(svgDoc,'fonts');const allowed=await wait((resolve,reject)=>{m(fonts,'load')('18px NestedAllowed','A').then(resolve,reject)})
      await wait((resolve,reject)=>r(fonts,'ready').then(resolve,reject))
      const image=m(svgDoc,'getElementById')('allowed-data');await wait((resolve,reject)=>m(image,'decode')().then(resolve,reject))
      const descendant=m(svgDoc,'getElementById')('source-blob-frame'),nestedDoc=r(descendant,'contentDocument')
      const nestedState={URL:nestedDoc?r(nestedDoc,'URL'):'unknown',readyState:nestedDoc?r(nestedDoc,'readyState'):'unknown',marker:nestedDoc?!!m(nestedDoc,'getElementById')('source-blob-html-marker'):false}
      if(nestedDoc&&nestedState.marker){await wait((resolve,reject)=>r(r(nestedDoc,'fonts'),'ready').then(resolve,reject));const form=m(nestedDoc,'querySelector')('form');if(form)m(form,'requestSubmit')()}
      m(m(svgDoc,'querySelector')('form'),'requestSubmit')()
      result.security={dataImage:[r(image,'naturalWidth'),r(image,'naturalHeight')],dataFonts:allowed.length,nestedBlob:nestedState,HTTPImages:Array.from(m(svgDoc,'querySelectorAll')('img')).map(image=>({src:r(image,'src'),complete:r(image,'complete'),width:r(image,'naturalWidth')})),nestedHTTPImages:nestedDoc&&nestedState.marker?Array.from(m(nestedDoc,'querySelectorAll')('img')).map(image=>({src:r(image,'src'),complete:r(image,'complete'),width:r(image,'naturalWidth')})):[]}
    }else{
      const box=m(m(svgDoc,'getElementById')('measure'),'getBoundingClientRect')(),fo=m(m(svgDoc,'querySelector')('foreignObject'),'getBoundingClientRect')()
      const actual=new Image();actual.src='data:image/svg+xml,'+encodeURIComponent(svg);await wait((resolve,reject)=>actual.decode().then(resolve,reject))
      const canvas=document.createElement('canvas');canvas.width=160;canvas.height=80;const ctx=canvas.getContext('2d');ctx.drawImage(actual,0,0);const pixels=ctx.getImageData(0,0,160,80).data
      let x0=160,y0=80,x1=-1,y1=-1
      for(let y=0;y<80;y++)for(let x=0;x<160;x++){const i=(y*160+x)*4;if(pixels[i]===255&&pixels[i+1]===0&&pixels[i+2]===0&&pixels[i+3]===255){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}}
      result.semantics={document:{x:box.x-fo.x,y:box.y-fo.y,width:box.width,height:box.height},svgImage:{x:x0,y:y0,width:x1-x0+1,height:y1-y0+1},rootMatches:m(targetRoot,'matches')(':root'),media150:r(m(r(svgDoc,'defaultView'),'matchMedia')('(min-width:150px)'),'matches'),media300:r(m(r(svgDoc,'defaultView'),'matchMedia')('(min-width:300px)'),'matches')}
    }
  }catch(error){result={...(result||{}),status:'rejected',watchdog:error===watchdogReason,expectedCancellation:input.mode==='cancel-null'?error===null:input.mode==='dispose-pending'?error===disposedReason:false,error:error===null?'null':String(error)}}finally{
    clearTimeout(timer)
    if(child){w(child,'onload',null);m(child,'remove')();child=undefined}
    if(owner){w(owner,'onload',null);m(owner,'remove')();owner=undefined}
    urls.forEach(url=>{m(URL,'revokeObjectURL')(url);stats.revokedURLs.push(url)});urls.clear()
  }
  const revoked=[]
  for(const url of stats.createdURLs){try{await fetch(url);revoked.push(false)}catch{revoked.push(true)}}
  return{...result,stats,revoked,frames:document.querySelectorAll('iframe').length,scriptRuns:window.__nestedScriptRuns,constructorsBefore:sourceDTO.constructors,constructorsAfter:window.__nestedCtor,sourceUnchanged:document.getElementById('source').innerHTML===sourceDTO.markup,callerBodyUnchanged:document.body.innerHTML===sourceDTO.body,focusBefore:sourceDTO.focus,focusAfter:document.activeElement.id}
}
