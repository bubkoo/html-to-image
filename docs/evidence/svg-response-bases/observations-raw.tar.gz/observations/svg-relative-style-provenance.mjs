import {createServer} from 'node:http'
import {writeFile} from 'node:fs/promises'
import {chromium,firefox,webkit} from 'playwright'
const trace=[]
const server=createServer((req,res)=>{trace.push(req.url);res.setHeader('Content-Type','text/html');res.end('<!doctype html>')})
await new Promise(r=>server.listen(4498,'127.0.0.1',r))
const results={purpose:'Observation: preserve original attributes/selectors while distinguishing unresolved declaration origins',engines:{}}
try{
 for(const [name,engine] of Object.entries({chromium,firefox,webkit})){
  const browser=await engine.launch()
  try{
   const page=await browser.newPage();await page.goto('http://127.0.0.1:4498/page.html')
   results.engines[name]=await page.evaluate(async()=>{
    const owned='https://'+crypto.randomUUID()+'.invalid/owned/document.svg'
    const frame=document.createElement('iframe');frame.setAttribute('sandbox','allow-same-origin')
    const ready=new Promise(r=>frame.onload=r)
    frame.srcdoc=`<!doctype html><base href="${owned}"><meta http-equiv="Content-Security-Policy" content="default-src 'none';style-src 'unsafe-inline';img-src 'none';base-uri 'none'"><body></body>`
    document.body.append(frame);await ready;frame.onload=null
    try{
     const doc=frame.contentDocument,host=doc.createElement('div'),shadow=host.attachShadow({mode:'open'})
     const ns='http://www.w3.org/2000/svg',svg=doc.createElementNS(ns,'svg')
     svg.innerHTML='<style>.file{fill:url(http://127.0.0.1:4498/assets/sprite.svg#paint)}[fill="url(sprite.svg#paint) purple"]{stroke:blue}</style><defs><linearGradient id="paint"><stop stop-color="green"/></linearGradient></defs>'
     const rows=[]
     for(const [id,text] of Object.entries({attr:'fill="url(sprite.svg#paint) purple"',inline:'style="fill:url(sprite.svg#paint) purple"',file:'class="file"',absolute:'fill="url(http://127.0.0.1:4498/sprite.svg#paint) purple"',fragment:'fill="url(#paint) purple"',xml:'xml:base="/xml/" fill="url(sprite.svg#paint) purple"'})){
      const g=doc.createElementNS(ns,'g');g.id=id;g.innerHTML=`<rect width="20" height="20" ${text}/>`;svg.append(g)
     }
     shadow.append(svg);doc.body.append(host)
     for(const g of svg.querySelectorAll('g')){const r=g.firstChild,s=doc.defaultView.getComputedStyle(r);rows.push({id:g.id,fill:s.fill,stroke:s.stroke,base:r.baseURI,attr:r.getAttribute('fill'),style:r.getAttribute('style')})}
     return{owned,base:doc.baseURI,url:doc.URL,rows}
    }finally{frame.remove()}
   })
  }finally{await browser.close()}
 }
}finally{await new Promise(r=>server.close(r))}
results.trace=trace
await writeFile('output/playwright/svg-relative-style-provenance.json',JSON.stringify(results,null,2)+'\n')
console.log(JSON.stringify(results,null,2))
