import {createServer} from 'node:http'
import {writeFile} from 'node:fs/promises'
import {chromium,firefox,webkit} from 'playwright'
const server=createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html>')});await new Promise(r=>server.listen(4499,'127.0.0.1',r))
const result={}
try{
 for(const [name,engine] of Object.entries({chromium,firefox,webkit})){
  const browser=await engine.launch()
  try{
   const page=await browser.newPage();await page.goto('http://127.0.0.1:4499/page.html')
   result[name]=await page.evaluate(async()=>{
    const frame=document.createElement('iframe');frame.id='owned-frame';frame.setAttribute('sandbox','allow-same-origin');frame.style.cssText='width:120px;height:20px;border:0'
    const html=`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none';style-src 'unsafe-inline';img-src blob:;base-uri 'none'"><style>body{margin:0}</style><body></body>`
    const ready=new Promise(r=>frame.onload=r);frame.srcdoc=html;document.body.append(frame);await ready
    const d=frame.contentDocument;d.open();d.write(html);d.close();const ns='http://www.w3.org/2000/svg',svg=d.createElementNS(ns,'svg');svg.setAttribute('width','120');svg.setAttribute('height','20');svg.innerHTML='<defs><linearGradient id="owned-paint"><stop stop-color="blue"/></linearGradient></defs>'
    const urls=[],uses=[]
    for(const [index,kind] of ['fragment','relative','absolute','missing','none','flat'].entries()){
     const fill={fragment:'url(#owned-paint)',relative:'url(page.html#owned-paint)',absolute:'url('+location.href+'#owned-paint)',missing:'url(#absent)',none:'none',flat:'green'}[kind]
     const xml=`<svg xmlns="${ns}"><defs><linearGradient id="owned-paint"><stop stop-color="green"/></linearGradient></defs><g id="probe"><rect width="20" height="20" fill="${fill}" pointer-events="visiblePainted"/></g></svg>`
     const url=URL.createObjectURL(new Blob([xml],{type:'image/svg+xml'}));urls.push(url);const use=d.createElementNS(ns,'use');use.id=kind;use.setAttribute('href',url+'#probe');use.setAttribute('x',String(index*20));svg.append(use);uses.push(use)
    }
    d.body.append(svg)
    try{const deadline=performance.now()+5000;while(uses.some(x=>x.getBBox().width!==20)&&performance.now()<deadline)await new Promise(r=>setTimeout(r,0));await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return{url:d.URL,hits:uses.map((u,i)=>({id:u.id,bbox:u.getBBox().width,hit:d.elementFromPoint(i*20+10,10)?.id||d.elementFromPoint(i*20+10,10)?.localName}))}}
    finally{window.ownedProbeURLs=urls}
   })
   await page.locator('#owned-frame').screenshot({path:`output/playwright/svg-painted-hit-${name}.png`})
   await page.evaluate(()=>{window.ownedProbeURLs.forEach(x=>URL.revokeObjectURL(x));document.querySelector('#owned-frame').remove()})
  }finally{await browser.close()}
 }
}finally{await new Promise(r=>server.close(r))}
await writeFile('output/playwright/svg-painted-hit-probe.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
