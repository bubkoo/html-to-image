from client import call,execute,folder,session
from pathlib import Path
from PIL import Image
import json,subprocess,re,time,base64,io,hashlib
address=re.search(r'\binet\s+(\d+\.\d+\.\d+\.\d+)',subprocess.check_output(['ifconfig','en15'],text=True)).group(1)
origin='http://'+address+':4373';prefix='/probe/'+str(time.time_ns())
call('/timeouts',{'pageLoad':60000,'script':120000})
call('/url',{'url':origin+prefix+'/page.html'})
execute('''
const prefix='''+json.dumps(prefix)+''';const root=document.createElement('div');root.id='source';root.style.cssText='display:flex;width:160px;height:20px;background:white';
for(const id of ['attr','inline','file','import','absolute','fragment','control']){
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('width','20');svg.setAttribute('height','20');svg.style.flex='none';const use=document.createElementNS(svg.namespaceURI,'use');use.setAttribute('href',prefix+'/assets/sprite.svg#'+id);use.setAttribute('width','20');use.setAttribute('height','20');svg.append(use);root.append(svg);
}
const yellow=document.createElement('div');yellow.style.cssText='width:20px;height:20px;background:yellow;flex:none';root.append(yellow);document.body.append(root);return true;
''')
for _ in range(80):
 if execute("return [...document.querySelectorAll('use')].every(x=>x.getBBox().width===20)"):break
 time.sleep(.1)
else:raise RuntimeError('source positive geometry unavailable')
time.sleep(.2)
meta=execute("return {rect:document.querySelector('#source').getBoundingClientRect().toJSON(),width:innerWidth,dpr:devicePixelRatio,markup:document.querySelector('#source').outerHTML,ua:navigator.userAgent}")
def photo(label):
 raw=base64.b64decode(call('/screenshot'));(folder/(label+'-screen.png')).write_bytes(raw)
 im=Image.open(io.BytesIO(raw)).convert('RGBA');scale=im.width/meta['width'];cx=round((meta['rect']['x']+150.5)*scale)
 rows=[y for y in range(im.height) if im.getpixel((cx,y))==(255,255,0,255)];runs=[]
 for y in rows:
  if not runs or y!=runs[-1][-1]+1:runs.append([y])
  else:runs[-1].append(y)
 valid=[r for r in runs if len(r)==round(20*scale)]
 if len(valid)!=1:raise RuntimeError('yellow alignment control failed '+str([(r[0],len(r)) for r in runs]))
 top=valid[0][0];left=round(meta['rect']['x']*scale);crop=Image.new('RGBA',(160,20))
 for y in range(20):
  for x in range(160):crop.putpixel((x,y),im.getpixel((left+int((x+.5)*scale),top+int((y+.5)*scale))))
 crop.save(folder/(label+'-native.png'))
 return {'centerPixels':[crop.getpixel((x,10)) for x in [10,30,50,70,90,110,130,150]],'screenSHA256':hashlib.sha256(raw).hexdigest(),'nativeRGBA_SHA256':hashlib.sha256(crop.tobytes()).hexdigest(),'screenSize':im.size,'scale':scale,'yellowControlTop':top}
before=photo('before')
result=call('/execute/async',{'script':'''const done=arguments[arguments.length-1];(async()=>{const api=await import('/es/index.js');const root=document.getElementById('source'),markup=root.outerHTML,requests=[];const renderer=api.createRenderer({pixelRatio:1,skipFonts:true,resources:{resolve:r=>{requests.push(r)}}});let snapshot;try{snapshot=await renderer.capture(root);const data=await snapshot.toImageData();return {requests,sourceUnchanged:markup===root.outerHTML,pixels:[10,30,50,70,90,110,130,150].map(x=>[...data.data.slice(4*(10*data.width+x),4*(10*data.width+x)+4)]),png:await snapshot.toPng(),diagnostics:snapshot.diagnostics}}finally{snapshot?.dispose();renderer.dispose()}})().then(done).catch(e=>done({error:String(e),stack:e.stack}));''','args':[]},timeout=125)
if result.get('png'):(folder/'capture.png').write_bytes(base64.b64decode(result.pop('png').split(',')[1]))
after=photo('after')
summary={'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'capabilities':{k:session['capabilities'].get(k) for k in ['platformName','safari:platformVersion','browserVersion','safari:deviceType','safari:useSimulator']},'columns':['attr','inline','file','import','absolute','fragment','control','yellow'],'meta':meta,'before':before,'export':result,'after':after,'nativeUnchanged':before['nativeRGBA_SHA256']==after['nativeRGBA_SHA256']}
(folder/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='meta'},indent=2))
