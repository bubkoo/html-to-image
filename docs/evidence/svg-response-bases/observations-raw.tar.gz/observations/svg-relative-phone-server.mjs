import {createServer} from 'node:http'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {resolve} from 'node:path'
import {chromium,firefox,webkit} from 'playwright'
const out=resolve('output/playwright/svg-relative-phone');await mkdir(out,{recursive:true})
const trace=[]
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname;trace.push(path)
 if(path==='/requests'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(trace));return}
 if(path.endsWith('/page.html')){res.setHeader('Content-Type','text/html');res.end('<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><style>body{margin:0}</style>');return}
 if(path.endsWith('/sprite.svg')){
  const imported='data:text/css,'+encodeURIComponent('.viaImport{fill:url("sprite.svg#paint") purple!important}')
  const color=path.includes('/assets/')?'green':'red'
  const ids=['attr','inline','file','import','absolute','control']
  const nodes=ids.map(id=>`<symbol id="${id}" viewBox="0 0 20 20"><rect width="20" height="20" ${id==='attr'?'fill="url(sprite.svg#paint) purple"':id==='inline'?'style="fill:url(sprite.svg#paint) purple"':id==='file'?'class="viaFile" fill="purple"':id==='import'?'class="viaImport" fill="purple"':id==='absolute'?`fill="url(http://${req.headers.host}${path}#paint) purple"`:'fill="green"'}/></symbol>`).join('')
  res.setHeader('Content-Type','image/svg+xml');res.setHeader('Cache-Control','no-store');res.end(`<svg xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="paint"><stop stop-color="${color}"/></linearGradient></defs><style>@import url('${imported}');.viaFile{fill:url(sprite.svg#paint) purple!important}</style>${nodes}</svg>`);return
 }
 if(path.startsWith('/es/')){try{res.setHeader('Content-Type','text/javascript');res.end(await readFile(resolve('.'+path)));return}catch{}}
 res.writeHead(404).end()
})
await new Promise(r=>server.listen(4373,'0.0.0.0',r))
console.log('Owned phone relative-base observation server ready');
