import {createServer} from 'node:http'
import {readFile,writeFile} from 'node:fs/promises'
import {resolve} from 'node:path'
import {firefox} from 'playwright'
const server=createServer(async(req,res)=>{const path=new URL(req.url,'http://localhost').pathname;if(path==='/page.html'){res.setHeader('Content-Type','text/html');res.end('<!doctype html>');return}const file=path==='/font.ttf'?'test/browser/fixtures/font-metrics.ttf':path.startsWith('/es/')?'.'+path:null;if(file){try{res.setHeader('Content-Type',path.endsWith('.js')?'text/javascript':'font/ttf');res.end(await readFile(resolve(file)));return}catch{}}res.writeHead(404).end()})
await new Promise(r=>server.listen(4497,'127.0.0.1',r))
const rows=[],browser=await firefox.launch()
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:4497/page.html')
 for(const font of [false,true]){
  if(font)await page.evaluate(async()=>{const s=document.createElement('style');s.textContent='@font-face{font-family:"Probe Retention";src:url(/font.ttf)}';document.head.append(s);await document.fonts.load('20px "Probe Retention"','A');await document.fonts.ready})
  for(let iteration=0;iteration<12;iteration++)for(const mode of ['native','native-clear-load','capture','capture-clear-load','environment-open','environment-probed']){
   await page.evaluate(async mode=>{
    if(mode.startsWith('environment')){
     const {createSVGStyleEnvironment}=await import('/es/svg-style-scope.js');const owner=createSVGStyleEnvironment(document);if(mode==='environment-probed')await owner.measurePolicy(()=>{});const reference=new WeakRef(await owner.getDocument());owner.dispose();window.ownedRetention={owner,reference};return
    }
    const frame=document.createElement('iframe');frame.srcdoc='<body style="margin:0;width:20px;height:20px;background:green"></body>';const ready=new Promise(resolve=>frame.onload=()=>resolve());document.body.append(frame);await ready
    if(mode.endsWith('clear-load'))frame.onload=null
    const reference=new WeakRef(frame.contentDocument)
    let renderer,capture
    if(mode.startsWith('capture')){const api=await import('/es/index.js');renderer=api.createRenderer({pixelRatio:1,skipFonts:true});capture=await renderer.capture(frame.contentDocument.body)}
    frame.remove();window.ownedRetention={reference,renderer,capture}
   },mode)
   await page.requestGC();await page.requestGC();await page.requestGC()
   const collected=await page.evaluate(()=>!window.ownedRetention.reference.deref());rows.push({font,iteration,mode,collected})
   await page.evaluate(()=>{window.ownedRetention.renderer?.dispose();window.ownedRetention=undefined})
  }
 }
 await writeFile('output/playwright/svg-redirect-file-css/retention-probe.json',JSON.stringify({source:'bafedeb9720a89b3c6fad0c98f70b51e2f7bdab1',version:browser.version(),rows},null,2)+'\n')
 console.log(JSON.stringify({measured:rows.length,failed:rows.filter(r=>!r.collected)}))
}finally{await browser.close();await new Promise(r=>server.close(r))}
