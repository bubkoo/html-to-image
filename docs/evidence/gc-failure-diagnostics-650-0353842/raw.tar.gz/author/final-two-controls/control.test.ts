/// <reference lib="es2021.weakref" />
import { expect, test } from 'vitest'
import { commands } from 'vitest/browser'
import { recordGCFailure } from '../../../../test/browser-unit/gc-failure'

function sourceReference(held: boolean) {
  const source = document.implementation.createHTMLDocument()
  if (held)
    Reflect.set(window, '__gcKnownStrongHolder', { sourceDocument: source })
  return new WeakRef(source)
}

test('successful collection creates no heap diagnostic', async () => {
  const reference = sourceReference(false)
  await commands.collectGarbage()
  await commands.collectGarbage()
  await commands.collectGarbage()
  const collected = reference.deref() === undefined
  if (!collected) await recordGCFailure(reference, collected, 'control-success')
  expect(collected).toBe(true)
})

test('deliberate strong holder preserves the original failing assertion', async () => {
  const reference = sourceReference(true)
  try {
    await commands.collectGarbage()
    await commands.collectGarbage()
    await commands.collectGarbage()
    const collected = reference.deref() === undefined
    const context = Object.freeze({
      originalCollected: collected,
      held: true,
      label: 'deliberate-strong-held-control',
      primaryGCRequests: 3,
      nullable: null,
    })
    if (!collected)
      await recordGCFailure(reference, collected, 'control-deliberate-strong-held', context)
    expect(collected).toBe(true)
  } finally {
    Reflect.deleteProperty(window, '__gcKnownStrongHolder')
  }
})
