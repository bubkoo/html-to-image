from pathlib import Path
import subprocess,json,hashlib,time,os,socket

root=Path('/Users/bytedance/.codex/worktrees/svg-style-cancellation/html-to-image')
assert Path.cwd().resolve()==root
folder=root/'output/playwright/svg-style-cancellation-20261125'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');base='25e83810cb7d1865b6a2108c67f195b6a09a05e3';source='d2501695c9aceafd7e301486bb1468631b50a5f4'
paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');paths=[p for p in paths if p]
def manifest():
    selected=set(paths)
    for dirname in ['es','lib','dist']:selected.update(str(f.relative_to(root)) for f in (root/dirname).rglob('*') if f.is_file())
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(selected)}
initial=manifest()
identity={'base':base,'sourceCommit':source,'head':head,'tree':git('rev-parse','HEAD^{tree}'),'branch':git('branch','--show-current'),'worktree':str(root),'node':subprocess.check_output(['node','--version'],cwd=root,text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],cwd=root,text=True).strip(),'trackedCount':len(paths),'changedFilesFromBase':git('diff','--name-status',base,'HEAD'),'coreHooksPathBefore':git('config','--get','core.hooksPath'),'sourceProductionBlob':git('rev-parse',source+':src/svg-style-scope.ts'),'candidateProductionBlob':git('rev-parse','HEAD:src/svg-style-scope.ts'),'sourceTestBlob':git('rev-parse',source+':test/browser-unit/svg-style-environment.test.ts'),'candidateTestBlob':git('rev-parse','HEAD:test/browser-unit/svg-style-environment.test.ts'),'parentProductionSHA256':hashlib.sha256(subprocess.check_output(['git','show',base+':src/svg-style-scope.ts'],cwd=root)).hexdigest(),'unrelatedNativeParentProductionSHA256':hashlib.sha256(subprocess.check_output(['git','show','c621:src/svg-style-scope.ts'],cwd=root)).hexdigest(),'pushedOrPRCreated':False,'inputScope':'All Git tracked files plus generated es/lib/dist; output/dependency caches excluded.'}
(folder/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(folder/'tracked-initial.json').write_text(json.dumps(initial,indent=2)+'\n')
receipts=[]
def stage(name,command,allow_generated=False):
    out=folder/name;out.mkdir()
    before=manifest();(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');start=time.monotonic()
    print('START',name,command,flush=True)
    with (out/'run.log').open('w') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    after=manifest();(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
    tracked_stable=all(before[p]==after[p]==initial[p] for p in paths)
    receipt={'stage':name,'command':command,'exitCode':result.returncode,'durationSeconds':time.monotonic()-start,'base':base,'sourceCommit':source,'head':head,'headUnchanged':git('rev-parse','HEAD')==head,'measuredInputCountBefore':len(before),'measuredInputCountAfter':len(after),'allTrackedInputsStable':tracked_stable,'allMeasuredInputsStable':before==after,'generatedChangesExpected':allow_generated,'defaultEnvironmentOverrides':{k:os.environ.get(k) for k in ['CI','TEST_SUITE','TEST_BROWSER','HTML_TO_IMAGE_SMOKE_PORT']}}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');receipts.append(receipt);(folder/'stage-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('END',name,json.dumps(receipt),flush=True)
    if not tracked_stable or (before!=after and not allow_generated):raise RuntimeError('Measured input guard changed in '+name)
    return result.returncode

try:
    if stage('install',['pnpm','install','--frozen-lockfile','--ignore-scripts']):raise RuntimeError('Frozen dependency install failed')
    stage('lint',['pnpm','run','lint:check'])
    built=stage('build',['pnpm','run','build'],allow_generated=True)==0
    if built:stage('package-contract',['pnpm','run','test:package'])
    stage('browser-types',['pnpm','run','test:browser:types'])
    stage('default-test',['pnpm','test'])
    if built:
        check=socket.socket();check.settimeout(1);busy=check.connect_ex(('127.0.0.1',4173))==0;check.close()
        (folder/'package-port-precondition.json').write_text(json.dumps({'port':4173,'listeningBeforePackage':busy,'defaultPortUnmodified':True},indent=2)+'\n')
        if busy:raise RuntimeError('Default4173 already has listener; coordinate parent, do not alter config or stop other owner')
        stage('browser-package',['pnpm','run','test:browser:package'])
finally:
    after=manifest();(folder/'tracked-final.json').write_text(json.dumps(after,indent=2)+'\n');(folder/'final-receipt.json').write_text(json.dumps({'base':base,'sourceCommit':source,'head':head,'headAfter':git('rev-parse','HEAD'),'trackedInputsStable':all(after[p]==initial[p] for p in paths),'gitStatus':git('status','--porcelain=v1'),'coreHooksPathAfter':git('config','--get','core.hooksPath'),'stages':receipts,'defaultRetriesAssertionsTimeoutsSkipsUnchanged':True,'mainWorkspaceWritten':False,'pushedOrPRCreated':False},indent=2)+'\n')
