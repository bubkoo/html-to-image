from pathlib import Path
import subprocess,json,hashlib,time,os,socket,shutil
root=Path('/Users/bytedance/.codex/worktrees/svg-style-cancellation/html-to-image')
assert Path.cwd().resolve()==root
folder=root/'output/playwright/svg-style-cancellation-20261125'
identity=json.loads((folder/'identity.json').read_text());head=identity['head']
tracked=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if p]
def manifest():
    paths=set(tracked)
    for name in ['es','lib','dist']:paths.update(str(f.relative_to(root)) for f in (root/name).rglob('*') if f.is_file())
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
expected=json.loads((folder/'default-test/inputs-after.json').read_text())
assert manifest()==expected
receipts=[]
def stage(name,command,env_changes=None):
    out=folder/name;out.mkdir();before=manifest();assert before==expected
    (out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');start=time.monotonic();env={**os.environ,**(env_changes or {})}
    print('START',name,command,env_changes or {},flush=True)
    with (out/'run.log').open('w') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    after=manifest();(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
    if (root/'.vitest/attachments').exists():shutil.copytree(root/'.vitest/attachments',out/'vitest-attachments',dirs_exist_ok=True)
    if name=='browser-package' and (root/'test-results').exists():shutil.copytree(root/'test-results',out/'test-results',dirs_exist_ok=True)
    receipt={'stage':name,'command':command,'exitCode':result.returncode,'durationSeconds':time.monotonic()-start,'base':identity['base'],'sourceCommit':identity['sourceCommit'],'head':head,'headAfter':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'measuredInputCount':len(before),'allMeasuredInputsStable':before==after==expected,'environment':{k:env.get(k) for k in ['CI','TEST_SUITE','TEST_BROWSER','HTML_TO_IMAGE_SMOKE_PORT']},'originalAssertionsTimeoutsFlagsRetriesAndSkips':True}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');receipts.append(receipt);(folder/'continuation-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('END',name,json.dumps(receipt),flush=True)
    if not receipt['allMeasuredInputsStable'] or receipt['headAfter']!=head:raise RuntimeError('Input orhead guard changed')
    return result.returncode
try:
    stage('source-followup',['pnpm','run','test:browser:source'])
    for port in [4197,4198]:
        s=socket.socket();s.settimeout(1);busy=s.connect_ex(('127.0.0.1',port))==0;s.close()
        if busy:raise RuntimeError('Independent packageport busy: '+str(port))
    stage('browser-package',['pnpm','run','test:browser:package'],{'HTML_TO_IMAGE_SMOKE_PORT':'4197'})
    stage('default-recheck',['pnpm','test'])
finally:
    current=manifest();(folder/'continuation-final-receipt.json').write_text(json.dumps({'identity':identity,'headAfter':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'all1033InputsStable':current==expected,'coreHooksPathAfter':subprocess.check_output(['git','config','--get','core.hooksPath'],cwd=root,text=True).strip(),'gitStatus':subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True),'receipts':receipts,'firstDefaultFailurePreserved':True,'noUnchangedThirdDefaultRun':True,'default4173ServiceUntouched':True},indent=2)+'\n')
