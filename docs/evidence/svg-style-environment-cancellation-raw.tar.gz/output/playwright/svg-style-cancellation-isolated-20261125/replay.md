# Independent SVG style cancellation acceptance

Base: `25e83810cb7d1865b6a2108c67f195b6a09a05e3`. Source fix: `d2501695c9aceafd7e301486bb1468631b50a5f4`. Cherry-picked candidate: `786603d733ae273e1c6ad420d3239414d36e8a45`, tree `6a272cb3b0bb19fa0fc1016ce1d3d58661475863`, branch `codex/svg-style-cancellation`.

The app created `/Users/bytedance/.codex/worktrees/svg-style-cancellation/html-to-image` from the exact base after checking attached worktrees. Only `src/svg-style-scope.ts` and `test/browser-unit/svg-style-environment.test.ts` differ. Both blobs exactly match the source fix. The old production file at this base and the native feature parent has the same SHA256, so the fix was checked independently of the unfinished native feature. `review.patch`, `commit.txt` and `identity.json` retain that boundary.

Actual local environment: Node 22.17.0, pnpm 10.34.9. CI Node 24 is separate. Commands run in this independent checkout:

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm run lint:check
pnpm run build
pnpm run test:package
pnpm run test:browser:types
pnpm test
```

Install uses the project's CI default and avoids prepare/Husky changes to shared Git configuration. All preliminary commands passed. The first `pnpm test` stopped during coverage: 1391 pass, 2 fail, 4 skip. Both failures are Firefox's existing native source screenshot commands, after fonts loaded and while waiting for stability, before the scene's library capture. The 93 cancellation cases did not fail. Source was short-circuited by the default `&&` chain. Original logs and the two original framework failure screenshots are preserved; the screenshots are blank after fixture cleanup and are not a captured failing raster oracle.

The default package port 4173 belonged to an unrelated user preview. It was never stopped, visited or captured. Through the project's existing configuration option, the following sequence then ran without changing source, assertions, timeouts, retries or skips:

```sh
pnpm run test:browser:source
HTML_TO_IMAGE_SMOKE_PORT=4197 pnpm run test:browser:package
pnpm test
```

Complete source passed 1274 with 4 inherited skips. Complete package passed 162/162. The last unchanged default test passed coverage 1393/4 skips and source 1274/4 skips. There was no third default run. This later success does not establish the cause of the two original timeouts or fix them.

An independent agent later reported 51 browser probes whose activity fits within `2026-11-24T20:20:10.991Z`–`20:20:28.305Z`; individual launch/close times were not collected. This may overlap the package stage. Earlier windows are not claimed continuously exclusive. The final default starts in the 20:22 UTC interval after that reported envelope, under coordinated no-launch instructions. Actual process inspection occurred after completion only. `concurrency-boundary.json` distinguishes these facts and labels receipt-derived timing as approximate.

All 904 tracked files remained stable. Build added 129 expected generated files; all 1033 tracked-plus-generated inputs stayed byte-identical through subsequent checks. Head and shared hooks path stayed unchanged, and Git status is clean. The worktree is retained for review. This child performed no push, PR creation or merge. Root subsequently reported pushing the same candidate and opening draft PR #652; remote CI is still a separate check.

The first default failures remain in `default-test/`, with explicit `first-failure-artifacts.json`. All later commands have separate logs, receipts and before/after manifests. `public-evidence-files.json` is the portable allowlist and `sha256-index.json` verifies precisely that selection. Dependencies, Git objects, duplicate screenshots/reports and private unrelated-service owner metadata are excluded. The source native glyph/shadow/fractional gates of #651 remain open and are not part of this earlier-base fix.
