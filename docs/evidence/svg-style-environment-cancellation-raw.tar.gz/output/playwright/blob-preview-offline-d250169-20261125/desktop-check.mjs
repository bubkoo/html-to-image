import { readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
import { chromium, firefox, webkit } from 'playwright'
const directory = new URL('./', import.meta.url)
const dataURL = (await readFile(new URL('blob-preview-data-url.txt', directory), 'utf8')).trim()
const manifest = JSON.parse(await readFile(new URL('manifest.json', directory), 'utf8'))
const report = { at: new Date().toISOString(), scope: 'Desktop Playwright real browser pointer clicks only. No phone connection, iPhone GUI acceptance, HTTP server, or production modification.', cases: [] }
try {
  for (const [engine, type] of Object.entries({ chromium, firefox, webkit })) {
    const browser = await type.launch({ headless: true })
    const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
    const page = await context.newPage()
    const requests = []
    const errors = []
    context.on('request', request => {
      const url = request.url()
      requests.push({ scheme: url.split(':')[0], length: url.length, blob: url.startsWith('blob:') ? url : undefined })
    })
    page.on('pageerror', error => errors.push(String(error)))
    try {
      await page.goto(dataURL)
      await page.waitForFunction(() => {
        const state = JSON.parse(document.getElementById('diagnostic').value)
        return state.state === 'ready' || state.state === 'error'
      })
      const initial = await page.locator('#diagnostic').inputValue().then(JSON.parse)
      assert.equal(initial.state, 'ready', JSON.stringify(initial.events))
      assert.equal(initial.png.mime, 'image/png')
      assert.equal(initial.png.allPixelsVerified, true)
      assert.equal(initial.png.redPixels, 6400)
      assert.equal(initial.png.bluePixels, 6400)
      const embedded = await page.locator('#embedded-umd').textContent()
      assert.equal(createHash('sha256').update(embedded).digest('hex'), manifest.umd.sha256)
      const nativeAnchor = await page.locator('#preview').evaluate(anchor => ({ tag: anchor.tagName, target: anchor.target, rel: anchor.rel, href: anchor.href }))
      assert.equal(nativeAnchor.tag, 'A')
      assert.equal(nativeAnchor.target, '_blank')
      assert.equal(nativeAnchor.rel, 'noopener')
      const opened = context.waitForEvent('page')
      await page.locator('#preview').click()
      const popup = await opened
      await popup.waitForLoadState('load')
      await popup.waitForFunction(() => document.images.length === 1 && document.images[0].complete && document.images[0].naturalWidth > 0)
      const png = await popup.evaluate(() => {
        const image = document.images[0]
        const canvas = document.createElement('canvas'); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight
        const ctx = canvas.getContext('2d'); ctx.drawImage(image, 0, 0)
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data
        let different = 0
        for (let y = 0; y < canvas.height; y++) for (let x = 0; x < canvas.width; x++) {
          const expected = x < 80 ? [255, 0, 0, 255] : [0, 0, 255, 255]
          expected.forEach((value, n) => { different += data[(y * canvas.width + x) * 4 + n] !== value })
        }
        return { width: image.naturalWidth, height: image.naturalHeight, different, openerIsNull: window.opener === null, url: location.href, contentType: document.contentType }
      })
      assert.deepEqual([png.width, png.height, png.different], [160, 80, 0])
      assert.equal(png.openerIsNull, true)
      assert.equal(png.url, initial.activeURL)
      assert.equal(png.contentType, 'image/png')
      await popup.locator('img').screenshot({ path: new URL(engine + '-preview.png', directory).pathname, scale: 'css' })
      await page.bringToFront()
      const clicked = await page.locator('#diagnostic').inputValue().then(JSON.parse)
      const click = clicked.events.find(event => event.name === 'preview-click')
      assert.equal(click.isTrusted, true)
      if (click.activation !== 'unknown') assert.equal(click.activation.isActive, true)
      await page.locator('#cleanup').click()
      const cleaned = await page.locator('#diagnostic').inputValue().then(JSON.parse)
      assert.equal(cleaned.state, 'cleaned')
      assert.equal(cleaned.activeURL, null)
      assert.equal(cleaned.events.find(event => event.name === 'preview-cleaned').isTrusted, true)
      assert.equal(await page.locator('#preview').getAttribute('href'), null)
      assert.equal(await page.locator('#preview').isVisible(), false)
      const revoked = await page.evaluate(async url => { try { await fetch(url); return false } catch { return true } }, initial.activeURL)
      assert.equal(revoked, true)
      assert.equal(requests.some(request => ['http', 'https'].includes(request.scheme)), false)
      assert.equal(errors.length, 0)
      const row = { engine, version: browser.version(), entry: 'data:text/html;base64', embeddedUMDSHA256: manifest.umd.sha256, initialPNG: initial.png, nativeAnchor, trustedClick: click, popup: png, cleanup: cleaned.events.find(event => event.name === 'preview-cleaned'), revokedVerified: revoked, requests, errors, passed: true }
      report.cases.push(row)
      await writeFile(new URL(engine + '-diagnostic.json', directory), JSON.stringify(cleaned, null, 2))
      console.log(JSON.stringify({ engine, passed: true, trustedClick: click.isTrusted, activation: click.activation, dimensions: [png.width, png.height], different: png.different, cleanup: cleaned.state, httpRequests: 0 }))
    } catch (error) {
      report.cases.push({ engine, version: browser.version(), passed: false, error: String(error), stack: error.stack, requests, errors })
      throw error
    } finally { await context.close(); await browser.close() }
  }
} finally {
  report.cleanup = { desktopBrowsersClosed: true, HTTPServerStarted: false, phoneConnectedOrOperated: false }
  report.allPassed = report.cases.length === 3 && report.cases.every(x => x.passed)
  await writeFile(new URL('desktop-receipt.json', directory), JSON.stringify(report, null, 2))
}
