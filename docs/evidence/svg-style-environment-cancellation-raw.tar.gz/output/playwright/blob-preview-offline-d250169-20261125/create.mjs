import { readFile, writeFile, readdir } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
const directory = new URL('./', import.meta.url)
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const umd = await readFile('dist/html-to-image.js')
const head = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
const dirty = execFileSync('git', ['status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8' }).trim()
const walk = async (directory) => {
  const paths = []
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = directory + '/' + entry.name
    if (entry.isDirectory()) paths.push(...await walk(path))
    else paths.push(path)
  }
  return paths.sort()
}
const source = []
for (const path of await walk('src')) source.push({ path, sha256: digest(await readFile(path)) })
const ledgerPath = 'output/playwright/native-scroll-followup/svg-style-abort-full-source/inputs-after.json'
const ledger = JSON.parse(await readFile(ledgerPath, 'utf8'))
const manifest = {
  preparedAt: new Date().toISOString(),
  head,
  trackedWorktreeDirty: !!dirty,
  source,
  sourceFingerprint: digest(JSON.stringify(source)),
  umd: { path: 'dist/html-to-image.js', bytes: umd.length, sha256: digest(umd), embedding: 'Exact raw current UMD bytes inside script#embedded-umd; no substitutions or guard stand-in.' },
  sourceAndUMDMatchFrozenPackageLedger: ledger['dist/html-to-image.js'] === digest(umd) && source.every(x => ledger[x.path] === x.sha256),
  ledgerPath,
  scope: 'Single-file offline manual Blob PNG preview. Desktop acceptance is independent of the still-pending iPhone trusted-click/new-tab/return-cleanup GUI acceptance.',
}
if (umd.toString().toLowerCase().includes('</script')) throw new Error('Raw UMD contains an HTML script terminator')
const before = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PNG 预览验证</title>
<style>
*{box-sizing:border-box}body{margin:0;padding:24px 20px 40px;background:#f3f5f8;color:#172235;font:17px/1.6 system-ui,sans-serif}main{max-width:520px;margin:auto}h1{font-size:25px;line-height:1.3;margin:0 0 12px}.card{padding:22px;background:white;border-radius:16px;box-shadow:0 3px 20px #14263c0a}p{margin:12px 0}#source{display:flex;width:160px;height:80px;padding:0;margin:0;overflow:hidden;background:white}#source>div{width:80px;height:80px;flex:none}.actions{display:flex;flex-wrap:wrap;gap:12px;margin:20px 0 0}a.action,button{display:inline-block;border:0;border-radius:10px;padding:13px 17px;font:inherit;line-height:1.4;text-decoration:none;background:#1462e8;color:white;cursor:pointer}button.secondary{background:#e8edf5;color:#172235}button:disabled{opacity:.45;cursor:default}[hidden]{display:none!important}#status{padding:12px 0;margin-bottom:0;font-weight:600}details{margin-top:22px;color:#596575;font-size:14px}textarea{display:block;width:100%;height:260px;margin-top:12px;padding:10px;border:1px solid #d9dfe8;background:white;border-radius:8px;font:12px/1.5 ui-monospace,monospace;resize:vertical}
</style></head><body><main><section class="card"><h1>PNG 预览验证</h1><p>图片准备好后，点下方链接。看到红蓝图片后，返回此页点“清理预览”。</p><div style="padding:20px 0"><div id="source" aria-label="红蓝测试图片"><div style="background:rgb(255,0,0)"></div><div style="background:rgb(0,0,255)"></div></div></div><p id="status" role="status">正在准备图片…</p><div class="actions"><a id="preview" class="action" target="_blank" rel="noopener" hidden>Open PNG preview</a><button id="cleanup" class="secondary" disabled>清理预览</button><button id="generate" class="secondary" hidden>重新生成 PNG</button></div></section><details><summary>验证记录</summary><textarea id="diagnostic" readonly aria-label="JSON 验证记录"></textarea></details></main>
<script id="embedded-umd">`
const after = `</script>
<script id="build-manifest" type="application/json">${JSON.stringify(manifest)}</script>
<script>
(() => {
  const status = document.getElementById('status')
  const preview = document.getElementById('preview')
  const cleanup = document.getElementById('cleanup')
  const generate = document.getElementById('generate')
  const diagnostic = document.getElementById('diagnostic')
  const record = { version: 1, environment: { userAgent: navigator.userAgent, dpr: devicePixelRatio }, build: JSON.parse(document.getElementById('build-manifest').textContent), events: [], png: null, activeURL: null, state: 'preparing' }
  let liveURL = null
  const activation = () => navigator.userActivation ? { isActive: navigator.userActivation.isActive, hasBeenActive: navigator.userActivation.hasBeenActive } : 'unknown'
  const emit = (name, extra = {}) => { record.events.push({ name, at: new Date().toISOString(), performanceTime: performance.now(), ...extra }); diagnostic.value = JSON.stringify(record, null, 2) }
  const display = (state, message) => { record.state = state; status.textContent = message }
  const prepare = async () => {
    generate.hidden = true
    cleanup.disabled = true
    preview.hidden = true
    display('preparing', '正在准备图片…')
    emit('prepare-start')
    try {
      if (!window.htmlToImage || typeof window.htmlToImage.toBlob !== 'function') throw new Error('Embedded real UMD did not expose toBlob')
      const blob = await window.htmlToImage.toBlob(document.getElementById('source'), { width: 160, height: 80, pixelRatio: 1, skipFonts: true, type: 'image/png' })
      if (!(blob instanceof Blob) || blob.type !== 'image/png') throw new Error('toBlob did not return a real image/png Blob')
      const pngBytes = await blob.arrayBuffer()
      const signature = Array.from(new Uint8Array(pngBytes).slice(0, 8))
      record.blob = { type: blob.type, bytes: blob.size, headerWidth: new DataView(pngBytes).getUint32(16), headerHeight: new DataView(pngBytes).getUint32(20) }
      if (signature.join() !== '137,80,78,71,13,10,26,10') throw new Error('PNG signature verification failed')
      liveURL = URL.createObjectURL(blob)
      const image = new Image()
      image.src = liveURL
      await image.decode()
      if (image.naturalWidth !== 160 || image.naturalHeight !== 80) throw new Error('Decoded PNG dimensions ' + image.naturalWidth + 'x' + image.naturalHeight + ' differ from160x80; PNG header=' + record.blob.headerWidth + 'x' + record.blob.headerHeight)
      const canvas = document.createElement('canvas')
      canvas.width = 160; canvas.height = 80
      const context = canvas.getContext('2d')
      context.drawImage(image, 0, 0)
      const pixels = context.getImageData(0, 0, 160, 80).data
      let red = 0, blue = 0
      for (let y = 0; y < 80; y++) for (let x = 0; x < 160; x++) {
        const i = (y * 160 + x) * 4
        const expected = x < 80 ? [255, 0, 0, 255] : [0, 0, 255, 255]
        if (expected.some((value, channel) => value !== pixels[i + channel])) throw new Error('Decoded red/blue pixel verification failed at' + x + ',' + y)
        if (x < 80) red++; else blue++
      }
      record.png = { mime: blob.type, bytes: blob.size, signature, width: image.naturalWidth, height: image.naturalHeight, redPixels: red, bluePixels: blue, allPixelsVerified: true, decodedBeforePreview: true }
      record.activeURL = liveURL
      preview.href = liveURL
      preview.hidden = false
      cleanup.disabled = false
      display('ready', '图片已准备好，请点击预览。')
      emit('png-verified')
    } catch (error) {
      if (liveURL) URL.revokeObjectURL(liveURL)
      liveURL = null; record.activeURL = null
      display('error', '图片生成失败，请展开验证记录。')
      generate.hidden = false
      emit('prepare-error', { error: String(error) })
    }
  }
  preview.addEventListener('click', event => {
    display('preview-clicked', '看见红蓝图片后，请返回此页清理预览。')
    emit('preview-click', { isTrusted: event.isTrusted, eventTimeStamp: event.timeStamp, activation: activation(), href: preview.href, target: preview.target, rel: preview.rel })
  })
  cleanup.addEventListener('click', event => {
    const revokedURL = liveURL
    if (liveURL) URL.revokeObjectURL(liveURL)
    liveURL = null; record.activeURL = null
    preview.removeAttribute('href'); preview.hidden = true
    cleanup.disabled = true; generate.hidden = false
    display('cleaned', '预览已清理。')
    emit('preview-cleaned', { isTrusted: event.isTrusted, activation: activation(), revokedURL })
  })
  generate.addEventListener('click', prepare)
  document.addEventListener('visibilitychange', () => emit('visibility', { value: document.visibilityState }))
  window.addEventListener('focus', () => emit('focus'))
  emit('page-ready')
  prepare()
})()
</script></body></html>
`
const html = Buffer.concat([Buffer.from(before), umd, Buffer.from(after)])
manifest.page = { bytes: html.length, sha256: digest(html) }
const dataURL = 'data:text/html;base64,' + html.toString('base64')
await writeFile(new URL('blob-preview-offline.html', directory), html)
await writeFile(new URL('blob-preview-data-url.txt', directory), dataURL + '\n')
await writeFile(new URL('manifest.json', directory), JSON.stringify({ ...manifest, dataURLCharacters: dataURL.length }, null, 2) + '\n')
console.log(JSON.stringify({ head, umd: manifest.umd, ledgerMatches: manifest.sourceAndUMDMatchFrozenPackageLedger, page: manifest.page, dataURLCharacters: dataURL.length }))
