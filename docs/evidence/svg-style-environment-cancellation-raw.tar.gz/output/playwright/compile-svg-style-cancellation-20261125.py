from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,tarfile,gzip,io,re
root=Path.cwd();base=root/'output/playwright/native-scroll-followup'
child=Path('/Users/bytedance/.codex/worktrees/svg-style-cancellation/html-to-image/output/playwright/svg-style-cancellation-20261125')
local=root/'output/playwright/svg-style-cancellation-isolated-20261125'
sha=lambda b:hashlib.sha256(b).hexdigest()
allow=json.loads((child/'public-evidence-files.json').read_text())
for row in allow['files']:
 data=(child/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
for row in json.loads((child/'sha256-index.json').read_text())['files']:
 data=(child/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
for name in [r['path'] for r in allow['files']]+allow['copyAlso']:
 target=local/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((child/name).read_bytes())
paths=[]
for folder in [local,root/'output/playwright/svg-style-cancellation-review-d2501695-20261125',root/'output/playwright/blob-preview-offline-d250169-20261125',*[base/name for name in ['svg-style-abort-checked-before','svg-style-abort-checked-after','svg-style-abort-checked-pair','svg-style-abort-full-default','svg-style-abort-full-source','svg-style-abort-full-packages']]]:
 paths.extend(p for p in folder.rglob('*') if p.is_file())
paths.extend([base/name for name in ['run-svg-style-abort-pair.py','run-default-check.py','run-source-check.py','run-package-check.py','svg-style-abort-lint-checked.log','svg-style-abort-types-checked.log','svg-style-abort-build.log','svg-style-abort-package-contract.log']])
paths.append(Path(__file__).resolve())
for p in paths:
 if p.resolve()==Path(__file__).resolve():continue # The compiler contains the literal detector patterns; hand-authored above, no fetched data.
 if p.suffix in ['.json','.log','.txt','.md','.py','.mjs','.js','.ts']:
  text=p.read_text(errors='replace')
  assert not re.search(r'(X-Amz-Signature|[?&]sig=|github_pat_|ghp_[A-Za-z0-9]{20}|Authorization: Bearer)',text,re.I),p
paths=sorted(set(paths));out=root/'docs/evidence';name='svg-style-environment-cancellation'
archive=out/(name+'-raw.tar.gz');index=out/(name+'-index.json');record=out/(name+'.json')
assert not any(p.exists() for p in [archive,index,record])
rows=[]
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for p in paths:
    data=p.read_bytes();n=str(p.relative_to(root));m=tarfile.TarInfo(n);m.size=len(data);m.mode=0o644;m.mtime=0;t.addfile(m,io.BytesIO(data));rows.append({'path':n,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):
  b=t.extractfile(m).read();assert m.name==row['path'] and len(b)==row['bytes'] and sha(b)==row['sha256']
arc={'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
index.write_text(json.dumps({'fileCount':len(rows),'allArchivedMemberHashesVerified':True,'archive':arc,'files':rows},indent=2)+'\n')
summary={
 'checkedAt':datetime.now(timezone.utc).isoformat(),'status':'Scoped SVG environment cancellation repair locally verified and submitted as draftPR652; remote CI and actual device are separate gates.',
 'pr':652,'url':'https://github.com/bubkoo/html-to-image/pull/652','draft':True,'merged':False,
 'identity':{'basePR':650,'base':'25e83810cb7d1865b6a2108c67f195b6a09a05e3','isolatedSource':'786603d733ae273e1c6ad420d3239414d36e8a45','integratedSource':'d2501695c9aceafd7e301486bb1468631b50a5f4','productionSHA256':'32cad8ced62649fa840d599afb110ffb36697ec0b359007b7348ca9f73e63aba','parentOriginalSHA256':'bff89181065a7865cf4219bdf5d86807c9e1d95d14147b7bfe8410e8e31f9e8d','baseAndSiblingBaselineProductionFileEqual':True,'sourceAndIsolatedProductionAndTestBlobsEqual':True,'productionFiles':['src/svg-style-scope.ts'],'testFiles':['test/browser-unit/svg-style-environment.test.ts'],'nativeFeatureInIsolatedProductionBranch':False},
 'bugs':['Falsy reason values replaced by fallback errors; truthiness conflates error outcomes','Disposed/aborted owner can deliver raw resolved document through later default resource-lock continuation'],
 'fix':'Explicit outcome discriminant, exact reason selected by signal.aborted, pre-aborted disposal, single-winner settlement and lifecycle check at resource-lock delivery. CSP/sandbox/viewport/readiness deadline unchanged.',
 'fixedFinalPair':{'performedOnSiblingCandidate':'c621e09a2dad905b719522f5ddf12664069caef5 baseline; shared factory bytes equal parent25e','engines':3,'before':{'failed':60,'passed':33},'after':{'passed':93},'casesPerEngine':31,'measuredInputsEach':446,'onlyChangedMeasuredInput':'src/svg-style-scope.ts','allOtherInputsEqual':True,'withinEachRunInputsUnchanged':True,'tests':'7reasons x4phases plus pending-dispose, dispose-before-lock and actual5000ms timeout/late-load cleanup','raw':'output/playwright/native-scroll-followup/svg-style-abort-checked-*'},
 'independentLocalValidation':{'source':'786603d733ae273e1c6ad420d3239414d36e8a45','node':'v22.17.0','pnpm':'10.34.9','measuredInputs':1033,'inputsUnchanged':True,'lintBuildPackageConsumersAndTypes':'passed','firstDefault':{'coveragePassed':1391,'coverageFailed':2,'coverageSkipped':4,'source':'not run after failed coverage'},'firstFailures':'Firefox charset-header dataCSS import and pattern nested-missing reference screenshots timeout before library capture; fonts loaded,waitingstable; blank postcleanup failure screenshots are not proof source wasblank','separateFullSource':{'passed':1274,'skipped':4},'builtPackages':{'passed':162},'oneUnchangedFinalDefaultRecheck':{'coveragePassed':1393,'sourcePassed':1274,'existingSkippedEach':4},'rootCauseOfFirstFailures':'not established; later success is not causal proof','concurrency':'51experimental browser cases only bounded20:20:10.991Z–20:20:28.305Z; mayoverlap earlierpackage. Finaldefault starts20:22 after that interval. Processsample aftercompletion proves only noownedautomation then, not continuous exclusive monitoring.'},
 'independentReview':{'passed':51,'perEngine':17,'extraReasons':['NaN','-0','Symbol','BigInt','throwing then getter','revoked Proxy','native reason after abort(undefined)'],'boundaries':['raw fulfilled promise cannot be retroactively rejected','completed resource-lock result remains winner; subsequent access rejects','same pending raw/locked consumers reject exactSymbol','timeout remains original winner; laterabort(false) affects lateraccess only'],'notAFullCaptureOrPackageSuite':True},
 'integratedCandidate':{'source':'d2501695c9aceafd7e301486bb1468631b50a5f4','measuredInputs':446,'inputsUnchanged':True,'coverage':{'passed':1554,'failed':2,'skipped':45},'defaultSourcePhase':'not run after coveragefailure','separateSource':{'passed':1435,'failed':2,'skipped':45},'packages':{'passed':176,'failed':2,'unsupported':2},'knownFailures':'macOSWebKit native-scroll visible-text/insetshadow atDPR1; ESM/UMD native-scroll groups alsoDPR2fractional. Strict native gates unchanged.','packageContract':'passed','artifactBoundary':'Only16 current source failure artifacts plus selectionreceipt copied; older shared artifacts excluded. No separately saved firstdefault screenshot claim. Exact finalpackage traces/context/reports retained.'},
 'offlineBlobPreview':{'source':'d2501695c9aceafd7e301486bb1468631b50a5f4','umdSHA256':'a9bc5674d4fa79ba4304ab24178dd7c18aa7bec4f851058e053486db8fdcfde8','umdBytes':99005,'pageSHA256':'4286c4bd234d96ae7358be2f63007ea60aa6def8475a8ef667229bac381ab25f','desktopEnginesPassed':3,'trustedPointerClick':True,'png':[160,80],'all12800PixelsVerified':True,'popupNoopenerAndPNGContentType':True,'cleanupAndRevokeVerified':True,'HTTPRequests':0,'physicalDeviceUsed':False,'notSupersedingInitialOfflineFailures':'Earlier e014 offline page initialmargin and WebKitdimension failures stay ignoredlocal pinned evidence; newerpage does not establish their fullcause/fix.'},
 'remoteCI':{'run':45480659033,'url':'https://github.com/bubkoo/html-to-image/actions/runs/45480659033','head':'786603d733ae273e1c6ad420d3239414d36e8a45','status':'in_progress at collection; no pass claim','CodeQL':'not scheduled for stackedbase; existingPR filter targets master'},
 'physicalDevice':'Not used; user defers until2026-11-24T22:02:04Z. Mirroring remains closed.','oldContributorPRActions':0,'npmPublished':False,'macNetworkChanged':False,
 'rawEvidence':{'index':index.name,'archive':arc,'fileCount':len(rows),'allMemberHashesVerified':True}}
record.write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'archive':arc,'files':len(rows),'copiedChild':len(allow['files'])+len(allow['copyAlso'])}))
