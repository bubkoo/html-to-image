(()=>{const exports={};"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readDOMProperty = readDOMProperty;
exports.readDOMMethod = readDOMMethod;
exports.readOptionalDOMProperty = readOptionalDOMProperty;
exports.readOptionalDOMMethod = readOptionalDOMMethod;
exports.hasDOMProperty = hasDOMProperty;
exports.writeDOMProperty = writeDOMProperty;
exports.createSVGStyleEnvironment = createSVGStyleEnvironment;
// A self-hosted Reflect.get can itself cache a foreign DOM getter. Forward
// through a transparent proxy so that its property cache sees only the proxy.
// An explicit receiver preserves native accessors and existing proxy traps.
// The handler has no prototype or traps, and no proxy is retained after use.
const handler = Object.freeze(Object.create(null));
function readDOMProperty(target, key) {
    // Array-like and prototype helpers also accept erased primitive values.
    // Box the lookup target while preserving the original accessor receiver;
    // nullish targets must still throw instead of becoming empty objects.
    const object = target == null ? target : Object(target);
    return Reflect.get(new Proxy(object, handler), key, target);
}
// Resolve the method before evaluating arguments, then retain its receiver.
// Forwarding the original method type preserves DOM overloads.
function readDOMMethod(target, key) {
    const method = readDOMProperty(target, key);
    return ((...args) => Reflect.apply(method, target, args));
}
function readOptionalDOMProperty(target, key) {
    return target == null ? undefined : readDOMProperty(target, key);
}
function readOptionalDOMMethod(target, key) {
    return target == null ? undefined : readDOMMethod(target, key);
}
// Keep the argument order of `key in target`; Reflect.has also leaves getters
// uncalled while checking inherited properties.
function hasDOMProperty(key, target) {
    return Reflect.has(new Proxy(target, handler), key);
}
function writeDOMProperty(target, key, value) {
    // Preserve strict assignment failure and the RHS return value, even when a
    // native setter normalizes the value stored in the DOM.
    if (!Reflect.set(new Proxy(target, handler), key, value, target)) {
        throw new TypeError('Cannot assign a DOM property');
    }
    return value;
}
const readDocumentProperty = readDOMProperty, readDocumentMethod = readDOMMethod;
function createSVGStyleEnvironment(source, signal) {
    var _a;
    const width = readOptionalDOMProperty(readDocumentProperty(source, 'defaultView'), 'innerWidth') || 1024;
    const height = readOptionalDOMProperty(readDocumentProperty(source, 'defaultView'), 'innerHeight') || 768;
    const fonts = [];
    (_a = readOptionalDOMMethod(readDocumentProperty(source, 'fonts'), 'forEach')) === null || _a === void 0 ? void 0 : _a((font) => {
        if (readDOMProperty(font, 'status') === 'loaded')
            fonts.push(font);
    });
    let frame;
    let pending;
    let cancel;
    let resourcesLocked = false;
    let disposed = false;
    const lockResources = (document) => {
        if (resourcesLocked)
            return;
        const policy = Reflect.apply(readDocumentProperty(document, 'createElement'), document, ['meta']);
        writeDOMProperty(policy, 'httpEquiv', 'Content-Security-Policy');
        writeDOMProperty(policy, 'content', "img-src 'none'; style-src 'unsafe-inline'");
        readDOMMethod(readDocumentProperty(document, 'head'), 'append')(policy);
        resourcesLocked = true;
    };
    const dispose = () => {
        disposed = true;
        signal === null || signal === void 0 ? void 0 : signal.removeEventListener('abort', dispose);
        cancel === null || cancel === void 0 ? void 0 : cancel();
        if (frame)
            readDOMMethod(frame, 'remove')();
        frame = undefined;
        pending = undefined;
        // Loaded FontFace wrappers can retain their source document after disposal.
        fonts.length = 0;
    };
    signal === null || signal === void 0 ? void 0 : signal.addEventListener('abort', dispose, { once: true });
    return {
        dispose,
        async measurePolicy(check, reportImportError, reportFragmentError) {
            const document = await this.getDocument(true);
            try {
                return await detectSVGStylePolicy(document, check, reportImportError, reportFragmentError);
            }
            finally {
                lockResources(document);
            }
        },
        getDocument(trustedProbe = false) {
            if (disposed)
                return Promise.reject((signal === null || signal === void 0 ? void 0 : signal.aborted)
                    ? signal.reason
                    : new Error('SVG style environment has been disposed'));
            if (signal === null || signal === void 0 ? void 0 : signal.aborted) {
                dispose();
                return Promise.reject(signal.reason);
            }
            if (!pending) {
                pending = new Promise((resolve, reject) => {
                    frame = readDocumentMethod(document, 'createElement')('iframe');
                    const ownFrame = frame;
                    readDOMMethod(ownFrame, 'setAttribute')('sandbox', 'allow-same-origin');
                    readDOMMethod(ownFrame, 'setAttribute')('aria-hidden', 'true');
                    writeDOMProperty(readDOMProperty(ownFrame, 'style'), 'cssText', `position:fixed!important;left:-99999px!important;top:0!important;width:${width}px!important;height:${height}px!important;opacity:0!important;border:0!important;pointer-events:none!important`);
                    let settled = false;
                    const finish = (outcome) => {
                        if (settled)
                            return;
                        settled = true;
                        clearTimeout(timer);
                        signal === null || signal === void 0 ? void 0 : signal.removeEventListener('abort', abort);
                        writeDOMProperty(ownFrame, 'onload', null);
                        cancel = undefined;
                        if ('error' in outcome) {
                            readDOMMethod(ownFrame, 'remove')();
                            reject(outcome.error);
                        }
                        else
                            resolve(outcome.document);
                    };
                    const abort = () => finish({
                        error: (signal === null || signal === void 0 ? void 0 : signal.aborted)
                            ? signal.reason
                            : new DOMException('Capture aborted', 'AbortError'),
                    });
                    const timer = setTimeout(() => finish({
                        error: new Error('SVG style environment did not become ready'),
                    }), 5000);
                    cancel = abort;
                    writeDOMProperty(ownFrame, 'onload', () => {
                        try {
                            const result = readDOMProperty(ownFrame, 'contentDocument');
                            if (!result ||
                                !readDocumentMethod(result, 'querySelector')('meta[data-svg-style-policy]'))
                                return;
                            const fontSet = readDocumentProperty(result, 'fonts');
                            fonts.forEach((font) => {
                                try {
                                    readDOMMethod(fontSet, 'add')(font);
                                }
                                catch (error) {
                                    // Some engines keep CSS-connected faces in their owner document.
                                    // Their resource embedding remains with the existing font pipeline.
                                    if ((error === null || error === void 0 ? void 0 : error.name) !==
                                        'InvalidModificationError')
                                        throw error;
                                }
                            });
                            finish({ document: result });
                        }
                        catch (error) {
                            finish({ error });
                        }
                    });
                    signal === null || signal === void 0 ? void 0 : signal.addEventListener('abort', abort, { once: true });
                    if (signal === null || signal === void 0 ? void 0 : signal.aborted) {
                        abort();
                        return;
                    }
                    writeDOMProperty(ownFrame, 'srcdoc', `<!doctype html><meta data-svg-style-policy http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'none'; style-src 'unsafe-inline' data:; img-src blob:; font-src data:; base-uri 'none'; form-action 'none'"><style>html,body{margin:0;overflow:hidden}</style><body></body>`);
                    readDOMMethod(readDocumentProperty(document, 'documentElement'), 'append')(ownFrame);
                });
            }
            return trustedProbe
                ? pending
                : pending.then((document) => {
                    if (disposed || (signal === null || signal === void 0 ? void 0 : signal.aborted))
                        throw (signal === null || signal === void 0 ? void 0 : signal.aborted)
                            ? signal.reason
                            : new Error('SVG style environment has been disposed');
                    lockResources(document);
                    return document;
                });
        },
    };
}
;window.__review=exports})()