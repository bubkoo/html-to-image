import{readFile,writeFile}from'node:fs/promises'
import{execFileSync}from'node:child_process'
import{createHash}from'node:crypto'
import{createServer}from'node:http'
import{chromium,firefox,webkit}from'playwright'
import ts from'typescript'
const directory=new URL('./',import.meta.url),commit='d2501695c9aceafd7e301486bb1468631b50a5f4'
const inputs=[]
const content={}
for(const path of['src/dom.ts','src/svg-style-scope.ts','test/browser-unit/svg-style-environment.test.ts']){const bytes=execFileSync('git',['show',commit+':'+path]);content[path]=bytes.toString();inputs.push({path,sha256:createHash('sha256').update(bytes).digest('hex')});await writeFile(new URL('input/'+path.replaceAll('/','__'),directory),bytes)}
const parsed=ts.createSourceFile('scope.ts',content['src/svg-style-scope.ts'],ts.ScriptTarget.Latest,true)
const fn=parsed.statements.find(x=>ts.isFunctionDeclaration(x)&&x.name?.text==='createSVGStyleEnvironment').getText(parsed)
const text=content['src/dom.ts']+'\nconst readDocumentProperty=readDOMProperty,readDocumentMethod=readDOMMethod;\n'+fn
const js=ts.transpileModule(text,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2019}}).outputText
const bootstrap='(()=>{const exports={};'+js+';window.__review=exports})()'
await writeFile(new URL('isolated-source.js',directory),bootstrap)
const server=createServer((req,res)=>res.writeHead(200,{'Content-Type':'text/html'}).end('<!doctype html><link rel="icon" href="data:,"><body></body>'))
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
const report={at:new Date().toISOString(),commit,inputs,cases:[],scope:'Read-only review plus exact commit source function in real native iframe controls; not a mainline test or build. Additional reasons and completed/raw/resource-lock/timeout winner boundaries only.'}
try{
for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
const browser=await type.launch({headless:true}),context=await browser.newContext(),page=await context.newPage()
try{
await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.addScriptTag({content:bootstrap})
const result=await page.evaluate(async()=>{
const create=__review.createSVGStyleEnvironment,rows=[]
const observe=p=>p.then(value=>({ok:true,value}),reason=>({ok:false,reason}))
const reasons=[['NaN',()=>NaN],['negative-zero',()=>-0],['symbol',()=>Symbol('owned reason')],['bigint',()=>17n],['throwing-then-getter',()=>Object.defineProperty({},'then',{get(){throw new Error('Reason then getter must not run')}})],['revoked-proxy',()=>{const x=Proxy.revocable({},{});x.revoke();return x.proxy}],['undefined-native-default',()=>undefined]]
for(const phase of['pre-aborted','fulfilled-raw-before-lock'])for(const[label,make]of reasons){
const abort=new AbortController(),input=make();if(phase==='pre-aborted')abort.abort(input)
const env=create(document,abort.signal);let doc
try{
if(phase==='fulfilled-raw-before-lock')doc=await env.getDocument(true)
const before=doc?.head.querySelectorAll('meta[http-equiv="Content-Security-Policy"]').length
const pending=observe(env.getDocument())
if(phase!=='pre-aborted')abort.abort(input)
const out=await pending
rows.push({kind:'extra-reason',phase,label,rejected:!out.ok,exactNativeReason:Object.is(out.reason,abort.signal.reason),lockCountBefore:before,lockCountAfter:doc?.head.querySelectorAll('meta[http-equiv="Content-Security-Policy"]').length,frames:document.querySelectorAll('iframe').length})
}finally{env.dispose()}
}
{
const abort=new AbortController(),env=create(document,abort.signal),reason=Symbol('pending raw')
try{const raw=env.getDocument(true),sameRaw=env.getDocument(true)===raw,untrusted=observe(env.getDocument()),rawResult=observe(raw);abort.abort(reason);const a=await rawResult,b=await untrusted;rows.push({kind:'pending-raw-and-untrusted',sameRaw,rawRejected:!a.ok,rawExact:a.reason===reason,untrustedRejected:!b.ok,untrustedExact:b.reason===reason,frames:document.querySelectorAll('iframe').length})}finally{env.dispose()}
}
{
const abort=new AbortController(),env=create(document,abort.signal),reason={owned:'completed winner'}
try{
const publicResult=observe(env.getDocument())
const raw=env.getDocument(true)
const aborted=raw.then(()=>abort.abort(reason))
const first=await publicResult;await aborted
const subsequent=await observe(env.getDocument())
rows.push({kind:'resource-lock-completed-before-abort',firstAlreadyFulfilled:first.ok,laterCallRejected:!subsequent.ok,laterExact:subsequent.reason===reason,frames:document.querySelectorAll('iframe').length})
}finally{env.dispose()}
}
{
const abort=new AbortController(),active=new Set(),signal=abort.signal
const add=signal.addEventListener.bind(signal),remove=signal.removeEventListener.bind(signal)
Object.defineProperty(signal,'addEventListener',{configurable:true,value(type,listener,options){if(type==='abort')active.add(listener);return add(type,listener,options)}})
Object.defineProperty(signal,'removeEventListener',{configurable:true,value(type,listener,options){if(type==='abort')active.delete(listener);return remove(type,listener,options)}})
const env=create(document,signal),started=performance.now()
try{
const pending=observe(env.getDocument()),frame=document.querySelector('iframe[aria-hidden="true"]');frame.remove()
const result=await pending
const beforeLate={onloadCleared:frame.onload===null,activeAbortListeners:active.size,frames:document.querySelectorAll('iframe').length}
frame.dispatchEvent(new Event('load'));abort.abort(false)
const after=await observe(env.getDocument())
rows.push({kind:'original-five-second-timeout-then-late-load-abort',elapsed:performance.now()-started,rejected:!result.ok,message:result.reason?.message,beforeLate,laterRejected:!after.ok,laterExactFalse:after.reason===false,remainingAbortListeners:active.size,frames:document.querySelectorAll('iframe').length})
}finally{env.dispose();delete signal.addEventListener;delete signal.removeEventListener}
}
return rows
})
report.cases.push({engine,version:browser.version(),rows:result})
console.log(JSON.stringify({engine,rows:result}))
await writeFile(new URL('results.json',directory),JSON.stringify(report,null,2))
}finally{await context.close();await browser.close()}
}
}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));report.cleanup={browsersClosed:true,serverClosed:true,mainlineModified:false,mainlineTestsBuildRun:false};await writeFile(new URL('results.json',directory),JSON.stringify(report,null,2))}
