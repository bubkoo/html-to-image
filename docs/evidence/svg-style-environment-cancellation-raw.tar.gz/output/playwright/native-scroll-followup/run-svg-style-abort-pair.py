from pathlib import Path
import subprocess,hashlib,json
base=Path(__file__).parent
path=Path('src/svg-style-scope.ts'); saved=path.read_bytes()
folder=base/'svg-style-abort-checked-pair';folder.mkdir(exist_ok=True)
(folder/'final-source.ts').write_bytes(saved)
receipt={'baseline':'c621e09a2dad905b719522f5ddf12664069caef5','onlyChangedProductionFile':str(path),'finalSHA256':hashlib.sha256(saved).hexdigest()}
try:
 old=subprocess.check_output(['git','show',receipt['baseline']+':'+str(path)]);path.write_bytes(old);receipt['baselineSHA256']=hashlib.sha256(old).hexdigest()
 r=subprocess.run(['python3',str(base/'run-source-check.py'),'svg-style-abort-checked-before','test/browser-unit/svg-style-environment.test.ts']);receipt['beforeExitCode']=r.returncode
finally:
 path.write_bytes(saved);receipt['finalRestoredExactly']=path.read_bytes()==saved;(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert receipt['finalRestoredExactly']
r=subprocess.run(['python3',str(base/'run-source-check.py'),'svg-style-abort-checked-after','test/browser-unit/svg-style-environment.test.ts']);receipt['afterExitCode']=r.returncode
before=json.loads((base/'svg-style-abort-checked-before'/'inputs-after.json').read_text());after=json.loads((base/'svg-style-abort-checked-after'/'inputs-after.json').read_text());receipt['changedMeasuredInputs']=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)];assert receipt['changedMeasuredInputs']==[str(path)]
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
raise SystemExit(r.returncode)
