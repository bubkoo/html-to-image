// Interface plan only. There is no source copier, selector filter, or generic
// executor implementation in this file. Snapshotting must be synchronous;
// after that boundary only these primitive DTOs may enter asynchronous work.

export type NodePathStep =
  | { readonly kind: 'child'; readonly index: number }
  | { readonly kind: 'shadow-child'; readonly index: number }

export interface AttributeDTO {
  readonly namespace: string | null
  readonly name: string
  readonly value: string
}

export type NodeDTO =
  | { readonly kind: 'text'; readonly value: string }
  | { readonly kind: 'comment'; readonly value: string }
  | {
      readonly kind: 'element'
      readonly namespace: string
      readonly name: string
      readonly attributes: readonly AttributeDTO[]
      readonly children: readonly NodeDTO[]
      readonly shadow?: {
        readonly mode: 'open' | 'closed'
        readonly children: readonly NodeDTO[]
        readonly stylesheets: readonly StylesheetDTO[]
      }
    }

export interface StylesheetDTO {
  readonly css: string
  readonly base: string
  readonly media: string
  readonly disabled: boolean
}

// Keep the native rule envelope, not merely an expanded selector string. In
// particular, CSS nesting, @scope, namespaces, and container conditions may
// alter matching. Expanding a parent list into :is() is not proven equivalent
// for conditional native scrollbar parts.
export interface FullRuleDTO {
  readonly exactSelector: string
  readonly exactPartAndSuffix: string
  readonly selectorBranchInOriginalList: number
  readonly originalSelectorList: string
  readonly envelopes: readonly {
    readonly kind: 'nesting' | 'scope' | 'container' | 'media' | 'supports' | 'layer'
    readonly text: string
  }[]
  readonly namespaces: readonly string[]
}

export interface MetricsDTO {
  readonly client: readonly [number, number]
  readonly extent: readonly [number, number]
  readonly offset: readonly [number, number]
  readonly borderBox: readonly [number, number]
}

export interface StaticContextDTO {
  readonly schema: 'native-scrollbar-context/v1'
  readonly treeScope: 'document' | 'shadow-root'
  readonly compatMode: 'CSS1Compat'
  readonly viewport: readonly [number, number]
  readonly pixelRatio: number
  readonly tree: NodeDTO
  readonly target: readonly NodePathStep[]
  readonly stylesheetScope: readonly NodePathStep[]
  readonly relatedHostAncestors: readonly NodePathStep[]
  readonly sourceMetrics: MetricsDTO
  readonly rule: FullRuleDTO
  readonly stylesheets: readonly StylesheetDTO[]
  readonly unsupported: readonly string[]
}

export type ContextSnapshotResult =
  | { readonly status: 'snapshot'; readonly context: StaticContextDTO }
  | { readonly status: 'unknown'; readonly reasons: readonly string[] }

export interface SignalEvidenceDTO {
  readonly exactSelector: string
  readonly contextKey: string
  readonly snapshotGeometryMatches: boolean
  readonly eventChannelReady: boolean
  readonly samePartPositiveReady: boolean
  readonly samePartNegativeQuiet: boolean
  readonly fenceReady: boolean
  readonly observedPartBeforeFence: boolean | null
  readonly attributableToTargetOnly: boolean
  readonly signalEvents: readonly {
    readonly marker: string
    readonly effectiveDirective: string
    readonly time: number
  }[]
}

export type ExactPartApplicationResult =
  | {
      readonly status: 'measured'
      readonly applies: boolean
      readonly evidence: SignalEvidenceDTO
    }
  | {
      readonly status: 'unknown'
      readonly reason:
        | 'snapshot-incomplete'
        | 'state-not-reproducible'
        | 'context-mismatch'
        | 'event-channel-unavailable'
        | 'same-part-positive-unobservable'
        | 'same-part-negative-not-quiet'
        | 'ambiguous-target-attribution'
        | 'fence-inconclusive'
      readonly evidence?: SignalEvidenceDTO
    }

// Planned phase boundary, deliberately not implemented:
//
// snapshotContext(sourceElement, nativeRule) -> ContextSnapshotResult
//   - synchronous reads only, reflective DOM access;
//   - local native-node maps discarded before return;
//   - preserve topology/attributes and actual tree-scope/rule envelope;
//   - report unmirrorable structure/state as unknown.
//
// measureExactPart(contextDTO, ownedTrustedProbeDocument, signal)
//   - no original Element/Rule/Sheet/Document in the selector context;
//   - keep prefix + original part + suffix unchanged;
//   - use native same-part positive/negative and independent fence controls;
//   - cancellation throws signal.reason before any error description;
//   - finally removes listeners/timers/nodes and disposes owned resources;
//   - no source-selector filtering or module-level live-DOM cache.
