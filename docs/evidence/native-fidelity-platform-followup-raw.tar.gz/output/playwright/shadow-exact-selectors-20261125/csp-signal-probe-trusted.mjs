import {chromium,webkit} from 'playwright'
import {createServer} from 'node:http'
import {mkdir,readFile,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
const folder=new URL('./csp-signal-trusted-probe/',import.meta.url);await mkdir(folder,{recursive:true})
const originalHelper=await readFile(new URL('../scrollbar-shadow-20261125/capability/environment-helper.js',import.meta.url),'utf8')
const helper=originalHelper.replace("'allow-same-origin'","'allow-same-origin allow-scripts'")
if(helper===originalHelper)throw new Error('Expected exactly one sandbox derivation')
await writeFile(new URL('fixed-environment-helper.js',folder),helper)
const requests=[]
const server=createServer((req,res)=>{
 requests.push(req.url)
 if(req.url==='/page'){
  res.writeHead(200,{'Content-Type':'text/html','Content-Security-Policy':"img-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'"})
  res.end('<!doctype html><meta charset="utf-8"><style>html,body{margin:0}</style><body></body>')
 }else res.writeHead(404).end()
})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
const origin='http://127.0.0.1:'+server.address().port
const receipt={at:new Date().toISOString(),scope:'Same complete selector/part/suffix in original ShadowRoot. Owned img-src-none CSP reports in a separately derived trusted probe frame (parent callbacks allowed, script-src none unchanged); not a production policy or a change to the existing untrusted SVG environment.',helperHash:createHash('sha256').update(helper).digest('hex'),origin,engines:[]}
const prefixes=[['plain','#panel'],['plain-ancestor','.plain #panel'],['host',':host(.theme) #panel'],['is-host',':is(:host(.theme), .plain) #panel'],['is-plain-only',':is(:host(.absent), .plain) #panel'],['where-host',':where(:host(.theme)) #panel'],['missing','#absent']]
const parts=[['root-h','::-webkit-scrollbar:horizontal'],['thumb-h','::-webkit-scrollbar-thumb:horizontal']]
const closed=[];let completed=false
try{
 for(const [engine,type]of Object.entries({chromium,webkit})){
  const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})})
  let page
  try{
   page=await browser.newPage({viewport:{width:500,height:300},deviceScaleFactor:1})
   const decode=await browser.newPage({viewport:{width:200,height:200},deviceScaleFactor:1})
   await page.goto(origin+'/page');await page.addScriptTag({content:helper})
   await page.evaluate(async()=>{
    const environment=window.createProbeEnvironment(document),privateDocument=await environment.getDocument(false)
    window.exactProbe={environment,privateDocument,events:[],cleanup:[],active:[],syntheticEvents:{main:0,private:0},frameContract:{sandbox:privateDocument.defaultView.frameElement.getAttribute('sandbox'),csp:Array.from(privateDocument.querySelectorAll('meta[http-equiv]')).map(x=>x.content)}}
    for(const [where,doc]of [['main',document],['private',privateDocument]]){
     doc.addEventListener('__probe_event',()=>window.exactProbe.syntheticEvents[where]++)
     doc.dispatchEvent(new Event('__probe_event'))
     doc.addEventListener('securitypolicyviolation',event=>window.exactProbe.events.push({where,at:performance.now(),blockedURI:event.blockedURI,effectiveDirective:event.effectiveDirective,originalPolicy:event.originalPolicy,sourceFile:event.sourceFile,line:event.lineNumber}))
    }
   })
   const rows=[]
   for(const where of ['main','private'])for(const [kind,prefix]of prefixes)for(const [part,suffix]of parts){
    const name=where+'-'+kind+'-'+part
    const setup=await page.evaluate(({where,prefix,suffix,name,origin})=>{
     const state=window.exactProbe,doc=where==='main'?document:state.privateDocument
     const root=doc.createElement('div');root.id='source';root.style.cssText='position:absolute;left:0;top:0;width:100px;height:100px;background:white;overflow:hidden'
     const host=doc.createElement('div');host.className='theme';host.style.cssText='display:block;width:100px;height:100px';root.append(host)
     const shadow=host.attachShadow({mode:'open'}),style=doc.createElement('style')
     const nonce=crypto.randomUUID(),url=origin+'/probe/'+name+'-'+nonce+'.png',fenceURL=origin+'/probe/fence-'+nonce+'.png'
     const selector=prefix+suffix
     style.textContent='#panel::-webkit-scrollbar{width:11px;height:7px;background:red}#panel::-webkit-scrollbar-track{background:red}#panel::-webkit-scrollbar-thumb{background:black;border-radius:0}#panel::-webkit-scrollbar-corner{background:blue}'+selector+'{width:19px;height:17px;background-color:yellow;background-image:url("'+url+'")}'
     const wrapper=doc.createElement('div');wrapper.className='plain';wrapper.style.cssText='display:block;width:100px;height:100px'
     const panel=doc.createElement('div');panel.id='panel';panel.style.cssText='position:relative;width:100px;height:100px;overflow:scroll;background:green';panel.innerHTML='<div style="width:240px;height:300px;background:green"><div style="position:absolute;left:45px;top:55px;width:4px;height:4px;background:blue"></div></div>'
     wrapper.append(panel);shadow.append(style,wrapper);doc.documentElement.append(root);panel.scrollLeft=40;panel.scrollTop=50
     const animations=[];panel.addEventListener('animationstart',event=>animations.push({name:event.animationName,pseudo:event.pseudoElement}))
     const client=[panel.clientWidth,panel.clientHeight]
     const fence=doc.createElement('div');fence.style.cssText='position:absolute;left:200px;top:0;width:1px;height:1px;background-image:url("'+fenceURL+'")';doc.documentElement.append(fence);fence.getBoundingClientRect()
     state.active.push({root,fence,panel,url,fenceURL,animations})
     state.current={root,fence,panel,url,fenceURL,animations,where}
     return {selector,css:style.textContent,shadowMarkup:shadow.innerHTML,url,fenceURL,client,prefixMatches:panel.matches(prefix),selectorSupported:doc.defaultView.CSS.supports('selector('+selector+')'),parsed:Array.from(style.sheet.cssRules).map(rule=>rule.selectorText??rule.cssText)}
    },{where,prefix,suffix,name,origin})
    let nativeColors
    if(where==='main'){
     const png=await page.locator('#source').screenshot({scale:'css'});await writeFile(new URL(engine+'-'+name+'.png',folder),png)
     nativeColors=await decode.evaluate(async source=>{const i=new Image();i.src='data:image/png;base64,'+source;await i.decode();const c=document.createElement('canvas');c.width=c.height=100;const ctx=c.getContext('2d');ctx.drawImage(i,0,0);const p=ctx.getImageData(0,0,100,100).data;let yellow=0,black=0;for(let n=0;n<p.length;n+=4){if(p[n]===255&&p[n+1]===255&&p[n+2]===0&&p[n+3]===255)yellow++;if(p[n]===0&&p[n+1]===0&&p[n+2]===0&&p[n+3]===255)black++}return {yellow,black}},png.toString('base64'))
    }
    const measured=await page.evaluate(async()=>{
     const state=window.exactProbe,scene=state.current,start=performance.now()
     // Readiness is a unique ordinary-element CSP fence, with a finite
     // diagnostic backstop. Missing part events alone are not a false result.
     while(!state.events.some(event=>event.where===scene.where&&event.blockedURI===scene.fenceURL)&&performance.now()-start<500)await new Promise(resolve=>setTimeout(resolve,0))
     await new Promise(resolve=>setTimeout(resolve,0))
     await new Promise(resolve=>setTimeout(resolve,0))
     const partEvents=state.events.filter(event=>event.where===scene.where&&event.blockedURI===scene.url),fenceEvents=state.events.filter(event=>event.where===scene.where&&event.blockedURI===scene.fenceURL)
     const owner=scene.where==='main'?document:state.privateDocument
     const resourceTimings=owner.defaultView.performance.getEntriesByType('resource').filter(x=>x.name===scene.url||x.name===scene.fenceURL).map(x=>({name:x.name,initiatorType:x.initiatorType,duration:x.duration,transferSize:x.transferSize}))
     const result={partEvents,fenceEvents,resourceTimings,syntheticEventCount:state.syntheticEvents[scene.where],animations:scene.animations,animationObjects:scene.panel.getAnimations({subtree:true}).map(a=>({type:a.constructor.name,playState:a.playState})),clientAfter:[scene.panel.clientWidth,scene.panel.clientHeight],offsetAfter:[scene.panel.scrollLeft,scene.panel.scrollTop]}
     scene.root.remove();scene.fence.remove();return result
    })
    rows.push({name,where,kind,part,prefix,suffix,...setup,nativeColors,...measured});console.log(engine,name,JSON.stringify({client:setup.client,partEvents:measured.partEvents.length,fenceEvents:measured.fenceEvents.length,animations:measured.animations.length,nativeColors}))
   }
   const scriptGuard=await page.evaluate(async(origin)=>{
 const state=window.exactProbe,doc=state.privateDocument;window.__untrustedProbeScripts=0
 const script=doc.createElement('script');script.textContent='window.top.__untrustedProbeScripts += 1';doc.documentElement.append(script)
 const image=doc.createElement('img');image.setAttribute('onerror','window.top.__untrustedProbeScripts += 10');image.src=origin+'/probe/untrusted-handler-'+crypto.randomUUID()+'.png';doc.documentElement.append(image)
 await new Promise(resolve=>setTimeout(resolve,0));await new Promise(resolve=>setTimeout(resolve,0));
 const value={executed:window.__untrustedProbeScripts,scriptViolations:state.events.filter(e=>e.where==='private'&&e.effectiveDirective.startsWith('script-src')).length};script.remove();image.remove();return value
},origin)
   receipt.engines.push({engine,version:browser.version(),rows,events:await page.evaluate(()=>window.exactProbe.events),syntheticEvents:await page.evaluate(()=>window.exactProbe.syntheticEvents),frameContract:await page.evaluate(()=>window.exactProbe.frameContract),scriptGuard});await writeFile(new URL('receipt.json',folder),JSON.stringify(receipt,null,2)+'\n')
  }finally{
   let cleanup
   try{cleanup=await page?.evaluate(()=>{const s=window.exactProbe;s?.active.forEach(x=>{x.root.remove();x.fence.remove()});s?.environment.dispose();return {iframes:document.querySelectorAll('iframe').length,hosts:document.querySelectorAll('div.theme').length}})}catch(error){cleanup={error:String(error)}}
   await browser.close();closed.push({engine,cleanup})
  }
 }
 completed=true
}finally{
 await new Promise(resolve=>server.close(resolve))
 await writeFile(new URL('cleanup.json',folder),JSON.stringify({completed,closed,serverClosed:!server.listening,requests,unexpectedImageRequests:requests.filter(path=>path.startsWith('/probe/'))},null,2)+'\n')
}
