# 完整原生 scrollbar selector：证据封存

## 已证明的范围

在两个固定浏览器版本、固定活动页面/私有 iframe、固定单 scroller 树中，完整 `prefix + original part + suffix` 的 CSP 资源应用信号与实际源结果一致：224/224 对。两边各 112 个测试形态，总计 448 行观察。没有使用源基础 computed 颜色替代原生参与结果。

源结果的独立判据是：56 对 root horizontal/vertical 规则读取相同 scrollbar 轴的实际 client 几何；168 对 thumb/track/track-piece/corner 规则读取实际源截图中的黄色像素。每个主页面形态均保留 PNG。信号为确切规则的 `background-image` 唯一 URL 对应 `securitypolicyviolation`；网络服务器收到的图片请求为 0。

`native-part-comparison.json` 保存逐对真值、判据、完整 selector、源 client、截图颜色和私有信号；`full-part-signal/receipt.json` 保存完整 CSS/结构/事件/浏览器版本；`fence-ordering.json` 保存 448 行事件顺序。

## 反例改变了修复方向

1. 同一原生 thumb 条件规则实际涂黄时，owner client 几何仍可保持 [89,93]。把 thumb 改为 root 再测几何不能证明原 thumb selector；它改变了参与语义。
2. 不含 `:host` 的 Light DOM `:is(.absent, .plain) #panel`，`Element.matches` 为 true，但两浏览器的条件 root/thumb/track/track-piece 规则均不参与；同 prefix 的无条件 corner 参与。
3. 因而不能按 `:host` 字符串、单个全局布尔能力、普通 DOM matches、或改写成另一原生 part 来筛选源规则。

## 私有环境边界

既有固定 f3a00b0 SVG factory（sandbox allow-same-origin，script-src none）在 WebKit 中不运行父 realm 注册的事件 callback；普通 synthetic 事件与 CSP 正例 fence 都为 0。因此使用该原环境时信号应为 unknown。

本实验另外派生了仅承载构造测试树的 trusted-only frame：sandbox 加 allow-scripts，保留 script-src none/img-src none。两个浏览器中父 callback 正常，主动插入 inline script 与 onerror 的负控均执行 0 次，各报告 2 个 script-src 拒绝。该结果只证明这些受控负控；不证明可在该 frame 中安全重建任意不可信 HTML/SVG，也不授权放宽现有 SVG 环境。

## 观察与未知必须分开

448 行均收到普通元素唯一 URL fence。存在 part 事件时，最后 part 事件均不晚于首 fence。这仅为本数据集顺序观察，不能推出任意资源调度的缺席证明。通用 false 结果至少需要对应 part 正例、负例、事件通道、唯一 target 归因、上下文一致和可用 fence；任一缺失返回 unknown。

目前没有实现真实源同步快照/安全重建、多个匹配 scroller 的目标归因、动态状态再现、完整 CSS envelope 再现、CSP 等待的 AbortSignal 测试。既有几何原型的取消测试不得算作本信号的取消证据。

## 最短下一步

`context-dto-plan.ts` 只定义纯 DTO 计划，未实现 source copier/executor/selector filter。应先实现同步 source context 快照并立即丢弃源 Node/Rule/Sheet 引用，然后只把 primitives 传给异步测量；保持完整 selector、原始 part/suffix、原 tree scope 和 CSS envelope。不能再现的状态/结构直接 unknown。

在生产集成前，先在独立 output 验证以下门槛：

- 多 scroller 中对目标 part 的唯一归因；可探索确切 selector 中使用新鲜 CSS variable，并只给目标继承 marker，但目前完全未验证。
- 单独 owned trusted-only frame 的执行/导航/资源约束，不能复用并放宽原不可信 SVG staging 环境。
- 事件 channel + 同 part positive/negative + fence 顺序；fence 超时及任何校准失败均 unknown。
- 所有 await 阶段取消，原样抛 signal.reason，包括 null/false/0/对象/不可转字符串对象；finally 清理 listener/timer/frame，不缓存源 Document 或 iframe。
- 结构/CSS scope/nesting/container/namespace、伪状态和可访问 ShadowRoot 的镜像一致性。未覆盖的不外推。

## 清理与主线隔离

所有独立浏览器已 close；随机 loopback 测试 server 已 close；iframe/host 均 0；图片 HTTP 请求 0。未修改生产源码、既有测试、台账、分支、网络设置或远端 PR。
