import { createRequire } from 'node:module'
import { createServer } from 'node:http'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const require = createRequire('/work/package.json')
const { chromium } = require('playwright')
const base = new URL('./', import.meta.url)
const out = new URL('result/', base)
await mkdir(out, { recursive: true })
const fixture = await readFile(new URL('input/native-scroll.mjs', base))
const font = await readFile(new URL('input/font-metrics.ttf', base))
const ci = JSON.parse(await readFile(new URL('input/chromium-native-visible-text.json', base), 'utf8'))
const ciPNG = await readFile(new URL('input/chromium-native-visible-text-native.png', base))
await writeFile(new URL('ci-frozen.svg', out), ci.frozenSvg)
const fontURL = 'data:font/ttf;base64,' + font.toString('base64')
const fontCSS = `@font-face{font-family:"Native Scroll Metrics";src:url("${fontURL}") format("truetype")}`
const server = createServer((request, response) => {
  const path = new URL(request.url, 'http://localhost').pathname
  if (path === '/test/browser/fixtures/native-scroll.mjs') response.writeHead(200, { 'Content-Type': 'text/javascript' }).end(fixture)
  else if (path === '/test/browser/fixtures/font-metrics.ttf') response.writeHead(200, { 'Content-Type': 'font/ttf' }).end(font)
  else response.writeHead(200, { 'Content-Type': 'text/html' }).end('<!doctype html><meta charset="utf-8"><body style="margin:0;background:white">')
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
const page = await context.newPage()
const report = { at: new Date().toISOString(), engine: 'chromium', browserVersion: browser.version(), playwright: require('playwright/package.json').version, flags: 'Unchanged Playwright default headless launch; no custom arguments/flags.', inputs: [], cases: [], scope: 'Independent SVG/image/canvas and actual native HTML screenshot controls. No production source modifications, no production API acceptance.' }
for (const name of ['native-scroll.mjs', 'font-metrics.ttf', 'chromium-native-visible-text.json', 'chromium-native-visible-text-native.png']) {
  report.inputs.push({ name, sha256: createHash('sha256').update(await readFile(new URL('input/' + name, base))).digest('hex') })
}
const render = async (svg, native, width, height) => page.evaluate(async ({ svg, native, width, height }) => {
  const read = async (url) => {
    const image = new Image(); image.decoding = 'sync'; image.src = url; await image.decode(); return image
  }
  const nativeImage = await read('data:image/png;base64,' + native)
  const image = await read('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg))
  const canvas = (alpha) => { const c = document.createElement('canvas'); c.width = width; c.height = height; const ctx = c.getContext('2d', { alpha }); return { c, ctx } }
  const reference = canvas(true); reference.ctx.drawImage(nativeImage, 0, 0)
  const direct = canvas(true); direct.ctx.drawImage(image, 0, 0)
  const a = direct.ctx.getImageData(0, 0, width, height)
  const n = reference.ctx.getImageData(0, 0, width, height)
  let allOpaque = true, transparent = 0, partial = 0
  for (let i = 3; i < a.data.length; i += 4) { allOpaque &&= a.data[i] === 255; transparent += a.data[i] === 0; partial += a.data[i] > 0 && a.data[i] < 255 }
  const opaque = canvas(false); opaque.ctx.drawImage(image, 0, 0)
  const copied = canvas(true); copied.ctx.drawImage(opaque.c, 0, 0)
  const candidate = canvas(true); candidate.ctx.drawImage(allOpaque ? opaque.c : direct.c, 0, 0)
  const pixels = (x) => x.ctx.getImageData(0, 0, width, height)
  const diff = (a, b) => { let channels = 0, alpha = 0, maxDelta = 0; for (let i = 0; i < a.data.length; i++) { channels += a.data[i] !== b.data[i]; if (i % 4 === 3) alpha += a.data[i] !== b.data[i]; maxDelta = Math.max(maxDelta, Math.abs(a.data[i] - b.data[i])) } return { channels, alpha, maxDelta } }
  return { allOpaque, transparent, partial, nativeAlpha: Array.from(n.data).filter((_, i) => i % 4 === 3).reduce((r, a) => { r[a === 255 ? 'opaque' : a === 0 ? 'transparent' : 'partial']++; return r }, { opaque: 0, transparent: 0, partial: 0 }), directNative: diff(a, n), opaqueNative: diff(pixels(opaque), n), copiedNative: diff(pixels(copied), n), candidateNative: diff(pixels(candidate), n), candidateDirect: diff(pixels(candidate), a), finalContextAttributes: candidate.ctx.getContextAttributes(), png: { direct: direct.c.toDataURL().split(',')[1], opaque: opaque.c.toDataURL().split(',')[1], copied: copied.c.toDataURL().split(',')[1], candidate: candidate.c.toDataURL().split(',')[1] } }
}, { svg, native, width, height })
const save = async (name, svg, native, result) => {
  await writeFile(new URL(name + '.svg', out), svg)
  await writeFile(new URL(name + '-native.png', out), native)
  for (const [key, png] of Object.entries(result.png)) await writeFile(new URL(name + '-' + key + '.png', out), Buffer.from(png, 'base64'))
  const row = { name, ...result, png: undefined }
  report.cases.push(row)
  await writeFile(new URL('results.json', out), JSON.stringify(report, null, 2))
  console.log(JSON.stringify(row))
  return row
}
try {
  await page.goto(`http://127.0.0.1:${server.address().port}/`)
  report.environment = await page.evaluate(() => ({ userAgent: navigator.userAgent, dpr: devicePixelRatio, smoothingSupported: CSS.supports('-webkit-font-smoothing:antialiased') }))
  const baseline = await render(ci.frozenSvg, ciPNG.toString('base64'), 40, 40)
  await save('ci-frozen-baseline', ci.frozenSvg, ciPNG, baseline)
  assert.equal(baseline.directNative.channels, 214)
  assert.equal(baseline.opaqueNative.channels, 0)
  assert.equal(baseline.copiedNative.channels, 0)
  assert.equal(baseline.finalContextAttributes.alpha, true)
  const nativeRoot = await page.evaluate(async () => {
    const module = await import('/test/browser/fixtures/native-scroll.mjs')
    const scene = await module.createNativeScrollScene('visible-text')
    scene.panel.style.scrollSnapType = 'none'; scene.panel.scrollLeft = 40; scene.panel.scrollTop = 47
    await new Promise(resolve => requestAnimationFrame(resolve))
    return { id: scene.root.id, source: scene.root.outerHTML, offsets: [scene.panel.scrollLeft, scene.panel.scrollTop] }
  })
  const currentNative = await page.locator('#' + nativeRoot.id).screenshot({ scale: 'css' })
  const current = await render(ci.frozenSvg, currentNative.toString('base64'), 40, 40)
  await save('original-fixture-native', ci.frozenSvg, currentNative, current)
  report.originalFixture = nativeRoot
  assert.equal(current.directNative.channels, 214)
  assert.equal(current.candidateNative.channels, 0)
  await page.evaluate(() => document.body.replaceChildren())
  const cases = [
    { name: 'plain-text', text: '' },
    { name: 'text-opacity-09', text: 'opacity:.9' },
    { name: 'root-opacity-09', root: 'opacity:.9', transparent: true },
    { name: 'root-rounded', root: 'border-radius:17px', transparent: true },
    { name: 'inner-rounded', text: 'border-radius:17px;background:white;overflow:hidden' },
    { name: 'root-mask', root: 'mask-image:linear-gradient(90deg,black,transparent)', transparent: true },
    { name: 'inner-mask', text: 'mask-image:linear-gradient(90deg,black,transparent)' },
    { name: 'fractional-transform', text: 'transform:translate(.25px,.5px)' },
    { name: 'translate-z', text: 'transform:translateZ(0)' },
    { name: 'rotate-y', text: 'transform:perspective(300px) rotateY(8deg);transform-origin:0 0' },
    { name: 'will-change-transform', text: 'will-change:transform' },
    { name: 'will-change-opacity', text: 'will-change:opacity' },
    { name: 'semi-transparent-red', text: 'color:rgba(255,0,0,.5)' },
    { name: 'semi-transparent-blue', text: 'color:rgba(0,0,255,.3)' },
    { name: 'smoothing-antialiased', text: '-webkit-font-smoothing:antialiased' },
    { name: 'smoothing-subpixel', text: '-webkit-font-smoothing:subpixel-antialiased' },
    { name: 'filter-opacity-one', text: 'filter:opacity(1)' },
    { name: 'filter-blur-zero', text: 'filter:blur(0)' },
    { name: 'blend-multiply', text: 'mix-blend-mode:multiply' },
    { name: 'fractional-font', text: 'font-size:17.25px;line-height:23.5px' },
  ]
  report.plannedCases = cases
  for (const entry of cases) {
    const source = await page.evaluate(async ({ entry, fontCSS }) => {
      document.head.querySelectorAll('style').forEach(x => x.remove())
      const font = document.createElement('style'); font.textContent = fontCSS; document.head.append(font)
      document.body.replaceChildren()
      const root = document.createElement('div'); root.id = 'alpha-probe-root'
      root.style.cssText = 'position:relative;width:160px;height:80px;overflow:hidden;margin:0;padding:0;background:white;font:18px/24px "Native Scroll Metrics";font-kerning:none;font-synthesis:none;' + (entry.root || '')
      const text = document.createElement('div'); text.style.cssText = 'position:absolute;left:5px;top:5px;width:145px;height:65px;color:blue;white-space:pre;' + (entry.text || ''); text.textContent = 'AAAAAA\nAAAAAA'
      root.append(text); document.body.append(root)
      await document.fonts.load('18px "Native Scroll Metrics"')
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))
      return { html: root.outerHTML, computed: { root: getComputedStyle(root).cssText, text: getComputedStyle(text).cssText } }
    }, { entry, fontCSS })
    const native = await page.locator('#alpha-probe-root').screenshot({ scale: 'css', ...(entry.transparent ? { omitBackground: true } : {}) })
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>' + fontCSS + '</style><foreignObject width="160" height="80">' + source.html.replace('<div ', '<div xmlns="http://www.w3.org/1999/xhtml" ') + '</foreignObject></svg>'
    const result = await render(svg, native.toString('base64'), 160, 80)
    result.source = source
    const row = await save(entry.name, svg, native, result)
    assert.equal(row.finalContextAttributes.alpha, true)
    if (!row.allOpaque) assert.equal(row.candidateDirect.channels, 0)
    if (row.allOpaque && row.directNative.channels === 0 && row.candidateNative.channels > 0) {
      report.counterexample = row.name
      report.decision = 'Reject global/automatic all-opaque redraw route: existing alpha render already matches native but opaque-intermediate copy changes visible pixels.'
      break
    }
  }
} finally {
  await context.close(); await browser.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve))
  report.cleanup = { browserClosed: true, serverClosed: true, originalProjectWritten: false, mainlineWritten: false, customBrowserFlags: false }
  report.inputsUnchanged = true
  for (const input of report.inputs) if (createHash('sha256').update(await readFile(new URL('input/' + input.name, base))).digest('hex') !== input.sha256) report.inputsUnchanged = false
  await writeFile(new URL('results.json', out), JSON.stringify(report, null, 2))
}
