# Single-target invisible SVG text dependency

After the parent explicitly allowed browser execution, the prepared probe ran 10 input variants × 2 independent backends × 2 repeats: 40 fresh WebKit contexts.

```sh
node output/playwright/webkit-followup-20261125/font-single-target-dependency/probe.mjs
# The command above prepares inputs only. Coordinate browser ownership before:
node output/playwright/webkit-followup-20261125/font-single-target-dependency/probe.mjs --run
```

Each context decodes the fixed native PNG reference, then loads and decodes exactly one target SVG, draws that target once and reads its first pixels. There is no extra warm SVG, target replay, timer or RAF. Default and software results are measured in separate contexts. The four target lifecycle events are retained for every row.

The target retains the original 40×40 viewport, viewBox, foreignObject contents and one occurrence of the exact original font URL. New text uses the same family, 10px size and used `AAAAAA` glyph. Opacity-zero text appears before or after the foreignObject; paired variants also move the existing font-face rule before the text. Wrong family, unspecified font, empty text, visibility hidden and unused defs are controls. `preflight.json` checks XML, namespaces, geometry and URL identity without launching a browser.

Every default first draw remains 264 different channels/max255. Every software first draw remains 246/max255. These are strict failures. No same-mechanism variants were added after the negative result.

The earlier decode of a separate used-font SVG before creating the target remains a different operation, with a default 21/max1 residual and software zero only for that local fixture. This probe neither adopts that preparation nor establishes internal font readiness from public load/decode. Private optimization of invisible text remains unobserved.

`assessment.json` and `receipt.json` preserve the conclusion and limits; the 40 PNGs preserve all first draws. All contexts and the browser closed in `finally`. No server, mainline test, build, production edit or network-setting change was made.
