# Draft: same-target invisible SVG text did not prepare the cold foreignObject font layout

The distinct operation-order positive—decode a separate used-font SVG before creating the target—does not imply that an invisible SVG text node in the same target can supply the same dependency boundary.

Forty independent WebKit contexts compared the original native PNG against a single cold target SVG's first decode/draw/read. Default Canvas remains 264 channels/max255, software remains 246/max255, across opacity-zero text before/after foreignObject, the original font-face moved to the SVG beginning, wrong-family/no-font/empty-text controls, visibility hidden and unused defs. The font URL appears once and is byte-for-byte unchanged; viewport/viewBox stay 40×40. Both backends are independently measured twice.

No warm image, repeated target export, timer or RAF was used. The declared invisible dependency did not change the observed result. Whether invisible-node optimization prevents font activation is not directly measured; do not promote this into an engine-internal proof or a production workaround.

The prior prepared default 21/max1 residual and software-zero local boundary remain open. No broader font, backend, shadow, DPR2 or physical-device acceptance follows. Mainline inputs were untouched; browser/context cleanup is recorded.

Evidence: `font-single-target-dependency/assessment.json`, `receipt.json`, `results.json`, individual SVG inputs and all 40 first-draw PNGs.
