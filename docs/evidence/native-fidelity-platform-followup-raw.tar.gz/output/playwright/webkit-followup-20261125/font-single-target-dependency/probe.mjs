import { webkit } from 'playwright'
import { readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'

const dir = new URL('./', import.meta.url)
const original = new URL('../font-lifecycle-followup/', dir)
const source = await readFile(new URL('original.svg', original), 'utf8')
const nativeBytes = await readFile(new URL('native.png', original))
const native = nativeBytes.toString('base64')
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const fontStyle = source.match(/<style[^>]*>@font-face[\s\S]*?<\/style>/)?.[0]
if (!fontStyle) throw new Error('Original embedded @font-face was not found')
const modes = ['baseline', 'opacity-zero-before', 'opacity-zero-after', 'opacity-zero-before-face-first', 'opacity-zero-after-face-first', 'wrong-family-before', 'no-font-before', 'empty-text-before', 'visibility-hidden-before', 'defs-unused-before']
const variants = modes.map(mode => {
  let svg = source
  const family = mode === 'wrong-family-before' ? 'serif' : 'Native Scroll Metrics'
  const font = mode === 'no-font-before' ? '' : `font-family="${family}" font-size="10" font-style="normal" font-weight="400" style="font-kerning:none;font-synthesis:none"`
  const content = mode === 'empty-text-before' ? '' : 'AAAAAA'
  let text = `<text x="0" y="12" ${font} ${mode === 'visibility-hidden-before' ? 'visibility="hidden"' : 'opacity="0"'}>${content}</text>`
  if (mode === 'defs-unused-before') text = `<defs>${text}</defs>`
  if (mode !== 'baseline') {
    if (mode.includes('after')) svg = svg.replace('</foreignObject>', '</foreignObject>' + text)
    else svg = svg.replace('<foreignObject', text + '<foreignObject')
  }
  if (mode.endsWith('face-first')) {
    svg = svg.replace(fontStyle, '')
    const openingEnd = svg.indexOf('>')
    svg = svg.slice(0, openingEnd + 1) + fontStyle + svg.slice(openingEnd + 1)
  }
  return { mode, svg, sha256: digest(svg), addedTextBeforeForeignObject: mode !== 'baseline' && svg.indexOf('<text ') < svg.indexOf('<foreignObject'), relocatedOriginalFontFace: mode.endsWith('face-first') }
})
await writeFile(new URL('original.svg', dir), source)
await writeFile(new URL('native.png', dir), nativeBytes)
for (const variant of variants) await writeFile(new URL(variant.mode + '.svg', dir), variant.svg)
await writeFile(new URL('prepared-inputs.json', dir), JSON.stringify({ at: new Date().toISOString(), sourceSha256: digest(source), nativeSha256: digest(nativeBytes), variants: variants.map(({ svg, ...rest }) => rest), scope: 'One cold target SVG per context. No warm image, timer, RAF or target repaint. Prepared only until parent authorizes browser start.' }, null, 2) + '\n')

if (!process.argv.includes('--run')) {
  console.log('Prepared10variants. Browser not started. Pass --run only after parent authorization.')
  process.exit(0)
}

const results = { at: new Date().toISOString(), version: null, sourceSha256: digest(source), nativeSha256: digest(nativeBytes), modes, cases: [], scope: 'Fresh WebKit context for every mode/backend/repeat. Exactly one SVG image load+decode and one target draw/read. Reference PNG decode does not use fonts. No timer/RAF/warm SVG.' }
const browser = await webkit.launch({ headless: true })
results.version = browser.version()
try {
  for (const repeat of [0, 1]) for (const software of [false, true]) for (const { mode, svg, sha256 } of variants) {
    const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 }), page = await context.newPage()
    try {
      const row = await page.evaluate(async ({ svg, native, software }) => {
        const events = [], start = performance.now(), stamp = name => events.push({ name, ms: performance.now() - start })
        const load = src => new Promise((resolve, reject) => {
          const image = new Image(); image.decoding = 'sync'
          image.onload = () => { stamp('image-load'); image.decode().then(() => { stamp('image-decode'); resolve(image) }, reject) }
          image.onerror = () => reject(new Error('Image load failed')); image.src = src
        })
        const canvas = document.createElement('canvas'); canvas.width = canvas.height = 40
        const ctx = canvas.getContext('2d', { willReadFrequently: software })
        const referenceImage = await load('data:image/png;base64,' + native)
        ctx.drawImage(referenceImage, 0, 0); const reference = ctx.getImageData(0, 0, 40, 40).data
        ctx.clearRect(0, 0, 40, 40); events.length = 0
        const image = await load('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg))
        ctx.drawImage(image, 0, 0); stamp('first-target-draw')
        const actual = ctx.getImageData(0, 0, 40, 40).data; stamp('first-target-read')
        let channels = 0, maxDelta = 0
        for (let i = 0; i < actual.length; i++) { channels += actual[i] !== reference[i]; maxDelta = Math.max(maxDelta, Math.abs(actual[i] - reference[i])) }
        return { channels, maxDelta, events, naturalSize: [image.naturalWidth, image.naturalHeight], png: canvas.toDataURL().split(',')[1] }
      }, { svg, native, software })
      const name = repeat + '-' + (software ? 'software-' : 'default-') + mode
      await writeFile(new URL(name + '.png', dir), Buffer.from(row.png, 'base64')); delete row.png
      results.cases.push({ repeat, software, mode, inputSha256: sha256, ...row }); console.log(repeat, software, mode, row.channels, row.maxDelta)
    } catch (error) { results.cases.push({ repeat, software, mode, inputSha256: sha256, error: String(error) }); console.log(repeat, software, mode, String(error)) }
    finally { await context.close() }
    await writeFile(new URL('results.json', dir), JSON.stringify(results, null, 2) + '\n')
  }
} finally { await browser.close() }
results.cleanup = { browserClosed: true, contextFinallyClosed: true, servicesStarted: false }
await writeFile(new URL('results.json', dir), JSON.stringify(results, null, 2) + '\n')
