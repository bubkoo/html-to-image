import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'

const workflowPath = process.argv[2] || new URL('../.github/workflows/pr-label-patch-size.yml', import.meta.url)
const workflow = await readFile(workflowPath, 'utf8')
const body = workflow.split('          script: |\n')[1]?.split('\n').filter(line => line.trim()).map(line => line.slice(12)).join('\n')
assert.ok(body, 'Expected the one inline Patch Size script')
const run = new (Object.getPrototypeOf(async function () {}).constructor)('github', 'context', 'core', 'process', body)
const makeFile = (filename, changes = 1, extra = {}) => ({ filename, status: 'modified', additions: changes, deletions: 0, changes, ...extra })
const list = count => Array.from({ length: count }, (_, i) => makeFile(`file-${i}.txt`))
const rows = []
async function check(name, files, options = {}) {
  const before = options.before || { head: { sha: 'head' }, base: { sha: 'base' }, changed_files: files.length, additions: files.reduce((n, f) => n + f.additions, 0), deletions: files.reduce((n, f) => n + f.deletions, 0), labels: [{ name: 'bug' }] }
  const after = structuredClone(options.after || before)
  options.mutateAfter?.(after)
  const writes = [], reads = [], messages = []
  let gets = 0
  const github = { rest: { pulls: {
    get: async () => { gets += 1; reads.push(`get-${gets}`); if (options.failGet === gets) throw new Error('API read failed'); return { data: structuredClone(gets === 1 ? before : after) } },
    listFiles: async ({ page, per_page }) => { assert.equal(per_page, 100); reads.push(`files-${page}`); if (options.failPage === page) throw new Error('API read failed'); let data = structuredClone(options.pages ? options.pages[page - 1] : files.slice((page - 1) * 100, page * 100)); data = options.mutatePage?.(page, data) ?? data; return { data } },
  }, issues: {
    addLabels: async request => { writes.push({ method: 'addLabels', labels: request.labels }) },
    removeLabel: async request => { writes.push({ method: 'removeLabel', name: request.name }) },
  } } }
  const context = { repo: { owner: 'fixture', repo: 'fixture' }, payload: { action: options.action || 'synchronize', pull_request: { number: 1, head: { sha: options.eventHead || before.head.sha } } } }
  let error
  try { await run(github, context, { info: value => messages.push(value) }, { env: { IGNORED: '!.gitignore\npnpm-lock.yaml' } }) } catch (caught) { error = caught }
  if (options.error) { assert.match(error?.message || '', options.error, name); assert.equal(writes.length, 0, name + ' wrote labels before a failed read/check') }
  else { assert.equal(error, undefined, name + ': ' + error?.message); if (options.label) assert.ok(messages.some(message => message.endsWith(': ' + options.label)), name); if (options.writes) assert.deepEqual(writes, options.writes, name) }
  rows.push({ name, passed: true, reads, plannedLabelWrites: writes, error: error?.message, messages })
}
for (const [changed, label] of [[0,'XS'],[9,'XS'],[10,'S'],[29,'S'],[30,'M'],[99,'M'],[100,'L'],[499,'L'],[500,'XL'],[999,'XL'],[1000,'XXL']]) await check(`threshold ${changed}`, [makeFile('source',changed)], { label:'size/'+label })
await check('empty PR', [], { label:'size/XS' })
for (const count of [127,128,200,3000]) await check(`complete ${count} files`, list(count), { label:count>=1000?'size/XXL':'size/L' })
await check('root lock ignored', [makeFile('pnpm-lock.yaml',1000)], { label:'size/XS' })
await check('gitignore included', [makeFile('.gitignore',10)], { label:'size/S' })
await check('nested lock included', [makeFile('nested/pnpm-lock.yaml',30)], { label:'size/M' })
await check('lock suffix included', [makeFile('pnpm-lock.yaml.bak',30)], { label:'size/M' })
await check('rename out of ignored lock included', [makeFile('source',10,{status:'renamed',previous_filename:'pnpm-lock.yaml'})], { label:'size/S' })
await check('rename into ignored lock included', [makeFile('pnpm-lock.yaml',30,{status:'renamed',previous_filename:'source'})], { label:'size/M' })
await check('rename from gitignore included', [makeFile('pnpm-lock.yaml',10,{status:'renamed',previous_filename:'.gitignore'})], { label:'size/S' })
await check('deletions counted', [makeFile('source',10,{additions:0,deletions:10})], { label:'size/S' })
await check('binary zero lines', [makeFile('image.png',0)], { label:'size/XS' })
await check('add then remove stale size labels; retain other labels', [makeFile('source',100)], { after:{head:{sha:'head'},base:{sha:'base'},changed_files:1,additions:100,deletions:0,labels:[{name:'bug'},{name:'size/S'},{name:'size/XS'}]}, writes:[{method:'addLabels',labels:['size/L']},{method:'removeLabel',name:'size/S'},{method:'removeLabel',name:'size/XS'}] })
await check('correct label is not rewritten', [makeFile('source',100)], { after:{head:{sha:'head'},base:{sha:'base'},changed_files:1,additions:100,deletions:0,labels:[{name:'bug'},{name:'size/L'}]},writes:[] })
await check('legacy reopened action ignored', [], { action:'reopened',writes:[] })
for (const failGet of [1,2]) await check(`get ${failGet} API failure`, list(101), { failGet,error:/API read failed/ })
for (const failPage of [1,2,3]) await check(`page ${failPage} API failure`, list(101), { failPage,error:/API read failed/ })
for (const field of ['head','base']) await check(`${field} changes during read`, list(101), { mutateAfter:after=>{after[field].sha='changed'},error:/changed during/ })
await check('stale event head',list(101),{eventHead:'old',error:/changed before/})
await check('file count changes during read',list(101),{mutateAfter:after=>{after.changed_files=102},error:/changed during/})
await check('incomplete first page',list(101),{mutatePage:(page,data)=>page===1?data.slice(1):data,error:/Incomplete/})
await check('incomplete second page',list(101),{mutatePage:(page,data)=>page===2?[]:data,error:/Incomplete/})
await check('unexpected tail page',list(101),{mutatePage:(page,data)=>page===3?[makeFile('extra')]:data,error:/pagination/})
await check('duplicate file across pages',list(101),{mutatePage:(page,data)=>page===2?[makeFile('file-0.txt')]:data,error:/repeated/})
await check('renamed file missing previous name',[makeFile('target',1,{status:'renamed'})],{error:/previous filename/})
await check('malformed file totals',[makeFile('source',1,{changes:2})],{error:/change counts/})
await check('metadata totals differ',[makeFile('source',1)],{before:{head:{sha:'head'},base:{sha:'base'},changed_files:1,additions:2,deletions:0,labels:[]},error:/totals do not match/})
await check('malformed labels before write',list(1),{mutateAfter:after=>{after.labels=[{}]},error:/Invalid PR label/})
await check('more than 3000 files',[],{before:{head:{sha:'head'},base:{sha:'base'},changed_files:3001,additions:0,deletions:0,labels:[]},error:/supported complete API range/})
if (process.argv[3]) {
  const directory = process.argv[3].replace(/\/$/,'')
  const load = async name => JSON.parse(await readFile(directory+'/'+name,'utf8'))
  const before = await load('pr-before.json'), after = await load('pr-after.json')
  const pages = await Promise.all([1,2,3].map(page=>load(`files-page-${page}.json`)))
  await check('captured real API pages (dry-run writes only)',pages.flat(),{before,after,pages,label:'size/XXL',writes:[]})
}
console.log(JSON.stringify({ workflowSHA256:createHash('sha256').update(workflow).digest('hex'),cases:rows.length,allPassed:true,githubWrites:0,scope:'Runs the exact inline workflow body with read fixtures and intercepted label methods; no network or source-code checkout/execution.',results:rows },null,2))
