import { readFile, writeFile } from 'node:fs/promises'
import { chromium, firefox, webkit } from 'playwright'
const directory = new URL('./', import.meta.url)
const baseline = JSON.parse(await readFile(new URL('results.json', directory), 'utf8'))
const report = { at: new Date().toISOString(), cases: [], scope: 'Owned-output SVG coordinate prototype only. Measures an isolated clone borderbox in a real160x80 browsing viewport, translates foreignObject origin and makes its viewport clip visible while retaining outer SVG crop. Does not alter any root/subtree CSS, source DOM, production API or mainline.' }
try {
  for (const [engine, type] of Object.entries({ chromium, firefox, webkit })) {
    const browser = await type.launch({ headless: true })
    const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
    const page = await context.newPage()
    try {
      await page.goto('data:text/html,<body style="margin:0"></body>')
      for (const source of baseline.cases.filter(x => x.engine === engine)) {
        const name = source.entry.name
        const svg = await readFile(new URL(`${engine}-${name}-original.svg`, directory), 'utf8')
        const native = (await readFile(new URL(`${engine}-${name}-native.png`, directory))).toString('base64')
        const output = await page.evaluate(async ({ svg, native }) => {
          const frame = document.createElement('iframe'); frame.style.cssText = 'position:absolute;left:0;top:0;width:160px;height:80px;border:0'
          const loaded = new Promise(resolve => { frame.onload = resolve })
          frame.srcdoc = '<!doctype html><style>html,body{margin:0;padding:0}</style>' + svg
          document.body.append(frame)
          try {
            await loaded
            const doc = frame.contentDocument
            const root = doc.getElementById('margin-source')
            const foreign = doc.querySelector('foreignObject')
            const originalSubtree = root.outerHTML
            const rootRect = root.getBoundingClientRect(), foreignRect = foreign.getBoundingClientRect()
            const offset = { x: rootRect.x - foreignRect.x, y: rootRect.y - foreignRect.y }
            const positions = () => {
              const r = root.getBoundingClientRect()
              return Array.from(root.children, child => { const b = child.getBoundingClientRect(); return { x: b.x - r.x, y: b.y - r.y, width: b.width, height: b.height } })
            }
            const beforeChildren = positions()
            foreign.setAttribute('x', -offset.x)
            foreign.setAttribute('y', -offset.y)
            foreign.setAttribute('overflow', 'visible')
            const afterChildren = positions()
            const normalizedRoot = root.getBoundingClientRect()
            const normalizedSvg = doc.querySelector('svg').outerHTML
            const image = new Image(); image.decoding = 'sync'; image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(normalizedSvg); await image.decode()
            const canvas = document.createElement('canvas'); canvas.width =160; canvas.height =80; const ctx = canvas.getContext('2d'); ctx.drawImage(image, 0, 0); const data = ctx.getImageData(0, 0, 160, 80)
            const originalImage = new Image(); originalImage.src = 'data:image/png;base64,' + native; await originalImage.decode()
            const reference = document.createElement('canvas'); reference.width =160; reference.height =80; const nctx = reference.getContext('2d'); nctx.drawImage(originalImage, 0, 0); const n = nctx.getImageData(0, 0, 160, 80)
            let differentChannels =0; for(let i=0;i<data.data.length;i++)differentChannels +=data.data[i] !==n.data[i]
            return { offset, originalRootRect: rootRect.toJSON(), normalizedRootRect: normalizedRoot.toJSON(), beforeChildren, afterChildren, subtreeStyleAndHTMLUnchanged: root.outerHTML ===originalSubtree, relativeChildLayoutUnchanged: JSON.stringify(beforeChildren)===JSON.stringify(afterChildren), viewportDimensionsUnchanged: foreign.getAttribute('width')==='100%'&&foreign.getAttribute('height')==='100%', differentChannels, svg: normalizedSvg, png:canvas.toDataURL().split(',')[1] }
          } finally { frame.remove() }
        }, { svg, native })
        await writeFile(new URL(`${engine}-${name}-viewport-origin.svg`, directory), output.svg)
        await writeFile(new URL(`${engine}-${name}-viewport-origin.png`, directory), Buffer.from(output.png,'base64'))
        const { svg: ignoredSVG, png: ignoredPNG, ...record } = output
        report.cases.push({ engine, name, ...record })
        console.log(JSON.stringify({engine,name,offset:output.offset,differentChannels:output.differentChannels,subtreeUnchanged:output.subtreeStyleAndHTMLUnchanged,layoutUnchanged:output.relativeChildLayoutUnchanged}))
      }
    } finally { await context.close(); await browser.close() }
  }
} finally {
  report.cleanup = { browserClosed:true, temporaryFrameRemoved:true, mainlineModified:false, sealedArtifactsModified:false, phoneOperated:false }
  await writeFile(new URL('viewport-origin-results.json', directory),JSON.stringify(report,null,2))
}
