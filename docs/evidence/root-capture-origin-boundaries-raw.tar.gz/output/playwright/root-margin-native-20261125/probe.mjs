import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { chromium, firefox, webkit } from 'playwright'
const directory = new URL('./', import.meta.url)
await mkdir(new URL('input/', directory), { recursive: true })
const sealedRoot = new URL('../blob-preview-offline-20261125/', import.meta.url)
const sealed = await readFile(new URL('blob-preview-offline.html', sealedRoot), 'utf8')
const manifest = JSON.parse(await readFile(new URL('manifest.json', sealedRoot), 'utf8'))
const umd = sealed.split('<script id="embedded-umd">')[1].split('</script>')[0]
if (createHash('sha256').update(umd).digest('hex') !== manifest.umd.sha256) throw new Error('Sealed UMD bytes differ from manifest')
await writeFile(new URL('input/html-to-image.js', directory), umd)
const sourceInputs = []
for (const path of ['src/apply-style.ts', 'src/capture.ts', 'src/clone-node.ts', 'src/util.ts', 'src/types.ts']) {
  const bytes = await readFile(path)
  sourceInputs.push({ path, sha256: createHash('sha256').update(bytes).digest('hex'), matchesSealed: manifest.source.find(x => x.path === path)?.sha256 === createHash('sha256').update(bytes).digest('hex') })
  await writeFile(new URL('input/' + path.replaceAll('/', '__'), directory), bytes)
}
const cases = [
  { name: 'zero-margin', root: 'margin:0' },
  { name: 'margin-top16', root: 'margin:16px 0 0' },
  { name: 'margin-left16', root: 'margin:0 0 0 16px' },
  { name: 'margin-top-left16', root: 'margin:16px 0 0 16px' },
  { name: 'margin-auto-horizontal', root: 'margin:0 auto' },
  { name: 'margin-auto-flex', root: 'margin:auto', parent: 'display:flex' },
  { name: 'margin-left-percentage', root: 'margin:0 0 0 10%' },
  { name: 'margin-top-percentage', root: 'margin:10% 0 0' },
  { name: 'collapse-through-parent', root: 'margin:16px 0 0', parent: 'display:block' },
  { name: 'collapsed-child-zero-root-margin', root: 'display:block;margin:0', childCollapse: true, parent: 'display:block' },
  { name: 'collapsed-child-root-margin16', root: 'display:block;margin:16px 0 0', childCollapse: true, parent: 'display:block' },
  { name: 'contained-child-margin-control', root: 'display:flow-root;margin:0', childCollapse: true },
  { name: 'negative-margin-control', root: 'margin:-8px 0 0 -8px' },
]
const report = { at: new Date().toISOString(), umd: manifest.umd, sourceInputs, cases: [], scope: 'Actual fixed UMD captures versus real border-box element screenshots. Root-margin-zero is an onCloneNode prototype only; not a source change, integration, or accepted fix.' }
try {
  for (const [engine, type] of Object.entries({ chromium, firefox, webkit })) {
    const browser = await type.launch({ headless: true })
    const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
    const page = await context.newPage()
    try {
      await page.goto('data:text/html,<html><body></body></html>')
      await page.addScriptTag({ content: umd })
      for (const entry of cases) {
        const source = await page.evaluate(entry => {
          document.body.style.cssText = 'margin:0;padding:32px;background:magenta'
          document.body.replaceChildren()
          const parent = document.createElement('div'); parent.id = 'source-parent'; parent.style.cssText = 'display:flow-root;width:240px;height:160px;margin:0;padding:0;' + (entry.parent || '')
          const root = document.createElement('div'); root.id = 'margin-source'; root.style.cssText = 'display:flex;width:160px;height:80px;margin:0;padding:0;border:0;background:red;' + entry.root
          if (entry.childCollapse) {
            root.innerHTML = '<div style="width:160px;height:40px;margin-top:24px;background:blue"></div><div style="width:160px;height:40px;background:red"></div>'
          } else root.innerHTML = '<div style="flex:none;width:80px;height:80px;background:red"></div><div style="flex:none;width:80px;height:80px;background:blue"></div>'
          parent.append(root); document.body.append(parent)
          const box = node => { const r = node.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height } }
          const computed = getComputedStyle(root)
          return { html: root.outerHTML, parent: parent.outerHTML, rootRect: box(root), parentRect: box(parent), childRects: Array.from(root.children, box), client: [root.clientWidth, root.clientHeight], margin: { top: computed.marginTop, right: computed.marginRight, bottom: computed.marginBottom, left: computed.marginLeft }, display: computed.display }
        }, entry)
        const native = await page.locator('#margin-source').screenshot({ scale: 'css' })
        await writeFile(new URL(`${engine}-${entry.name}-native.png`, directory), native)
        const nativeBase64 = native.toString('base64')
        const result = await page.evaluate(async ({ nativeBase64, explicit }) => {
          const root = document.getElementById('margin-source')
          const original = root.outerHTML
          const beforeRect = root.getBoundingClientRect().toJSON()
          const image = new Image(); image.src = 'data:image/png;base64,' + nativeBase64; await image.decode()
          const nativeCanvas = document.createElement('canvas'); nativeCanvas.width = image.naturalWidth; nativeCanvas.height = image.naturalHeight
          const nctx = nativeCanvas.getContext('2d'); nctx.drawImage(image, 0, 0); const reference = nctx.getImageData(0, 0, nativeCanvas.width, nativeCanvas.height)
          const modes = []
          for (const mode of ['original', 'root-margin-zero', ...(explicit ? ['explicit160x80'] : [])]) {
            const renderer = htmlToImage.createRenderer({ pixelRatio: 1, skipFonts: true, ...(mode === 'explicit160x80' ? { width: 160, height: 80 } : {}), ...(mode === 'root-margin-zero' ? { onCloneNode(source, copy) { if (source === root) copy.style.margin = '0' } } : {}) })
            let capture
            try {
              capture = await renderer.capture(root)
              const data = await capture.toImageData()
              const svg = decodeURIComponent((await capture.toSvg()).split(',').slice(1).join(','))
              const canvas = document.createElement('canvas'); canvas.width = data.width; canvas.height = data.height; canvas.getContext('2d').putImageData(data, 0, 0)
              let channels = 0, alpha = 0, transparent = 0
              for (let i = 0; i < data.data.length; i++) { channels += data.data[i] !== reference.data[i]; if (i % 4 === 3) { alpha += data.data[i] !== reference.data[i]; transparent += data.data[i] !== 255 } }
              modes.push({ mode, width: data.width, height: data.height, differentChannels: channels, alphaDifferentChannels: alpha, nonOpaquePixels: transparent, svg, png: canvas.toDataURL().split(',')[1], diagnostics: capture.diagnostics })
            } finally { capture?.dispose(); renderer.dispose() }
          }
          return { modes, sourceUnchanged: original === root.outerHTML && JSON.stringify(beforeRect) === JSON.stringify(root.getBoundingClientRect().toJSON()) }
        }, { nativeBase64, explicit: entry.name === 'margin-top-left16' })
        for (const output of result.modes) {
          await writeFile(new URL(`${engine}-${entry.name}-${output.mode}.svg`, directory), output.svg)
          await writeFile(new URL(`${engine}-${entry.name}-${output.mode}.png`, directory), Buffer.from(output.png, 'base64'))
        }
        const row = { engine, version: browser.version(), entry, source, sourceUnchanged: result.sourceUnchanged, modes: result.modes.map(({ svg, png, ...mode }) => mode) }
        report.cases.push(row)
        console.log(JSON.stringify({ engine, name: entry.name, margin: source.margin, relativeChildY: source.childRects[0].y - source.rootRect.y, modes: row.modes }))
        await writeFile(new URL('results.json', directory), JSON.stringify(report, null, 2))
      }
    } finally { await context.close(); await browser.close() }
  }
} finally {
  report.inputsUnchanged = true
  for (const input of sourceInputs) if (createHash('sha256').update(await readFile(input.path)).digest('hex') !== input.sha256) report.inputsUnchanged = false
  report.cleanup = { desktopBrowsersClosed: true, serverStarted: false, mainlineModified: false, sealedArtifactsModified: false, phoneOperated: false }
  await writeFile(new URL('results.json', directory), JSON.stringify(report, null, 2))
}
