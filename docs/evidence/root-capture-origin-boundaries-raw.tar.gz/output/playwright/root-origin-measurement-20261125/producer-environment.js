// Owned-output feasibility helper. It accepts serialized primitives, no source DOM.
window.createTrustedProducerProbe = (dimensions, external, onStage) => {
  const { readDOMProperty:r,readDOMMethod:m,writeDOMProperty:w }=window.__baseline
  const token=crypto.randomUUID(),nonce=crypto.randomUUID()
  const origin=location.origin,targetOrigin=origin==='null'?'*':origin
  const policy=`default-src 'none';script-src 'nonce-${nonce}';style-src 'unsafe-inline' data:;img-src data: blob:;font-src data:;frame-src 'none';object-src 'none';connect-src 'none';base-uri 'none';form-action 'none'`
  const controller=new AbortController(),signal=controller.signal
  const disposedReason=new Error('Trusted producer probe disposed')
  let frame,current,activeURL,disposed=false,started=false
  const urls=new Set(),pending=new Set()
  const stats={events:[],abortListenersAdded:0,abortListenersRemoved:0,messageListenerActive:false,ignoredSource:0,ignoredToken:0,createdURLs:[],revokedURLs:[]}
  const add=(target,listener)=>{m(target,'addEventListener')('abort',listener,{once:true});stats.abortListenersAdded++}
  const remove=(target,listener)=>{m(target,'removeEventListener')('abort',listener);stats.abortListenersRemoved++}
  const stage=name=>{stats.events.push({name,at:performance.now()});onStage?.(name)}
  const relay=()=>controller.abort(r(external,'reason'))
  let onMessage
  const dispose=()=>{
    if(disposed)return
    disposed=true
    remove(signal,dispose);remove(external,relay)
    if(onMessage){m(window,'removeEventListener')('message',onMessage);onMessage=undefined;stats.messageListenerActive=false}
    if(frame){w(frame,'onload',null);m(frame,'remove')();frame=undefined}
    current=undefined
    urls.forEach(url=>{m(URL,'revokeObjectURL')(url);stats.revokedURLs.push(url)})
    urls.clear()
  }
  add(signal,dispose);add(external,relay)
  if(r(external,'aborted'))relay()
  const wait=(begin)=>new Promise((resolve,reject)=>{
    let done=false,nativeCleanup
    const finish=(ok,value)=>{if(done)return;done=true;remove(signal,abort);pending.delete(abort);nativeCleanup?.();if(ok)resolve(value);else reject(value)}
    const abort=()=>finish(false,r(signal,'reason'))
    add(signal,abort);pending.add(abort)
    if(r(signal,'aborted')){abort();return}
    try{const cleanup=begin(value=>finish(true,value),error=>finish(false,error));if(done)cleanup?.();else nativeCleanup=cleanup}catch(error){finish(false,error)}
  })
  const bootstrap = `(()=>{
    const token=${JSON.stringify(token)},expectedOrigin=${JSON.stringify(origin)},replyOrigin=${JSON.stringify(targetOrigin)};
    let used=false;
    const reply=data=>parent.postMessage({...data,token},replyOrigin);
    const receive=event=>{
      if(event.source!==parent||event.origin!==expectedOrigin||!event.data||event.data.token!==token||event.data.type!=='produce-svg'||typeof event.data.svg!=='string'||used)return;
      used=true;window.removeEventListener('message',receive);
      try{
        const lock=document.createElement('meta');lock.setAttribute('data-producer-lock','');lock.httpEquiv='Content-Security-Policy';lock.content="script-src 'none'";document.head.append(lock);
        const blob=new Blob([event.data.svg],{type:'image/svg+xml'});const url=URL.createObjectURL(blob);
        reply({type:'svg-produced',url,locked:true});
      }catch(error){reply({type:'producer-error',error:String(error)})}
    };
    window.addEventListener('message',receive);
    reply({type:'producer-ready'});
  })();`
  return {
    disposedReason,
    async open(svg){
      if(started)throw new Error('Producer probe is single-use')
      started=true
      if(typeof svg!=='string')throw new TypeError('Serialized SVG string required')
      const url=await wait((resolve,reject)=>{
        frame=m(document,'createElement')('iframe');const ownFrame=frame
        m(ownFrame,'setAttribute')('sandbox','allow-same-origin allow-scripts');m(ownFrame,'setAttribute')('inert','');m(ownFrame,'setAttribute')('tabindex','-1');m(ownFrame,'setAttribute')('aria-hidden','true')
        w(r(ownFrame,'style'),'cssText',`position:fixed;left:-99999px;top:0;width:${dimensions.width}px;height:${dimensions.height}px;opacity:0;border:0;pointer-events:none`)
        onMessage=event=>{
          if(r(event,'source')!==r(ownFrame,'contentWindow')){stats.ignoredSource++;return}
          if(r(event,'origin')!==origin)return
          const data=r(event,'data')
          if(!data||data.token!==token){stats.ignoredToken++;return}
          try{
            const doc=r(ownFrame,'contentDocument')
            if(data.type==='producer-ready'){
              const meta=m(doc,'querySelector')('meta[data-producer-policy]'),script=m(doc,'getElementById')('trusted-producer')
              if(!meta||r(meta,'content')!==policy||!script||r(script,'nonce')!==nonce)throw new Error('Producer ready without exact owned CSP/script marker')
              stats.ready={URL:r(doc,'URL'),metaConfirmed:true,nonceConfirmed:true,sandbox:m(ownFrame,'getAttribute')('sandbox'),capturedSVGAbsent:!m(doc,'querySelector')('svg,foreignObject,iframe')}
              stage('ready')
              if(r(signal,'aborted'))return
              m(r(ownFrame,'contentWindow'),'postMessage')({type:'produce-svg',token,svg},targetOrigin)
              stage('request-posted')
            }else if(data.type==='svg-produced'){
              const lock=m(doc,'querySelector')('meta[data-producer-lock]')
              if(!lock||r(lock,'content')!=="script-src 'none'"||typeof data.url!=='string'||!data.url.startsWith('blob:'+origin+'/'))throw new Error('Producer response not policy-locked/owned Blob URL')
              urls.add(data.url);stats.createdURLs.push(data.url);activeURL=data.url
              stats.lock={metaConfirmed:true,scriptNone:true}
              stage('produced')
              resolve(data.url)
            }else if(data.type==='producer-error')reject(new Error(data.error))
          }catch(error){reject(error)}
        }
        m(window,'addEventListener')('message',onMessage);stats.messageListenerActive=true
        w(ownFrame,'srcdoc',`<!doctype html><meta data-producer-policy http-equiv="Content-Security-Policy" content="${policy}"><script id="trusted-producer" nonce="${nonce}">${bootstrap}</script><body></body>`)
        m(document.documentElement,'append')(ownFrame)
        stage('frame-started')
        return()=>{if(onMessage){m(window,'removeEventListener')('message',onMessage);onMessage=undefined;stats.messageListenerActive=false}}
      })
      if(r(signal,'aborted'))throw r(signal,'reason')
      current=await wait((resolve,reject)=>{
        const ownFrame=frame
        m(ownFrame,'setAttribute')('sandbox','allow-same-origin')
        stats.beforeNavigationSandbox=m(ownFrame,'getAttribute')('sandbox')
        w(ownFrame,'onload',()=>{
          try{
            const doc=r(ownFrame,'contentDocument')
            if(!doc||r(doc,'URL')!==url)return
            if(r(r(doc,'documentElement'),'namespaceURI')!=='http://www.w3.org/2000/svg')throw new Error('Producer navigation did not create SVG document')
            resolve(doc)
          }catch(error){reject(error)}
        })
        m(ownFrame,'removeAttribute')('srcdoc');w(ownFrame,'src',url);stage('navigation-started')
        return()=>w(ownFrame,'onload',null)
      })
      stage('svg-ready')
      return current
    },
    async loadFont(family){
      if(r(signal,'aborted'))throw r(signal,'reason')
      await wait((resolve,reject)=>{
        const fonts=r(current,'fonts'),native=m(fonts,'load')('18px '+family,'A')
        stats.fontWait={set:r(fonts,'status'),faces:Array.from(fonts,font=>({family:r(font,'family'),status:r(font,'status')}))}
        native.then(resolve,reject);stage('font-wait')
      })
    },
    dispose(){if(!r(signal,'aborted'))controller.abort(disposedReason);else dispose()},
    testWrongSource(){window.postMessage({type:'svg-produced',token,url:'blob:'+origin+'/forged'},targetOrigin)},
    snapshot(){return {...stats,pending:pending.size,activeURLs:urls.size,framePresent:!!frame,disposed,activeURL}},
  }
}
