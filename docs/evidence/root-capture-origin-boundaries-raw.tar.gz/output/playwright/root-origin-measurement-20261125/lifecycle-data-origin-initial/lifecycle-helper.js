// Owned-output lifecycle primitive; not a production root measurement.
window.createLifecycleProbe = (dimensions, external, fontURL, onStage) => {
  const { readDOMProperty: r, readDOMMethod: m, writeDOMProperty: w } = window.__baseline
  const controller = new AbortController()
  const signal = controller.signal
  const disposeReason = new Error('Owned root-origin probe disposed')
  const stats = { added: 0, removed: 0, activeWaits: 0, stages: [], revoked: [], fontStatusAtWait: null }
  let frame, current, finished = false
  const urls = new Set()
  const add = (target, listener) => { m(target, 'addEventListener')('abort', listener, { once: true }); stats.added++ }
  const remove = (target, listener) => { m(target, 'removeEventListener')('abort', listener); stats.removed++ }
  const relay = () => controller.abort(r(external, 'reason'))
  const cleanup = () => {
    if (finished) return
    finished = true
    remove(signal, cleanup)
    remove(external, relay)
    if (frame) { w(frame, 'onload', null); m(frame, 'remove')(); frame = undefined }
    current = undefined
    urls.forEach(url => { m(URL, 'revokeObjectURL')(url); stats.revoked.push(url) })
    urls.clear()
  }
  add(signal, cleanup); add(external, relay)
  if (r(external, 'aborted')) relay()
  const wait = (stage, start) => new Promise((resolve, reject) => {
    let settled = false, finishNative
    stats.activeWaits++
    const finish = (ok, value) => {
      if (settled) return
      settled = true
      remove(signal, abort)
      stats.activeWaits--
      finishNative?.()
      if (ok) resolve(value)
      else reject(value)
    }
    const abort = () => finish(false, r(signal, 'reason'))
    add(signal, abort)
    if (r(signal, 'aborted')) { abort(); return }
    try {
      const nativeCleanup = start(value => finish(true, value), error => finish(false, error))
      if (settled) nativeCleanup?.()
      else finishNative = nativeCleanup
      stats.stages.push(stage)
      onStage?.(stage)
    } catch (error) { finish(false, error) }
  })
  return {
    stats,
    disposeReason,
    async openHTML() {
      current = await wait('html', resolve => {
        frame = m(document, 'createElement')('iframe')
        const ownFrame = frame
        m(ownFrame, 'setAttribute')('sandbox', 'allow-same-origin')
        m(ownFrame, 'setAttribute')('inert', '')
        m(ownFrame, 'setAttribute')('tabindex', '-1')
        w(r(ownFrame, 'style'), 'cssText', `position:fixed;left:-99999px;top:0;width:${dimensions.width}px;height:${dimensions.height}px;opacity:0;border:0;pointer-events:none`)
        w(ownFrame, 'onload', () => {
          const doc = r(ownFrame, 'contentDocument')
          if (doc && m(doc, 'querySelector')('meta[data-owned-lifecycle]')) resolve(doc)
        })
        w(ownFrame, 'srcdoc', `<!doctype html><meta data-owned-lifecycle http-equiv="Content-Security-Policy" content="default-src 'none';script-src 'none';style-src 'unsafe-inline';img-src data: blob:;font-src data:;frame-src 'none';form-action 'none'"><body></body>`)
        m(document.documentElement, 'append')(ownFrame)
        return () => w(ownFrame, 'onload', null)
      })
    },
    async navigateOwnedDataSVG() {
      if (r(signal, 'aborted')) throw r(signal, 'reason')
      const family = 'OwnedLifecycleFont'
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>@font-face{font-family:${family};src:url("${fontURL}")}</style><foreignObject width="160" height="80"><div xmlns="http://www.w3.org/1999/xhtml" id="owned-lifecycle-root" style="width:160px;height:80px;background:red"><input autofocus="autofocus"/></div></foreignObject></svg>`
      const view = r(current, 'defaultView')
      const blob = Reflect.construct(r(view, 'Blob'), [[svg], { type: 'image/svg+xml' }])
      const url = m(r(view, 'URL'), 'createObjectURL')(blob)
      urls.add(url)
      current = await wait('svg', resolve => {
        const ownFrame = frame
        w(ownFrame, 'onload', () => {
          const doc = r(ownFrame, 'contentDocument')
          if (doc && r(doc, 'URL') === url && m(doc, 'getElementById')('owned-lifecycle-root')) resolve(doc)
        })
        m(ownFrame, 'removeAttribute')('srcdoc'); w(ownFrame, 'src', url)
        return () => w(ownFrame, 'onload', null)
      })
    },
    async loadActualDataFont() {
      if (r(signal, 'aborted')) throw r(signal, 'reason')
      const fonts = r(current, 'fonts')
      await wait('font', (resolve, reject) => {
        const native = m(fonts, 'load')('18px OwnedLifecycleFont', 'A')
        stats.fontStatusAtWait = { set: r(fonts, 'status'), faces: Array.from(fonts, font => r(font, 'status')) }
        native.then(resolve, reject)
      })
    },
    dispose() { if (!r(signal, 'aborted')) controller.abort(disposeReason); else cleanup() },
    snapshot() { return { ...stats, activeURLs: urls.size, framePresent: !!frame, disposed: finished } },
  }
}
