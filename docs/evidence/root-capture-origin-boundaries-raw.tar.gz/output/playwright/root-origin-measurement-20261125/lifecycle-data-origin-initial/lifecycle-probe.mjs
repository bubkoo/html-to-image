import { readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { chromium, firefox, webkit } from 'playwright'
import ts from 'typescript'
const directory = new URL('./', import.meta.url)
const dom = await readFile(new URL('input/src__dom.ts', directory), 'utf8')
const style = await readFile('src/svg-style-scope.ts', 'utf8')
await writeFile(new URL('input/src__svg-style-scope.ts', directory), style)
const parsed = ts.createSourceFile('src/svg-style-scope.ts', style, ts.ScriptTarget.Latest, true)
const fn = parsed.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'createSVGStyleEnvironment').getText(parsed)
const aliases = 'const readDocumentProperty=readDOMProperty,readDocumentMethod=readDOMMethod;'
const compiled = ts.transpileModule(dom + '\n' + aliases + '\n' + fn, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2019 } }).outputText
const bootstrap = '(()=>{const exports={};' + compiled + ';window.__baseline=exports})()'
const helper = await readFile(new URL('lifecycle-helper.js', directory), 'utf8')
const fontURL = 'data:font/ttf;base64,' + (await readFile(new URL('input/font-metrics.ttf', directory))).toString('base64')
const report = { at: new Date().toISOString(), sources: { originalStyleSHA256: createHash('sha256').update(style).digest('hex'), actualDOMSHA256: createHash('sha256').update(dom).digest('hex'), ownedHelperSHA256: createHash('sha256').update(helper).digest('hex') }, cases: [], scope: 'Exact existing source function falsy-reason controls plus a separate new owned-output cancellation primitive. Real pending iframe and actual data FontFace waits; no product or CSP acceptance inferred.' }
try {
  for (const [engine, type] of Object.entries({ chromium, firefox, webkit })) {
    const browser = await type.launch({ headless: true })
    const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
    const page = await context.newPage()
    try {
      await page.goto('data:text/html,<body><input id="focus"><div id="source"></div></body>')
      await page.addScriptTag({ content: bootstrap })
      await page.addScriptTag({ content: helper })
      const state = await page.evaluate(async fontURL => {
        customElements.define('lifecycle-source-element', class extends HTMLElement { constructor() { super(); window.__lifecycleConstructors = (window.__lifecycleConstructors || 0) + 1 } })
        document.getElementById('source').innerHTML = '<lifecycle-source-element></lifecycle-source-element>'
        document.getElementById('focus').focus()
        const sourceDTO = { markup: document.body.innerHTML, constructors: window.__lifecycleConstructors, focus: document.activeElement.id }
        const rows = []
        for (const label of ['null', 'false', 'zero', 'object']) {
          const reason = label === 'null' ? null : label === 'false' ? false : label === 'zero' ? 0 : new Error('Original object reason')
          const abort = new AbortController()
          const env = __baseline.createSVGStyleEnvironment(document, abort.signal)
          const pending = env.getDocument()
          abort.abort(reason)
          let rejected, fulfilled = false
          try { await pending; fulfilled = true } catch (error) { rejected = error }
          env.dispose()
          rows.push({ kind: 'existing-function', label, fulfilled, exactReason: rejected === reason, rejection: rejected && typeof rejected === 'object' ? { name: rejected.name, message: rejected.message } : rejected, frames: document.querySelectorAll('iframe').length })
        }
        for (const stage of ['html', 'svg', 'font']) for (const action of ['normal', 'null', 'false', 'zero', 'dispose']) {
          const abort = new AbortController()
          const reason = action === 'null' ? null : action === 'false' ? false : action === 'zero' ? 0 : new Error('Unused reason')
          let env
          env = createLifecycleProbe({ width:160,height:80 },abort.signal,fontURL,observed => { if(observed===stage) { if(action==='dispose')env.dispose(); else if(action!=='normal')abort.abort(reason) } })
          let rejected, fulfilled = false
          try {
            await env.openHTML()
            if(stage!=='html')await env.navigateOwnedDataSVG()
            if(stage==='font')await env.loadActualDataFont()
            fulfilled = true
          } catch(error) { rejected=error }
          const expected = action==='dispose' ? env.disposeReason : reason
          env.dispose()
          rows.push({ kind:'owned-primitive',stage,action,fulfilled,exactReason: action==='normal'?fulfilled:rejected===expected,stats:env.snapshot(),frames:document.querySelectorAll('iframe').length,focus:document.activeElement.id,sourceUnchanged:document.body.innerHTML===sourceDTO.markup,constructors:window.__lifecycleConstructors })
        }
        return { rows, sourceDTO, finalSourceUnchanged:document.body.innerHTML===sourceDTO.markup, finalFocus:document.activeElement.id, constructors:window.__lifecycleConstructors }
      },fontURL)
      report.cases.push({engine,version:browser.version(),...state})
      console.log(JSON.stringify({engine,existing:state.rows.filter(x=>x.kind==='existing-function'),owned:state.rows.filter(x=>x.kind==='owned-primitive').map(x=>({stage:x.stage,action:x.action,exact:x.exactReason,fulfilled:x.fulfilled,active:x.stats.activeWaits,balanced:x.stats.added===x.stats.removed,frames:x.frames,font:x.stats.fontStatusAtWait})),sourceUnchanged:state.finalSourceUnchanged,focus:state.finalFocus}))
    } finally { await context.close(); await browser.close() }
  }
} finally {
  report.cleanup={browsersClosed:true,serverStarted:false,mainlineModified:false,oldArtifactsModified:false,phoneOperated:false}
  await writeFile(new URL('lifecycle-results.json',directory),JSON.stringify(report,null,2))
}
