import { createServer } from 'node:http'
import { readFile,writeFile } from 'node:fs/promises'
import {createHash}from'node:crypto'
import{chromium,firefox,webkit}from'playwright'
import ts from'typescript'
const dir=new URL('./',import.meta.url)
const dom=await readFile(new URL('input/src__dom.ts',dir),'utf8')
const bootstrap='(()=>{const exports={};'+ts.transpileModule(dom,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2019}}).outputText+';window.__baseline=exports})()'
const helper=await readFile(new URL('producer-environment.js',dir),'utf8')
const fontURL='data:font/ttf;base64,'+(await readFile(new URL('input/font-metrics.ttf',dir))).toString('base64')
const http=[]
const server=createServer((request,response)=>{const p=new URL(request.url,'http://localhost').pathname;http.push({path:p,at:Date.now(),method:request.method});response.writeHead(200,{'Content-Type':p==='/'?'text/html':p.endsWith('.css')?'text/css':p.endsWith('.js')?'text/javascript':'image/svg+xml'}).end(p==='/'?'<!doctype html><link rel="icon" href="data:,"><body><input id="focus"><div id="source"></div></body>':p.endsWith('.css')?'.none{color:red}':p.endsWith('.js')?'top.__producerScriptRuns++':'<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="red"/></svg>')})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
const origin=`http://127.0.0.1:${server.address().port}`
const report={at:new Date().toISOString(),helperSHA256:createHash('sha256').update(helper).digest('hex'),cases:[],scope:'Fixed nonce trusted producer before any captured SVG; actual private-realm mint after extra scriptnone CSP, then no-scripts sandbox before untrusted SVG navigation. CSP/server evidence gate only.'}
try{
for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
const browser=await type.launch({headless:true}),context=await browser.newContext({viewport:{width:414,height:896},deviceScaleFactor:1}),page=await context.newPage(),messages=[],network=[]
page.on('console',message=>messages.push({type:message.type(),text:message.text()}));page.on('request',request=>{if(request.url().includes('/marker/'))network.push({kind:'attempt',url:request.url(),at:Date.now()})});page.on('requestfailed',request=>{if(request.url().includes('/marker/'))network.push({kind:'failed',url:request.url(),reason:request.failure(),at:Date.now()})});page.on('response',response=>{if(response.url().includes('/marker/'))network.push({kind:'response',url:response.url(),status:response.status(),at:Date.now()})})
try{
await page.goto(origin);await page.addScriptTag({content:bootstrap});await page.addScriptTag({content:helper})
const start=Date.now()
const result=await page.evaluate(async({origin,fontURL})=>{
const{readDOMProperty:r,readDOMMethod:m,writeDOMProperty:w}=window.__baseline
window.__producerScriptRuns=0;window.__producerConstructors=0
customElements.define('producer-source-element',class extends HTMLElement{constructor(){super();window.__producerConstructors++}})
const dto=(()=>{document.getElementById('source').innerHTML='<producer-source-element data-owned="source"></producer-source-element>';document.getElementById('focus').focus();return{source:document.getElementById('source').innerHTML,body:document.body.innerHTML,constructors:window.__producerConstructors,focus:document.activeElement.id}})()
const dataSVG='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="blue"/></svg>')
const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>@import url("${origin}/marker/import.css");@font-face{font-family:ProducerAllowed;src:url("${fontURL}")}@font-face{font-family:ProducerDenied;src:url("${origin}/marker/font.ttf")}</style><script>top.__producerScriptRuns++</script><script href="${origin}/marker/script.js"/><image href="${origin}/marker/image.svg" width="4" height="4"/><image href="${dataSVG}" x="150" width="4" height="4"/><foreignObject width="160" height="80"><div xmlns="http://www.w3.org/1999/xhtml" id="measure" style="width:80px;height:40px;margin:16px 0 0 7px;background:red;font-family:ProducerDenied">${dto.source}A<img src="${origin}/marker/html-image.svg" onerror="top.__producerScriptRuns++"/><iframe src="${origin}/marker/frame.html"></iframe><form action="${origin}/marker/form" method="post"><input autofocus="autofocus"/></form></div></foreignObject></svg>`
const abort=new AbortController(),guard=new Error('Independent5s security probe watchdog; not a production timeout'),timer=setTimeout(()=>abort.abort(guard),5000)
let env,result
env=createTrustedProducerProbe({width:160,height:80},abort.signal,stage=>{if(stage==='frame-started')env.testWrongSource()})
try{
const doc=await env.open(svg),view=r(doc,'defaultView'),root=m(doc,'getElementById')('measure'),box=m(root,'getBoundingClientRect')()
const font=m(r(doc,'fonts'),'load')('18px ProducerAllowed','A');await font
const image=Reflect.construct(r(view,'Image'),[]);w(image,'src',dataSVG);await m(image,'decode')()
m(m(doc,'querySelector')('form'),'requestSubmit')()
result={status:'svg-ready',contentType:r(doc,'contentType'),URL:r(doc,'URL'),geometry:{x:box.x,y:box.y,width:box.width,height:box.height},dataImage:[r(image,'naturalWidth'),r(image,'naturalHeight')],dataFontFaces:(await font).length,scriptRuns:window.__producerScriptRuns,constructors:window.__producerConstructors,sourceConstructors:dto.constructors,sourceUnchanged:document.getElementById('source').innerHTML===dto.source,focusBefore:dto.focus,focusAfter:document.activeElement.id}
}catch(error){result={status:'rejected',watchdog:error===guard,error:String(error)}}finally{clearTimeout(timer);env.dispose()}
const snapshot=env.snapshot()
const revoked=[];for(const url of snapshot.createdURLs){try{await fetch(url);revoked.push(false)}catch{revoked.push(true)}}
return{...result,snapshot,revoked,frames:document.querySelectorAll('iframe').length,callerBodyUnchanged:document.body.innerHTML===dto.body}
},{origin,fontURL})
const serverRequests=http.filter(x=>x.at>=start&&x.path.startsWith('/marker/'))
const row={engine,version:browser.version(),...result,serverRequests,network,console:messages}
report.cases.push(row);console.log(JSON.stringify({engine,status:result.status,serverRequests:serverRequests.map(x=>x.path),dataImage:result.dataImage,dataFonts:result.dataFontFaces,scripts:result.scriptRuns,constructors:result.constructors,focus:result.focusAfter,cleanup:result.snapshot,revoked:result.revoked,frames:result.frames}))
await writeFile(new URL('producer-security-results.json',dir),JSON.stringify(report,null,2))
}finally{await context.close();await browser.close()}
}
}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));report.http=http;report.cleanup={browsersClosed:true,serverClosed:true,mainlineModified:false,oldArtifactsModified:false,phoneOperated:false};await writeFile(new URL('producer-security-results.json',dir),JSON.stringify(report,null,2))}
