import { createServer } from 'node:http'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { chromium, firefox, webkit } from 'playwright'
import ts from 'typescript'
const directory = new URL('./', import.meta.url)
await mkdir(new URL('input/', directory), { recursive: true })
const domText = await readFile('src/dom.ts', 'utf8')
await writeFile(new URL('input/src__dom.ts', directory), domText)
const compiled = ts.transpileModule(domText, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2019 } }).outputText
const bootstrap = '(()=>{const exports={};' + compiled + ';window.__dom=exports})()'
const font = await readFile('test/browser/fixtures/font-metrics.ttf')
await writeFile(new URL('input/font-metrics.ttf', directory), font)
const fontURL = 'data:font/ttf;base64,' + font.toString('base64')
const http = []
const server = createServer((request, response) => {
  const path = new URL(request.url, 'http://localhost').pathname
  http.push({ path, at: Date.now(), method: request.method })
  if (path === '/') response.writeHead(200, { 'Content-Type': 'text/html' }).end('<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><body style="margin:0"><input id="focus" value="Caller focus"><div id="caller-source"></div></body>')
  else response.writeHead(200, { 'Content-Type': path.endsWith('.css') ? 'text/css' : path.endsWith('.js') ? 'text/javascript' : path.endsWith('.ttf') ? 'font/ttf' : 'image/svg+xml', 'Cache-Control': 'no-store' }).end(path.endsWith('.css') ? '.none{color:red}' : path.endsWith('.js') ? 'top.__svgScriptRuns++' : path.endsWith('.ttf') ? font : '<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="red"/></svg>')
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const origin = `http://127.0.0.1:${server.address().port}`
const report = { at: new Date().toISOString(), source: { domSHA256: createHash('sha256').update(domText).digest('hex'), fontSHA256: createHash('sha256').update(font).digest('hex') }, cases: [], scope: 'CSP inheritance and SVGDocument geometry feasibility only; separate owned output, no production change.' }
try {
  for (const [engine, type] of Object.entries({ chromium, firefox, webkit })) {
    const browser = await type.launch({ headless: true })
    try {
      for (const creator of ['restricted-realm', 'parent-realm-control']) {
        const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
        const page = await context.newPage()
        const requests = []
        const consoleMessages = []
        page.on('request', request => { if (request.url().startsWith(origin + '/marker/')) requests.push({ url: request.url(), method: request.method(), at: Date.now() }) })
        page.on('console', message => consoleMessages.push({ type: message.type(), text: message.text() }))
        try {
          await page.goto(origin)
          await page.addScriptTag({ content: bootstrap })
          const state = await page.evaluate(async ({ origin, creator, fontURL }) => {
            const { readDOMProperty: r, readDOMMethod: m, writeDOMProperty: w } = window.__dom
            window.__svgScriptRuns = 0
            window.__customRuns = 0
            customElements.define('measurement-source-element', class extends HTMLElement { constructor() { super(); window.__customRuns++ } })
            const sourceDTO = (() => {
              const source = document.getElementById('caller-source')
              source.innerHTML = '<measurement-source-element data-copy="yes"></measurement-source-element>'
              document.getElementById('focus').focus()
              return { html: source.innerHTML, callerHTML: document.body.innerHTML, constructors: window.__customRuns, focus: document.activeElement.id }
            })()
            const frame = m(document, 'createElement')('iframe')
            m(frame, 'setAttribute')('sandbox', 'allow-same-origin')
            m(frame, 'setAttribute')('inert', '')
            m(frame, 'setAttribute')('tabindex', '-1')
            m(frame, 'setAttribute')('aria-hidden', 'true')
            w(r(frame, 'style'), 'cssText', 'position:fixed;left:-99999px;top:0;width:160px;height:80px;opacity:0;border:0;pointer-events:none')
            const policy = "default-src 'none'; script-src 'none'; style-src 'unsafe-inline' data:; img-src data: blob:; font-src data:; base-uri 'none'; form-action 'none'; frame-src 'none'; object-src 'none'; connect-src 'none'"
            const loaded = new Promise(resolve => w(frame, 'onload', resolve))
            w(frame, 'srcdoc', '<!doctype html><meta http-equiv="Content-Security-Policy" content="' + policy + '"><body></body>')
            m(document.documentElement, 'append')(frame)
            let blobURL
            try {
              await loaded
              w(frame, 'onload', null)
              const privateView = r(frame, 'contentWindow')
              const dataSVG = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="blue"/></svg>')
              const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>@font-face{font-family:MeasureData;src:url("${fontURL}")}@font-face{font-family:Denied;src:url("${origin}/marker/font.ttf")}@import url("${origin}/marker/import.css");:root>foreignObject #measure{margin-left:31px!important}@media(min-width:300px){#measure{margin-top:33px!important}}</style><script>top.__svgScriptRuns++</script><script href="${origin}/marker/script.js"/><image href="${origin}/marker/image.svg" width="4" height="4"/><image id="allowed-data" href="${dataSVG}" x="150" width="4" height="4"/><foreignObject width="160" height="80"><div xmlns="http://www.w3.org/1999/xhtml" id="measure" style="width:80px;height:40px;margin:16px 0 0 7px;background:red"><span style="font-family:Denied">A</span>${sourceDTO.html}<img src="${origin}/marker/html-image.svg" onerror="top.__svgScriptRuns++"/><iframe src="${origin}/marker/child-frame.html"></iframe><form action="${origin}/marker/form" method="post"><input autofocus="autofocus"/></form></div></foreignObject></svg>`
              const owner = creator === 'restricted-realm' ? privateView : window
              const BlobClass = r(owner, 'Blob')
              const blob = Reflect.construct(BlobClass, [[svg], { type: 'image/svg+xml' }])
              blobURL = m(r(owner, 'URL'), 'createObjectURL')(blob)
              const navigated = new Promise(resolve => w(frame, 'onload', resolve))
              m(frame, 'removeAttribute')('srcdoc')
              w(frame, 'src', blobURL)
              await navigated
              w(frame, 'onload', null)
              const doc = r(frame, 'contentDocument')
              const view = r(doc, 'defaultView')
              const root = m(doc, 'getElementById')('measure')
              const rect = m(root, 'getBoundingClientRect')()
              const fonts = r(doc, 'fonts')
              const loadedFonts = await m(fonts, 'load')('18px MeasureData', 'A')
              await m(doc.querySelector('form'), 'requestSubmit')()
              const image = Reflect.construct(r(view, 'Image'), [])
              w(image, 'src', dataSVG)
              let dataImage
              try { await m(image, 'decode')(); dataImage = { width: r(image, 'naturalWidth'), height: r(image, 'naturalHeight') } } catch (error) { dataImage = { error: String(error) } }
              return { creator, contentType: r(doc, 'contentType'), URL: r(doc, 'URL'), geometry: { x: rect.x + 99999, y: rect.y, width: rect.width, height: rect.height }, rootMatches: m(doc.documentElement, 'matches')(':root'), media300: m(view, 'matchMedia')('(min-width:300px)').matches, scriptRuns: window.__svgScriptRuns, constructorRuns: window.__customRuns, beforeConstructors: sourceDTO.constructors, focusAfter: document.activeElement.id, focusBefore: sourceDTO.focus, sourceUnchanged: document.getElementById('caller-source').innerHTML === sourceDTO.html, dataImage, loadedDataFonts: loadedFonts.length, fonts: Array.from(fonts, font => ({ family: font.family, status: font.status })) }
            } finally {
              w(frame, 'onload', null)
              m(frame, 'remove')()
              if (blobURL) m(URL, 'revokeObjectURL')(blobURL)
            }
          }, { origin, creator, fontURL })
          const row = { engine, version: browser.version(), ...state, requests, consoleMessages, remainingFrames: await page.locator('iframe').count() }
          report.cases.push(row)
          console.log(JSON.stringify({ engine, creator, requests: requests.map(x => x.url.split('/marker/')[1]), geometry: state.geometry, scripts: state.scriptRuns, constructors: state.constructorRuns, focus: state.focusAfter, dataImage: state.dataImage, dataFonts: state.loadedDataFonts, contentType: state.contentType }))
          await writeFile(new URL('csp-results.json', directory), JSON.stringify(report, null, 2))
        } finally { await context.close() }
      }
    } finally { await browser.close() }
  }
} finally {
  server.closeAllConnections(); await new Promise(resolve => server.close(resolve))
  report.cleanup = { browsersClosed: true, serverClosed: true, mainlineModified: false, oldArtifactsModified: false, phoneOperated: false }
  await writeFile(new URL('http.json', directory), JSON.stringify(http, null, 2))
  await writeFile(new URL('csp-results.json', directory), JSON.stringify(report, null, 2))
}
