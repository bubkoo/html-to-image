import { createServer } from 'node:http'
import { readFile, writeFile } from 'node:fs/promises'
import { chromium, firefox, webkit } from 'playwright'
import ts from 'typescript'
const directory = new URL('./', import.meta.url)
const dom = await readFile(new URL('input/src__dom.ts', directory), 'utf8')
const bootstrap = '(()=>{const exports={};' + ts.transpileModule(dom, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2019 } }).outputText + ';window.__dom=exports})()'
const font = await readFile(new URL('input/font-metrics.ttf', directory))
const fontURL = 'data:font/ttf;base64,' + font.toString('base64')
const http = []
const server = createServer((request, response) => {
  const path = new URL(request.url, 'http://localhost').pathname
  http.push({ path, at: Date.now(), method: request.method })
  response.writeHead(200, { 'Content-Type': path === '/' ? 'text/html' : path.endsWith('.css') ? 'text/css' : path.endsWith('.js') ? 'text/javascript' : path.endsWith('.ttf') ? 'font/ttf' : 'image/svg+xml' })
  response.end(path === '/' ? '<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><body style="margin:0"><input id="focus"><div id="source"></div></body>' : path.endsWith('.ttf') ? font : path.endsWith('.css') ? '.none{color:red}' : path.endsWith('.js') ? 'top.__scriptRuns++' : '<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="red"/></svg>')
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const origin = `http://127.0.0.1:${server.address().port}`
const report = { at: new Date().toISOString(), cases: [], scope: 'Alternative feasibility only: keep restrictive CSP-bearing HTML Document alive, replace its documentElement with SVG root. contentType remains text/html; require independent actual SVG Image selector/media equality before trusting it.' }
try {
  for (const [engine, type] of Object.entries({ chromium, firefox, webkit })) {
    const browser = await type.launch({ headless: true })
    const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
    const page = await context.newPage()
    const requests = [], consoleMessages = []
    page.on('request', request => { if (request.url().includes('/marker/')) requests.push({ url: request.url(), method: request.method(), at: Date.now() }) })
    page.on('console', message => consoleMessages.push({ type: message.type(), text: message.text() }))
    try {
      await page.goto(origin)
      await page.addScriptTag({ content: bootstrap })
      const result = await page.evaluate(async ({ origin, fontURL }) => {
        const { readDOMProperty: r, readDOMMethod: m, writeDOMProperty: w } = window.__dom
        window.__scriptRuns = 0; window.__constructors = 0
        customElements.define('retained-source-element', class extends HTMLElement { constructor() { super(); window.__constructors++ } })
        const sourceDTO = (() => {
          document.getElementById('source').innerHTML = '<retained-source-element data-copy="yes"></retained-source-element>'
          document.getElementById('focus').focus()
          return { markup: document.getElementById('source').innerHTML, focus: document.activeElement.id, constructors: window.__constructors }
        })()
        const frame = m(document, 'createElement')('iframe')
        m(frame, 'setAttribute')('sandbox', 'allow-same-origin'); m(frame, 'setAttribute')('inert', ''); m(frame, 'setAttribute')('tabindex', '-1')
        w(r(frame, 'style'), 'cssText', 'position:fixed;left:-99999px;top:0;width:160px;height:80px;opacity:0;border:0;pointer-events:none')
        const policy = "default-src 'none'; script-src 'none'; style-src 'unsafe-inline' data:; img-src data: blob:; font-src data:; frame-src 'none'; object-src 'none'; connect-src 'none'; base-uri 'none'; form-action 'none'"
        const loaded = new Promise(resolve => w(frame, 'onload', resolve))
        w(frame, 'srcdoc', '<!doctype html><meta http-equiv="Content-Security-Policy" content="' + policy + '"><body></body>')
        m(document.documentElement, 'append')(frame)
        try {
          await loaded; w(frame, 'onload', null)
          const doc = r(frame, 'contentDocument'), view = r(doc, 'defaultView')
          const parse = svg => m(Reflect.construct(r(window, 'DOMParser'), []), 'parseFromString')(svg, 'image/svg+xml')
          const install = svg => {
            const parsed = parse(svg)
            const root = m(doc, 'importNode')(r(parsed, 'documentElement'), true)
            m(doc, 'replaceChild')(root, r(doc, 'documentElement'))
          }
          const dataSVG = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="4" height="4"><rect width="4" height="4" fill="blue"/></svg>')
          const attack = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>@import url("${origin}/marker/import.css");@font-face{font-family:Allowed;src:url("${fontURL}")}@font-face{font-family:Denied;src:url("${origin}/marker/font.ttf")}</style><script>top.__scriptRuns++</script><script href="${origin}/marker/script.js"/><image href="${origin}/marker/image.svg" width="4" height="4"/><foreignObject width="160" height="80"><div xmlns="http://www.w3.org/1999/xhtml"><span style="font-family:Denied">A</span>${sourceDTO.markup}<img src="${origin}/marker/html-image.svg" onerror="top.__scriptRuns++"/><iframe src="${origin}/marker/frame.html"></iframe><form action="${origin}/marker/form" method="post"><input autofocus="autofocus"/></form></div></foreignObject></svg>`
          install(attack)
          const loadedFonts = await m(r(doc, 'fonts'), 'load')('18px Allowed', 'A')
          const image = Reflect.construct(r(view, 'Image'), []); w(image, 'src', dataSVG); await m(image, 'decode')()
          m(m(doc, 'querySelector')('form'), 'requestSubmit')()
          const security = { contentType: r(doc, 'contentType'), namespace: r(r(doc, 'documentElement'), 'namespaceURI'), scriptRuns: window.__scriptRuns, constructors: window.__constructors, sourceConstructors: sourceDTO.constructors, sourceUnchanged: document.getElementById('source').innerHTML === sourceDTO.markup, focusBefore: sourceDTO.focus, focusAfter: document.activeElement.id, dataImage: [r(image, 'naturalWidth'), r(image, 'naturalHeight')], dataFonts: loadedFonts.length }
          const cases = [
            { name: 'plain', css: '' },
            { name: 'svg-root-selector', css: ':root>foreignObject #measure{margin-left:31px!important}' },
            { name: 'active-media150', css: '@media(min-width:150px){#measure{margin-top:23px!important}}' },
            { name: 'inactive-media300', css: '@media(min-width:300px){#measure{margin-top:33px!important}}' },
            { name: 'uppercase-html-selector', css: 'DIV{margin-left:43px!important}' },
            { name: 'lowercase-foreign-selector', css: 'foreignobject #measure{margin-left:47px!important}' },
          ]
          const geometry = []
          for (const entry of cases) {
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80"><style>${entry.css}</style><foreignObject width="160" height="80"><div xmlns="http://www.w3.org/1999/xhtml" id="measure" style="width:80px;height:40px;margin:16px 0 0 7px;background:red"></div></foreignObject></svg>`
            install(svg)
            const measure = m(doc, 'getElementById')('measure'), foreign = m(doc, 'querySelector')('foreignObject')
            const box = m(measure, 'getBoundingClientRect')(), fo = m(foreign, 'getBoundingClientRect')()
            const documentOrigin = { x: box.x - fo.x, y: box.y - fo.y }
            const actual = new Image(); actual.src = 'data:image/svg+xml,' + encodeURIComponent(svg); await actual.decode()
            const canvas = document.createElement('canvas'); canvas.width =160; canvas.height =80; const ctx = canvas.getContext('2d'); ctx.drawImage(actual,0,0); const pixels = ctx.getImageData(0,0,160,80).data
            let minX =160, minY =80
            for(let y=0;y<80;y++)for(let x=0;x<160;x++){const i=(y*160+x)*4;if(pixels[i]===255&&pixels[i+1]===0&&pixels[i+2]===0&&pixels[i+3]===255){minX=Math.min(minX,x);minY=Math.min(minY,y)}}
            geometry.push({ ...entry, documentOrigin, svgImageOrigin: { x:minX,y:minY }, match:documentOrigin.x===minX&&documentOrigin.y===minY })
          }
          return { security, geometry }
        } finally { w(frame,'onload',null);m(frame,'remove')() }
      }, { origin, fontURL })
      const row = { engine, version: browser.version(), ...result, requests, consoleMessages, remainingFrames: await page.locator('iframe').count() }
      report.cases.push(row)
      console.log(JSON.stringify({ engine, security:result.security, requests:requests.map(x=>x.url.split('/marker/')[1]), geometry:result.geometry }))
    } finally { await context.close(); await browser.close() }
  }
} finally {
  server.closeAllConnections();await new Promise(resolve=>server.close(resolve))
  report.cleanup={browsersClosed:true,serverClosed:true,mainlineModified:false,oldArtifactsModified:false,phoneOperated:false}
  await writeFile(new URL('retained-policy-http.json',directory),JSON.stringify(http,null,2))
  await writeFile(new URL('retained-policy-results.json',directory),JSON.stringify(report,null,2))
}
