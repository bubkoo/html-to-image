import { readDOMProperty as r, readDOMMethod as m, writeDOMProperty as w } from './dom.snapshot'

// Experimental bounded static HTML/CSS prototype. This is deliberately not a
// production copier or a selector policy. All unsupported contexts are unknown.
type D = any
type Step = { kind: 'child' | 'shadow'; index: number }
type Attr = { name: string; namespace: string | null; value: string }
type Tree = { kind: 'text'; value: string } | { kind: 'comment'; value: string } | {
  kind: 'element'; name: string; namespace: string; attributes: Attr[];
  children: Tree[]; shadow?: Tree[]; styleText?: string
}
type Metrics = { client: number[]; extent: number[]; offset: number[] }
export interface ContextDTO {
  schema: 'bounded-native-context/v1'
  viewport: number[]
  htmlAttributes: Attr[]
  head: Tree[]
  body: Tree
  targetPath: Step[]
  selectedStylePath: Step[]
  rulePath: number[]
  ruleText: string
  selector: string
  partAndSuffix: string
  ordinaryPrefix: string
  ordinaryExpected: boolean
  scope: 'document' | 'shadow-root'
  metrics: Metrics
  ownerState: Record<string, string>
}
export type Snapshot = { status: 'snapshot'; dto: ContextDTO } | { status: 'unknown'; reason: string }
const nativePart = /::(-webkit-scrollbar(?:-thumb|-track-piece|-track|-corner)?)(?::(?:horizontal|vertical|start|end))*$/
const knownTags = new Set(['html', 'head', 'body', 'div', 'span', 'style'])
const badCSS = /(?:animation|transition)\s*:|url\s*\(|@import\b|@namespace\b|expression\s*\(|-moz-binding|behavior\s*:|var\s*\(/i
const unsupportedSelector = /\[|:(?!host\(|is\(|where\(|horizontal\b|vertical\b|start\b|end\b|:-webkit-scrollbar)\w|\+|~|\|/i
const list = (value: D): D[] => {
  const values: D[] = []
  for (let i = 0; i < r(value, 'length'); i++) values.push(r(value, i))
  return values
}
const attrs = (node: D): Attr[] => list(r(node, 'attributes')).map(a => ({
  name: r(a, 'name'), namespace: r(a, 'namespaceURI'), value: r(a, 'value'),
}))
const metrics = (node: D): Metrics => ({
  client: [r(node, 'clientWidth'), r(node, 'clientHeight')],
  extent: [r(node, 'scrollWidth'), r(node, 'scrollHeight')],
  offset: [r(node, 'scrollLeft'), r(node, 'scrollTop')],
})
function reject(reason: string): never { throw new Error(reason) }
function safeSelector(selector: string): void {
  if (unsupportedSelector.test(selector)) reject('unsupported-selector-state-or-structure')
  // :is/:where with only plain static branches are kept exactly. Any :host
  // mixed into a functional list remains outside this bounded snapshotter.
  if (/:(?:is|where)\([^)]*:host/.test(selector)) reject('unsupported-functional-host-context')
}
function cssText(sheet: D, selected: D, path: number[], found: { rule?: number[]; selector?: string; ancestors: string[] }): string {
  const rules = list(r(sheet, 'cssRules'))
  return rules.map((rule, i) => {
    const here = path.concat(i)
    const text = r(rule, 'cssText') as string
    if (badCSS.test(text)) reject('unsupported-css-resource-or-variable')
    const selector = r(rule, 'selectorText') as string | undefined
    if (selector != null) safeSelector(selector)
    else if (!/^@(media|supports|layer)\b/i.test(text)) reject('unsupported-rule-envelope')
    if (!selector && /^@media\b/i.test(text)) {
      const condition = r(rule, 'conditionText') as string
      if (!/^\(\s*(?:min|max)-(?:width|height)\s*:\s*\d+(?:\.\d+)?px\s*\)$/.test(condition)) reject('unsupported-dynamic-media-envelope')
    }
    if (rule === selected) {
      const image = m(r(rule, 'style'), 'getPropertyValue')('background-image') as string
      if (image && image !== 'none') reject('unsupported-source-background-image-cascade')
      if (!selector || !nativePart.test(selector)) reject('unsupported-selected-native-rule')
      found.rule = here; found.selector = selector
    }
    const nested = r(rule, 'cssRules')
    if (nested && r(nested, 'length')) {
      const before = found.rule
      cssText(rule, selected, here, found)
      if (found.rule !== before && selector) found.ancestors.unshift(selector)
    }
    return text
  }).join('\n')
}
function basicOrdinaryExpected(target: D, prefix: string, ancestors: string[]): { prefix: string; expected: boolean } {
  let resolved = prefix
  // Only one uncomplicated nesting parent is calibrated. The original native
  // selector/envelope is never rewritten: this is an ordinary-match crosscheck.
  for (let i = ancestors.length - 1; i >= 0; i--) {
    const parent = ancestors[i]
    if (parent.includes(',') || parent.includes(':') || parent.includes('&')) reject('unsupported-nesting-calibration')
    resolved = resolved.includes('&') ? resolved.replace(/&/g, parent) : parent + ' ' + resolved
  }
  if (resolved.includes('&')) reject('unresolved-nesting-context')
  const host = /^:host\((\.[\w-]+)\)\s+(.+)$/.exec(resolved)
  if (host) {
    const root = m(target, 'getRootNode')()
    const ownerHost = r(root, 'host')
    if (!ownerHost) return { prefix: resolved, expected: false }
    return { prefix: resolved, expected: m(ownerHost, 'matches')(host[1]) && m(target, 'matches')(host[2]) }
  }
  if (resolved.includes(':host')) reject('unsupported-host-context')
  return { prefix: resolved, expected: m(target, 'matches')(resolved) }
}

// Intentionally synchronous. All maps holding original nodes/rules live only in
// this call and are discarded before returning a primitive-only DTO.
export function snapshotContext(target: D, selectedRule: D): Snapshot {
  try {
    const source = r(target, 'ownerDocument'), view = r(source, 'defaultView')
    const computed = m(view, 'getComputedStyle')(target), ownerState: Record<string, string> = {}
    for (const property of ['overflow-x', 'overflow-y', 'direction', 'writing-mode', 'scrollbar-width']) ownerState[property] = m(computed, 'getPropertyValue')(property)
    if (ownerState['overflow-x'] !== 'scroll' || ownerState['overflow-y'] !== 'scroll' || ownerState.direction !== 'ltr' || ownerState['writing-mode'] !== 'horizontal-tb' || !['', 'auto'].includes(ownerState['scrollbar-width'])) reject('unsupported-owner-scrollbar-state')
    if (r(source, 'compatMode') !== 'CSS1Compat') reject('unsupported-document-mode')
    if (r(r(source, 'adoptedStyleSheets'), 'length')) reject('unsupported-adopted-source-stylesheets')
    const body = r(source, 'body'), head = r(source, 'head'), html = r(source, 'documentElement')
    const paths = new Map<D, Step[]>(), found: { style?: Step[]; rule?: number[]; selector?: string; ancestors: string[] } = { ancestors: [] }
    const visit = (node: D, path: Step[]): Tree => {
      paths.set(node, path)
      const type = r(node, 'nodeType')
      if (type === 3 || type === 8) return { kind: type === 3 ? 'text' : 'comment', value: r(node, 'nodeValue') || '' }
      if (type !== 1) reject('unsupported-node-type')
      const name = r(node, 'localName') as string, namespace = r(node, 'namespaceURI') as string
      if (namespace !== 'http://www.w3.org/1999/xhtml' || !knownTags.has(name)) reject('unsupported-active-or-foreign-element')
      const attributes = attrs(node)
      for (const attr of attributes) {
        if (attr.namespace || !/^(id|class|style|data-[\w-]+)$/.test(attr.name)) reject('unsupported-active-or-selector-attribute')
        if (attr.name === 'style' && badCSS.test(attr.value)) reject('unsupported-inline-resource-or-variable')
      }
      const result: Extract<Tree, { kind: 'element' }> = { kind: 'element', name, namespace, attributes, children: [] }
      if (name === 'style') {
        const sheet = r(node, 'sheet')
        if (!sheet) reject('unavailable-stylesheet')
        if (r(sheet, 'disabled')) reject('unsupported-disabled-stylesheet')
        const before = found.rule
        result.styleText = cssText(sheet, selectedRule, [], found)
        if (found.rule !== before) found.style = path
      }
      result.children = list(r(node, 'childNodes')).map((child, index) => visit(child, path.concat({ kind: 'child', index })))
      const shadow = r(node, 'shadowRoot')
      if (shadow) {
        if (r(shadow, 'mode') !== 'open') reject('unsupported-closed-shadow')
        if (r(r(shadow, 'adoptedStyleSheets'), 'length')) reject('unsupported-adopted-source-stylesheets')
        result.shadow = list(r(shadow, 'childNodes')).map((child, index) => visit(child, path.concat({ kind: 'shadow', index })))
      }
      if (name === 'div' && r(node, 'tagName') !== 'DIV') reject('unexpected-custom-element-state')
      return result
    }
    // The bounded contract excludes head selectors/structural selectors. The
    // private frame keeps its own CSP meta in head, separate from source styles.
    const headDTO = list(r(head, 'childNodes')).map((node, index) => visit(node, [{ kind: 'child', index: -1 }, { kind: 'child', index }]))
    const tree = visit(body, [])
    const targetPath = paths.get(target)
    if (!targetPath || !found.style || !found.rule || !found.selector) reject('target-or-rule-not-in-snapshot')
    const part = found.selector.match(nativePart)![0], prefix = found.selector.slice(0, -part.length)
    if (!['::-webkit-scrollbar', '::-webkit-scrollbar-thumb:horizontal', '::-webkit-scrollbar-track:vertical'].includes(part)) reject('unsupported-unproven-part-state')
    const ordinary = basicOrdinaryExpected(target, prefix, found.ancestors)
    const targetRoot = m(target, 'getRootNode')()
    const dto: ContextDTO = {
      schema: 'bounded-native-context/v1', viewport: [r(view, 'innerWidth'), r(view, 'innerHeight')],
      htmlAttributes: attrs(html), head: headDTO, body: tree, targetPath,
      selectedStylePath: found.style, rulePath: found.rule,
      ruleText: r(selectedRule, 'cssText'), selector: found.selector, partAndSuffix: part,
      ordinaryPrefix: ordinary.prefix, ordinaryExpected: ordinary.expected,
      scope: targetRoot === source ? 'document' : 'shadow-root', metrics: metrics(target), ownerState,
    }
    if (dto.htmlAttributes.some(a => a.namespace || !/^(id|class|style)$/.test(a.name) || (a.name === 'style' && badCSS.test(a.value)))) reject('unsupported-html-attribute')
    return { status: 'snapshot', dto }
  } catch (error) {
    return { status: 'unknown', reason: error instanceof Error ? error.message : 'snapshot-read-failed' }
  }
}

export interface Measurement {
  status: 'measured' | 'unknown'
  applies?: boolean
  reason?: string
  evidence: Record<string, unknown>
}
export interface ProbeOptions { fenceDelayMs?: number; onPhase?: (phase: string) => void }
function validateDTO(dto: ContextDTO): void {
  const seen = new Set<object>()
  const primitive = (value: unknown): void => {
    if (value == null || ['string', 'number', 'boolean'].includes(typeof value)) return
    if (typeof value !== 'object' || seen.has(value as object)) reject('non-primitive-or-cyclic-context')
    const proto = Object.getPrototypeOf(value)
    if (proto !== Object.prototype && proto !== Array.prototype && proto !== null) reject('non-plain-context-object')
    seen.add(value as object)
    Object.keys(value).forEach(key => primitive((value as Record<string, unknown>)[key]))
    seen.delete(value as object)
  }
  primitive(dto)
  if (dto.schema !== 'bounded-native-context/v1') reject('unsupported-context-schema')
  safeSelector(dto.selector)
  const attributes = (values: Attr[]) => values.forEach(a => {
    if (a.namespace || !/^(id|class|style|data-[\w-]+)$/.test(a.name)) reject('unsafe-context-attribute')
    if (a.name === 'style' && badCSS.test(a.value)) reject('unsafe-context-inline-css')
  })
  const tree = (node: Tree): void => {
    if (node.kind === 'text' || node.kind === 'comment') return
    if (!knownTags.has(node.name) || node.namespace !== 'http://www.w3.org/1999/xhtml') reject('unsafe-context-element')
    attributes(node.attributes)
    if (node.styleText != null && badCSS.test(node.styleText)) reject('unsafe-context-stylesheet')
    node.children.forEach(tree); node.shadow?.forEach(tree)
  }
  attributes(dto.htmlAttributes); dto.head.forEach(tree); tree(dto.body)
}
export function createContextExecutor(dto: ContextDTO, signal?: AbortSignal, options: ProbeOptions = {}) {
  const owner = document // Owned harness document, never a snapshotted source.
  let frame: D, owned: D, pendingReject: ((reason: unknown) => void) | undefined
  let disposed = false, started = false, finished = false, cancelled = false, cancelReason: unknown
  const removals: (() => void)[] = [], timers = new Set<ReturnType<typeof setTimeout>>()
  const events: { marker: string; directive: string; at: number }[] = []
  const nonce = Math.random().toString(36).slice(2), base = r(r(owner, 'location'), 'origin') + '/native-context-probe/' + nonce + '/'
  const urls = { part: base + 'part.png', context: base + 'context.png', positive: base + 'positive.png', negative: base + 'negative.png', fence: base + 'fence.png' }
  const partVar = '--native-part-' + nonce, contextVar = '--native-context-' + nonce
  const diagnostics = { framesCreated: 0, framesRemoved: 0, disposedCalls: 0, listeners: 0, lateEvents: 0, completed: false, phases: [] as string[] }
  const phase = (value: string) => { diagnostics.phases.push(value); options.onPhase?.(value) }
  const listen = (object: D, type: string, fn: D) => {
    m(object, 'addEventListener')(type, fn); diagnostics.listeners++
    removals.push(() => { m(object, 'removeEventListener')(type, fn); diagnostics.listeners-- })
  }
  const timer = (callback: () => void, milliseconds: number) => {
    const id = setTimeout(() => { timers.delete(id); callback() }, milliseconds)
    timers.add(id); return id
  }
  const dispose = () => {
    diagnostics.disposedCalls++
    if (disposed) return
    disposed = true
    while (removals.length) removals.pop()!()
    timers.forEach(clearTimeout); timers.clear()
    if (frame) { m(frame, 'remove')(); diagnostics.framesRemoved++; frame = undefined }
    owned = undefined
    if (pendingReject) { const fail = pendingReject; pendingReject = undefined; fail(cancelled ? cancelReason : new Error('Probe disposed')) }
  }
  const abort = () => {
    cancelled = true; cancelReason = r(signal!, 'reason'); phase('abort'); dispose()
  }
  const check = () => { if (cancelled) throw cancelReason; if (disposed) throw new Error('Probe disposed') }
  const attributes = (node: D, values: Attr[]) => values.forEach(a => m(node, 'setAttribute')(a.name, a.value))
  const make = (tree: Tree): D => {
    if (tree.kind === 'text') return m(owned, 'createTextNode')(tree.value)
    if (tree.kind === 'comment') return m(owned, 'createComment')(tree.value)
    const node = m(owned, 'createElementNS')(tree.namespace, tree.name); attributes(node, tree.attributes)
    if (tree.styleText != null) w(node, 'textContent', tree.styleText)
    else tree.children.forEach(child => m(node, 'append')(make(child)))
    if (tree.shadow) {
      const shadow = m(node, 'attachShadow')({ mode: 'open' })
      tree.shadow.forEach(child => m(shadow, 'append')(make(child)))
    }
    return node
  }
  const path = (steps: Step[]): D => {
    let node = r(owned, 'body')
    for (const step of steps) {
      if (step.index === -1) { node = r(owned, 'head'); continue }
      if (step.kind === 'shadow') node = r(node, 'shadowRoot')
      node = r(r(node, 'childNodes'), step.index)
    }
    return node
  }
  const ruleAt = (sheet: D): D => {
    let object = sheet
    for (const index of dto.rulePath) object = r(r(object, 'cssRules'), index)
    return object
  }
  const sheet = (root: D, text: string): D => {
    const constructor = r(r(owned, 'defaultView'), 'CSSStyleSheet') as D
    const result: D = Reflect.construct(constructor, [])
    m(result, 'replaceSync')(text)
    w(root, 'adoptedStyleSheets', list(r(root, 'adoptedStyleSheets')).concat(result))
    return result
  }
  const set = (node: D, property: string, value: string) => m(r(node, 'style'), 'setProperty')(property, value, 'important')
  const evidence = () => ({ events: events.slice(), metrics: owned ? metrics(path(dto.targetPath)) : null, exactSelector: dto.selector, originalPartAndSuffix: dto.partAndSuffix, urls, diagnostics: { ...diagnostics, phases: diagnostics.phases.slice(), timers: timers.size } })
  const run = async (): Promise<Measurement> => {
    if (started) throw new Error('Probe already started')
    started = true
    try {
      // Read/throw preabort before any frame creation, preserving every reason.
      if (signal && r(signal, 'aborted')) { cancelled = true; cancelReason = r(signal, 'reason'); throw cancelReason }
      check()
      validateDTO(dto)
      if (signal) listen(signal, 'abort', abort)
      check()
      // DTO is JSON round-trippable and contains no original DOM references.
      phase('frame-create'); check()
      frame = m(owner, 'createElement')('iframe'); diagnostics.framesCreated++
      m(frame, 'setAttribute')('sandbox', 'allow-same-origin allow-scripts')
      m(frame, 'setAttribute')('data-owned-native-context-probe', nonce)
      w(r(frame, 'style'), 'cssText', 'position:fixed;left:-20000px;top:0;border:0;width:' + dto.viewport[0] + 'px;height:' + dto.viewport[1] + 'px')
      await new Promise<void>((resolve, reject) => {
        pendingReject = reject
        listen(frame, 'load', () => {
          if (disposed) { diagnostics.lateEvents++; return }
          const doc = r(frame, 'contentDocument')
          if (!doc || !m(doc, 'querySelector')('meta[data-native-context-policy]')) return
          owned = doc; pendingReject = undefined; resolve()
        })
        timer(() => reject(new Error('Frame readiness timeout')), 2000)
        w(frame, 'srcdoc', '<!doctype html><meta data-native-context-policy http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'none\'; style-src \'unsafe-inline\'; img-src \'none\'; font-src \'none\'; base-uri \'none\'; form-action \'none\'"><body></body>')
        m(r(owner, 'documentElement'), 'append')(frame)
      })
      check(); phase('frame-ready'); check()
      let notify = () => {}
      listen(owned, 'securitypolicyviolation', (event: D) => {
        if (disposed || finished) { diagnostics.lateEvents++; return }
        const uri = r(event, 'blockedURI') as string
        if (!uri.startsWith(base)) return
        const marker = Object.keys(urls).find(key => urls[key as keyof typeof urls] === uri) || 'other'
        events.push({ marker, directive: r(event, 'effectiveDirective'), at: m(performance, 'now')() }); notify()
      })
      attributes(r(owned, 'documentElement'), dto.htmlAttributes)
      dto.head.forEach(tree => m(r(owned, 'head'), 'append')(make(tree)))
      const bodyDTO = dto.body as Extract<Tree, { kind: 'element' }>
      attributes(r(owned, 'body'), bodyDTO.attributes)
      bodyDTO.children.forEach(tree => m(r(owned, 'body'), 'append')(make(tree)))
      const target = path(dto.targetPath), styleNode = path(dto.selectedStylePath), originalSheet = r(styleNode, 'sheet')
      const selected = ruleAt(originalSheet), root = m(styleNode, 'getRootNode')()
      if (r(selected, 'selectorText') !== dto.selector || r(selected, 'cssText') !== dto.ruleText) return { status: 'unknown', reason: 'rule-envelope-or-parser-mismatch', evidence: evidence() }
      w(target, 'scrollLeft', dto.metrics.offset[0]); w(target, 'scrollTop', dto.metrics.offset[1])
      if (JSON.stringify(metrics(target)) !== JSON.stringify(dto.metrics)) return { status: 'unknown', reason: 'source-context-geometry-mismatch', evidence: evidence() }
      // The complete original selector/part/suffix stays untouched. Fresh
      // variables are reset on every ordinary element, then set on target only.
      sheet(root, '*{' + partVar + ':none!important;' + contextVar + ':none!important}')
      set(target, partVar, 'url("' + urls.part + '")'); set(target, contextVar, 'url("' + urls.context + '")')
      m(r(selected, 'style'), 'setProperty')('background-image', 'var(' + partVar + ')', 'important')
      const contextSheet = sheet(root, dto.head.length || dto.body ? list(r(originalSheet, 'cssRules')).map(rule => r(rule, 'cssText')).join('\n') : '')
      const ordinary = ruleAt(contextSheet)
      w(ordinary, 'selectorText', dto.selector.slice(0, -dto.partAndSuffix.length))
      w(r(ordinary, 'style'), 'cssText', 'background-image:var(' + contextVar + ')!important')
      // Calibration lives in its own shadow scope and has no source marker.
      const control = m(owned, 'createElement')('div'), controlRoot = m(control, 'attachShadow')({ mode: 'open' })
      const cal = m(owned, 'createElement')('div'), content = m(owned, 'createElement')('div')
      m(cal, 'setAttribute')('id', 'calibration'); w(r(cal, 'style'), 'cssText', 'width:100px;height:100px;overflow:scroll')
      w(r(content, 'style'), 'cssText', 'width:240px;height:300px'); m(cal, 'append')(content); m(controlRoot, 'append')(cal)
      sheet(controlRoot, '#calibration::-webkit-scrollbar{width:11px;height:7px}#calibration' + dto.partAndSuffix + '{background-image:url("' + urls.positive + '")}#missing' + dto.partAndSuffix + '{background-image:url("' + urls.negative + '")}')
      m(r(owned, 'documentElement'), 'append')(control); w(cal, 'scrollLeft', dto.metrics.offset[0]); w(cal, 'scrollTop', dto.metrics.offset[1])
      // Force actual style/layout work before entering an unresolved CSP wait.
      m(target, 'getBoundingClientRect')(); m(cal, 'getBoundingClientRect')(); phase('csp-wait'); check()
      const result = await new Promise<Measurement>((resolve, reject) => {
        pendingReject = reject
        notify = () => {
          if (disposed || finished) return
          if (!events.some(event => event.marker === 'fence')) return
          pendingReject = undefined
          const has = (marker: string) => events.some(event => event.marker === marker && event.directive === 'img-src')
          const contextOK = has('context') === dto.ordinaryExpected
          const sourceExtentObservable = dto.metrics.client.every((value, axis) => value > 0 && dto.metrics.extent[axis] > value)
          const result: Measurement = !has('part') && dto.ordinaryExpected && !sourceExtentObservable
            ? { status: 'unknown', reason: 'part-state-unobservable', evidence: evidence() }
            : !has('positive') || has('negative') || !contextOK
            ? { status: 'unknown', reason: !has('positive') ? 'same-part-positive-unobservable' : has('negative') ? 'same-part-negative-not-quiet' : 'ordinary-prefix-context-mismatch', evidence: evidence() }
            : { status: 'measured', applies: has('part'), evidence: evidence() }
          resolve(result)
        }
        timer(() => { pendingReject = undefined; resolve({ status: 'unknown', reason: 'fence-timeout', evidence: evidence() }) }, 1000)
        timer(() => {
          if (disposed) return
          phase('fence-insert')
          const fence = m(owned, 'createElement')('div'); w(r(fence, 'style'), 'cssText', 'width:1px;height:1px;background-image:url("' + urls.fence + '")')
          m(r(owned, 'documentElement'), 'append')(fence); m(fence, 'getBoundingClientRect')()
        }, options.fenceDelayMs == null ? 20 : options.fenceDelayMs)
      })
      check(); finished = true; diagnostics.completed = true; phase('complete'); return result
    } catch (error) {
      if (cancelled) throw cancelReason
      throw error
    } finally { dispose() }
  }
  return { run, dispose, diagnostics: () => ({ ...diagnostics, phases: diagnostics.phases.slice(), timers: timers.size, framePresent: Boolean(frame), eventMarkers: events.map(event => event.marker), urls: { ...urls } }) }
}

export const DOM = { r, m, w, list, metrics }
