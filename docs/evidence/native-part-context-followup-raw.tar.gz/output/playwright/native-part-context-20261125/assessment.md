# 静态原生 scrollbar 上下文原型

本轮验证了同步 DTO 快照、原规则重建、多个 scroller 的目标归因和实际等待取消。它仍是有明确范围的原型，不能作为通用 selector 过滤器或已完成的生产修复。

## 实际源对照

Chromium 156.0.8078.4 / WebKit 27.2 中共 24/24 对一致。源是实际渲染的独立 Document/ShadowRoot 树，源 target 自己的 scrollbar 轴带像素提供真值；PNG 没有遮罩或修改。整张截图可能包含嵌套 scroller 的黄色，所以最终判据只数 target 自己的横轴/纵轴带，并保留整张原图。没有用 base computed 色代替原生源结果。

覆盖 Document/ShadowRoot 的 sibling 阳性与阴性、嵌套 descendant 阴性、host 条件、普通 :is，以及原样 nesting/media/supports/layer 规则。源完全移除、引用清除后才调用 executor，所有快照都是同步返回的 primitives。原 selector 与 CSSOM rule path 在原 sheet 中保持，校验源 ruleText 与重建 ruleText 相等后只加入 background-image 标记。实际 native selector 没有展开成 :is 或替换 part。

嵌套阴性中，target 自己的横条黄色为 0，子 scroller 导致整张图仍有黄色 49；executor 对 target 返回 false，而同一快照树中把 child 设为 target 后返回 true。新鲜 marker 变量在 scope 中每个普通元素上重置为 none!important，只在目标上设置 URL，因此 child 不能继承 target URL。所有 source attribute selector（含 [style]）都拒绝；增加 inline marker 不被用来支持这些 selector。

## 取消、清理和环境隔离

每浏览器 6 个 preabort、6 个实际 CSP wait 期间 abort、1 个 pending iframe load abort，合计 26 个取消 reason 严格同一。reason 含 0、false、null、字符串、对象与不可 string 化对象。CSP wait 的取消发生在 part/context/positive 事件已到、fence 未插入时，随后发出的 late fence 不恢复完成。另验证 run 前 dispose 和真实 wait 中重复 dispose，所有 listener/timer/frame 清零。

执行器只接收 DTO，在 owned harness 中建立独立 trusted-only iframe，sandbox allow-same-origin allow-scripts，script-src none / img-src none。没有复用或放宽现有不可信 SVG 环境。主动插入 inline script / onerror 的私有 frame 负控在两浏览器执行均 0，script-src-elem / script-src-attr 拒绝都可见。篡改 DTO 插入 script 在创建 frame 前被拒绝。

32 个快照负控均 unknown，包含活动元素、handler、URL、源 var()/gradient、disabled stylesheet、[style]、hover、nth-child、混合 host functional、动态 media、标准 scrollbar-width:none、RTL 和未证明的 track-piece。几何不符、rule text 不符、fence 超时、inactive media 下 ordinary-prefix 校准不符也都 unknown。所有标记和 guard URL 指向 owned loopback server；两轮服务器都仅收到 2 个页面请求，没有图片/标记 HTTP 请求。所有浏览器与 server 已关闭。

## 可绘制性反例检查

另外固定前置版本完成 12 个 visibility 对照，输入、PNG、事件位于 visibility-results：

- root width/height:0 和 root display:none：源 client 从 [89,93] 变为 [100,100]，没有黄/黑像素，直接证明规则参与并隐藏 scrollbar。part CSP 事件仍存在，返回 true。
- ancestor opacity:0：源 client 保持 [89,93]、截图全无黄/黑，但 part/context/positive/fence 均存在，返回 true。
- ancestor display:none：源 client [0,0]，ordinary-prefix marker 缺席，返回 unknown。
- thumb opacity:0 / display:none：在这两个版本里没有隐藏实际 thumb（仍黄 231），返回 true。

因此这一组没有找到“规则参与、事件缺席却 false”的反例；不能把像素 0 解释为未匹配，也不能反过来由 12 例证明任意不可绘制 part 都可靠。当前版本进一步限制 owner 为 LTR horizontal-tb、双轴 overflow:scroll、scrollbar-width:auto，selected part 仅为实际验证的 bare root、thumb:horizontal、track:vertical。button/track-piece 等未证明的 part/state 明确 unknown，未制造默认不存在的 part。absence 且源轴 extent 不可观察时也 unknown。

## 证据边界与下一步

原型只证明上述固定静态范围。剩余门槛包括任意源 CSS/资源/var 的有效值、原生 part 更复杂状态、完整祖先与外部 stylesheet/namespace/scope/container、闭合 ShadowRoot、动态状态、跨浏览器事件 fence 的一般调度保证。当前实验中的 fence 顺序可观察，不能当成任意资源调度的完成屏障证明。

如果继续实现，应先选一条真实 issue 中尚不支持的最小上下文作为新增反例，把源真值、目标唯一归因、ordinary-prefix、同 part 正负校准、不可绘制性、取消清理一起验证；不要把本次 24 对推广成任意 sourceDocument 的结论，也不要先接入主线规则过滤。

## 复现与类型检查

- node output/playwright/native-part-context-20261125/compile.cjs
- node output/playwright/native-part-context-20261125/probe.mjs
- node output/playwright/native-part-context-20261125/visibility-probe.mjs

独立 TypeScript 检查按仓库 noImplicitAny / strictNullChecks / noUnusedLocals、ES5 target 通过，没有运行主线 build。额外 strictFunctionTypes 尝试只在原样复制的 dom helper 既有泛型转换处失败，保留日志，未修改该 helper 或主线。

两个早期探针错误保留原日志及清理回执：一是移除 frame 后再读取 defaultView，二是测试 guard 在 body 前插节点改变 DTO index；最终分别改为提前取得 owned test realm 的 event constructor，以及 guard 独立放在 head。它们不属于生产源码修复。
