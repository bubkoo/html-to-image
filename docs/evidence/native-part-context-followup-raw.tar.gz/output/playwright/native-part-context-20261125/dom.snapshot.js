// A self-hosted Reflect.get can itself cache a foreign DOM getter. Forward
// through a transparent proxy so that its property cache sees only the proxy.
// An explicit receiver preserves native accessors and existing proxy traps.
// The handler has no prototype or traps, and no proxy is retained after use.
const handler = Object.freeze(Object.create(null));
function readDOMProperty(target, key) {
    // Array-like and prototype helpers also accept erased primitive values.
    // Box the lookup target while preserving the original accessor receiver;
    // nullish targets must still throw instead of becoming empty objects.
    const object = target == null ? target : Object(target);
    return Reflect.get(new Proxy(object, handler), key, target);
}
// Resolve the method before evaluating arguments, then retain its receiver.
// Forwarding the original method type preserves DOM overloads.
function readDOMMethod(target, key) {
    const method = readDOMProperty(target, key);
    return ((...args) => Reflect.apply(method, target, args));
}
function readOptionalDOMProperty(target, key) {
    return target == null ? undefined : readDOMProperty(target, key);
}
function readOptionalDOMMethod(target, key) {
    return target == null ? undefined : readDOMMethod(target, key);
}
// Keep the argument order of `key in target`; Reflect.has also leaves getters
// uncalled while checking inherited properties.
function hasDOMProperty(key, target) {
    return Reflect.has(new Proxy(target, handler), key);
}
function writeDOMProperty(target, key, value) {
    // Preserve strict assignment failure and the RHS return value, even when a
    // native setter normalizes the value stored in the DOM.
    if (!Reflect.set(new Proxy(target, handler), key, value, target)) {
        throw new TypeError('Cannot assign a DOM property');
    }
    return value;
}
