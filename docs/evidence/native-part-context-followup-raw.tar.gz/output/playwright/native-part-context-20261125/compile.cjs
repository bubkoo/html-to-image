const fs = require('node:fs')
const ts = require('typescript')
const p = __dirname + '/'
for (const name of ['dom.snapshot', 'prototype']) {
  let source = ts.transpileModule(fs.readFileSync(p + name + '.ts', 'utf8'), {
    compilerOptions: {target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ESNext},
  }).outputText
  source = source.replace(/^import .*$/gm, '').replace(/export /g, '')
  if (name === 'prototype') source = 'const r=readDOMProperty,m=readDOMMethod,w=writeDOMProperty;\n' + source + '\nwindow.nativeContextPrototype={snapshotContext,createContextExecutor,DOM};'
  fs.writeFileSync(p + name + '.js', source)
}
