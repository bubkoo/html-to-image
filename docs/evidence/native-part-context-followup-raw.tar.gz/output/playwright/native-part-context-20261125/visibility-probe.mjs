import { chromium, webkit } from 'playwright'
import { createServer } from 'node:http'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
const folder = new URL('./visibility-results/', import.meta.url)
await mkdir(folder, { recursive: true })
const helper = await readFile(new URL('./dom.snapshot.js', import.meta.url), 'utf8')
const prototype = await readFile(new URL('./prototype-before-visibility-gate.js', import.meta.url), 'utf8')
const requests = []
const server = createServer((req, res) => {
  requests.push(req.url)
  res.writeHead(200, { 'Content-Type': 'text/html', 'Content-Security-Policy': "img-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'" })
  res.end('<!doctype html><body style="margin:0"></body>')
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const origin = 'http://127.0.0.1:' + server.address().port
const cases = [
  { name: 'document-positive-distractor', mode: 'document', targetMatch: true },
  { name: 'document-negative-distractor', mode: 'document', targetMatch: false },
  { name: 'shadow-positive-distractor', mode: 'shadow', targetMatch: true },
  { name: 'shadow-negative-distractor', mode: 'shadow', targetMatch: false },
  { name: 'document-nested-descendant-negative', mode: 'document', targetMatch: false, nestedOther: true },
  { name: 'shadow-nested-descendant-negative', mode: 'shadow', targetMatch: false, nestedOther: true },
  { name: 'shadow-host-positive-context', mode: 'shadow', targetMatch: true, selector: ':host(.theme) .match .panel' },
  { name: 'document-functional-plain', mode: 'document', targetMatch: true, selector: ':is(.absent, .match) .panel' },
  { name: 'document-nested-envelopes-positive', mode: 'document', targetMatch: true, nested: true },
  { name: 'document-nested-envelopes-negative', mode: 'document', targetMatch: false, nested: true },
  { name: 'shadow-nested-envelopes-positive', mode: 'shadow', targetMatch: true, nested: true },
  { name: 'document-track-vertical-negative-distractor', mode: 'document', targetMatch: false, suffix: '::-webkit-scrollbar-track:vertical' },
]
const receipt = { scope: 'Bounded static primitives DTO and target-isolated original-native-part CSP executor prototype. Not production policy.', at: new Date().toISOString(), prototypeSHA256: createHash('sha256').update(prototype).digest('hex'), engines: [] }
const closed = []; let completed = false
async function source(page, test) {
  return page.evaluate(async test => {
    const { DOM: { r, m, w, list }, snapshotContext } = window.nativeContextPrototype
    const frame = m(document, 'createElement')('iframe')
    m(frame, 'setAttribute')('id', 'source-frame'); m(frame, 'setAttribute')('sandbox', 'allow-same-origin')
    w(r(frame, 'style'), 'cssText', 'display:block;border:0;width:500px;height:300px')
    await new Promise(resolve => { m(frame, 'addEventListener')('load', resolve, { once: true }); w(frame, 'srcdoc', '<!doctype html><body style="margin:0"></body>'); m(r(document, 'body'), 'append')(frame) })
    const doc = r(frame, 'contentDocument'), fixture = m(doc, 'createElement')('div')
    m(fixture, 'setAttribute')('id', 'fixture'); w(r(fixture, 'style'), 'cssText', 'width:100px;height:220px;' + (test.ancestorStyle || ''))
    m(r(doc, 'body'), 'append')(fixture)
    let root = r(doc, 'body')
    if (test.mode === 'shadow') {
      const host = m(doc, 'createElement')('div'); m(host, 'setAttribute')('class', 'theme')
      w(r(host, 'style'), 'cssText', 'width:100px;height:220px'); m(fixture, 'append')(host)
      root = m(host, 'attachShadow')({ mode: 'open' })
    }
    const style = m(doc, 'createElement')('style'), suffix = test.suffix || '::-webkit-scrollbar-thumb:horizontal'
    const prefix = test.selector || '.match .panel', selectedSelector = test.nested ? '& .panel' + suffix : prefix + suffix
    let nativeRule = test.nested ? '@media (min-width: 1px){@supports (overflow:scroll){@layer sample{.match{& .panel' + suffix + '{background-color:yellow!important}}}}}' : selectedSelector + '{background-color:yellow!important}'
    if (test.mediaFalse) nativeRule = '@media (max-width:1px){' + nativeRule + '}'
    if (test.mediaDynamic) nativeRule = '@media (hover:hover){' + nativeRule + '}'
    w(style, 'textContent', '.panel::-webkit-scrollbar{width:11px;height:7px;background:red}.panel::-webkit-scrollbar-thumb{background:black}.panel::-webkit-scrollbar-track{background:red}.panel::-webkit-scrollbar-corner{background:blue}' + nativeRule)
    m(root, 'append')(style)
    let target, targetContent, otherTarget
    for (const [name, match] of [['target', test.targetMatch], ['other', true]]) {
      const box = m(doc, 'createElement')('div'); m(box, 'setAttribute')('id', name + '-box'); m(box, 'setAttribute')('class', match ? 'match' : 'absent')
      w(r(box, 'style'), 'cssText', 'width:100px;height:100px;margin:0 0 20px')
      const panel = m(doc, 'createElement')('div'); m(panel, 'setAttribute')('class', 'panel')
      w(r(panel, 'style'), 'cssText', 'width:100px;height:100px;overflow:scroll;background:green')
      const content = m(doc, 'createElement')('div'); w(r(content, 'style'), 'cssText', 'width:240px;height:300px;background:green')
      m(panel, 'append')(content); m(box, 'append')(panel); m(test.nestedOther && name === 'other' ? targetContent : test.mode === 'shadow' ? root : fixture, 'append')(box)
      w(panel, 'scrollLeft', 40); w(panel, 'scrollTop', 50)
      if (name === 'target') { target = panel; targetContent = content } else otherTarget = panel
    }
    let selected
    const find = sheet => list(r(sheet, 'cssRules')).forEach(rule => {
      if (r(rule, 'selectorText') === selectedSelector) selected = rule
      if (r(rule, 'cssRules')) find(rule)
    })
    find(r(style, 'sheet'))
    if (!selected) throw new Error('selected source rule unavailable: ' + selectedSelector)
    for (const [name,value] of Object.entries(test.extraDeclarations || {})) m(r(selected,'style'),'setProperty')(name,value,'important')
    if (test.unsafe === 'disabled-sheet') w(r(style, 'sheet'), 'disabled', true)
    if (test.unsafe === 'inline-handler') m(target, 'setAttribute')('onclick', 'window.top.__nativeGuard += 100')
    if (['script', 'img', 'custom-element'].includes(test.unsafe)) {
      const active = m(doc, 'createElement')(test.unsafe === 'custom-element' ? 'custom-danger' : test.unsafe)
      if (test.unsafe === 'script') w(active, 'textContent', 'window.top.__nativeGuard += 1000')
      m(target, 'append')(active)
    }
    if (test.unsafe === 'css-url') m(r(selected, 'style'), 'setProperty')('background-image', 'url('+r(r(document,'location'),'origin')+'/unsafe.png)')
    if (test.unsafe === 'css-gradient') m(r(selected, 'style'), 'setProperty')('background-image', 'linear-gradient(red, blue)', 'important')
    if (test.unsafe === 'css-var') m(r(selected, 'style'), 'setProperty')('background-color', 'var(--source-color)')
    const snapshot = snapshotContext(target, selected)
    window.sourceFixture = { frame, doc, target, selected, style }
    const plain = value => value == null || ['string', 'number', 'boolean'].includes(typeof value) || (Array.isArray(value) ? value.every(plain) : Object.getPrototypeOf(value) === Object.prototype && Object.keys(value).every(key => plain(value[key])))
    return { snapshot, primitiveOnly: plain(snapshot), synchronous: !(snapshot instanceof Promise), sourceRule: r(selected, 'cssText'), sourceSelector: r(selected, 'selectorText'), otherSnapshot: snapshotContext(otherTarget, selected) }
  }, test)
}
async function colors(decode, png) {
  return decode.evaluate(async base64 => {
    const r = readDOMProperty, m = readDOMMethod, w = writeDOMProperty
    const image = Reflect.construct(r(window, 'Image'), []); w(image, 'src', 'data:image/png;base64,' + base64); await m(image, 'decode')()
    const canvas = m(document, 'createElement')('canvas'); w(canvas, 'width', 100); w(canvas, 'height', 100)
    const context = m(canvas, 'getContext')('2d'); m(context, 'drawImage')(image, 0, 0)
    const pixels = r(m(context, 'getImageData')(0, 0, 100, 100), 'data'); let yellow = 0, black = 0, ownHorizontalYellow = 0, ownVerticalYellow = 0
    for (let i = 0; i < pixels.length; i += 4) { if (pixels[i] === 255 && pixels[i + 1] === 255 && pixels[i + 2] === 0) { yellow++; const x=(i/4)%100, y=Math.floor(i/4/100); if(y>=93&&x<89)ownHorizontalYellow++; if(x>=89&&y<93)ownVerticalYellow++; } if (!pixels[i] && !pixels[i + 1] && !pixels[i + 2]) black++ }
    return { yellow, black, ownHorizontalYellow, ownVerticalYellow }
  }, png.toString('base64'))
}

const visibilityCases = [
  {name:'root-zero',mode:'document',targetMatch:true,suffix:'::-webkit-scrollbar',extraDeclarations:{width:'0px',height:'0px'}},
  {name:'root-display-none',mode:'document',targetMatch:true,suffix:'::-webkit-scrollbar',extraDeclarations:{display:'none'}},
  {name:'thumb-opacity-zero',mode:'document',targetMatch:true,extraDeclarations:{opacity:'0'}},
  {name:'ancestor-display-none',mode:'document',targetMatch:true,ancestorStyle:'display:none'},
  {name:'ancestor-opacity-zero',mode:'document',targetMatch:true,ancestorStyle:'opacity:0'},
  {name:'thumb-display-none',mode:'document',targetMatch:true,extraDeclarations:{display:'none'}},
]
receipt.scope='Visibility/paint absence counterexamples, pre-gate prototype; zero color alone is not non-membership.'
try {
 for (const [engine,type] of Object.entries({chromium,webkit})) {
  const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})});let page
  try {
   page=await browser.newPage({viewport:{width:700,height:400}});await page.goto(origin);await page.addScriptTag({content:helper+'\n'+prototype})
   const decode=await browser.newPage();await decode.addScriptTag({content:helper});const rows=[]
   for(const test of visibilityCases) {
    const data=await source(page,test);const png=await (test.ancestorStyle?page.locator('#source-frame'):page.locator('#source-frame').contentFrame().locator('#target-box')).screenshot({scale:'css'});await writeFile(new URL(engine+'-'+test.name+'.png',folder),png)
    const sourceColors=await colors(decode,png)
    const measured=await page.evaluate(async snapshot=>{
     const {createContextExecutor,DOM:{m}}=window.nativeContextPrototype;m(window.sourceFixture.frame,'remove')();delete window.sourceFixture
     if(snapshot.status!=='snapshot')return {snapshotUnknown:snapshot.reason}
     const executor=createContextExecutor(JSON.parse(JSON.stringify(snapshot.dto))),result=await executor.run();return {result,diagnostics:executor.diagnostics()}
    },data.snapshot)
    const sourceGeometry=data.snapshot.dto?.metrics
    const rootRuleDefinitelyParticipates=test.name.startsWith('root-')&&sourceGeometry.client[0]===100&&sourceGeometry.client[1]===100
    const row={test,...data,sourceColors,sourceGeometry,rootRuleDefinitelyParticipates,measured};rows.push(row)
    console.log(engine,test.name,JSON.stringify({sourceClient:sourceGeometry?.client,sourceColors,definiteRootParticipation:rootRuleDefinitelyParticipates,status:measured.result?.status,signal:measured.result?.applies,events:measured.diagnostics?.eventMarkers}))
   }
   receipt.engines.push({engine,version:browser.version(),rows});await writeFile(new URL('receipt.json',folder),JSON.stringify(receipt,null,2)+'\n')
  } finally {const cleanup=await page?.evaluate(()=>{const {r,m}=window.nativeContextPrototype.DOM;return {frames:r(m(document,'querySelectorAll')('iframe'),'length')}});await browser.close();closed.push({engine,cleanup})}
 }
 completed=true
} finally {await new Promise(resolve=>server.close(resolve));await writeFile(new URL('cleanup.json',folder),JSON.stringify({completed,closed,serverClosed:!server.listening,requests},null,2)+'\n')}
