import { chromium, webkit } from 'playwright'
import { createServer } from 'node:http'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { deflateSync } from 'node:zlib'
const folder = new URL('./minimal-results/', import.meta.url)
await mkdir(folder, { recursive: true })
const helper = await readFile(new URL('./dom.snapshot.js', import.meta.url), 'utf8')
function crc32(bytes) { let crc=0xffffffff;for(const byte of bytes){crc^=byte;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0)}return (crc^0xffffffff)>>>0 }
function chunk(name, data) { const tag=Buffer.from(name),size=Buffer.alloc(4),crc=Buffer.alloc(4);size.writeUInt32BE(data.length);crc.writeUInt32BE(crc32(Buffer.concat([tag,data])));return Buffer.concat([size,tag,data,crc]) }
function png(marker) { const header=Buffer.alloc(13);header.writeUInt32BE(1,0);header.writeUInt32BE(1,4);header[8]=8;header[9]=6;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('tEXt',Buffer.from('marker\0'+marker)),chunk('IDAT',deflateSync(Buffer.from([0,0,0,0,0]))),chunk('IEND',Buffer.alloc(0))]).toString('base64') }
const imageBytes = Object.fromEntries(['part','context','positive','negative'].map(name=>[name,png(name)]))
const requests=[]
const server=createServer((req,res)=>{requests.push(req.url);res.writeHead(200,{'Content-Type':'text/html','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src blob: data:; frame-src 'self'"});res.end('<!doctype html><body style="margin:0"></body>')})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port
const receipt={scope:'Observe local Blob/data CSS-native-part ResourceTiming and genuine Window-load order; no polling readiness.',at:new Date().toISOString(),engines:[]};const closed=[];let completed=false
try{
 for(const [engine,type]of Object.entries({chromium,webkit})){
  const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})});let page
  try{
   page=await browser.newPage({viewport:{width:700,height:400}});const consoleMessages=[];page.on('console',message=>consoleMessages.push({type:message.type(),text:message.text()}));await page.goto(origin);await page.addScriptTag({content:helper})
   const rows=[]
   for(const kind of ['blob','data'])for(const scope of ['document']){
    const result=await page.evaluate(async({kind,scope,imageBytes})=>{
     const r=readDOMProperty,m=readDOMMethod,w=writeDOMProperty
     const array=value=>{const out=[];for(let i=0;i<r(value,'length');i++)out.push(r(value,i));return out}
     const frame=m(document,'createElement')('iframe');m(frame,'setAttribute')('sandbox','allow-same-origin allow-scripts');w(r(frame,'style'),'cssText','position:fixed;left:0;top:0;width:500px;height:300px;border:0')
     const events=[],entries=[],violations=[],urls={};let observer,owned,view,timeout,removed=false, syntheticDocument=0,syntheticWindow=0, beforeCloseDiagnostic
     const time=()=>m(r(view,'performance'),'now')()
     const serialize=entry=>({name:r(entry,'name'),initiatorType:r(entry,'initiatorType'),entryType:r(entry,'entryType'),startTime:r(entry,'startTime'),responseEnd:r(entry,'responseEnd'),duration:r(entry,'duration'),fetchStart:r(entry,'fetchStart'),transferSize:r(entry,'transferSize')})
     const snapshot=()=>array(m(r(view,'performance'),'getEntriesByType')('resource')).map(serialize)
     const scaffold='<!doctype html><meta data-passive-policy http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'none\'; style-src \'unsafe-inline\'; img-src blob: data:; base-uri \'none\'; form-action \'none\'"><body style="margin:0"></body>'
     try{
      await new Promise((resolve,reject)=>{
       timeout=setTimeout(()=>reject(new Error('Initial frame load timeout')),2000)
       m(frame,'addEventListener')('load',()=>{const doc=r(frame,'contentDocument');if(doc&&m(doc,'querySelector')('meta[data-passive-policy]')){clearTimeout(timeout);resolve()}},{once:true})
       w(frame,'srcdoc',scaffold);m(r(document,'body'),'append')(frame)
      })
      owned=r(frame,'contentDocument');m(owned,'open')();m(owned,'write')(scaffold);view=r(owned,'defaultView')
      const policy=m(owned,'querySelector')('meta[data-passive-policy]');events.push({phase:'written-open-document',at:time(),readyState:r(owned,'readyState'),csp:r(policy,'content')})
      m(owned,'addEventListener')('__passive_control',()=>syntheticDocument++);m(view,'addEventListener')('__passive_control',()=>syntheticWindow++);const synthetic=Reflect.construct(r(view,'Event'),['__passive_control']);m(owned,'dispatchEvent')(synthetic);m(view,'dispatchEvent')(Reflect.construct(r(view,'Event'),['__passive_control']));m(frame,'addEventListener')('load',()=>events.push({phase:'iframe-load',at:time(),readyState:r(owned,'readyState')}));m(owned,'addEventListener')('DOMContentLoaded',()=>events.push({phase:'DOMContentLoaded',at:time()}));m(owned,'addEventListener')('readystatechange',()=>events.push({phase:'readystatechange',at:time(),readyState:r(owned,'readyState')}));
      m(owned,'addEventListener')('securitypolicyviolation',event=>violations.push({directive:r(event,'effectiveDirective'),blockedURI:r(event,'blockedURI')}))
      m(r(view,'performance'),'clearResourceTimings')()
      const constructor=r(view,'PerformanceObserver')
      if(constructor){observer=Reflect.construct(constructor,[record=>{const at=time();for(const entry of array(m(record,'getEntries')()))entries.push({observedAt:at,...serialize(entry)})}]);m(observer,'observe')({entryTypes:['resource']})}
      for(const name of Object.keys(imageBytes)){
       if(kind==='data')urls[name]='data:image/png;base64,'+imageBytes[name]
       else{const raw=atob(imageBytes[name]),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);const blob=Reflect.construct(r(view,'Blob'),[[bytes],{type:'image/png'}]);urls[name]=m(r(view,'URL'),'createObjectURL')(blob)}
      }
      const source=m(owned,'createElement')('div');m(source,'setAttribute')('id','source');let root=source
      if(scope==='shadow')root=m(source,'attachShadow')({mode:'open'})
      const style=m(owned,'createElement')('style');w(style,'textContent','#panel,#cal{width:100px;height:100px;overflow:scroll;background:green}#panel::-webkit-scrollbar,#cal::-webkit-scrollbar{width:11px;height:7px;background:red}#panel::-webkit-scrollbar-thumb,#cal::-webkit-scrollbar-thumb{background:black}#panel::-webkit-scrollbar-thumb:horizontal{background-color:yellow;background-image:url("'+urls.part+'")}#panel{background-image:url("'+urls.context+'")}#cal::-webkit-scrollbar-thumb:horizontal{background-image:url("'+urls.positive+'")}#missing::-webkit-scrollbar-thumb:horizontal{background-image:url("'+urls.negative+'")}')
      m(root,'append')(style);let target
      for(const id of ['panel','cal']){const panel=m(owned,'createElement')('div');m(panel,'setAttribute')('id',id);const content=m(owned,'createElement')('div');w(r(content,'style'),'cssText','width:240px;height:300px');m(panel,'append')(content);m(root,'append')(panel);if(id==='panel')target=panel}
      m(r(owned,'body'),'append')(source);w(target,'scrollLeft',40);w(target,'scrollTop',50)
      const rect=m(target,'getBoundingClientRect')(),client=[r(target,'clientWidth'),r(target,'clientHeight')]
      const beforeClose={at:time(),readyState:r(owned,'readyState'),entries:snapshot(),rect:[r(rect,'width'),r(rect,'height')],client}
      beforeCloseDiagnostic=beforeClose
      events.push({phase:'before-close',at:beforeClose.at})
      const load=await new Promise((resolve,reject)=>{
       timeout=setTimeout(()=>reject(new Error('Trusted Window load timeout')),2000)
       m(view,'addEventListener')('load',()=>{
        const at=time(),pending=observer?array(m(observer,'takeRecords')()).map(serialize):[]
        events.push({phase:'window-load',at,readyState:r(owned,'readyState')});clearTimeout(timeout)
        resolve({at,entries:snapshot(),observerPending:pending})
       },{once:true})
       events.push({phase:'close-call',at:time()});m(owned,'close')();events.push({phase:'close-return',at:time(),readyState:r(owned,'readyState')})
      })
      await Promise.resolve()
      const afterLoadMicrotask={at:time(),entries:snapshot(),observerPending:observer?array(m(observer,'takeRecords')()).map(serialize):[]}
      const markerEntries=load.entries.filter(entry=>Object.values(urls).includes(entry.name))
      return {kind,scope,urls,client,beforeClose,load,afterLoadMicrotask,observerEntries:entries,events,violations,markerEntriesAtLoad:markerEntries,capability:markerEntries.some(e=>e.name===urls.part)&&markerEntries.some(e=>e.name===urls.context)&&markerEntries.some(e=>e.name===urls.positive)?'observed-positive-markers-at-load':'unknown-no-complete-positive-timing'}
     }catch(error){return {kind,scope,unknown:String(error),urls,events,entries,violations,syntheticDocument,syntheticWindow,beforeClose:beforeCloseDiagnostic,finalReadyState:owned?r(owned,'readyState'):null,finalResourceEntries:view?snapshot():null,finalHTML:owned?r(r(owned,'body'),'innerHTML'):null}}
     finally{clearTimeout(timeout);if(observer)m(observer,'disconnect')();if(view&&kind==='blob')for(const url of Object.values(urls))m(r(view,'URL'),'revokeObjectURL')(url);m(frame,'remove')();removed=true}
    },{kind,scope,imageBytes})
    rows.push(result);console.log(engine,kind,scope,JSON.stringify({capability:result.capability,unknown:result.unknown,atLoad:result.markerEntriesAtLoad?.map(x=>({url:Object.entries(result.urls).find(([,u])=>u===x.name)?.[0],type:x.initiatorType,end:x.responseEnd})),observed:result.observerEntries?.length,load:result.load?.at,violations:result.violations?.length}))
   }
   receipt.engines.push({engine,version:browser.version(),rows,consoleMessages});await writeFile(new URL('receipt.json',folder),JSON.stringify(receipt,null,2)+'\n')
  }finally{const cleanup=await page?.evaluate(()=>{const r=readDOMProperty,m=readDOMMethod;return {frames:r(m(document,'querySelectorAll')('iframe'),'length')}});await browser.close();closed.push({engine,cleanup})}
 }
 completed=true
}finally{await new Promise(resolve=>server.close(resolve));await writeFile(new URL('cleanup.json',folder),JSON.stringify({completed,closed,serverClosed:!server.listening,requests},null,2)+'\n')}
