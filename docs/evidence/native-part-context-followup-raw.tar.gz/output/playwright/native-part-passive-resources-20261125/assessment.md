# Blob/data 被动资源信号：当前方案不可用

在当前 Chromium 156.0.8078.4 / WebKit 27.2 中，Blob/data 的原生 scrollbar CSS background marker 无法通过私有 ResourceTiming/PerformanceObserver 观测。结果必须为 unknown，不能把条目缺席解释成 selector 不参与。

## 已排除探针前提故障

capability-results 是未执行 document.open/write 的独立阳性控制。两个浏览器 × Blob/data 共 4 组：

- 父 realm 注册的私有 Document synthetic event callback 均运行 1 次。
- 独立透明 PNG 的 Image.decode 均成功，naturalWidth/naturalHeight 均 1；PNG 是有效的透明 RGBA 1×1。
- 真实 scrollbar owner client 均为 [89,93]，已强制读取实际几何。
- 私有 performance.getEntriesByType('resource')、PerformanceObserver callback、takeRecords 全部没有条目，包括普通 CSS context 与已成功 decode 的独立 IMG 阳性。
- CSP violation 为 0，没有 CSP console error，没有图片 HTTP 请求。

所以空记录不能归因于 PNG 无效、CSP 拒绝或事件通道未启动，也不能作为完整 native selector 的阴性证据。

## 协议层原因

[Resource Timing 编辑草案 §3.2](https://w3c.github.io/resource-timing/#resources-included-in-the-performanceresourcetiming-interface) 明确说明 timing entries 面向 HTTP(S) 资源，并说明 data: IMG 不报告 PerformanceResourceTiming。本次 Blob/data 的全空结果与其 HTTP(S) 范围一致。这不是通过增加轮询、延长等待或更换 load fence 可以补齐的 selector 信号。

## open/write/close 的独立观察

minimal-results 在 document.open/write(empty owned trusted scaffold) 后安装 Document/Window callback，再以 imperative DOM/CSS 构造树、读取几何并 document.close。两个浏览器 × Blob/data 共 4 组：

- Document 与 Window synthetic callback 均正常（各 1 次）。
- DOMContentLoaded、readystatechange 到 complete 均可见。
- 预期 Window load / iframe load callback 均未观察到，最终仅由 2 秒诊断上限收口 unknown；该上限没有被当作成功 readiness。
- 最终 ResourceTiming 与 Observer 仍全部为空。完整 phase 顺序、最终 readyState、原 HTML/CSS 与 URL 都已保存。

因此本轮没有得到“Window load 覆盖已发起 CSS part background 完成”的证据；readyState complete 也没有被当成可推断 native-part 缺席的屏障。初轮 Document/ShadowRoot 8 组的相同失败观察另外保留，没有用之后的控制替换原始失败记录。

## 没有做的扩张

没有把此前 CSP 原型的 root0/hidden、多 scroller、var 未知或 nesting/envelope 结果搬作本协议的证据。基础阳性 marker 已不可观测，继续扩矩阵不能改变方案选择，故没有继续增加这些测试、固定等待、重试或轮询。

现有不可信 SVG environment、主线源码、旧 84 文件目录均未改。独立 trusted-only iframe 保留 script-src none，仅允许 Blob/data 图片。Chromium 仍产生 allow-scripts + allow-same-origin 的 sandbox warning（没有 CSP error），原始 console 完整保留；这也是将来若考虑生产环境需要单独处理的限制。

全部 iframe、浏览器和随机 loopback server 已关闭。每个最终控制 server 仅收到 2 个页面 GET，没有 marker/图片 HTTP 请求。Blob URL 在 finally revoke，observer disconnect。

下一步应保留 unknown，并选择不依赖非 HTTP ResourceTiming 的方向；本次没有找到可替换 CSP 事件的无报错 membership 信号。
