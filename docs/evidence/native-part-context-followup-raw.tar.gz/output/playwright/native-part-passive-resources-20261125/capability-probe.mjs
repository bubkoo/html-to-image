import { chromium, webkit } from 'playwright'
import { createServer } from 'node:http'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { deflateSync } from 'node:zlib'
const folder = new URL('./capability-results/', import.meta.url)
await mkdir(folder, { recursive: true })
const helper = await readFile(new URL('./dom.snapshot.js', import.meta.url), 'utf8')
function crc32(bytes) { let crc=0xffffffff;for(const byte of bytes){crc^=byte;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0)}return (crc^0xffffffff)>>>0 }
function chunk(name, data) { const tag=Buffer.from(name),size=Buffer.alloc(4),crc=Buffer.alloc(4);size.writeUInt32BE(data.length);crc.writeUInt32BE(crc32(Buffer.concat([tag,data])));return Buffer.concat([size,tag,data,crc]) }
function png(marker) { const header=Buffer.alloc(13);header.writeUInt32BE(1,0);header.writeUInt32BE(1,4);header[8]=8;header[9]=6;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('tEXt',Buffer.from('marker\0'+marker)),chunk('IDAT',deflateSync(Buffer.from([0,0,0,0,0]))),chunk('IEND',Buffer.alloc(0))]).toString('base64') }
const imageBytes = Object.fromEntries(['part','context','positive','negative'].map(name=>[name,png(name)]))
const requests=[]
const server=createServer((req,res)=>{requests.push(req.url);res.writeHead(200,{'Content-Type':'text/html','Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src blob: data:; frame-src 'self'"});res.end('<!doctype html><body style="margin:0"></body>')})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port
const receipt={scope:'Observe local Blob/data CSS-native-part ResourceTiming and genuine Window-load order; no polling readiness.',at:new Date().toISOString(),engines:[]};const closed=[];let completed=false

try{
 for(const [engine,type]of Object.entries({chromium,webkit})){
  const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})});let page
  try{
   page=await browser.newPage({viewport:{width:700,height:400}});const consoleMessages=[];page.on('console',message=>consoleMessages.push({type:message.type(),text:message.text()}));await page.goto(origin);await page.addScriptTag({content:helper});const rows=[]
   for(const kind of ['blob','data']){
    const result=await page.evaluate(async({kind,imageBytes})=>{
     const r=readDOMProperty,m=readDOMMethod,w=writeDOMProperty,array=value=>{const out=[];for(let i=0;i<r(value,'length');i++)out.push(r(value,i));return out}
     const frame=m(document,'createElement')('iframe');m(frame,'setAttribute')('sandbox','allow-same-origin allow-scripts');w(r(frame,'style'),'cssText','position:fixed;left:0;top:0;width:500px;height:300px;border:0')
     let timeout,owned,view,observer,synthetic=0;const urls={},observed=[],violations=[]
     const resource=entry=>({name:r(entry,'name'),initiatorType:r(entry,'initiatorType'),startTime:r(entry,'startTime'),responseEnd:r(entry,'responseEnd'),duration:r(entry,'duration')})
     try{
      await new Promise((resolve,reject)=>{timeout=setTimeout(()=>reject(new Error('Initial load timeout')),2000);m(frame,'addEventListener')('load',()=>{clearTimeout(timeout);resolve()},{once:true});w(frame,'srcdoc','<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'none\'; style-src \'unsafe-inline\'; img-src blob: data:"><body style="margin:0"></body>');m(r(document,'body'),'append')(frame)})
      owned=r(frame,'contentDocument');view=r(owned,'defaultView');m(owned,'addEventListener')('securitypolicyviolation',event=>violations.push({directive:r(event,'effectiveDirective'),blockedURI:r(event,'blockedURI')}));m(owned,'addEventListener')('__control',()=>synthetic++);m(owned,'dispatchEvent')(Reflect.construct(r(view,'Event'),['__control']))
      const ctor=r(view,'PerformanceObserver');if(ctor){observer=Reflect.construct(ctor,[record=>observed.push(...array(m(record,'getEntries')()).map(resource))]);m(observer,'observe')({entryTypes:['resource']})}
      for(const name of Object.keys(imageBytes)){if(kind==='data')urls[name]='data:image/png;base64,'+imageBytes[name];else{const raw=atob(imageBytes[name]),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);urls[name]=m(r(view,'URL'),'createObjectURL')(Reflect.construct(r(view,'Blob'),[[bytes],{type:'image/png'}]))}}
      const style=m(owned,'createElement')('style');w(style,'textContent','#panel{width:100px;height:100px;overflow:scroll;background-image:url("'+urls.context+'")}#panel::-webkit-scrollbar{width:11px;height:7px}#panel::-webkit-scrollbar-thumb:horizontal{background-color:yellow;background-image:url("'+urls.part+'")}');m(r(owned,'body'),'append')(style)
      const panel=m(owned,'createElement')('div');m(panel,'setAttribute')('id','panel');const content=m(owned,'createElement')('div');w(r(content,'style'),'cssText','width:240px;height:300px');m(panel,'append')(content);m(r(owned,'body'),'append')(panel);w(panel,'scrollLeft',40);w(panel,'scrollTop',50);m(panel,'getBoundingClientRect')()
      const image=Reflect.construct(r(view,'Image'),[]);w(image,'src',urls.positive)
      await Promise.race([m(image,'decode')(),new Promise((_,reject)=>{timeout=setTimeout(()=>reject(new Error('Independent Image.decode control timeout')),2000)})]);clearTimeout(timeout)
      const atDecode=m(r(view,'performance'),'now')(),entries=array(m(r(view,'performance'),'getEntriesByType')('resource')).map(resource),pending=observer?array(m(observer,'takeRecords')()).map(resource):[]
      return {kind,synthetic,decodedImage:[r(image,'naturalWidth'),r(image,'naturalHeight')],client:[r(panel,'clientWidth'),r(panel,'clientHeight')],urls,atDecode,entries,observed,pending,violations,html:r(r(owned,'body'),'innerHTML'),readyState:r(owned,'readyState'),capability:entries.some(e=>e.name===urls.part)&&entries.some(e=>e.name===urls.context)?'observed-css-part-timing':'unknown-no-complete-positive-css-timing'}
     }catch(error){return {kind,unknown:String(error),synthetic,observed,violations}}
     finally{clearTimeout(timeout);if(observer)m(observer,'disconnect')();if(view&&kind==='blob')for(const url of Object.values(urls))m(r(view,'URL'),'revokeObjectURL')(url);m(frame,'remove')()}
    },{kind,imageBytes})
    rows.push(result);console.log(engine,kind,JSON.stringify({capability:result.capability,unknown:result.unknown,synthetic:result.synthetic,decoded:result.decodedImage,entries:result.entries?.map(e=>({marker:Object.entries(result.urls).find(([,u])=>u===e.name)?.[0],type:e.initiatorType})),observed:result.observed?.length,violations:result.violations.length}))
   }
   receipt.engines.push({engine,version:browser.version(),rows,consoleMessages});await writeFile(new URL('receipt.json',folder),JSON.stringify(receipt,null,2)+'\n')
  }finally{const cleanup=await page?.evaluate(()=>{const r=readDOMProperty,m=readDOMMethod;return {frames:r(m(document,'querySelectorAll')('iframe'),'length')}});await browser.close();closed.push({engine,cleanup})}
 }
 completed=true
}finally{await new Promise(resolve=>server.close(resolve));await writeFile(new URL('cleanup.json',folder),JSON.stringify({completed,closed,serverClosed:!server.listening,requests},null,2)+'\n')}
