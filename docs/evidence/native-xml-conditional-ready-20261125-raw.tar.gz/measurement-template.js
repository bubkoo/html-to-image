(()=>{
 const self=document.currentScript;self.remove()
 const marker=__MARKER__,tuple=__TUPLE__
 let observer,disconnected=0,observerCreated=0
 const emit=(kind,data={})=>top.postMessage({marker,kind,...data},'*')
 const disconnect=()=>{if(observer){observer.disconnect();disconnected++;observer=undefined}}
 const sample=()=>{const root=document.documentElement,target=document.getElementById(tuple.id),rootStyle=getComputedStyle(root),targetStyle=getComputedStyle(target,tuple.pseudo||null);return{rootCount:rootStyle.length,targetCount:targetStyle.length,rootRect:root.getBoundingClientRect().toJSON(),targetRect:target.getBoundingClientRect().toJSON(),transform:targetStyle.transform,background:targetStyle.backgroundColor,hrefs:[...document.querySelectorAll('link')].map(e=>e.getAttribute('href')),DOM:new XMLSerializer().serializeToString(document)}}
 const valid=state=>state.rootCount>0&&state.targetCount>0&&Number.isFinite(state.rootRect.width)&&Number.isFinite(state.rootRect.height)&&state.rootRect.width>0&&state.rootRect.height>0
 const freezeReady=(state,readyStage)=>{
  const target=document.getElementById(tuple.id),props=Object.keys(tuple.longhands),initial=getComputedStyle(target,tuple.pseudo||null),now=Object.fromEntries(props.map(p=>[p,initial.getPropertyValue(p)])),same=props.every(p=>now[p]===tuple.longhands[p]),observations=[]
  for(const a of target.getAnimations({subtree:true}).filter(a=>typeof a.animationName==='string')){a.pause();a.currentTime=same?tuple.time:0;observations.push({name:a.animationName,currentTime:a.currentTime,playState:a.playState})}
  const restored=getComputedStyle(target,tuple.pseudo||null),pose={transform:restored.transform,background:restored.backgroundColor,same,longhands:now,animations:observations}
  __FREEZE__
  emit('result',{readyStage,pose,final:{transform:final.transform,background:final.backgroundColor},svg:new XMLSerializer().serializeToString(document),hrefs:[...document.querySelectorAll('link')].map(e=>e.getAttribute('href')),observerCreated,observerDisconnected:disconnected,scriptRemoved:!self.isConnected,computedCount:snapshots.length})
 }
 addEventListener('unload',disconnect,{once:true})
 try{
  const E=sample();emit('E',{sample:E})
  if(valid(E)){emit('E-valid');freezeReady(E,'E');return}
  observer=new ResizeObserver(entries=>{
   try{
    const entry=entries.find(e=>e.target===document.documentElement),state=sample(),size=entry?{width:entry.contentRect.width,height:entry.contentRect.height}:null
    emit('observer-entry',{size,sample:state})
    if(!entry||size.width<=0||size.height<=0||!valid(state)){disconnect();emit('not-ready',{size,sample:state,observerCreated,observerDisconnected:disconnected});return}
    disconnect();emit('R',{sample:state,size,observerCreated,observerDisconnected:disconnected});freezeReady(state,'R')
   }catch(error){disconnect();emit('error',{error:String(error),observerCreated,observerDisconnected:disconnected})}
  });observerCreated++;observer.observe(document.documentElement);emit('observer-armed')
 }catch(error){disconnect();emit('error',{error:String(error),observerCreated,observerDisconnected:disconnected})}
})()
