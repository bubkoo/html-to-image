import datetime,hashlib,json,os,pathlib,re,socket,subprocess,time
p=pathlib.Path('output/playwright/minimatch-dev-security-20261125')
expected='f8d1c4b1abb7decf143fdf418ad08fa8b22bd309'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected
tracked=subprocess.check_output(['git','ls-files','-z','src','test','scripts','package.json','pnpm-lock.yaml','tsconfig.json','tsconfig.browser-tests.json','rollup.config.js','eslint.config.mjs','playwright.config.ts','vitest.browser.config.mts']).split(b'\0')
inputs={name.decode():{'bytes':pathlib.Path(name.decode()).stat().st_size,'sha256':hashlib.sha256(pathlib.Path(name.decode()).read_bytes()).hexdigest()} for name in tracked if name}
(p/'candidate-inputs-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
env=os.environ.copy();env['HUSKY']='0';env['CI']='1';env.pop('TEST_BROWSER',None);env.pop('TEST_SUITE',None)
receipt={'source':expected,'branch':'codex/minimatch-dev-security','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],text=True).strip(),'platform':os.uname().sysname,'CI':'1','runtimeSourceChanged':False,'inputCount':len(inputs),'stages':[]}
def stage(name,args,extra=None):
 own=env.copy();own.update(extra or {});start=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 print(json.dumps({'stage':name,'status':'started','at':at}),flush=True)
 with (p/(name+'.log')).open('wb') as log:
  result=subprocess.run(args,env=own,stdout=log,stderr=subprocess.STDOUT)
 text=(p/(name+'.log')).read_text(errors='replace');plain=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',text)
 row={'name':name,'command':args,'startedAt':at,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'durationSeconds':round(time.monotonic()-start,3),'exitCode':result.returncode,'testSummaries':re.findall(r'^\s*(?:Test Files|Tests|Duration)\s+.+$',plain,re.M),'environmentOverrides':extra or {}}
 receipt['stages'].append(row);(p/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'stage':name,'exitCode':result.returncode,'seconds':row['durationSeconds'],'summaries':row['testSummaries'][-4:]}),flush=True);return row,plain
for name,script in [('lint-check','lint:check'),('build','build'),('package-contract','test:package'),('browser-types','test:browser:types')]:stage(name,['pnpm','run',script])
row,text=stage('default-full',['pnpm','test'])
if row['exitCode'] and not re.search(r'^> html-to-image@[^\n]+ test:browser:source ',text,re.M):stage('source-full-after-coverage-failure',['pnpm','run','test:browser:source'])
s=socket.socket()
try:s.bind(('127.0.0.1',4197));available=True
except OSError:available=False
finally:s.close()
if available:stage('package-browser-full',['pnpm','run','test:browser:package'],{'HTML_TO_IMAGE_SMOKE_PORT':'4197'})
else:receipt['stages'].append({'name':'package-browser-full','status':'blocked-port-in-use','port':4197,'serviceNotTouched':True})
after={name:{'bytes':pathlib.Path(name).stat().st_size,'sha256':hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()} for name in inputs}
(p/'candidate-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');receipt['inputsUnchanged']=inputs==after;receipt['changedInputs']=[name for name in inputs if inputs[name]!=after[name]];receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['allStagesPassed']=all(stage.get('exitCode')==0 for stage in receipt['stages']);(p/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'finished':True,'allStagesPassed':receipt['allStagesPassed'],'inputsUnchanged':receipt['inputsUnchanged'],'stages':[(s['name'],s.get('exitCode',s.get('status'))) for s in receipt['stages']]}),flush=True)
