const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),{createRequire}=require('node:module')
const folder='output/playwright/minimatch-dev-security-20261125/'
const YAML=require(process.cwd()+'/node_modules/.pnpm/yaml@2.9.1/node_modules/yaml')
const semver=require(process.cwd()+'/node_modules/.pnpm/semver@7.8.5/node_modules/semver')
const lock=YAML.parse(fs.readFileSync('pnpm-lock.yaml','utf8')),baseline=YAML.parse(fs.readFileSync(folder+'baseline-pnpm-lock.yaml','utf8'))
const identity=key=>{const base=key.split('(')[0],i=base.lastIndexOf('@');return{name:base.slice(0,i),version:base.slice(i+1)}}
const relevant=name=>name==='eslint'||name==='@eslint/config-array'||name==='typescript-eslint'||name==='minimatch'||name==='@isaacs/nonrecursive-glob-match'||name.startsWith('@typescript-eslint/')
function findPackage(name,parent){const req=createRequire(parent);for(const location of req.resolve.paths(name)||[]){const file=path.join(location,name,'package.json');if(fs.existsSync(file)){const json=JSON.parse(fs.readFileSync(file));if(json.name===name)return{path:fs.realpathSync(file),json}}}throw new Error('Cannot locate '+name)}
const versions=Object.keys(lock.packages).map(identity).filter(x=>x.name==='minimatch').map(x=>x.version)
if(versions.some(v=>semver.satisfies(v,'>=7.0.0 <11.0.1')))throw new Error('Vulnerable minimatch remains in lock')
const assertions=[]
for(const entry of Object.keys(lock.packages).map(identity).filter(x=>relevant(x.name))){
 const folderName=entry.name.replace('/','+').replace(/^@/,'@')+'@'+entry.version
 const dirs=fs.readdirSync('node_modules/.pnpm').filter(n=>n===folderName||n.startsWith(folderName+'_'))
 if(dirs.length!==1)throw new Error('Ambiguous physical package '+entry.name+' '+dirs)
 const jsonPath=path.resolve('node_modules/.pnpm/'+dirs[0]+'/node_modules/'+entry.name+'/package.json'),pkg=JSON.parse(fs.readFileSync(jsonPath))
 for(const [name,range]of Object.entries(pkg.dependencies||{})){
  const resolved=findPackage(name,jsonPath)
  if(!semver.satisfies(resolved.json.version,range))throw new Error('Out-of-range dependency '+entry.name+' -> '+name+' '+range+' got '+resolved.json.version)
  assertions.push({parent:entry.name,parentVersion:entry.version,name,range,installed:resolved.json.version})
 }
}
function versionMap(packages){const result={};for(const key of Object.keys(packages)){const {name,version}=identity(key);(result[name]??=[]).push(version)}return result}
const old=versionMap(baseline.packages),now=versionMap(lock.packages)
for(const name of Object.keys(old))if(!relevant(name)&&JSON.stringify(old[name])!==JSON.stringify(now[name]))throw new Error('Unrelated version changed '+name)
for(const [file,args]of [['candidate-why-minimatch.json',['why','minimatch','--json']],['candidate-list-minimatch.json',['list','minimatch','--depth','Infinity','--json']]]){const result=cp.spawnSync('pnpm',args,{encoding:'utf8'});if(result.status)throw new Error(result.stderr);fs.writeFileSync(folder+file,result.stdout)}
const graph=JSON.parse(fs.readFileSync(folder+'candidate-list-minimatch.json')),reachable=new Set()
function walk(value){if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){if(key==='minimatch'&&item&&typeof item==='object'&&item.version)reachable.add(item.version);walk(item)}}walk(graph)
if([...reachable].some(v=>semver.satisfies(v,'>=7.0.0 <11.0.1'))||!reachable.size)throw new Error('Reachable installed graph unsafe or absent')
const result={checkedAt:new Date().toISOString(),lockMinimatchVersions:versions,reachableInstalledMinimatchVersions:[...reachable],vulnerableRange:'>=7.0.0 <11.0.1',affectedReachablePnpmGraphVersions:[],scope:'Reachable pnpm lock/list graph; bundled npm internals are separately reported',overrides:JSON.parse(fs.readFileSync('package.json')).pnpm?.overrides||null,unrelatedVersionFamiliesUnchanged:true,installedRangeAssertions:assertions.length,dependencyRangeAssertions:assertions}
fs.writeFileSync(folder+'candidate-dependency-graph.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,dependencyRangeAssertions:undefined},null,2))
