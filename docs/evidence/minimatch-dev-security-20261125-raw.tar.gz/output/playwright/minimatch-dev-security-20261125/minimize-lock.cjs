// Keep baseline versions outside the explicitly required lint dependency chain.
const fs = require('node:fs')
const cp = require('node:child_process')
const YAML = require(process.cwd() + '/node_modules/.pnpm/yaml@2.9.1/node_modules/yaml')
const semver = require(process.cwd() + '/node_modules/.pnpm/semver@7.8.5/node_modules/semver')
const folder = 'output/playwright/minimatch-dev-security-20261125/'
if (cp.execFileSync('git', ['rev-parse', 'HEAD'], {encoding:'utf8'}).trim() !== 'f8d1c4b1abb7decf143fdf418ad08fa8b22bd309') throw new Error('Wrong source head')
const beforeText = fs.readFileSync(folder + 'baseline-pnpm-lock.yaml', 'utf8')
const fullText = fs.readFileSync(folder + 'unminimized-pnpm-lock.yaml', 'utf8')
const before = YAML.parse(beforeText), full = YAML.parse(fullText)
const identity = key => {const base=key.split('(')[0],i=base.lastIndexOf('@');return {name:base.slice(0,i),version:base.slice(i+1)}}
const required = name => name === 'eslint' || name === '@eslint/config-array' || name === 'typescript-eslint' || name === 'minimatch' || name === '@isaacs/nonrecursive-glob-match' || name.startsWith('@typescript-eslint/')
const versions = object => {const result={};for(const key of Object.keys(object)){const {name,version}=identity(key);(result[name]??=[]).push(version)}return result}
const baselineVersions=versions(before.packages), targetVersions=versions(full.packages)
function blocks(text, section) {
 const start=text.indexOf('\n'+section+':\n')+section.length+3
 const next=text.indexOf('\nsnapshots:\n',start)
 const body=text.slice(start,section==='packages'?next:text.length)
 const result=new Map();let current
 for(const line of body.split(/(?<=\n)/)){
  if(/^  \S.*:(?:[ \t]*\{\})?[ \t]*\n?$/.test(line)){
   const raw=line.trim().replace(/:\s*(?:\{\})?\s*$/,''),key=raw.startsWith("'")?raw.slice(1,-1).replace(/''/g,"'"):raw
   current=key;result.set(key,line)
  }else if(current)result.set(current,result.get(current)+line)
 }
 return result
}
const targetVersion=name=>{const values=targetVersions[name];if(!values||values.length!==1)throw new Error('Ambiguous required version '+name);return values[0]}
function adjust(block) {
 // Existing peer contexts still point to the root ESLint version.
 block=block.replaceAll('eslint@10.14.0','eslint@10.15.0')
 return block.split('\n').map(line=>{
  const match=/^( {6})(('[^']+'|[^:]+): )(.+)$/.exec(line)
  if(!match)return line
  const name=match[3].replace(/^'|'$/g,''),raw=match[4],quoted=raw.startsWith("'")&&raw.endsWith("'"),value=quoted?raw.slice(1,-1):raw
  const version=value.split('(')[0];if(!semver.valid(version))return line
  let selected=version
  if(required(name))selected=targetVersion(name)
  else if(baselineVersions[name]&&!baselineVersions[name].includes(version)){
   const available=baselineVersions[name].filter(v=>semver.major(v)===semver.major(version)).sort(semver.rcompare)
   if(!available.length)throw new Error('No baseline-compatible version '+name+' '+version)
   selected=available[0]
  }
  const next=selected+value.slice(version.length)
  return match[1]+match[2]+(quoted?"'"+next+"'":next)
 }).join('\n')
}
const basePackages=blocks(beforeText,'packages'),fullPackages=blocks(fullText,'packages')
for(const [text,parsed] of [[beforeText,before],[fullText,full]])for(const section of ['packages','snapshots']){const keys=[...blocks(text,section).keys()].sort();if(JSON.stringify(keys)!==JSON.stringify(Object.keys(parsed[section]).sort()))throw new Error('Incomplete block parser '+section)}
const packageBlocks=new Map([...basePackages].filter(([key])=>!required(identity(key).name)))
for(const [key,block] of fullPackages)if(required(identity(key).name))packageBlocks.set(key,block)
const snapshotBlocks=new Map()
for(const [key,block] of blocks(beforeText,'snapshots'))if(!required(identity(key).name))snapshotBlocks.set(key.replaceAll('eslint@10.14.0','eslint@10.15.0'),adjust(block))
for(const [key,block] of blocks(fullText,'snapshots'))if(required(identity(key).name))snapshotBlocks.set(key,adjust(block))
const render=map=>[...map].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([,block])=>block.trimEnd()+'\n\n').join('')
const header=fullText.slice(0,fullText.indexOf('\npackages:\n'))
const reduced=header+'\npackages:\n\n'+render(packageBlocks)+'snapshots:\n\n'+render(snapshotBlocks)
const parsed=YAML.parse(reduced)
for(const [name,old] of Object.entries(baselineVersions))if(!required(name)){
 const after=versions(parsed.packages)[name]
 if(JSON.stringify(old.slice().sort())!==JSON.stringify(after.slice().sort()))throw new Error('Unrelated package versions changed '+name)
}
const changes=[]
for(const name of new Set([...Object.keys(baselineVersions),...Object.keys(versions(parsed.packages))])){
 const a=baselineVersions[name]||[],b=versions(parsed.packages)[name]||[]
 if(JSON.stringify(a)!==JSON.stringify(b))changes.push({name,before:a,after:b})
}
fs.writeFileSync('pnpm-lock.yaml',reduced.trimEnd()+'\n')
fs.writeFileSync(folder+'minimal-lock-reduction.json',JSON.stringify({method:'Preserve baseline unrelated package/snapshot blocks and existing compatible transitive versions; retain only required upstream lint chain and updated ESLint peer contexts. No override.',packageVersionChanges:changes,restoredUnrelatedVersionFamilies:Object.keys(targetVersions).filter(name=>!required(name)&&JSON.stringify(targetVersions[name])!==JSON.stringify(baselineVersions[name]))},null,2)+'\n')
console.log(JSON.stringify({requiredPackageVersionChanges:changes.length,changedNames:changes.map(x=>x.name)},null,2))
