#!/usr/bin/env python3
"""Portable read-only validation and deterministic sealing of remote snapshots."""
import argparse,datetime,gzip,hashlib,html,io,json,re,tarfile,urllib.parse,zipfile
from pathlib import Path,PurePosixPath

NAME='master-independent-fixes-remote'
EXPECTED={653:('5b074c4168158d5047f5bc65155f534547273635','5347dd116f8d900a440335586d4f9c5651088040',1234,1113,2),654:('b652860210997de165e3790674eb13b06ef029fa','f2092e4cf4f089c7dc43a5c491f22e256cf1b19c',1411,1291,1)}
BASE='f8d1c4b1abb7decf143fdf418ad08fa8b22bd309'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def safe(name):
 p=PurePosixPath(name)
 return bool(name) and not p.is_absolute() and '\\' not in name and '..' not in p.parts

def analyze(root):
 transfers=load(root/'log-transfer.json')
 for item in transfers['logs']:
  b=(root/item['path']).read_bytes();s=b.decode()
  assert len(b)==item['expectedUTF8Bytes'] and len(s)==item['codePoints'] and len(s.split('\n'))==item['lineCount']
 results=[]
 for n,(head,merge,coverage,source,failed) in EXPECTED.items():
  d=root/f'pr{n}';m=d/'metadata';pr=load(m/'pr.json');hc=load(m/'head-commit.json');mc=load(m/'tested-merge-commit.json')
  assert pr['head']['sha']==head and pr['base']['sha']==BASE and hc['sha']==head and mc['sha']==merge
  parents=[x['sha'] for x in mc['parents']]
  assert parents==[BASE,head] and hc['tree']['sha']==mc['tree']['sha']
  runs={}
  for typ in ['ci','codeql']:
   r=load(m/f'{typ}-run.json');js=load(m/f'{typ}-jobs.json');a=load(m/f'{typ}-artifacts.json');assert js['total_count']==len(js['jobs'])==1 and a['total_count']==len(a['artifacts'])
   j=js['jobs'][0];assert r['head_sha']==head and r['run_attempt']==1 and r['status']=='completed'
   assert r['conclusion']==('failure' if typ=='ci' else 'success')
   log=(d/f'logs/{typ}-job-{j["id"]}.log').read_text();clean=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',log)
   checkout=re.search(r'git log -1 --format=%H\n[^\n]*? ([0-9a-f]{40})\n',clean)
   assert checkout and checkout.group(1)==merge
   runs[typ]={k:r[k] for k in ['id','html_url','head_sha','status','conclusion','run_attempt','created_at','updated_at']}
   runs[typ].update(jobID=j['id'],jobURL=j['html_url'],jobStartedAt=j['started_at'],jobCompletedAt=j['completed_at'],actualCheckoutSHA=checkout.group(1),artifactCount=a['total_count'],steps=j['steps'])
   if typ=='ci':
    assert f'Tests  {coverage} passed | 4 skipped' in clean
    assert f'Tests  {failed} failed | {source} passed | 4 skipped' in clean
    for line in (['83:52','82:54'] if n==653 else ['44:45']):assert '.test.ts:'+line in clean
    assert 'AssertionError: expected false to be true' in clean
    steps={s['number']:s for s in j['steps']}
    assert all(steps[x]['conclusion']=='success' for x in [3,7,8,9,10]) and steps[12]['conclusion']=='failure'
    assert all(steps[x]['conclusion']=='skipped' for x in [13,16,17])
  sourceMeta=load(d/'source/source-metadata.json');sourceName='svg-style-source-lifetime.test.ts' if n==653 else 'svg-fragment-lifetime.test.ts'
  sourceRows=[(sourceName,sourceMeta),('scrollbar-box.test.ts',load(d/'source/gutter-source-metadata.json'))]
  if n==654:sourceRows.append(('svg-fragment-paint.mjs',load(d/'source/fixture-source-metadata.json')))
  for filename,sm in sourceRows:
   b=(d/'source'/filename).read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
   assert blob==sm['blobSHA'] and sm['ref']==head
  artifact=load(d/'artifacts/artifact-verification.json');meta=load(m/'ci-artifacts.json')['artifacts'][0];zbytes=(d/'artifacts/report.zip').read_bytes()
  assert meta['digest']==artifact['GitHubDigest']==artifact['actualDigest']=='sha256:'+sha(zbytes)
  assert len(zbytes)==artifact['sizeInBytes']
  with zipfile.ZipFile(io.BytesIO(zbytes)) as z:
   assert z.testzip() is None
   infos=[x for x in z.infolist() if not x.is_dir()];assert len(infos)==artifact['memberCount']==(8 if n==653 else 6)
   assert len({x.filename for x in infos})==len(infos)
   recorded={x['path']:x for x in artifact['members']}
   for item in infos:
    assert safe(item.filename) and ((item.external_attr>>16)&0o170000)!=0o120000
    b=z.read(item);assert b==(d/'artifacts/extracted'/item.filename).read_bytes()
    assert len(b)==recorded[item.filename]['bytes'] and sha(b)==recorded[item.filename]['sha256']
  result={'pr':n,'url':pr['html_url'],'state':pr['state'],'draft':pr['draft'],'remoteUpdatedAt':pr['updated_at'],'headSHA':head,'baseSHA':BASE,'testedMerge':{'sha':merge,'parents':parents,'headIsSecondParent':True,'mergeTreeSHA':mc['tree']['sha'],'headTreeSHA':hc['tree']['sha'],'mergeTreeEqualsHeadTree':True,'checkoutProvenByBothJobLogs':True},'runs':runs,'tests':{'coverage':{'passed':coverage,'failed':0,'skipped':4},'source':{'passed':source,'failed':failed,'skipped':4},'publishedEntryContract':'passed','lintBuildAndBrowserTypes':'passed','builtPackageBrowserTests':'skipped','coveralls':'skipped','codecov':'skipped'},'pinnedSource':sourceMeta,'artifact':artifact}
  results.append(result)
 results[0]['failures']=[{'browser':'firefox','case':'disposed SVG owner releases source with font=false and opened=true','assertion':'held.reference.deref() === undefined','line':83,'column':52,'nativeControlAssertion':'passed at line 82','terminalEnvironmentAssertion':'not reached at line 85','interpretation':'The held source remained reachable at this check. The native paired source was collected. This does not establish the retention root.'},{'browser':'firefox','case':'disposed SVG owner releases source with font=true and opened=true','assertion':'native.reference.deref() === undefined','line':82,'column':54,'heldAssertion':'not reached at line 83','terminalEnvironmentAssertion':'not reached at line 85','interpretation':'The no-owner native paired source remained reachable. This case does not establish failure of the held-owner collection assertion.'}]
 results[0]['fixtureContext']={'source':'An actual srcdoc iframe is removed in finally; the held case creates, opens and disposes createSVGStyleEnvironment while the paired native case never creates it. Font=true first verifies its loaded face. Source markup/font-state and frame-list checks precede GC. Three GC commands precede the assertions.','error':'AssertionError: expected false to be true','notThePriorLocalFrameDetachedFailure':True}
 results[1]['failures']=[{'browser':'webkit','case':'a frozen SVG host-tree capture releases its source document before rendering','assertion':'reference.deref() === undefined','line':44,'column':45,'frameComparison':'not reached at line 45','toImageDataAndPixelComparison':'not reached at lines 46-49','interpretation':'The inert createHTMLDocument source remained reachable after capture and three GC commands. No rendering or pixel failure is established.'}]
 results[1]['fixtureContext']={'source':'createHTMLDocument body contains external SVG use, inline pattern definitions and solid color elements; renderer.capture completed with skipFonts=true before the failing GC check. renderer.dispose executes in finally.','policy':'getSVGFragmentFixturePolicy resolved before capture; its fragmentPage value is not recorded in this job. The pinned fixture uses independently loaded HTTP use geometry and hit-testing controls, not UA selection.','notReachedExpectedPixel':'[0,0,255,255] when fragmentPage=true; [0,128,0,255] otherwise','error':'AssertionError: expected false to be true'}
 gutter=load(root/'gutter-png-comparison.json')
 for x in gutter:assert x['libraryAuthoredDifferentChannels']==0 and x['nativeDifferentChannels']==22 and x['nativeAuthoredDifferentChannels']==22
 return {'schemaVersion':1,'repository':'bubkoo/html-to-image','scope':'Immutable-head remote CI/CodeQL readback of two independent draft PRs; no manual rerun or browser launch.','apiReadTimes':load(root/'api-read-times.json'),'additionalFixtureRead':load(root/'pr654/source/fixture-source-metadata.json')['checkedAt'],'baseSHAIsSnapshotOnly':True,'pullRequests':results,'gutterDiagnostics':{'decodedPNGComparisons':gutter,'sameGutterSourceBlob':'6a644ffa4020ad3827f45cbf7e1b2de907608f9a','meaning':'Separate Chromium gutter evidence, unrelated to GC assertion screenshots. Capture equals authored; native differs in 22 RGBA channels. Existing source lines 58-75 explicitly skip the horizontal-only native mismatch after authored equality, so native thumb fidelity remains unverified.','nativeEqualityAccepted':False},'limitations':['Snapshot readback does not assert the current default tip stayed unchanged.','Passing CodeQL is separate from failing browser-source CI; built-package browser tests and coverage uploads did not run.','Collection assertion failures do not alone diagnose a retention root, browser GC defect or rendering error.','Failure screenshots are GitHub Actions artifacts, not iPhone verification.','No integration acceptance or mobile verification is inferred from these independent PR runs.'],'operations':{'githubMutations':0,'manualReruns':0,'browserLaunches':0,'networkSettingsChanges':0,'sourceOrTestChanges':0,'signedDownloadURLsSaved':False}}

def privacy(root):
 checked=[];hits=[]
 for f in sorted(root.rglob('*')):
  if not f.is_file() or f.suffix in ['.png','.zip'] or f.name=='privacy-scan.json':continue
  s=f.read_text();checked.append(str(f.relative_to(root)))
  for text in [s,html.unescape(s).replace('\\/','/')]:
   for url in re.findall(r'https?://[^\s<>"\x1b]+',text):
    u=urllib.parse.urlsplit(url);keys=urllib.parse.parse_qs(u.query)
    if any(k.lower() in ['sig','signature','token','access_token','x-amz-signature','x-goog-signature','se','sp','sv'] for k in keys):hits.append({'path':str(f.relative_to(root)),'kind':'signed-or-credential-URL'})
   for pat in [r'gh[pousr]_[A-Za-z0-9_]{20,}',r'github_pat_[A-Za-z0-9_]{20,}',r'AKIA[0-9A-Z]{16}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']:
    if re.search(pat,text):hits.append({'path':str(f.relative_to(root)),'kind':'credential-pattern'})
 assert not hits,hits
 return {'textFilesScanned':checked,'findings':hits,'rawFilesModifiedForPublication':False,'signedOrOpaqueDownloadURLsPersisted':False,'zipPayloadsAlsoScannedAfterVerifiedExtraction':True,'scope':'URL query and credential patterns plus original/HTML-decoded and JSON escaped-slash text; ZIP CRC, digest, safe member paths and extracted byte equality independently checked. This is a scoped publication scan, not a claim to detect arbitrary secrets.'}

def verify(docs):
 summary=load(docs/(NAME+'.json'));index=load(docs/(NAME+'-index.json'));archive=docs/(NAME+'-raw.tar.gz');b=archive.read_bytes()
 assert len(b)==index['archive']['bytes'] and sha(b)==index['archive']['sha256']
 assert summary['rawArchive']==index['archive'] and summary['memberIndex']==NAME+'-index.json'
 with tarfile.open(archive,'r:gz') as t:
  members=t.getmembers();assert len(members)==index['memberCount'] and len({x.name for x in members})==len(members)
  wanted={x['path']:x for x in index['members']};assert set(wanted)=={x.name for x in members}
  data={}
  for m in members:
   assert safe(m.name) and m.isfile() and m.uid==m.gid==m.mtime==0
   x=t.extractfile(m).read();assert m.size==len(x)==wanted[m.name]['bytes'] and sha(x)==wanted[m.name]['sha256'];data[m.name]=x
  assert json.loads(data['analysis.json'])=={k:v for k,v in summary.items() if k not in ['rawArchive','memberIndex','sealedAt']}
  for n in EXPECTED:
   d=f'pr{n}/';meta=json.loads(data[d+'metadata/ci-artifacts.json'])['artifacts'][0];z=data[d+'artifacts/report.zip'];assert meta['digest']=='sha256:'+sha(z)
   with zipfile.ZipFile(io.BytesIO(z)) as zp:
    assert zp.testzip() is None
    for m in zp.infolist():
     if not m.is_dir():assert zp.read(m)==data[d+'artifacts/extracted/'+m.filename]
 print(json.dumps({'verified':True,'members':len(members),'archiveBytes':len(b),'archiveSHA256':sha(b)},indent=2))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('raw',type=Path);ap.add_argument('docs',type=Path);ap.add_argument('--verify',action='store_true');a=ap.parse_args()
 if a.verify:verify(a.docs);return
 targets=[a.docs/(NAME+s) for s in ['.json','-index.json','-raw.tar.gz']];assert not any(p.exists() for p in targets),'Refusing to overwrite existing evidence'
 analysis=analyze(a.raw);write(a.raw/'analysis.json',analysis);write(a.raw/'privacy-scan.json',privacy(a.raw))
 files=sorted(f for f in a.raw.rglob('*') if f.is_file());assert all(not f.is_symlink() for f in files)
 members=[];buf=io.BytesIO()
 with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as t:
   for f in files:
    name=str(f.relative_to(a.raw));assert safe(name);b=f.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=info.uid=info.gid=0;t.addfile(info,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 b=buf.getvalue();targets[2].write_bytes(b);arc={'path':targets[2].name,'bytes':len(b),'sha256':sha(b),'format':'gzip-compressed USTAR','membersContainOnlyRegularFiles':True}
 write(targets[1],{'schemaVersion':1,'archive':arc,'memberCount':len(members),'members':members})
 write(targets[0],{**analysis,'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rawArchive':arc,'memberIndex':targets[1].name})
 verify(a.docs)
 # Recompare every raw source byte against the sealed archive after publication.
 with tarfile.open(targets[2],'r:gz') as t:
  for m in t.getmembers():assert t.extractfile(m).read()==(a.raw/m.name).read_bytes()
if __name__=='__main__':main()
