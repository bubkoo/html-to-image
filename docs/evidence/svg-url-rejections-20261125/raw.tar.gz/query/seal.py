from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('query_clip_verify',p/'verify.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
checks=v.derive(p);r=json.loads((p/'results.json').read_text())
a={'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'startedUTC':r['startedUTC'],'completedUTC':r['completedUTC'],
   'scope':'Only original fixed3engines×2callerURLquery policies; nativeuse clip observations, no screenshots or production candidate.',
   'decision':'REJECT original query-only runtime probe:actual sourceTrapHTTP1 and0/6predeclaredpositiveReady. No nativeURIbase ability or safe runtime discrimination inferred.',
   'independentChecks':checks,
   'harnessPremiseCorrection':{
       'timing':'Parent noted null-versus-empty-query premise after original6 already started. All6original inputs/results retained, no basename substitution/retry/expandedscope.',
       'standardURL':'Offline WHATWG URL table shows ?#id resolves to caller.html?#id; withoutfragment retains trailing? and is not exact href of caller.html withquery=null. q1 samequeryhref equals actualDocumentURL. .search is empty forboth null/empty, so it alone is insufficient.',
       'actualHTTP':'Chromium noQuery initialnavigation is followed by actual secondHTTP GET to samecaller route. BrowserrequestEvents records trailing? URL; servernormalized pathname+search alone erases empty?. Extra server receipt establishes safetyfailure.',
       'boundary':'This noQuery mismatch is a failed same-document premise, not proof of an incorrect SVGURIbase. Corrected basename token was not executed. q1 has exact equality but still fails other controls.',
       'BlobURLSyntax':'Offline Node newURL(relativequery,BlobURL) resolves to BlobURL?query#id in all6; it does not throw. Whether that resulting URL can load a Blob registry entry is separate and was not tested via an extraqueryBlob fetch.',
       'verifierCorrection':'First offline verifier draft expected Blob query URL constructor to throw; actual already-recorded URL table contradicted it. Corrected verifier checks the recorded resolved URL instead. Original6 browser inputs/results unchanged; no browser rerun.'},
   'observations':{
       'chromium':'Nativeuse loads all4;flatTTT;absoluteBlobfileClipFFF bothrows, so6pxpositive failed. noQuerydirectFFF/varTTT;q1directTFF/varTTT. q1directTFF is not presumedpage12 or validatedbaseorigin.',
       'firefox':'At2500msnativeuse load guard, bbox20/flatTTT/fileclipTFF observed,direct/varTTT. Resourcegeometry/hitpositives exist, but nativeuse-load contract did not complete. Not described as resources never loaded; no quiettimer fallback/reclassification.',
       'webkit':'Nativeuse loads andbbox20/flatTTT;absoluteBlobClipTTT so6pxpositive failed;direct/varTTT. ProbeBlob postrevoke fetch resolvesstatus200 bothrows;fileClipBlob fetchrejects. Response bodies not read in those200branches, so only header-resolution is known.',
       'positiveControls':'All6flatgroups hit2/8/15;onlyFF2fileclipgroups hit2 andmiss8/15,butnoengine/queryrow passes all predeclaredload/bbox/file/flat conditions. Absence or failedpositive never means detectedbase.',
       'resourceIdentity':'Separateheld6pxclipBlob first permits knownabsoluteBlobURL in immutableprobeBlob. Both liveBlob resources actualbeforefetch matched savedbytes;relativetoken/direct/variable and6/12clip definitions retained. No file/page stylesheet flag inference.',
       'cleanup':'12ownedrevoke callsrecorded;10postfetchreject,2WebKitprobe postfetchheaders200(notclaimedinvalidated). OwnSVGremoved,callerbody/framesrestored,all6contexts/3browsers/serverclosed. NoGCcollectionclaim.',
       'noProductionInference':'NoappUMD/source/file-page-policy function loaded. NoHTTP sourcepaint fixture result replaced byBlob hitpatterns. Fixed6failed anddoesnot justify rebase/UA/invertedflag implementation.'},
   'limits':[
       'Pageclip12width comes from recorded harnessconstruction;not independently readback/hitcalibrated with an extra caller-only group. Existingfile/flatpositive failure already blocks ability claims.',
       'SourceTrapHTTP1 rejects originalprotocol regardless otherpatterns;HTTP0alone would not provide positive readiness.',
       'Nativeuse loadguard exactly2500ms,noRAF/polling/retry. PostguardFFbbox/hits observations only,not fallbacksuccess.',
       'WebKit200afterrevoke preservesResponse header observation only;body was not consumed,so no fullreadability or successfulinvalidation claim.',
       'No additional basename/Blob variant run;standardURL analysis offline anddoesnot assert nativeSVG internalresolution.'],
   'operations':{'fixedCasesExecuted':6,'screenshots':0,'retries':0,'sourceChanges':0,
                 'productionBuilds':0,'PRWrites':0,'phoneActions':0,'networkSettingsChanges':0}}
(p/'assessment.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
files=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
       for f in sorted(p.rglob('*'))if f.is_file()and f.name!='sha256-index.json']
(p/'sha256-index.json').write_text(json.dumps({'createdUTC':a['createdUTC'],'payloadCount':len(files),
                                             'payloadBytes':sum(x['bytes']for x in files),'files':files},indent=2)+'\n')
print('files',len(files),'plusindex',len(files)+1)
print('assessmentSHA',hashlib.sha256((p/'assessment.json').read_bytes()).hexdigest())
print('indexSHA',hashlib.sha256((p/'sha256-index.json').read_bytes()).hexdigest())
