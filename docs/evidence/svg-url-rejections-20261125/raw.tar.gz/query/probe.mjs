import {createServer} from 'node:http'
import {writeFile} from 'node:fs/promises'
import {createHash,randomUUID} from 'node:crypto'
import {chromium,firefox,webkit} from 'playwright'
const own=n=>new URL(n,import.meta.url),sha=b=>createHash('sha256').update(b).digest('hex'),journal=[],paths=new Map()
let origin
const server=createServer((req,res)=>{const url=new URL(req.url,'http://localhost'),key=url.pathname+url.search,count=(paths.get(key)?.count||0)+1,route=paths.get(key);if(route)route.count=count;const allowed=!!route&&count===1&&req.method==='GET';journal.push({receivedUTC:new Date().toISOString(),path:key,method:req.method,allowedInitialNavigation:allowed,caseID:route?.id??null});res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type','text/html');if(route)res.end('<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><style>html,body{margin:0}svg{display:block}</style><body></body>');else res.writeHead(404).end('unexpected source HTTP')})
const report={startedUTC:new Date().toISOString(),fixedCases:6,cases:[],HTTPJournal:journal,cleanup:{}}
const save=()=>writeFile(own('results.json'),JSON.stringify(report,null,2)+'\n')
try{
 await new Promise((r,j)=>{server.once('error',j);server.listen(0,'127.0.0.1',r)});origin='http://127.0.0.1:'+server.address().port;report.origin=origin
 for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
  const browser=await type.launch({headless:true});report.cleanup[engine]={browserClosed:false,version:browser.version()}
  try{for(const policy of ['noQuery','q=1']){
   const id=engine+'-'+policy.replace('=','')+'-'+randomUUID(),pathname='/probe/'+id+'/caller.html',query=policy==='noQuery'?'':'?q=1',url=origin+pathname+query;paths.set(pathname+query,{id,count:0})
   const context=await browser.newContext({viewport:{width:160,height:80},deviceScaleFactor:1}),page=await context.newPage(),row={id,engine,policy,url,version:browser.version(),console:[],pageErrors:[],requestEvents:[]};report.cases.push(row)
   page.on('console',m=>row.console.push({type:m.type(),text:m.text()}));page.on('pageerror',e=>row.pageErrors.push(String(e)));page.on('request',r=>{if(/^https?:|^blob:/.test(r.url()))row.requestEvents.push({method:r.method(),url:r.url(),kind:r.resourceType()})})
   try{
    await page.goto(url,{waitUntil:'load'});row.measurement=await page.evaluate(async({id})=>{
     const ns='http://www.w3.org/2000/svg',clipID='page-clip-'+id,fileID='fileClip-'+id,token='?'+location.search.slice(1)+'#'+clipID,events=[],start=performance.now(),before={body:document.body.outerHTML,frames:document.querySelectorAll('iframe,object').length}
     const fileSVG=`<svg xmlns="${ns}" width="20" height="20"><defs><clipPath id="${fileID}" clipPathUnits="userSpaceOnUse"><rect width="6" height="20"/></clipPath></defs></svg>`,fileURL=URL.createObjectURL(new Blob([fileSVG],{type:'image/svg+xml'}))
     const probeSVG=`<svg xmlns="${ns}" width="20" height="20"><defs><clipPath id="${clipID}" clipPathUnits="userSpaceOnUse"><rect width="6" height="20"/></clipPath></defs><symbol id="direct" viewBox="0 0 20 20"><rect width="20" height="20" fill="green" clip-path="url('${token}')"/></symbol><symbol id="variable" viewBox="0 0 20 20"><rect width="20" height="20" fill="green" style="--p:url('${token}');clip-path:var(--p)"/></symbol><symbol id="absolute" viewBox="0 0 20 20"><rect width="20" height="20" fill="green" clip-path="url('${fileURL}#${fileID}')"/></symbol><symbol id="flat" viewBox="0 0 20 20"><rect width="20" height="20" fill="green"/></symbol></svg>`,probeURL=URL.createObjectURL(new Blob([probeSVG],{type:'image/svg+xml'}))
     const svg=document.createElementNS(ns,'svg');svg.id='owned-probe';svg.setAttribute('width','96');svg.setAttribute('height','20');svg.setAttribute('viewBox','0 0 96 20');svg.innerHTML=`<defs><clipPath id="${clipID}" clipPathUnits="userSpaceOnUse"><rect width="12" height="20"/></clipPath></defs>`
     const uses=[],loads=[],urls=[{role:'fileClip',url:fileURL,text:fileSVG},{role:'probe',url:probeURL,text:probeSVG}];let timer,loadOutcome
     try{
      for(const resource of urls){const r=await fetch(resource.url);resource.before={ok:r.ok,status:r.status,body:await r.text()};resource.beforeMatches=resource.before.body===resource.text}
      for(const[ index,name]of ['direct','variable','absolute','flat'].entries()){
       const use=document.createElementNS(ns,'use');use.id='sample-'+name;use.setAttribute('x',String(index*24));use.setAttribute('width','20');use.setAttribute('height','20');loads.push(new Promise((resolve,reject)=>{use.onload=()=>{events.push({group:name,event:'load',elapsedMS:performance.now()-start});resolve()};use.onerror=()=>{events.push({group:name,event:'error',elapsedMS:performance.now()-start});reject(Error(name+' use resource error'))}}));use.setAttribute('href',probeURL+'#'+name);svg.append(use);uses.push({name,use,index})
      }
      document.body.append(svg)
      try{const all=Promise.all(loads);void all.catch(()=>{});await Promise.race([all,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('2500ms nativeuse load guard')),2500)})]);loadOutcome='all-native-use-loads'}catch(e){loadOutcome=String(e)}finally{clearTimeout(timer)}
      const measurements=uses.map(({name,use,index})=>{let bbox;try{const b=use.getBBox();bbox={x:b.x,y:b.y,width:b.width,height:b.height}}catch(e){bbox={error:String(e)}}const samples=[2,8,15].map(x=>{const point={x:index*24+x,y:10},hit=document.elementFromPoint(point.x,point.y);return{...point,hitTag:hit?.localName??null,hitID:hit?.id??null,ownUse:hit===use}});return{name,bbox,samples,hitPattern:samples.map(x=>x.ownUse)}})
      const by=Object.fromEntries(measurements.map(x=>[x.name,x])),bboxReady=measurements.every(x=>x.bbox.width===20&&x.bbox.height===20),filePositive=JSON.stringify(by.absolute.hitPattern)==='[true,false,false]',flatPositive=JSON.stringify(by.flat.hitPattern)==='[true,true,true]',positiveReady=loadOutcome==='all-native-use-loads'&&bboxReady&&filePositive&&flatPositive
      return{documentURL:document.URL,documentURI:document.documentURI,baseURI:document.baseURI,callerBaseEqualsURL:document.baseURI===document.URL,query:location.search,relativeQueryToken:token,clipID,fileID,fileSVG,probeSVG,events,loadOutcome,measurements,bboxReady,filePositive,flatPositive,positiveReady,before,elapsedMS:performance.now()-start,resources:urls}
     }finally{
      clearTimeout(timer);for(const{use}of uses){use.onload=use.onerror=null}svg.remove()
      const cleanup=[];for(const resource of urls){URL.revokeObjectURL(resource.url);try{const r=await fetch(resource.url);cleanup.push({role:resource.role,revokeCalled:true,fetchAfterResolved:true,status:r.status})}catch(e){cleanup.push({role:resource.role,revokeCalled:true,fetchAfterResolved:false,error:String(e)})}}
      window.__probeCleanup={resources:cleanup,svgRemoved:!svg.isConnected,after:{body:document.body.outerHTML,frames:document.querySelectorAll('iframe,object').length},listenersRemoved:true,timerCleared:true}
     }
    },{id})
    row.resourceCleanup=await page.evaluate(()=>window.__probeCleanup);row.callerUnchanged=JSON.stringify(row.measurement.before)===JSON.stringify(row.resourceCleanup.after)
    for(const key of ['fileSVG','probeSVG']){await writeFile(own(id+'-'+key+'.svg'),row.measurement[key]);row.measurement[key+'SHA256']=sha(row.measurement[key]);delete row.measurement[key]}
    for(const resource of row.measurement.resources){resource.textSHA256=sha(resource.text);delete resource.text;resource.before.bodySHA256=sha(resource.before.body);delete resource.before.body}
   }catch(error){row.error=String(error);row.stack=error.stack}
   finally{await context.close();row.contextClosed=true;row.closedUTC=new Date().toISOString();await save()}
   console.log(JSON.stringify({engine,policy,baseEqual:row.measurement?.callerBaseEqualsURL,token:row.measurement?.relativeQueryToken,load:row.measurement?.loadOutcome,patterns:row.measurement?.measurements.map(x=>({group:x.name,bbox:x.bbox,hits:x.hitPattern})),positiveReady:row.measurement?.positiveReady,cleanup:row.resourceCleanup,error:row.error}))
  }}finally{await browser.close();report.cleanup[engine].browserClosed=true;report.cleanup[engine].closedUTC=new Date().toISOString();await save()}
 }
}finally{
 await new Promise(r=>server.close(r));report.cleanup.serverClosed=!server.listening
 const extra=journal.filter(x=>!x.allowedInitialNavigation);report.sourceTrapHTTP=extra;report.totalSourceTrapHTTP=extra.length
 for(const row of report.cases){row.sourceTrapHTTP=extra.filter(x=>x.caseID===row.id);row.safeRuntimeProbeEligible=!row.error&&row.measurement?.positiveReady===true&&row.measurement?.callerBaseEqualsURL===true&&extra.length===0}
 report.completedUTC=new Date().toISOString();await save()
}
