"""Offline stdlib verifier for rejected fixed native-query clip probe. No browser."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET


def sha(content):
    return hashlib.sha256(content).hexdigest()


def derive(folder):
    report=json.loads((folder/'results.json').read_text())
    urls=json.loads((folder/'standard-url-analysis.json').read_text())
    assert report['fixedCases']==len(report['cases'])==len(urls['rows'])==6
    assert len(report['HTTPJournal'])==7 and report['totalSourceTrapHTTP']==len(report['sourceTrapHTTP'])==1
    assert sum(x['allowedInitialNavigation']for x in report['HTTPJournal'])==6
    assert report['sourceTrapHTTP'][0]['caseID']==report['cases'][0]['id']
    assert report['cases'][0]['engine']=='chromium'and report['cases'][0]['policy']=='noQuery'
    assert report['cleanup']['serverClosed']and all(report['cleanup'][e]['browserClosed']for e in ['chromium','firefox','webkit'])
    expected_patterns=[[[False,False,False],[True,True,True],[False,False,False],[True,True,True]],
                       [[True,False,False],[True,True,True],[False,False,False],[True,True,True]],
                       [[True,True,True],[True,True,True],[True,False,False],[True,True,True]],
                       [[True,True,True],[True,True,True],[True,False,False],[True,True,True]],
                       [[True,True,True],[True,True,True],[True,True,True],[True,True,True]],
                       [[True,True,True],[True,True,True],[True,True,True],[True,True,True]]]
    rows=[];rejected=resolved=0
    for index,(row,analysis)in enumerate(zip(report['cases'],urls['rows'])):
        assert 'error'not in row and row['contextClosed']and row['callerUnchanged']
        m=row['measurement'];assert analysis['caseID']==row['id']
        assert m['baseURI']==m['documentURL']==m['documentURI']==row['url']and m['callerBaseEqualsURL']
        assert analysis['actualDocumentURL']==m['documentURL']and analysis['token']==m['relativeQueryToken']
        assert m['relativeQueryToken']=='?'+m['query'].lstrip('?')+'#'+m['clipID']
        exact=row['policy']=='q=1'
        assert analysis['exactPageHrefEqualsDocumentURL']==exact
        assert analysis['standardPageWithoutFragmentHref']==row['url']+(''if exact else'?')
        assert analysis['standardBlobRelativeResolution']['resolved']==analysis['BlobBaseURL']+analysis['token']
        assert m['positiveReady']is False and row['safeRuntimeProbeEligible']is False and m['bboxReady']is True
        actual=[g['hitPattern']for g in m['measurements']]
        assert actual==expected_patterns[index]
        assert m['flatPositive']is True and m['filePositive']==(row['engine']=='firefox')
        if row['engine']=='firefox':assert '2500ms nativeuse load guard'in m['loadOutcome']
        else:assert m['loadOutcome']=='all-native-use-loads'
        for i,group in enumerate(m['measurements']):
            assert group['bbox']=={'x':i*24,'y':0,'width':20,'height':20}
            assert [s['x']for s in group['samples']]==[i*24+x for x in [2,8,15]]
            assert all(s['y']==10 for s in group['samples'])
        for resource in m['resources']:
            suffix='fileSVG'if resource['role']=='fileClip'else'probeSVG'
            raw=(folder/(row['id']+'-'+suffix+'.svg')).read_bytes()
            assert sha(raw)==m[suffix+'SHA256']==resource['textSHA256']==resource['before']['bodySHA256']
            assert resource['beforeMatches']and resource['before']['ok']and resource['before']['status']==200
            root=ET.fromstring(raw);assert root.tag=='{http://www.w3.org/2000/svg}svg'
        cleanup=row['resourceCleanup'];assert cleanup['svgRemoved']and cleanup['listenersRemoved']and cleanup['timerCleared']
        assert m['before']==cleanup['after']and cleanup['after']['frames']==0
        for resource in cleanup['resources']:
            assert resource['revokeCalled']
            if resource['fetchAfterResolved']:
                resolved+=1;assert row['engine']=='webkit'and resource['role']=='probe'and resource['status']==200
                assert 'body'not in resource
            else:rejected+=1
        rows.append({'engine':row['engine'],'policy':row['policy'],'documentURL':row['url'],
                     'relativeQueryToken':m['relativeQueryToken'],
                     'standardPageHrefWithoutFragment':analysis['standardPageWithoutFragmentHref'],
                     'exactSameDocumentHref':exact,'baseEqualsDocumentURL':True,
                     'nativeLoadOutcome':m['loadOutcome'],'events':m['events'],
                     'hitPatterns':dict(zip(['direct','variable','absoluteFileClip','flat'],actual)),
                     'bboxAll20x20':True,'filePositive':m['filePositive'],'flatPositive':True,
                     'positiveReady':False,'safeRuntimeProbeEligible':False,
                     'postRevokeFetch':cleanup['resources'],'contextClosed':True})
    assert rejected==10 and resolved==2
    first=urls['rows'][0]
    assert first['callerHTTPEvents'][1]['url']==first['actualDocumentURL']+'?'
    return{'cases':rows,'actualSourceTrapHTTP':report['sourceTrapHTTP'],'allowedInitialNavigations':6,
           'totalServerReceipts':7,'eligibleCases':0,'filePositiveCases':2,'flatPositiveCases':6,
           'postRevokeFetchRejected':10,'postRevokeFetchResolvedHeadersOnly':2,
           'cleanup':report['cleanup']}


def main():
    folder=Path(__file__).resolve().parent
    index=json.loads((folder/'sha256-index.json').read_text())
    actual={str(f.relative_to(folder))for f in folder.rglob('*')if f.is_file()and f.name!='sha256-index.json'}
    assert actual=={r['path']for r in index['files']}
    for row in index['files']:
        content=(folder/row['path']).read_bytes();assert len(content)==row['bytes']and sha(content)==row['sha256']
    assert derive(folder)==json.loads((folder/'assessment.json').read_text())['independentChecks']
    assert not any(f.suffix.lower()=='.png'for f in folder.rglob('*'))
    print('Verifiedfixed6 rejected probes;7actualHTTP/1trap;null-v-emptyqueryhref;nativepatterns/readinessfailures;12revoke calls/10reject+2headers200;sourceSHA/cleanup/no screenshots.')


if __name__=='__main__':
    main()
