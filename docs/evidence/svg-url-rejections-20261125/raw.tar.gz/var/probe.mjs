import {createServer} from 'node:http'
import {readFile,writeFile} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
import {createHash} from 'node:crypto'
import {chromium,firefox,webkit} from 'playwright'
const own=n=>new URL(n,import.meta.url),sha=b=>createHash('sha256').update(b).digest('hex')
const template=await readFile(own('source-template.svg'),'utf8'),columns=['relative-attribute','relative-inline','inherited-custom-property']
const oldOrigin='http://127.0.0.1:55798';let origin,phase='setup';const requests=[]
function resource(color){return template.replaceAll(oldOrigin,origin).replace('fill="green"','fill="'+color+'"')}
const pageHTML='<!doctype html><style>html,body{margin:0;background:white}#matrix{display:flex;width:60px;height:20px;background:white}#matrix>svg{display:block;flex:none;overflow:hidden}</style><div id="matrix">'+columns.map(id=>`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><use href="/paint/assets/sprite.svg#${id}" width="20" height="20"/></svg>`).join('')+'</div>'
const server=createServer((req,res)=>{const u=new URL(req.url,'http://localhost');requests.push({atUTC:new Date().toISOString(),phase,path:u.pathname+u.search});res.setHeader('Cache-Control','no-store');if(u.pathname==='/paint/page.html'){res.setHeader('Content-Type','text/html');res.end(pageHTML)}else if(u.pathname.endsWith('/sprite.svg')){res.setHeader('Content-Type','image/svg+xml');res.end(resource(u.searchParams.has('different')?(u.pathname.includes('/assets/')?'yellow':'blue'):(u.pathname.includes('/assets/')?'green':'red')))}else res.writeHead(404).end()})
const report={startedUTC:new Date().toISOString(),columns,results:[],requests,cleanup:{},libraryLoaded:'Unmodified9c09 currentUMD for baseline only; no candidate build unless CSSOM path improves'}
try{
 await new Promise((r,j)=>{server.once('error',j);server.listen(0,'127.0.0.1',r)});origin='http://127.0.0.1:'+server.address().port;report.origin=origin
 await writeFile(own('fixture-page.html'),pageHTML);await writeFile(own('fixture-resource.svg'),resource('green'))
 for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
  const browser=await type.launch({headless:true}),context=await browser.newContext({viewport:{width:300,height:160},deviceScaleFactor:1}),page=await context.newPage(),row={engine,version:browser.version(),console:[],pageErrors:[]};report.results.push(row)
  page.on('console',m=>row.console.push({phase,type:m.type(),text:m.text()}));page.on('pageerror',e=>row.pageErrors.push(String(e)))
  try{
   phase=engine+'/native';await page.goto(origin+'/paint/page.html',{waitUntil:'load'});await page.waitForFunction(()=>Array.from(document.querySelectorAll('use')).every(x=>x.getBBox().width===20));await page.waitForLoadState('networkidle')
   const before=await page.locator('#matrix').screenshot({scale:'css'});await writeFile(own(engine+'-native-before.png'),before);row.nativeSHA256=sha(before);row.sourceDOMBefore=await page.locator('#matrix').evaluate(x=>x.outerHTML)
   await page.addScriptTag({path:fileURLToPath(own('current.umd.js'))});phase=engine+'/current9c09'
   const current=await page.evaluate(async nativeB64=>{const node=document.querySelector('#matrix'),uri=await htmlToImage.toSvg(node),image=new Image();image.src=uri;await image.decode();const canvas=document.createElement('canvas');canvas.width=60;canvas.height=20;const c=canvas.getContext('2d');c.drawImage(image,0,0);const actual=c.getImageData(0,0,60,20).data,png=canvas.toDataURL();const native=new Image();native.src='data:image/png;base64,'+nativeB64;await native.decode();c.clearRect(0,0,60,20);c.drawImage(native,0,0);const expected=c.getImageData(0,0,60,20).data;const columns=Array.from({length:3},(_,col)=>{let differentChannels=0,differentPixels=0;for(let y=0;y<20;y++)for(let x=col*20;x<col*20+20;x++){let changed=false;for(let k=0;k<4;k++){const at=4*(y*60+x)+k;if(actual[at]!==expected[at]){differentChannels++;changed=true}}differentPixels+=changed}const at=4*(10*60+col*20+10);return{differentChannels,differentPixels,nativeCenter:Array.from(expected.slice(at,at+4)),captureCenter:Array.from(actual.slice(at,at+4))}});return{uri,svg:decodeURIComponent(uri.slice(uri.indexOf(',')+1)),png,columns}},before.toString('base64'))
   await writeFile(own(engine+'-current.svg'),current.svg);await writeFile(own(engine+'-current.png'),Buffer.from(current.png.split(',')[1],'base64'));row.current9c09Columns=current.columns.map((x,i)=>({id:columns[i],...x}));row.current9c09DifferentChannels=current.columns.reduce((n,x)=>n+x.differentChannels,0)
   phase=engine+'/privateXML-probes'
   row.privateXML=await page.evaluate(async({url,columns})=>{
    const response=await fetch(url),text=await response.text(),fileURL=response.url,xmlNS='http://www.w3.org/XML/1998/namespace'
    const frame=document.createElement('iframe');frame.setAttribute('sandbox','allow-same-origin');frame.style.cssText='position:fixed;left:-99999px;top:0;width:300px;height:160px;opacity:0;pointer-events:none';let timer
    try{
     await new Promise((resolve,reject)=>{frame.onload=()=>{if(frame.contentDocument?.querySelector('meta[data-measurement]'))resolve()};timer=setTimeout(()=>reject(Error('2500ms private measurement document guard')),2500);frame.srcdoc='<!doctype html><meta data-measurement http-equiv="Content-Security-Policy" content="default-src \'none\';script-src \'none\';style-src \'unsafe-inline\' data:;img-src \'none\';font-src data:;base-uri \'none\';form-action \'none\'"><style>html,body{margin:0;overflow:hidden}</style><body></body>';document.documentElement.append(frame)})
     clearTimeout(timer);frame.onload=null;const doc=frame.contentDocument,view=frame.contentWindow,modes=[]
     for(const mode of ['baseline','temporaryXMLBaseForceCustomPropertyRead']){
      const source=new DOMParser().parseFromString(text,'image/svg+xml'),root=source.documentElement,serialize=()=>new XMLSerializer().serializeToString(root),snapshot=()=>({XML:serialize(),rootAttrs:Array.from(root.attributes,a=>[a.name,a.value]),styleLiterals:Array.from(source.querySelectorAll('[style]'),e=>[e.getAttribute('id'),e.getAttribute('style')]),fillLiterals:Array.from(source.querySelectorAll('[fill]'),e=>[e.getAttribute('id'),e.getAttribute('fill')])}),before=snapshot(),reads=[];const beforeBase=root.baseURI;let duringBase
      if(mode!=='baseline'){
       const prior=root.getAttributeNS(xmlNS,'base');root.setAttributeNS(xmlNS,'xml:base',fileURL);duringBase=root.baseURI
       try{for(const element of source.querySelectorAll('[style]')){const literal=element.getAttribute('style');if(!/(^|;)\s*--paint\s*:/.test(literal))continue;const style=element.style,value=style.getPropertyValue('--paint'),typed=element.attributeStyleMap?.get('--paint');reads.push({tag:element.localName,literal,baseURI:element.baseURI,styleValue:value,cssText:style.cssText,attributeStyleMapSupported:!!element.attributeStyleMap,typedValue:typed?.toString()??null,typedConstructor:typed?.constructor.name??null})}}
       finally{if(prior===null)root.removeAttributeNS(xmlNS,'base');else root.setAttributeNS(xmlNS,'xml:base',prior)}
      }
      const restoredBase=root.baseURI,after=snapshot(),values=[]
      for(const id of columns){const original=source.getElementById(id),container=doc.createElement('div');container.style.cssText='position:absolute!important;left:-9999px!important;opacity:0!important';const shadow=container.attachShadow({mode:'open'}),fragment=doc.importNode(original,true);shadow.append(fragment);doc.documentElement.append(container);try{const rect=fragment.querySelector('rect'),style=view.getComputedStyle(rect),parent=rect.parentElement;values.push({id,originalStyle:original.getAttribute('style'),rectStyle:rect.getAttribute('style'),rectFill:rect.getAttribute('fill'),parentStyle:parent.getAttribute('style'),parentCustomProperty:view.getComputedStyle(parent).getPropertyValue('--paint'),fill:style.getPropertyValue('fill'),computedLength:style.length,rectBaseURI:rect.baseURI,parentBaseURI:parent.baseURI})}finally{container.remove()}}
      modes.push({mode,sourceContentType:source.contentType,sourceDocumentURI:source.documentURI,beforeBase,duringBase,restoredBase,measurementBase:doc.baseURI,reads,before,after,literalsAndSerializedXMLUnchanged:JSON.stringify(before)===JSON.stringify(after),values})
     }
     return{fileURL,fetchedText:text,modes,frameCreated:1,frameRemovedInFinally:true}
    }finally{clearTimeout(timer);frame.onload=null;frame.remove()}
   },{url:origin+'/paint/assets/sprite.svg',columns})
   await writeFile(own(engine+'-private-source.svg'),row.privateXML.fetchedText);row.privateXML.fetchedTextSHA256=sha(row.privateXML.fetchedText);delete row.privateXML.fetchedText
   row.framesAfter=await page.locator('iframe').count();const after=await page.locator('#matrix').screenshot({scale:'css'});await writeFile(own(engine+'-native-after.png'),after);row.sourceScreenshotUnchanged=before.equals(after);row.sourceDOMAfter=await page.locator('#matrix').evaluate(x=>x.outerHTML);row.sourceDOMUnchanged=row.sourceDOMBefore===row.sourceDOMAfter
   const [baseline,temporary]=row.privateXML.modes;row.allComputedFillUnchanged=baseline.values.every((x,i)=>x.fill===temporary.values[i].fill)
   console.log(JSON.stringify({engine,currentDifferent:row.current9c09DifferentChannels,native:row.current9c09Columns.map(x=>x.nativeCenter),beforeBase:temporary.beforeBase,duringBase:temporary.duringBase,restoredBase:temporary.restoredBase,reads:temporary.reads,baseline:baseline.values.map(x=>({id:x.id,fill:x.fill})),temporary:temporary.values.map(x=>({id:x.id,fill:x.fill})),literalsUnchanged:temporary.literalsAndSerializedXMLUnchanged,allComputedFillUnchanged:row.allComputedFillUnchanged,framesAfter:row.framesAfter,sourceUnchanged:row.sourceScreenshotUnchanged}))
  }catch(error){row.error=String(error);row.stack=error.stack;console.log(engine,'ERROR',row.error)}
  finally{await context.close();await browser.close();row.contextClosed=true;row.browserClosed=true;row.closedUTC=new Date().toISOString();await writeFile(own('results.json'),JSON.stringify(report,null,2)+'\n')}
 }
}finally{await new Promise(r=>server.close(r));report.cleanup.serverClosed=!server.listening;report.completedUTC=new Date().toISOString();await writeFile(own('results.json'),JSON.stringify(report,null,2)+'\n')}
