"""Offline verifier for bounded transient XML-base parse-context probe."""
from pathlib import Path
import hashlib,json,struct,zlib
def sha(data):
    return hashlib.sha256(data).hexdigest()


def png(data):
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    pos, compressed, chunks, header = 8, bytearray(), [], None
    while pos < len(data):
        size = struct.unpack('>I', data[pos:pos + 4])[0]
        kind = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + size]
        crc = struct.unpack('>I', data[pos + 8 + size:pos + 12 + size])[0]
        assert zlib.crc32(kind + body) & 0xffffffff == crc
        chunks.append(kind.decode('ascii'))
        if kind == b'IHDR':
            header = struct.unpack('>IIBBBBB', body)
        if kind == b'IDAT':
            compressed.extend(body)
        pos += size + 12
        if kind == b'IEND':
            break
    assert pos == len(data) and header is not None
    width, height, depth, color, compression, filtering, interlace = header
    assert (depth, compression, filtering, interlace) == (8, 0, 0, 0)
    assert color in (2, 6), ('unsupported PNG color type', color)
    channels = 3 if color == 2 else 4
    stride = width * channels
    decoded = zlib.decompress(bytes(compressed))
    assert len(decoded) == height * (stride + 1)
    previous = bytearray(stride)
    rgba = bytearray()
    for y in range(height):
        at = y * (stride + 1)
        method = decoded[at]
        assert 0 <= method <= 4
        row = bytearray(decoded[at + 1:at + 1 + stride])
        for x in range(stride):
            left = row[x - channels] if x >= channels else 0
            up = previous[x]
            upper_left = previous[x - channels] if x >= channels else 0
            prediction = 0
            if method == 1:
                prediction = left
            elif method == 2:
                prediction = up
            elif method == 3:
                prediction = (left + up) // 2
            elif method == 4:
                p = left + up - upper_left
                distances = (abs(p - left), abs(p - up), abs(p - upper_left))
                prediction = (left if distances[0] <= distances[1] and distances[0] <= distances[2]
                              else up if distances[1] <= distances[2] else upper_left)
            row[x] = (row[x] + prediction) & 255
        if channels == 4:
            rgba.extend(row)
        else:
            for x in range(0, stride, 3):
                rgba.extend(row[x:x + 3])
                rgba.append(255)
        previous = row
    return width, height, bytes(rgba), chunks


def derive(folder):
    report=json.loads((folder/'results.json').read_text())
    assert len(report['results'])==3 and report['cleanup']['serverClosed']
    result=[]
    for row in report['results']:
        assert 'error'not in row and row['contextClosed']and row['browserClosed']and row['framesAfter']==0
        assert row['sourceScreenshotUnchanged']and row['sourceDOMUnchanged']
        baseline,temporary=row['privateXML']['modes']
        file_url=row['privateXML']['fileURL']
        assert file_url.endswith('/paint/assets/sprite.svg')
        assert baseline['mode']=='baseline'and temporary['mode']=='temporaryXMLBaseForceCustomPropertyRead'
        assert baseline['before']==baseline['after']==temporary['before']==temporary['after']
        assert temporary['literalsAndSerializedXMLUnchanged']and baseline['literalsAndSerializedXMLUnchanged']
        assert temporary['beforeBase']==temporary['duringBase']==temporary['restoredBase']==temporary['measurementBase']
        assert temporary['duringBase']!=file_url
        assert len(temporary['reads'])==1 and temporary['reads'][0]['styleValue']=='url(sprite.svg?different#paint) purple'
        assert temporary['reads'][0]['baseURI']==temporary['duringBase']
        assert baseline['sourceContentType']==temporary['sourceContentType']=='image/svg+xml'
        assert baseline['values']==temporary['values'] and row['allComputedFillUnchanged']
        for value in temporary['values']:
            assert value['computedLength']>0 and '/paint/sprite.svg?different#paint'in value['fill']
            assert '/paint/assets/'not in value['fill']
        source=(folder/(row['engine']+'-private-source.svg')).read_bytes()
        assert sha(source)==row['privateXML']['fetchedTextSHA256']
        before=(folder/(row['engine']+'-native-before.png')).read_bytes()
        after=(folder/(row['engine']+'-native-after.png')).read_bytes()
        actual=(folder/(row['engine']+'-current.png')).read_bytes()
        assert before==after and sha(before)==row['nativeSHA256']
        w,h,n,_=png(before);aw,ah,c,_=png(actual);assert(w,h,aw,ah)==(60,20,60,20)
        cols=[]
        for col,identity in enumerate(report['columns']):
            channels=pixels=0
            for y in range(20):
                for x in range(col*20,col*20+20):
                    at=4*(y*60+x);changed=sum(n[at+k]!=c[at+k]for k in range(4));channels+=changed;pixels+=bool(changed)
            center=4*(10*60+col*20+10)
            cols.append({'id':identity,'differentChannels':channels,'differentPixels':pixels,
                         'nativeCenter':list(n[center:center+4]),'captureCenter':list(c[center:center+4])})
        assert cols==row['current9c09Columns']
        assert sum(x['differentChannels']for x in cols)==row['current9c09DifferentChannels']
        expected=1200 if row['engine']=='chromium' else 3600
        assert row['current9c09DifferentChannels']==expected
        result.append({'engine':row['engine'],'version':row['version'],'currentDifferentChannels':expected,
                       'nativeAndCurrentColumns':cols,'fileResponseURL':file_url,
                       'beforeBase':temporary['beforeBase'],'duringBaseAfterTemporarySetter':temporary['duringBase'],
                       'restoredBase':temporary['restoredBase'],'measurementBase':temporary['measurementBase'],
                       'CSSOMReads':temporary['reads'],'computedFillsUnchanged':True,
                       'literalAttributesAndXMLUnchanged':True,'contextAndBrowserClosed':True,'measurementFramesAfter':0})
    return{'engines':result,'nativeColumns':9,'privateComparisons':9,
           'computedFillChanges':0,'candidateBuilt':False,'full12Expanded':False,'serverClosed':True}


def main():
    folder=Path(__file__).resolve().parent
    index=json.loads((folder/'sha256-index.json').read_text())
    actual={str(p.relative_to(folder))for p in folder.rglob('*')if p.is_file()and p.name!='sha256-index.json'}
    assert actual=={r['path']for r in index['files']}
    for row in index['files']:
        content=(folder/row['path']).read_bytes();assert len(content)==row['bytes']and sha(content)==row['sha256']
    assert derive(folder)==json.loads((folder/'assessment.json').read_text())['independentChecks']
    assert sha((folder/'current.umd.js').read_bytes())=='9c090fc25401c32b55c80dce3acaa71c6a8e0dc538046b4abad67c584dccee1a'
    print('Verified3engines/9nativecolumns, transient-base unchanged9computedfills/literals,9c09PNGerrors1200/3600/3600,cleanup,and memberSHA.')


if __name__=='__main__':
    main()
