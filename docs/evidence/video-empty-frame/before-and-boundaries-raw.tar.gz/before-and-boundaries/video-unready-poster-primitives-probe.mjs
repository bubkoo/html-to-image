import {createServer} from 'node:http'
import {readFile,mkdir,writeFile} from 'node:fs/promises'
import {resolve} from 'node:path'
import {chromium,firefox,webkit} from 'playwright'
const out=resolve('output/playwright/video-unready-poster-primitives');await mkdir(out,{recursive:true})
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname
 if(path==='/pending.mp4'){res.writeHead(200,{'Content-Type':'video/mp4'});res.flushHeaders();return}
 if(path==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><style>body{margin:0}</style>');return}
 if(path.startsWith('/es/')){try{res.setHeader('Content-Type','text/javascript');res.end(await readFile(resolve('.'+path)));return}catch{}}
 res.writeHead(404).end()
})
await new Promise(r=>server.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${server.address().port}`;const results={}
try{
 for(const [name,type] of Object.entries({chromium,firefox,webkit})){
  const browser=await type.launch()
  try{
   for(const mode of ['poster','blank','poster-play','blank-play','poster-play-pause','blank-play-pause']){
   const page=await browser.newPage({deviceScaleFactor:1});await page.goto(url)
   await page.evaluate((mode)=>{const video=document.createElement('video');video.id='source';video.style.cssText='display:block;width:60px;height:40px;background:blue';if(mode.startsWith('poster'))video.poster='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="60" height="40"><rect width="60" height="40" fill="red"/></svg>');video.preload='auto';video.src='/pending.mp4';document.body.append(video);video.load();video.muted=true;if(mode.includes('play')){void video.play().catch(()=>{});if(mode.endsWith('pause'))video.pause()}},mode)
   await page.waitForFunction(()=>document.getElementById('source').currentSrc)
   await page.locator('#source').screenshot({path:resolve(out,name+'-'+mode+'-before.png'),scale:'css'})
   const record=await page.evaluate(async()=>{const video=document.getElementById('source');const state={readyState:video.readyState,currentSrc:video.currentSrc,videoWidth:video.videoWidth,videoHeight:video.videoHeight,paused:video.paused,played:video.played.length,markup:video.outerHTML};const nativeCanvas=document.createElement('canvas');nativeCanvas.width=60;nativeCanvas.height=40;const ctx=nativeCanvas.getContext('2d');let primitive;try{ctx.drawImage(video,0,0,60,40);primitive={pixel:Array.from(ctx.getImageData(30,20,1,1).data)}}catch(error){primitive={error:error.name,message:error.message}};state.primitive=primitive;state.seeking=video.seeking;state.networkState=video.networkState;state.currentTime=video.currentTime;const {createRenderer}=await import('/es/index.js');const renderer=createRenderer({skipFonts:true,pixelRatio:1,timeout:2000});let capture;try{capture=await renderer.capture(video);return {state,success:true,png:await capture.toPng(),sourceUnchanged:state.markup===video.outerHTML}}catch(error){return {state,success:false,error:{name:error.name,message:error.message},sourceUnchanged:state.markup===video.outerHTML}}finally{capture?.dispose();renderer.dispose()}})
   if(record.png){await writeFile(resolve(out,name+'-'+mode+'-capture.png'),Buffer.from(record.png.split(',')[1],'base64'));delete record.png}
   await page.locator('#source').screenshot({path:resolve(out,name+'-'+mode+'-after.png'),scale:'css'});results[name+'-'+mode]={version:browser.version(),...record};await page.close()
   }
  }finally{await browser.close()}
 }
}finally{server.closeAllConnections();await new Promise(r=>server.close(r))}
await writeFile(resolve(out,'observation.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(Object.fromEntries(Object.entries(results).map(([k,v])=>[k,{readyState:v.state.readyState,currentSrc:!!v.state.currentSrc,success:v.success,error:v.error}]))))
