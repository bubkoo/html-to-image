from client import call,execute,folder,session
import json,time,base64,io,hashlib,subprocess,re
from PIL import Image
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
address=re.search(r'\binet\s+(\d+\.\d+\.\d+\.\d+)',subprocess.check_output(['ifconfig','en15'],text=True)).group(1)
call('/timeouts',{'pageLoad':60000,'script':60000})
call('/url',{'url':'http://'+address+':4373/test/browser/svg-native-device.html?empty-video='+head},timeout=65)
execute('''
window.videoNativeRecords=[];window.videoNativeScene=null;window.videoNativeDone=null;window.videoNativeSequence=0;
(async()=>{
 const {createEmptyVideoFixture}=await import('/test/browser/fixtures/empty-video.mjs');const esm=await import('/es/index.js');
 const photo=(video,name,phase)=>new Promise(resolve=>{
  window.deliverVideoNativePixels=pixels=>{window.videoNativeScene=null;resolve(pixels)};
  window.videoNativeScene={sequence:++window.videoNativeSequence,name,phase,rect:video.getBoundingClientRect().toJSON(),viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},readyState:video.readyState,currentSrc:video.currentSrc,paused:video.paused,videoWidth:video.videoWidth,videoHeight:video.videoHeight};
 });
 for(const [format,api] of [['esm',esm],['umd',window.htmlToImage]])for(const mode of ['empty','selected','play-pause']){
  const fixture=await createEmptyVideoFixture(mode),name=format+'-'+mode;
  try{
   const before=await photo(fixture.video,name,'before');let data;
   const result=await fixture.run(async(node,options)=>{data=await api.toImageData(node,options);return data});
   const canvas=document.createElement('canvas');canvas.width=data.width;canvas.height=data.height;canvas.getContext('2d').putImageData(data,0,0);
   const after=await photo(fixture.video,name,'after');let different=0,changed=0,maximum=0;
   for(let i=0;i<data.data.length;i++){if(before[i]!==data.data[i])different++;if(before[i]!==after[i])changed++;maximum=Math.max(maximum,Math.abs(before[i]-data.data[i]))}
   window.videoNativeRecords.push({format,mode,...result,nativeDifferentChannels:different,maximumDifference:maximum,sourceChangedChannels:changed,png:canvas.toDataURL(),readyState:fixture.video.readyState,paused:fixture.video.paused,videoWidth:fixture.video.videoWidth,videoHeight:fixture.video.videoHeight});
  }finally{fixture.dispose()}
 }
 return{passed:window.videoNativeRecords.length};
})().then(value=>window.videoNativeDone=value).catch(error=>window.videoNativeDone={error:String(error),stack:error.stack});return true;
''')
photos=[];seen=0;deadline=time.monotonic()+240
while time.monotonic()<deadline:
 state=execute('return {scene:window.videoNativeScene,done:window.videoNativeDone}')
 if state['done']:break
 scene=state['scene']
 if not scene or scene['sequence']==seen:time.sleep(.1);continue
 seen=scene['sequence'];name=scene['name']+'-'+scene['phase'];raw=base64.b64decode(call('/screenshot'));(folder/(name+'-screen.png')).write_bytes(raw)
 source=Image.open(io.BytesIO(raw));rgba=source.convert('RGBA');rect=scene['rect'];scale=rgba.width/scene['viewport']['width'];width=round(rect['width']);height=round(rect['height']);assert (width,height)==(64,44)
 left=round(rect['x']*scale);cx=left+int((width/2+.5)*scale);yellow=(255,255,0,255);ys=[y for y in range(rgba.height) if rgba.getpixel((cx,y))==yellow];runs=[]
 for y in ys:
  if not runs or y!=runs[-1][-1]+1:runs.append([y])
  else:runs[-1].append(y)
 candidates=[]
 for top in runs:
  if len(top)!=round(2*scale):continue
  bottom=[r for r in runs if len(r)==round(2*scale) and r[0]-top[0]==round((height-2)*scale)]
  if not bottom:continue
  if all(rgba.getpixel((left+x,top[0]))==yellow for x in range(round(width*scale))):candidates.append(top[0])
 if len(candidates)!=1:
  (folder/'native-calibration-error.json').write_text(json.dumps({'scene':scene,'screenSize':rgba.size,'scale':scale,'yellowRuns':[(r[0],len(r)) for r in runs],'candidates':candidates},indent=2));raise RuntimeError('native yellow border calibration failed')
 top=candidates[0];pixels=[];crop=Image.new('RGBA',(width,height))
 for y in range(height):
  for x in range(width):
   value=rgba.getpixel((left+int((x+.5)*scale),top+int((y+.5)*scale)));pixels.extend(value);crop.putpixel((x,y),value)
 for y in range(height):
  assert crop.getpixel((0,y))==yellow and crop.getpixel((width-1,y))==yellow
 for x in range(width):assert crop.getpixel((x,0))==yellow and crop.getpixel((x,height-1))==yellow
 crop.save(folder/(name+'-native.png'));photos.append({**scene,'screenSize':rgba.size,'sampleScale':scale,'nativeTop':top,'screenSHA256':hashlib.sha256(raw).hexdigest(),'nativeRGBA_SHA256':hashlib.sha256(bytes(pixels)).hexdigest(),'iccProfileSHA256':hashlib.sha256(source.info['icc_profile']).hexdigest() if source.info.get('icc_profile') else None})
 execute('window.deliverVideoNativePixels('+json.dumps(pixels)+');return true')
else:raise RuntimeError('native empty video verification timed out')
records=execute('return window.videoNativeRecords||[]')
for row in records:(folder/(row['format']+'-'+row['mode']+'-capture.png')).write_bytes(base64.b64decode(row.pop('png').split(',')[1]))
summary={'sourceCommit':head,'runtimeSource':'ea97a25a45cb9db202d30d0f8dd704d57d7de3af','capabilities':{k:session['capabilities'].get(k) for k in ['platformName','safari:platformVersion','browserVersion','safari:deviceType','safari:useSimulator']},'photos':photos,'records':records,'done':state['done'],'oracle':'Actual source screenshots, calibrated by four yellow borders, CSS-pixel centers; no resampling or tolerance'}
(folder/'native-summary.json').write_text(json.dumps(summary,indent=2))
if state['done'].get('error'):raise RuntimeError(json.dumps(state['done']))
assert len(records)==6 and len(photos)==12
assert all(r['nativeDifferentChannels']==0 and r['sourceChangedChannels']==0 for r in records)
print(json.dumps({'nativePairs':len(records),'photos':len(photos),'allExact':True,'sourceUnchanged':True}))
