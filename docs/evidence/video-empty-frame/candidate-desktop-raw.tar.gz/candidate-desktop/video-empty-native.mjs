import {chromium,firefox,webkit} from 'playwright'
import {mkdir,writeFile,readFile} from 'node:fs/promises'
import {resolve} from 'node:path'
import {createHash} from 'node:crypto'
const out=resolve('output/playwright/video-empty-native');await mkdir(out,{recursive:true});const rows=[]
const inputs=['src/clone-node.ts','es/clone-node.js','lib/clone-node.js','dist/html-to-image.js','test/browser/fixtures/empty-video.mjs','test/browser/fixtures/video-readiness-server.mjs']
const hashes={};for(const path of inputs)hashes[path]=createHash('sha256').update(await readFile(path)).digest('hex')
for(const [engine,type] of Object.entries({chromium,firefox,webkit})){
 const browser=await type.launch()
 try{
  for(const format of ['esm','umd'])for(const mode of ['empty','selected','play-pause']){
   const page=await browser.newPage({deviceScaleFactor:1});await page.goto('http://127.0.0.1:4373/test/browser/umd.html')
   if(format==='umd')await page.addScriptTag({url:'/dist/html-to-image.js'})
   const setup=await page.evaluate(async(mode)=>{const {createEmptyVideoFixture}=await import('/test/browser/fixtures/empty-video.mjs');window.ownedEmptyVideo=await createEmptyVideoFixture(mode);return{id:window.ownedEmptyVideo.video.id,readyState:window.ownedEmptyVideo.video.readyState}},mode)
   const prefix=engine+'-'+format+'-'+mode
   try{
    await page.locator('#'+setup.id).screenshot({path:resolve(out,prefix+'-before.png'),scale:'css'})
    const record=await page.evaluate(async(format)=>{const api=format==='esm'?await import('/es/index.js'):window.htmlToImage;let image;const result=await window.ownedEmptyVideo.run(async(node,options)=>{image=await api.toImageData(node,options);return image});const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;canvas.getContext('2d').putImageData(image,0,0);return{...result,png:canvas.toDataURL()}},format)
    await writeFile(resolve(out,prefix+'-capture.png'),Buffer.from(record.png.split(',')[1],'base64'));delete record.png
    await page.locator('#'+setup.id).screenshot({path:resolve(out,prefix+'-after.png'),scale:'css'});rows.push({engine,format,mode,version:browser.version(),...record})
   }finally{await page.evaluate(()=>window.ownedEmptyVideo.dispose());await page.close()}
  }
 }finally{await browser.close()}
}
await writeFile(resolve(out,'observations.json'),JSON.stringify({inputSHA256:hashes,rows},null,2)+'\n');console.log(JSON.stringify({nativePairs:rows.length,sourceUnchanged:rows.every(x=>x.sourceUnchanged)}))
