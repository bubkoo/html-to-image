# Original 28 PRs: current readback

UTC checkedAt: 2026-11-24T20:23:13.000Z (read began 2026-11-24T20:22:35.618Z).

All 28 GitHub connector reads succeeded. 27 remain open; #398 remains closed and unmerged. No PR is merged. All 28 head SHAs, states and titles match the existing audit entries. No comments, closure, reopening, tracker changes, commits or pushes were made.

The baseline entries do not record head ref, base ref/SHA, merged or updated timestamps. Those fields are current observations only. Every base ref is master; the 13 distinct returned base SHAs must not be interpreted as a single live master tip or as unchanged/changed against an absent baseline. This is metadata readback, not code-diff, CI or issue-acceptance validation.

| PR | State | Head ref / SHA | Base ref / returned SHA | Merged | GitHub updatedAt (UTC) | Diff vs baseline |
| --- | --- | --- | --- | --- | --- | --- |
| [#585](https://github.com/bubkoo/html-to-image/pull/585) | open | pr / 9ede3815e690 | master / ad4ff590fd39 | false | 2026-11-05T09:40:13Z | none for state/head/title |
| [#581](https://github.com/bubkoo/html-to-image/pull/581) | open | master / 9ee9e0f9dd31 | master / 2d8d43e6959f | false | 2026-11-03T16:13:09Z | none for state/head/title |
| [#577](https://github.com/bubkoo/html-to-image/pull/577) | open | fix/repeating-linear-gradient / 35a6953ce31c | master / 116ff7a1d43d | false | 2026-11-16T17:34:49Z | none for state/head/title |
| [#575](https://github.com/bubkoo/html-to-image/pull/575) | open | fix/svg-css-variables-not-resolved / a8def89611d0 | master / 116ff7a1d43d | false | 2026-11-02T04:03:27Z | none for state/head/title |
| [#574](https://github.com/bubkoo/html-to-image/pull/574) | open | dependabot/npm_and_yarn/rollup-3.30.0 / 8edd3595adb1 | master / 073f6618b9ab | false | 2026-02-26T06:44:41Z | none for state/head/title |
| [#568](https://github.com/bubkoo/html-to-image/pull/568) | open | patch-1 / a752f019d247 | master / 073f6618b9ab | false | 2026-06-19T02:59:55Z | none for state/head/title |
| [#560](https://github.com/bubkoo/html-to-image/pull/560) | open | perf/clear-caches / e3f59317b338 | master / 43a2e2763644 | false | 2026-06-10T03:07:57Z | none for state/head/title |
| [#540](https://github.com/bubkoo/html-to-image/pull/540) | open | dependabot/npm_and_yarn/pbkdf2-3.1.3 / 76805a80a7be | master / 43a2e2763644 | false | 2026-06-10T03:16:53Z | none for state/head/title |
| [#533](https://github.com/bubkoo/html-to-image/pull/533) | open | fix/make-waiting-on-frame-as-an-option / 247475cc4c7f | master / 43a2e2763644 | false | 2026-06-04T17:34:16Z | none for state/head/title |
| [#511](https://github.com/bubkoo/html-to-image/pull/511) | open | feature/disable-font-size-shrink / 1d59779c522c | master / 995728147e44 | false | 2026-06-26T15:19:17Z | none for state/head/title |
| [#504](https://github.com/bubkoo/html-to-image/pull/504) | open | fix/image-decode-issue / c9d4b5f192a1 | master / 995728147e44 | false | 2026-11-20T12:07:49Z | none for state/head/title |
| [#499](https://github.com/bubkoo/html-to-image/pull/499) | open | fix/svg_use / 3caf213e24d9 | master / 995728147e44 | false | 2026-11-02T04:03:21Z | none for state/head/title |
| [#498](https://github.com/bubkoo/html-to-image/pull/498) | open | fix/blank-Image-in-safari / 91bec76c178a | master / 43a2e2763644 | false | 2026-06-05T18:00:30Z | none for state/head/title |
| [#482](https://github.com/bubkoo/html-to-image/pull/482) | open | patch-1 / 712af489c395 | master / 128dc3edfde9 | false | 2026-11-03T09:07:13Z | none for state/head/title |
| [#473](https://github.com/bubkoo/html-to-image/pull/473) | open | master / 0b677d591b33 | master / 128dc3edfde9 | false | 2026-11-19T00:04:11Z | none for state/head/title |
| [#451](https://github.com/bubkoo/html-to-image/pull/451) | open | fix-video-size / ad7092d5e75a | master / 0b9da019fffe | false | 2026-08-27T11:46:32Z | none for state/head/title |
| [#443](https://github.com/bubkoo/html-to-image/pull/443) | open | feature/request_init_generator / 7aee57edb9bf | master / ebb91a63aa2b | false | 2025-11-04T21:17:53Z | none for state/head/title |
| [#442](https://github.com/bubkoo/html-to-image/pull/442) | open | uramacharles / 0fb224261833 | master / 05a2712ca374 | false | 2025-10-17T11:36:39Z | none for state/head/title |
| [#430](https://github.com/bubkoo/html-to-image/pull/430) | open | pref/cache / b26144609a76 | master / d913a2e995a5 | false | 2026-11-20T04:26:47Z | none for state/head/title |
| [#427](https://github.com/bubkoo/html-to-image/pull/427) | open | feature/svg-use-tags-with-external-files / 225e357cd971 | master / d913a2e995a5 | false | 2026-11-02T04:03:18Z | none for state/head/title |
| [#409](https://github.com/bubkoo/html-to-image/pull/409) | open | fix/strached-image / 9673188ab391 | master / 9083028a222c | false | 2026-04-01T12:58:06Z | none for state/head/title |
| [#408](https://github.com/bubkoo/html-to-image/pull/408) | open | scrolling_workaround / a6e135583d82 | master / 9083028a222c | false | 2026-04-03T17:32:50Z | none for state/head/title |
| [#407](https://github.com/bubkoo/html-to-image/pull/407) | open | support_extra_css / 772ca3228b2d | master / 9083028a222c | false | 2023-06-08T17:26:29Z | none for state/head/title |
| [#401](https://github.com/bubkoo/html-to-image/pull/401) | open | fix/image-decode / 676b0db99457 | master / b751cbf212cc | false | 2026-09-29T10:13:19Z | none for state/head/title |
| [#400](https://github.com/bubkoo/html-to-image/pull/400) | open | add-no-cache / f4a9fdd3a64b | master / b751cbf212cc | false | 2025-09-17T09:48:41Z | none for state/head/title |
| [#398](https://github.com/bubkoo/html-to-image/pull/398) | closed | patch-2 / b5bfeb33785d | master / b751cbf212cc | false | 2026-11-14T19:38:55Z | none for state/head/title |
| [#393](https://github.com/bubkoo/html-to-image/pull/393) | open | bug/392-handle-use-href-attribute / 90389a7df1c9 | master / b751cbf212cc | false | 2026-11-02T04:03:24Z | none for state/head/title |
| [#376](https://github.com/bubkoo/html-to-image/pull/376) | open | feature/included-pseudo-elements / f6363fcc11e3 | master / b751cbf212cc | false | 2026-05-09T12:38:56Z | none for state/head/title |

Full SHAs, per-response requestedAt/checkedAt and the current-only fields are retained in summary.json; sanitized original connector payloads are in raw/. No signed URL or token redactions were necessary.
