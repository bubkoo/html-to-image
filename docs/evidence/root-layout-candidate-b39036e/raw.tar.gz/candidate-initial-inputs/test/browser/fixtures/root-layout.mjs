let sequence = 0

export const rootLayoutCases = [
  ['zero-margin', 'margin:0'],
  ['margin-top16', 'margin:16px 0 0'],
  ['margin-left16', 'margin:0 0 0 16px'],
  ['margin-top-left16', 'margin:16px 0 0 16px'],
  ['margin-auto-horizontal', 'margin:0 auto'],
  ['margin-auto-flex', 'margin:auto', 'display:flex'],
  ['margin-left-percentage', 'margin:0 0 0 10%'],
  ['margin-top-percentage', 'margin:10% 0 0'],
  ['collapse-through-parent', 'margin:16px 0 0', 'display:block'],
  [
    'collapsed-child-zero-root-margin',
    'display:block;margin:0',
    'display:block',
    true,
  ],
  [
    'collapsed-child-root-margin16',
    'display:block;margin:16px 0 0',
    'display:block',
    true,
  ],
  ['contained-child-margin-control', 'display:flow-root;margin:0', '', true],
  ['negative-margin-control', 'margin:-8px 0 0 -8px'],
  ['columns', 'display:block;column-count:2', '', true],
  [
    'content-visibility-hidden',
    'display:block;content-visibility:hidden',
    '',
    true,
  ],
  [
    'content-visibility-auto',
    'display:block;content-visibility:auto',
    '',
    true,
  ],
  ['flex-through-contents', 'display:block', 'display:flex', true],
  ['grid-item', 'display:block', 'display:grid', true],
  ['contained-relative-child', 'display:flow-root', '', true],
  ['empty-prefix', 'display:block', 'display:block', true],
  ['fieldset-content', 'display:block;min-inline-size:0', '', true],
  ['important-root', 'margin:16px'],
  ['important-child', 'display:block', '', true],
]

function createScene(entry) {
  const stage = document.createElement('div')
  stage.style.cssText =
    'position:fixed;left:32px;top:32px;width:300px;height:240px;display:flow-root;background:white;z-index:2147483647'
  const parent = document.createElement('div')
  parent.style.cssText =
    'display:flow-root;width:240px;height:160px;margin:0;padding:0;' +
    (entry[2] || '')
  const root = document.createElement(
    entry[0] === 'fieldset-content' ? 'fieldset' : 'div',
  )
  root.id = 'root-layout-' + ++sequence
  root.style.cssText =
    'display:flex;width:160px;height:80px;margin:0;padding:0;border:0;background:red;' +
    entry[1]
  root.innerHTML = entry[3]
    ? '<div style="width:160px;height:40px;margin-top:24px;background:blue"></div><div style="width:160px;height:40px;background:red"></div>'
    : '<div style="flex:none;width:80px;height:80px;background:red"></div><div style="flex:none;width:80px;height:80px;background:blue"></div>'
  if (entry[0] === 'flex-through-contents') {
    const contents = document.createElement('div')
    contents.style.display = 'contents'
    contents.append(root)
    parent.append(contents)
  } else parent.append(root)
  if (entry[0] === 'contained-relative-child') {
    root.firstElementChild.style.position = 'relative'
    root.firstElementChild.style.top = '-24px'
  }
  if (entry[0] === 'empty-prefix') {
    const empty = document.createElement('div')
    empty.style.cssText = 'height:0;min-height:0;margin:0 0 12px'
    root.prepend(empty)
  }
  if (entry[0] === 'important-root' || entry[0] === 'important-child') {
    const style = document.createElement('style')
    style.textContent =
      entry[0] === 'important-root'
        ? `#${root.id}{margin:16px!important}`
        : `#${root.id}>div:first-of-type{margin-top:24px!important}`
    root.prepend(style)
  }
  stage.append(parent)
  document.body.append(stage)
  return { stage, root }
}

function differences(a, b) {
  if (a.width !== b.width || a.height !== b.height)
    throw new Error(
      `Root-layout dimensions ${a.width}x${a.height} != ${b.width}x${b.height}`,
    )
  let count = 0
  for (let i = 0; i < a.data.length; i += 1)
    if (a.data[i] !== b.data[i]) count += 1
  return count
}

export async function checkRootLayout(api, name, readNative) {
  const entry = rootLayoutCases.find((item) => item[0] === name)
  if (!entry) throw new Error('Unknown root-layout case: ' + name)
  const { stage, root } = createScene(entry)
  const before = stage.outerHTML
  try {
    const native = await readNative(root.id)
    const actual = await api.toImageData(root, {
      pixelRatio: 1,
      skipFonts: true,
    })
    return {
      differentChannels: differences(native, actual),
      sourceUnchanged: stage.outerHTML === before,
    }
  } finally {
    stage.remove()
  }
}

export async function checkRootLayoutIntent(api, kind, readNative) {
  const { stage, root } = createScene(['intent', 'margin:16px'])
  const before = stage.outerHTML
  const options = { pixelRatio: 1, skipFonts: true }
  const transform = kind.startsWith('transform-') ? kind.slice(10) : ''
  const margin = kind === 'style-zero' ? '0px' : '16px'
  if (kind === 'style-margin' || kind === 'style-zero')
    options.style = { margin }
  else if (kind === 'clone-margin')
    options.onClone = ({ root: copy }) => {
      copy.style.margin = margin
    }
  else if (kind === 'node-margin')
    options.onCloneNode = (source, copy) => {
      if (source === root) copy.style.margin = margin
    }
  else if (transform) options.style = { transform }
  else if (kind === 'border-dimensions') {
    root.style.border = '2px solid lime'
    root.style.boxSizing = 'border-box'
    options.width = 120
    options.height = 60
    options.style = { margin: '16px', transform: 'translateX(8px)' }
  } else throw new Error('Unknown intent: ' + kind)
  // Independent normal DOM viewport: the external source margin is absent;
  // only the declared user override is applied. White is an opaque RGB oracle.
  const shell = document.createElement('div')
  shell.id = root.id + '-oracle'
  const width = options.width || root.offsetWidth
  const height = options.height || root.offsetHeight
  shell.style.cssText = `position:absolute;left:0;top:0;display:flow-root;width:${width}px;height:${height}px;overflow:hidden;background:white`
  const expected = root.cloneNode(true)
  expected.removeAttribute('id')
  expected.style.margin = transform ? '0' : margin
  if (options.width) expected.style.width = options.width + 'px'
  if (options.height) expected.style.height = options.height + 'px'
  if (transform) expected.style.transform = transform
  if (kind === 'border-dimensions') expected.style.transform = 'translateX(8px)'
  shell.append(expected)
  stage.append(shell)
  const sourceBeforeCapture = root.outerHTML
  try {
    const native = await readNative(shell.id)
    shell.remove()
    const actual = await api.toImageData(root, options)
    const canvas = document.createElement('canvas')
    canvas.width = actual.width
    canvas.height = actual.height
    const context = canvas.getContext('2d')
    context.putImageData(actual, 0, 0)
    context.globalCompositeOperation = 'destination-over'
    context.fillStyle = 'white'
    context.fillRect(0, 0, canvas.width, canvas.height)
    const opaque = context.getImageData(0, 0, canvas.width, canvas.height)
    return {
      differentChannels: differences(native, opaque),
      sourceUnchanged: root.outerHTML === sourceBeforeCapture,
      sourceBeforeSetup: before,
      topLeftAlpha: actual.data[3],
    }
  } finally {
    stage.remove()
  }
}
