from pathlib import Path
import subprocess, hashlib, json, datetime

p = Path(__file__).parent
base = '2f5b369e376fd462034ee8349125fea9724b61b7'
files = ['src/capture.ts', 'src/clone-node.ts']
all_inputs = files + ['src/root-layout.ts', 'test/browser/fixtures/root-layout.mjs', 'test/browser-unit/root-layout.test.ts']
saved = {name: Path(name).read_bytes() for name in all_inputs}
sha = lambda data: hashlib.sha256(data).hexdigest()
record = {'base': base, 'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'candidateInputs': {name: sha(data) for name, data in saved.items()}}
try:
    for name in files:
        Path(name).write_bytes(subprocess.check_output(['git', 'show', base + ':' + name]))
    record['baselineInputs'] = {name: sha(Path(name).read_bytes()) for name in all_inputs}
    with (p / 'baseline-targeted.log').open('wb') as log:
        process = subprocess.Popen(['pnpm', 'exec', 'vitest', 'run', '--config', 'vitest.browser.config.mts', 'test/browser-unit/root-layout.test.ts'], stdout=log, stderr=subprocess.STDOUT)
        record['PID'] = process.pid
        record['exitCode'] = process.wait()
finally:
    for name in files:
        Path(name).write_bytes(saved[name])
    record['restored'] = {name: Path(name).read_bytes() == data for name, data in saved.items()}
    record['completedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (p / 'baseline-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
