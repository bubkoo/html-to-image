import { readNativeSVGFixturePolicy } from './svg-native-styles.mjs'
const ns = 'http://www.w3.org/2000/svg'
export const svgFragmentPaintCases = [
  'attribute-page',
  'attribute-missing',
  'inline-page',
  'inline-missing',
  'inner-page',
  'inner-missing',
]
let policy
async function readPolicy() {
  const base = await readNativeSVGFixturePolicy(),
    svg = document.createElementNS(ns, 'svg')
  if (document.getElementById('svg-fragment-scope-clip'))
    throw new Error('Fragment fixture ID collision')
  svg.setAttribute('width', '20')
  svg.setAttribute('height', '20')
  svg.style.cssText = 'position:fixed;left:0;top:0;opacity:0;z-index:2147483647'
  svg.innerHTML =
    '<defs><clipPath id="svg-fragment-scope-clip"><rect width="12" height="20"/></clipPath></defs>'
  const use = document.createElementNS(ns, 'use')
  use.setAttribute(
    'href',
    '/test/browser/fixtures/svg-fragment-policy.svg#probe',
  )
  svg.append(use)
  document.body.append(svg)
  try {
    const deadline = performance.now() + 5000
    while (performance.now() < deadline) {
      if (
        use.getBBox().width === 20 &&
        document.elementFromPoint(2, 10) === use &&
        document.elementFromPoint(15, 10) !== use
      )
        return {
          ...base,
          fragmentPage: document.elementFromPoint(8, 10) === use,
        }
      // eslint-disable-next-line no-await-in-loop
      await new Promise((resolve) => setTimeout(resolve, 0))
    }
    throw new Error(
      'Independent HTTP fragment-scope clipping controls did not become ready',
    )
  } finally {
    svg.remove()
  }
}
export function getSVGFragmentFixturePolicy() {
  policy ||= readPolicy()
  return policy
}
const difference = (a, b) =>
  a.data.reduce((n, v, i) => n + (v !== b.data[i]), 0)
const png = (image) => {
  const canvas = document.createElement('canvas')
  canvas.width = image.width
  canvas.height = image.height
  canvas.getContext('2d').putImageData(image, 0, 0)
  return canvas.toDataURL().split(',')[1]
}
export async function checkSVGFragmentPaint(api, name, readNative, record) {
  const policy = await getSVGFragmentFixturePolicy(),
    kind = name.split('-')[0],
    present = name.endsWith('-page'),
    paint = kind === 'inner' ? 'fragment-inner-paint' : 'fragment-paint'
  const root = document.createElement('div')
  root.id = 'svg-fragment-' + Math.random().toString(36).slice(2)
  root.style.cssText = 'display:flex;width:60px;height:20px;background:white'
  const definitions = document.createElementNS(ns, 'svg')
  definitions.setAttribute('width', '0')
  definitions.setAttribute('height', '0')
  definitions.style.cssText = 'position:absolute;overflow:hidden'
  if (present)
    definitions.innerHTML =
      '<defs><linearGradient id="' +
      paint +
      '"><stop stop-color="blue"/></linearGradient></defs>'
  const svg = document.createElementNS(ns, 'svg'),
    use = document.createElementNS(ns, 'use')
  svg.setAttribute('width', '20')
  svg.setAttribute('height', '20')
  svg.style.flex = 'none'
  use.setAttribute(
    'href',
    '/test/browser/fixtures/svg-fragment-paint.svg#' + kind,
  )
  use.setAttribute('width', '20')
  use.setAttribute('height', '20')
  svg.append(use)
  root.append(svg)
  ;['blue', 'yellow'].forEach((color) => {
    const control = document.createElement('div')
    control.style.cssText = `flex:none;width:20px;height:20px;background:${color}`
    root.append(control)
  })
  document.body.append(definitions, root)
  const requests = [],
    renderer = api.createRenderer({
      pixelRatio: 1,
      skipFonts: true,
      resources: {
        resolve: (request) => {
          requests.push(request)
        },
      },
    })
  let capture
  try {
    const deadline = performance.now() + 5000
    while (use.getBBox().width !== 20 && performance.now() < deadline)
      // eslint-disable-next-line no-await-in-loop
      await new Promise((resolve) => setTimeout(resolve, 0))
    if (use.getBBox().width !== 20)
      throw new Error('Native fragment-paint positive control did not load')
    await new Promise((resolve) =>
      requestAnimationFrame(() => requestAnimationFrame(resolve)),
    )
    const source = root.outerHTML + definitions.outerHTML,
      before = readNative ? await readNative(root.id) : undefined,
      expected = new ImageData(60, 20)
    const color = policy.fragmentPage
      ? present
        ? [0, 0, 255, 255]
        : [128, 0, 128, 255]
      : [0, 128, 0, 255]
    for (let y = 0; y < 20; y++)
      for (let x = 0; x < 60; x++)
        expected.data.set(
          x < 20
            ? kind === 'attribute' &&
              policy.file &&
              (x === 0 || x === 19 || y === 0 || y === 19)
              ? [0, 0, 255, 255]
              : color
            : x < 40
              ? [0, 0, 255, 255]
              : [255, 255, 0, 255],
          4 * (y * 60 + x),
        )
    capture = await renderer.capture(root)
    const actual = await capture.toImageData(),
      after = readNative ? await readNative(root.id) : undefined
    const sourceUnchanged =
        source === root.outerHTML + definitions.outerHTML &&
        (!before || difference(before, after) === 0),
      nativeDifferentChannels = before ? difference(before, actual) : null,
      referenceDifferentChannels = before ? difference(before, expected) : null,
      actualDifferentChannels = difference(expected, actual)
    await record?.({
      kind: 'svg-fragment-' + name,
      policy,
      sourceUnchanged,
      sourceBefore: source,
      sourceAfter: root.outerHTML + definitions.outerHTML,
      nativeDifferentChannels,
      referenceDifferentChannels,
      actualDifferentChannels,
      requests,
      diagnostics: capture.diagnostics,
      native: before && png(before),
      capture: png(actual),
      authored: png(expected),
    })
    if (!sourceUnchanged)
      throw new Error('Fragment capture changed the source or page definition')
    if (referenceDifferentChannels)
      throw new Error(
        'Independent fragment reference differs from native: ' +
          referenceDifferentChannels,
      )
    if (actualDifferentChannels)
      throw new Error(
        name + ' output differs in ' + actualDifferentChannels + ' channels',
      )
    return { sourceUnchanged, fullPixelMatch: true, requests }
  } finally {
    capture?.dispose()
    renderer.dispose()
    root.remove()
    definitions.remove()
  }
}
