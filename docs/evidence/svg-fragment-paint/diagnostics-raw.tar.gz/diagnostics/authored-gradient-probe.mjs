import {webkit} from 'playwright'
import {writeFile} from 'node:fs/promises'
const browser=await webkit.launch()
try{
 const page=await browser.newPage()
 for(const kind of ['plain','foreign','symbol']){
  const result=await page.evaluate(async kind=>{
   const ns='http://www.w3.org/2000/svg',gradient='<linearGradient id="paint"><stop stop-color="blue"/></linearGradient>'
   const rect='<rect width="20" height="20" fill="url(#paint)"/>',controls='<rect x="20" width="20" height="20" fill="blue"/><rect x="40" width="20" height="20" fill="yellow"/>'
   let body='<defs>'+gradient+'</defs>'+rect+controls
   if(kind==='symbol')body='<defs>'+gradient+'<symbol id="symbol" viewBox="0 0 20 20">'+rect+'</symbol></defs><use href="#symbol" width="20" height="20"/>'+controls
   if(kind==='foreign')body='<foreignObject width="60" height="20"><div xmlns="http://www.w3.org/1999/xhtml" style="display:flex;width:60px;height:20px;background:white"><svg xmlns="'+ns+'" width="20" height="20"><defs>'+gradient+'</defs>'+rect+'</svg><div style="width:20px;height:20px;background:blue"></div><div style="width:20px;height:20px;background:yellow"></div></div></foreignObject>'
   const xml='<svg xmlns="'+ns+'" width="60" height="20" viewBox="0 0 60 20">'+body+'</svg>',image=new Image();image.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(xml);await image.decode();const canvas=document.createElement('canvas');canvas.width=60;canvas.height=20;canvas.getContext('2d').drawImage(image,0,0);return{xml,png:canvas.toDataURL().split(',')[1]}
  },kind)
  await writeFile('output/playwright/svg-fragment-paint/authored-'+kind+'.svg',result.xml)
  await writeFile('output/playwright/svg-fragment-paint/authored-'+kind+'.png',Buffer.from(result.png,'base64'))
 }
}finally{await browser.close()}
