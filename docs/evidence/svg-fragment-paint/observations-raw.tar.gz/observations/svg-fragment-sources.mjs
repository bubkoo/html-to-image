import {createServer} from 'node:http'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {resolve} from 'node:path'
import {chromium,firefox,webkit} from 'playwright'
const out=resolve('output/playwright/svg-fragment-sources');await mkdir(out,{recursive:true})
const trace=[]
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname;trace.push(path)
 if(path.endsWith('/page.html')){res.setHeader('Content-Type','text/html');res.end('<!doctype html><style>body{margin:0}</style>');return}
 if(path.endsWith('/sprite.svg')){
  const imported='data:text/css,'+encodeURIComponent('.viaImport{fill:url("sprite.svg#paint") purple!important}')
  const color=path.includes('/assets/')?'green':'red'
  const ids=['attr','inline','file','import','absolute','fragment','inner','control']
  const nodes=ids.map(id=>`<symbol id="${id}" viewBox="0 0 20 20">${id==='inner'?'<defs><linearGradient id="inner-paint"><stop stop-color="green"/></linearGradient></defs>':''}<rect width="20" height="20" ${id==='attr'?'fill="url(sprite.svg#paint) purple"':id==='inline'?'style="fill:url(sprite.svg#paint) purple"':id==='file'?'class="viaFile" fill="purple"':id==='import'?'class="viaImport" fill="purple"':id==='inner'?'fill="url(#inner-paint) purple"':id==='fragment'?'fill="url(#paint) purple"':id==='absolute'?`fill="url(http://127.0.0.1:4495${path}#paint) purple"`:'fill="green"'}/></symbol>`).join('')
  res.setHeader('Content-Type','image/svg+xml');res.setHeader('Cache-Control','no-store');res.end(`<svg xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="paint"><stop stop-color="${color}"/></linearGradient></defs><style>@import url('${imported}');.viaFile{fill:url(sprite.svg#paint) purple!important}</style>${nodes}</svg>`);return
 }
 if(path.startsWith('/es/')){try{res.setHeader('Content-Type','text/javascript');res.end(await readFile(resolve('.'+path)));return}catch{}}
 res.writeHead(404).end()
})
await new Promise(r=>server.listen(4495,'127.0.0.1',r))
const results={sourceHead:'bafedeb9720a89b3c6fad0c98f70b51e2f7bdab1',meaning:'Observation only; no runtime fix',engines:{}}
try{
 for(const [name,engine] of Object.entries({chromium,firefox,webkit})){
  const browser=await engine.launch()
  try{
   const page=await browser.newPage({deviceScaleFactor:1});const prefix='/probe/'+crypto.randomUUID()
   await page.goto('http://127.0.0.1:4495'+prefix+'/page.html');const start=trace.length
   await page.evaluate(prefix=>{
    const root=document.createElement('div');root.id='source';root.style.cssText='display:flex;width:180px;height:20px;background:white'
    for(const id of ['attr','inline','file','import','absolute','fragment','inner','control']){
     const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('width','20');svg.setAttribute('height','20');svg.style.flex='none';const use=document.createElementNS(svg.namespaceURI,'use');use.setAttribute('href',prefix+'/assets/sprite.svg#'+id);use.setAttribute('width','20');use.setAttribute('height','20');svg.append(use);root.append(svg)
    }
    const yellow=document.createElement('div');yellow.style.cssText='width:20px;height:20px;background:yellow;flex:none';root.append(yellow);document.body.append(root);const defs=document.createElementNS('http://www.w3.org/2000/svg','svg');defs.setAttribute('width','0');defs.setAttribute('height','0');defs.innerHTML='<defs><linearGradient id="paint"><stop stop-color="blue"/></linearGradient></defs>';document.body.append(defs)
   },prefix)
   await page.waitForFunction(()=>Array.from(document.querySelectorAll('use')).every(x=>x.getBBox().width===20))
   await page.waitForLoadState('networkidle');await page.locator('#source').screenshot({path:resolve(out,name+'-before.png'),scale:'css'})
   const captureStart=trace.length
   const result=await page.evaluate(async()=>{
    const {createRenderer}=await import('/es/index.js');const root=document.getElementById('source'),markup=root.outerHTML;const requests=[];const renderer=createRenderer({pixelRatio:1,skipFonts:true,resources:{resolve:({url,kind})=>{requests.push({url,kind})}}});let snapshot
    try{snapshot=await renderer.capture(root);const data=await snapshot.toImageData();return{sourceUnchanged:markup===root.outerHTML,requests,pixels:[10,30,50,70,90,110,130,150,170].map(x=>Array.from(data.data.slice(4*(10*data.width+x),4*(10*data.width+x)+4))),png:await snapshot.toPng(),diagnostics:snapshot.diagnostics}}finally{snapshot?.dispose();renderer.dispose()}
   })
   await writeFile(resolve(out,name+'-capture.png'),Buffer.from(result.png.split(',')[1],'base64'));delete result.png
   await page.locator('#source').screenshot({path:resolve(out,name+'-after.png'),scale:'css'})
   results.engines[name]={...result,version:browser.version(),prefix,columns:['attribute','inline','file-css','data-import-css','absolute','fragment','inner-fragment','flat','yellow'],nativeRequests:trace.slice(start,captureStart),captureRequests:trace.slice(captureStart)}
  }finally{await browser.close()}
 }
}finally{await new Promise(r=>server.close(r))}
await writeFile(resolve(out,'observation.json'),JSON.stringify(results,null,2)+'\n')
console.log('Owned relative-source observations saved')
