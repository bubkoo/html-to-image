import {createServer} from 'node:http'
import {writeFile} from 'node:fs/promises'
import {chromium,firefox,webkit} from 'playwright'
const server=createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html>')});await new Promise(r=>server.listen(4494,'127.0.0.1',r));const result={}
try{for(const [name,engine] of Object.entries({chromium,firefox,webkit})){const browser=await engine.launch();try{result[name]={};for(const variant of ['visible','offscreen','transparent','rewrite']){const page=await browser.newPage();try{await page.goto('http://127.0.0.1:4494/probe/page.html');result[name][variant]=await page.evaluate(async variant=>{
   const frame=document.createElement('iframe');frame.id='owned-frame';frame.setAttribute('sandbox','allow-same-origin');frame.style.cssText=variant==='visible'?'width:100px;height:20px;border:0;display:block':`position:fixed;left:${variant==='offscreen'?-99999:0}px;top:0;width:100px;height:20px;border:0;opacity:0;pointer-events:none`
   const ready=new Promise(r=>frame.onload=r)
   const html=`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none';style-src 'unsafe-inline';img-src blob:;base-uri 'none'"><style>body{margin:0;width:100px;height:20px;background:white}</style><body></body>`
   frame.srcdoc=html;document.body.append(frame);await ready
   const d=frame.contentDocument;if(variant==='rewrite'){d.open();d.write(html);d.close()}
   const ns='http://www.w3.org/2000/svg',svg=d.createElementNS(ns,'svg');svg.setAttribute('width','100');svg.setAttribute('height','20')
   svg.innerHTML='<defs><clipPath id="owned-clip"><rect width="12" height="20"/></clipPath></defs>'
   const urls=[],uses=[]
   for(const [index,kind] of ['fragment','relative','absolute','missing','flat'].entries()){
    const value={fragment:'#owned-clip',relative:'page.html#owned-clip',absolute:location.href+'#owned-clip',missing:'absent.html#owned-clip'}[kind]
    const clip=value?`clip-path="url(${value})"`:''
    const xml=`<svg xmlns="${ns}"><defs><clipPath id="owned-clip"><rect width="6" height="20"/></clipPath></defs><g id="probe"><rect width="20" height="20" fill="green" ${clip}/></g></svg>`
    const url=URL.createObjectURL(new Blob([xml],{type:'image/svg+xml'}));urls.push(url)
    const use=d.createElementNS(ns,'use');use.id=kind;use.setAttribute('href',url+'#probe');use.setAttribute('x',String(index*20));svg.append(use);uses.push(use)
   }
   d.body.append(svg)
   const deadline=performance.now()+5000
   while(uses.some(x=>x.getBBox().width!==20)&&performance.now()<deadline)await new Promise(r=>setTimeout(r,0))
   await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))
   const hits=uses.map((use,i)=>({id:use.id,bbox:use.getBBox().width,points:[2,8,15].map(x=>d.elementFromPoint(i*20+x,10)?.id||d.elementFromPoint(i*20+x,10)?.localName)}))
   window.ownedProbeURLs=urls
   const result={url:d.URL,base:d.baseURI,hits};urls.forEach(u=>URL.revokeObjectURL(u));frame.remove();return result},variant)}finally{await page.close()}}}finally{await browser.close()}}}finally{await new Promise(r=>server.close(r))}
await writeFile('output/playwright/svg-redirect-file-css/clip-private-context.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
