import { type SVGImportPolicy } from './svg-style-imports.js';
export interface SVGStylePolicy extends SVGImportPolicy {
    file: boolean;
    page: boolean;
    whole: boolean;
    fragment?: 'file' | 'page';
}
export declare function detectSVGFragmentPolicy(document: Document, check: () => void): Promise<'file' | 'page'>;
export declare function snapshotSVGPageStyles(document: Document, report: (url: string, error: unknown) => void): () => string;
export declare function svgStyleContextKey(host: Element): string;
export declare function detectSVGStylePolicy(document: Document, check: () => void, reportImportError?: (error: unknown) => void, reportFragmentError?: (error: unknown) => void): Promise<SVGStylePolicy>;
export declare function createSVGStyleEnvironment(source: Document, signal?: AbortSignal): {
    dispose: () => void;
    measurePolicy(check: () => void, reportImportError?: (error: unknown) => void, reportFragmentError?: (error: unknown) => void): Promise<SVGStylePolicy>;
    getDocument(trustedProbe?: boolean): Promise<Document>;
};
export declare function freezeSVGFragmentStyles(original: Element, copy: Element, styleRoot: Document | DocumentFragment | Element, host: Element, document: Document, policy: SVGStylePolicy, resolveURLs: (text: string, style: Element) => string, pageStyles: () => string, prepareFonts: (families: readonly string[]) => Promise<string>, reportFontError: (error: unknown) => void, prepareFileStyle: (text: string) => Promise<string>): Promise<void>;
