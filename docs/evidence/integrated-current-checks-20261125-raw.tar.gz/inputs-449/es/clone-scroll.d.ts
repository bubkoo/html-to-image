import type { Options } from './types.js';
export declare function cloneScrollState<T extends HTMLElement>(nativeNode: T, clonedNode: T, options: Options, scrollLeft?: T["scrollLeft"], scrollTop?: T["scrollTop"]): void;
