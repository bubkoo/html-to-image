import type { Options } from './types.js';
export declare function getWebFontCSS<T extends HTMLElement>(node: T, options: Options, styleSource?: Element): Promise<string>;
export declare function getSVGStyleFontCSS(families: readonly string[], loadedFamilies: readonly string[], source: Element, options: Options): Promise<string>;
export declare function embedWebFonts<T extends HTMLElement>(clonedNode: T, options: Options, styleSource?: Element): Promise<void>;
