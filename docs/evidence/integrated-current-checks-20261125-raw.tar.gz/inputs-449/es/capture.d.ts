import type { Capture, CaptureNode, Options } from './types.js';
import { CaptureTask } from './task.js';
export declare function createCapture(node: CaptureNode, options: Options, task: CaptureTask, release?: () => void): Promise<Capture>;
