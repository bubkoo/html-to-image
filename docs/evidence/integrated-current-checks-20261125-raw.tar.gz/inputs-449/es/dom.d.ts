export declare function readDOMProperty<T, K extends keyof T>(target: T, key: K): T[K];
export declare function readDOMMethod<K extends PropertyKey, T extends Record<K, (...args: never[]) => unknown>>(target: T, key: K): T[K];
export declare function readOptionalDOMProperty<T extends object, K extends keyof T>(target: T, key: K): T[K];
export declare function readOptionalDOMProperty<T extends object, K extends keyof T>(target: T | null | undefined, key: K): T[K] | undefined;
export declare function readOptionalDOMMethod<K extends PropertyKey, T extends Record<K, (...args: never[]) => unknown>>(target: T | null | undefined, key: K): T[K] | undefined;
export declare function hasDOMProperty<T extends object, K extends PropertyKey>(key: K, target: T): target is T & Record<K, unknown>;
export declare function writeDOMProperty<T extends object, K extends keyof T, V extends T[K]>(target: T, key: K, value: V): V;
