import { Options } from './types.js';
export declare function embedImages<T extends HTMLElement>(clonedNode: T, options: Options): Promise<void>;
export declare function embedClonedStyles(css: string, document: Document, options: Options): Promise<string>;
