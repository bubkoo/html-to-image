import type { Options } from './types.js';
export declare function ensureSVGSymbols<T extends HTMLElement>(source: T, clone: T, options: Options): Promise<T>;
export declare function cloneNode<T extends HTMLElement>(node: T, options: Options, isRoot?: boolean, resolveSymbols?: boolean, targetDocument?: Document): Promise<T | null>;
