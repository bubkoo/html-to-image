import type { Options } from './types.js';
export declare function freezeScrollbarPresence(source: HTMLElement, clone: HTMLElement, sourceStyle?: CSSStyleDeclaration): void;
export declare function cloneScrollbarStyles(source: HTMLElement, clone: HTMLElement, options: Options, selected?: readonly string[]): Promise<void>;
export declare function beginScrollbarStyleScope(options: Options): () => void;
