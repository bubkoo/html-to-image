import type { CaptureTask } from './task.js';
export declare function cloneNativeScroll(original: HTMLElement, clone: HTMLElement, task: CaptureTask, x: number, y: number): boolean;
