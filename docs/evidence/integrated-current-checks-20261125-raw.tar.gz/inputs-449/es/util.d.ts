import type { Options } from './types.js';
export declare function resolveUrl(url: string, baseUrl: string | null): string;
export declare const uuid: () => string;
export declare function delay<T>(ms: number): (args: T) => Promise<T>;
export declare function toArray<T>(arrayLike: any): T[];
export declare function getStyleProperties(style?: CSSStyleDeclaration, selected?: readonly string[]): readonly string[];
export declare function getImageSize(targetNode: HTMLElement, options?: Options): {
    width: number;
    height: number;
};
export declare function getPixelRatio(): number;
export declare function checkCanvasDimensions(canvas: HTMLCanvasElement): void;
export declare function canvasToBlob(canvas: HTMLCanvasElement, options?: Options): Promise<Blob | null>;
export declare function createImage(url: string, options: Options, image?: HTMLImageElement): Promise<HTMLImageElement>;
export declare function svgToDataURL(svg: SVGElement): Promise<string>;
export declare function nodeToDataURL(node: HTMLElement, width: number, height: number, ownerDocument?: Document, clonedStyles?: string): Promise<string>;
export declare const isInstanceOfElement: <T extends typeof Element | typeof HTMLElement | typeof SVGImageElement>(node: Element | HTMLElement | SVGImageElement, instance: T) => node is T["prototype"];
