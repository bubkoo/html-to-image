export declare function resolveNestedSelector(selector: string, parent: string): string;
