import type { Options, Renderer } from './types.js';
export declare function createRenderer(defaults?: Options): Renderer;
