import type { Options, ResourceKind } from './types.js';
export declare function parseURLs(cssText: string): string[];
export declare function embed(cssText: string, resourceURL: string, baseURL: string | null, options: Options, getContentFromUrl?: (url: string) => Promise<string>, kind?: ResourceKind): Promise<string>;
export declare function shouldEmbed(url: string): boolean;
export declare function embedResources(cssText: string, baseUrl: string | null, options: Options, kind?: ResourceKind): Promise<string>;
