export type SVGLayerPolicy = 'none' | 'flat' | 'ordered';
export interface SVGImportPolicy {
    dataImports: boolean;
    fileLayers: SVGLayerPolicy;
    importLayers: SVGLayerPolicy;
}
export declare function rewriteSVGStyleURLs(text: string, resolve: (value: string) => string | undefined): string;
export declare function decodeCSS(blob: Blob, metadata: string, environment: string): Promise<{
    text: string;
    encoding: string;
}>;
export declare function prepareSVGFileStyle(text: string, document: Document, policy: SVGImportPolicy, load: (url: string) => Promise<Blob>, check: () => Promise<void>, report: (url: string, error: unknown) => void): Promise<string>;
