import type { Options } from './types.js';
export declare function applyStyle<T extends HTMLElement>(node: T, options: Options): T;
