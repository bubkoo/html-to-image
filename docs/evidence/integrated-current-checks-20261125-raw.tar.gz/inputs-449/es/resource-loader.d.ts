import type { CaptureDiagnostic, ExtensionContext, Options, ResourceKind } from './types.js';
export declare class ResourceResolverError extends Error {
    readonly cause: unknown;
    constructor(cause: unknown);
}
export declare function blobToDataURL(blob: Blob): Promise<string>;
export declare class ResourceLoader {
    private readonly options;
    private readonly context;
    readonly warn: (diagnostic: CaptureDiagnostic) => void;
    private pending;
    private responseURLs;
    private customResponses;
    constructor(options: Options, context: ExtensionContext, warn?: (diagnostic: CaptureDiagnostic) => void);
    private key;
    responseURL(url: string, kind: ResourceKind, contentType?: string): string;
    isCustomResponse(url: string, kind: ResourceKind, contentType?: string): boolean;
    load(url: string, kind: ResourceKind, contentType?: string): Promise<Blob>;
    private fetch;
    clear(): void;
}
