import type { Options } from './types.js';
export declare const svgNamespace = "http://www.w3.org/2000/svg";
export declare function getSVGReference(node: Element): string | null;
export declare function setSVGReference(node: Element, value: string): void;
export declare function embedSVGReferences(source: Element, root: Element, options: Options, cloneLocal: (node: Element) => Promise<Element | null>): Promise<void>;
