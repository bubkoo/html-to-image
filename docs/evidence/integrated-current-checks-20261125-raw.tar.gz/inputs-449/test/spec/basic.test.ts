
import * as htmlToImage from '../../src'
import { delay } from '../../src/util'
import {
  clean,
  bootstrap,
  check,
  renderAndCheck,
  assertTextRendered,
} from './helper'
import './setup'

afterAll(() => {
  clean()
})

describe('basic usage', () => {
  it('should render to svg', async () => {
    await bootstrap('small/node.html', 'small/style.css', 'small/image')
      .then(htmlToImage.toSvg)
      .then(check)
  })

  it('should render to png', async () => {
    await bootstrap('small/node.html', 'small/style.css', 'small/image')
      .then(htmlToImage.toPng)
      .then(check)
  })

  it('should render to blob', async () => {
    await bootstrap('small/node.html', 'small/style.css', 'small/image')
      .then(htmlToImage.toBlob)
      .then((blob) => URL.createObjectURL(blob!))
      .then(check)
  })

  it('should render to jpeg', async () => {
    await bootstrap('small/node.html', 'small/style.css', 'small/image-jpeg')
      .then((node) => htmlToImage.toJpeg(node))
      .then(check)
  })

  it('should use quality parameter when rendering to jpeg', async () => {
    await bootstrap(
      'small/node.html',
      'small/style.css',
      'small/image-jpeg-low',
    )
      .then((node) => htmlToImage.toJpeg(node, { quality: 0.5 }))
      .then(check)
  })

  it('should convert an element to an array of pixels', async () => {
    await bootstrap('pixeldata/node.html', 'pixeldata/style.css')
      .then((node) =>
        htmlToImage.toPixelData(node).then((pixels) => ({ node, pixels })),
      )
      .then(({ node, pixels }) => {
        for (let y = 0; y < node.scrollHeight; y += 1) {
          for (let x = 0; x < node.scrollWidth; x += 1) {
            const rgba = [0, 0, 0, 0]

            if (y < 10) {
              rgba[0] = 255
            } else if (y < 20) {
              rgba[1] = 255
            } else {
              rgba[2] = 255
            }

            if (x < 10) {
              rgba[3] = 255
            } else if (x < 20) {
              rgba[3] = 0.4 * 255
            } else {
              rgba[3] = 0.2 * 255
            }

            const offset = 4 * y * node.scrollHeight + 4 * x

            const target: number[] = []
            pixels.slice(offset, offset + 4).forEach((i) => target.push(i))
            expect(target).toEqual(rgba)
          }
        }
      })
  })

  it('should handle border', async () => {
    await bootstrap(
      'border/node.html',
      'border/style.css',
      'border/image',
    ).then(renderAndCheck)
  })

  it('should render bigger node', async () => {
    await bootstrap('bigger/node.html', 'bigger/style.css', 'bigger/image')
      .then((parent) => {
        const child = parent.querySelector('.dom-child-node') as HTMLDivElement
        for (let i = 0; i < 10; i += 1) {
          parent.appendChild(child.cloneNode(true))
        }
        return parent
      })
      .then(renderAndCheck)
  })

  it('should handle "#" in colors and attributes', async () => {
    await bootstrap('hash/node.html', 'hash/style.css', 'small/image').then(
      renderAndCheck,
    )
  })

  it('should render whole node when its scrolled', async () => {
    await bootstrap('scroll/node.html', 'scroll/style.css', 'scroll/image')
      .then((node) => node.querySelector('#scrolled') as HTMLDivElement)
      .then(renderAndCheck)
  })

  it('should render with external stylesheet', async () => {
    await bootstrap('sheet/node.html', 'sheet/style.css', 'sheet/image')
      .then(delay(1000))
      .then(renderAndCheck)
  })

  it('should render text nodes', async () => {
    await bootstrap('text/node.html', 'text/style.css').then(
      assertTextRendered(['SOME TEXT', 'SOME MORE TEXT']),
    )
  })

  it('should preserve content of ::before and ::after pseudo elements', async () => {
    await bootstrap('pseudo/node.html', 'pseudo/style.css').then(
      assertTextRendered([
        'JUSTBEFORE',
        'BOTHBEFORE',
        'JUSTAFTER',
        'BOTHAFTER',
      ]),
    )
  })

  it('should render web fonts', async () => {
    await bootstrap('fonts/node.html', 'fonts/style.css')
      .then(delay(1000))
      .then(assertTextRendered(['apper']))
  })

  it('should render images', async () => {
    await bootstrap('images/node.html', 'images/style.css')
      .then(delay(500))
      .then(assertTextRendered(['PNG', 'JPG']))
  })

  it('should render webp images', async () => {
    await bootstrap('webp/node.html', 'webp/style.css')
      .then(delay(500))
      .then(assertTextRendered(['PNG']))
  })

  it('should render background images', async () => {
    await bootstrap('css-bg/node.html', 'css-bg/style.css').then(
      assertTextRendered(['JPG']),
    )
  })

  it('should render user input from <input>', async () => {
    const text = 'USER INPUT'
    await bootstrap('input/node.html', 'input/style.css')
      .then(() => {
        const input = document.getElementById('input') as HTMLInputElement
        input.value = text
      })
      .then(assertTextRendered([text]) as any)
  })

  it('should render user input from <textarea>', async () => {
    const text = `USER\nINPUT`

    await bootstrap('textarea/node.html', 'textarea/style.css')
      .then(() => {
        const input = document.getElementById('input') as HTMLInputElement
        input.value = text
      })
      .then(assertTextRendered([text]) as any)
  })

  it('should render canvas pixels inside a parent node', async () => {
    const node = await bootstrap('canvas/node.html', 'canvas/style.css')
    const canvas = node.querySelector('#content') as HTMLCanvasElement
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = 'red'
    ctx.fillRect(0, 0, 150, 150)
    ctx.fillStyle = 'blue'
    ctx.fillRect(150, 0, 150, 150)

    const image = await htmlToImage.toImageData(node, {
      pixelRatio: 1,
      skipFonts: true,
    })
    const pixel = (x: number) =>
      Array.from(
        image.data.slice(
          4 * (50 * image.width + x),
          4 * (50 * image.width + x) + 4,
        ),
      )
    expect([image.width, image.height]).toEqual([200, 100])
    expect(pixel(50)).toEqual([255, 0, 0, 255])
    expect(pixel(150)).toEqual([0, 0, 255, 255])
  })
})
