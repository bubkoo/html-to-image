from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,subprocess,re,zipfile,io,shutil
ROOT=Path.cwd();OUT=ROOT/'output/playwright/integrated-current-checks-20261125';RAW=OUT/'raw';BASE=ROOT/'output/playwright/native-scroll-followup'
RUNS=['integrated-cancellation-security-default','integrated-gc-runner-default','integrated-gc-runner-source','integrated-gc-runner-packages']
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def utc(stamp):return datetime.fromtimestamp(stamp,timezone.utc).isoformat()
origins=[]
def copy(src,dst,scope):
 src=ROOT/src if not src.is_absolute() else src
 assert src.is_file() and not src.is_symlink()
 data=src.read_bytes();target=RAW/dst;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 origins.append({'path':str(dst),'origin':str(src.relative_to(ROOT)),'originMTimeUTC':utc(src.stat().st_mtime),'bytes':len(data),'sha256':sha(data),'scope':scope})
RAW.mkdir(exist_ok=False)
for name in RUNS:
 d=BASE/name
 for f in sorted(d.rglob('*')):
  if f.is_file():copy(f,Path('runs')/name/f.relative_to(d),'Run-owned frozen source/log/receipt/input ledger; copied without modification.')
new=load(BASE/RUNS[3]/'inputs-after.json');old=load(BASE/RUNS[0]/'inputs-after.json');assert len(new)==449 and len(old)==447
for path,want in new.items():
 src=ROOT/path;assert sha(src.read_bytes())==want,path;copy(src,Path('inputs-449')/path,'Complete 449-entry frozen input ledger byte copy, checked against exact recorded SHA256.')
oldconfig=subprocess.check_output(['git','show','7bb46a4b67f355cc5b3d5efacf55bf4356324d57:vitest.browser.config.mts'])
assert sha(oldconfig)==old['vitest.browser.config.mts'];(RAW/'boundary').mkdir();(RAW/'boundary/vitest.browser.config.before.mts').write_bytes(oldconfig)
static=['integrated-fixed-lint-install.log','integrated-cancellation-security-lint.log','integrated-cancellation-security-build.log','integrated-cancellation-security-types.log','integrated-cancellation-security-consumers.log','integrated-gc-runner-lint.log','integrated-gc-runner-types.log']
for name in static:copy(BASE/name,Path('static')/name,'Existing static validation log. Standalone files do not encode process exit status.')
# Select only four exact log-linked names, not the historical screenshot directory.
screens=[('resource-resolver-cancellation.test.ts/a-disposed-SVG-environment-releases-its-document-with-probed-false.png',RUNS[0]),('svg-style-source-lifetime.test.ts/disposed-SVG-owner-releases-source-with-font-false-and-opened-false.png',RUNS[0]),('native-scroll.test.ts/native-scroll-padding-shadow-matches-source-pixels.png',RUNS[2]),('native-scroll.test.ts/native-scroll-visible-text-preserves-native-glyph-placement.png',RUNS[2])]
selected=[]
for path,name in screens:
 f=ROOT/'.vitest/attachments/failure-screenshots'/path;assert str(Path('.vitest/attachments/failure-screenshots')/path) in (BASE/name/'run.log').read_text()
 assert f.stat().st_mtime<=(BASE/name/'run.log').stat().st_mtime
 destination=Path('screenshots')/name/path;copy(f,destination,'Exact log-listed failure filename, matched by local mtime to this run; not assigned to earlier runs sharing its name.')
 selected.append({'path':str(destination),'run':name,'originMTimeUTC':utc(f.stat().st_mtime),'provenance':'Log-listed exact path plus preserved local timestamp; no original run-specific image digest was recorded. Native screenshots were last written during source run and are not attributed to either default run.'})
for kind in ['visible-text','padding-shadow']:
 for f in sorted((ROOT/'.vitest/attachments/scrollbar-box').glob('webkit-native-'+kind+'*')):
  assert 1795555850 <= f.stat().st_mtime<=1795555866
  copy(f,Path('native-source-diagnostics')/f.name,'Native scroll JSON/PNG last written in integrated-gc-runner-source local time window; source run only.')
traces=[]
for fmt in ['ESM','UMD']:
 d=ROOT/f'test-results/package-built-{fmt}-native-scroll-matches-actual-source-pixels-webkit'
 for name in ['trace.zip','error-context.md']:copy(d/name,Path('package-failures')/fmt/name,'Exact package failure path referenced by integrated package run log; trace header title/epoch also checked.')
 zbytes=(d/'trace.zip').read_bytes();members=[];headers=[];report=None
 with zipfile.ZipFile(io.BytesIO(zbytes)) as z:
  assert z.testzip() is None
  assert len({i.filename for i in z.infolist()})==len(z.infolist())
  for item in z.infolist():
   p=PurePosixPath(item.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in item.filename and ((item.external_attr>>16)&0o170000)!=0o120000
   data=z.read(item);members.append({'path':item.filename,'bytes':len(data),'sha256':sha(data)})
   if item.filename.endswith('.trace'):
    header=json.loads(data.decode().splitlines()[0]);headers.append({'member':item.filename,'header':header})
    if 'title' in header:assert f'built {fmt}: native scroll matches actual source pixels' in header['title']
   if item.filename.startswith('attachments/') and data.startswith(b'{'):
    value=json.loads(data)
    if value.get('group')=='scroll':report=value
 assert report and report['format']==fmt and [x['kind'] for x in report['failed']]==['visible-text','fractional','padding-shadow']
 write(RAW/Path('package-failures')/fmt/'native-scroll-report.json',report)
 traces.append({'format':fmt,'zipPath':str(Path('package-failures')/fmt/'trace.zip'),'zipSHA256':sha(zbytes),'zipCRCVerified':True,'members':members,'contextHeaders':headers,'nativeReport':report,'originMTimeUTC':utc((d/'trace.zip').stat().st_mtime)})
write(RAW/'trace-verification.json',traces)
copy(ROOT/'test-results/.last-run.json',Path('package-failures/.last-run.json'),'Latest package runner status file; subordinate to full package run log.')
write(RAW/'origins.json',{'collectedAt':datetime.now(timezone.utc).isoformat(),'files':origins,'selectedScreenshots':selected,'phonePrivatePathsEnumeratedOrCopied':False,'policy':'Explicit allowlists only: four run directories, seven static logs, 449 frozen-ledger paths, exact four screenshot filenames, exact two source diagnostic prefixes, exact two package failures and latest-run status. No phone/private folder glob or traversal.'})
write(RAW/'boundary/input-diff.json',{'before':{'run':RUNS[0],'count':len(old)},'after':{'run':RUNS[1],'count':len(new)},'added':sorted(set(new)-set(old)),'removed':sorted(set(old)-set(new)),'changed':sorted(k for k in new.keys()&old.keys() if new[k]!=old[k]),'runtimeSourceAndGeneratedOutputHashesUnchanged':all(old[k]==new[k] for k in old if k.startswith(('src/','es/','lib/','dist/'))),'oldConfigGitObjectMatchesLedger':True,'strictCausalAttribution':False})
print(json.dumps({'rawFiles':sum(x.is_file() for x in RAW.rglob('*')),'rawBytes':sum(x.stat().st_size for x in RAW.rglob('*') if x.is_file()),'screenNames':selected,'449InputCopiesVerified':True},indent=2))
