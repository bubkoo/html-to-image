import fs from 'node:fs/promises'
import http from 'node:http'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import assert from 'node:assert/strict'
import {chromium,firefox,webkit} from 'playwright'
const directory=new URL('./',import.meta.url),root=process.cwd()
const originalDirectory=new URL('../blob-preview-offline-integrated-20261125/',directory)
const frozen=await fs.readFile(new URL('blob-preview-offline.html',originalDirectory))
const manifest=JSON.parse(await fs.readFile(new URL('manifest.json',originalDirectory),'utf8'))
const sha=b=>createHash('sha256').update(b).digest('hex')
assert.equal(frozen.length,126151);assert.equal(sha(frozen),manifest.page.sha256)
const ledger=JSON.parse(await fs.readFile(root+'/output/playwright/native-scroll-followup/integrated-gc-runner-packages/inputs-after.json','utf8'))
async function inputs(){const result={};for(const path of Object.keys(ledger))result[path]=sha(await fs.readFile(root+'/'+path));return result}
const before=await inputs();await fs.writeFile(new URL('inputs-before.json',directory),JSON.stringify(before,null,2))
assert.deepEqual(before,ledger)
const remoteSmall='https://raw.githubusercontent.com/bubkoo/html-to-image/f8d1c4b1abb7decf143fdf418ad08fa8b22bd309/package.json'
const remoteExpected=sha(execFileSync('git',['show','f8d1c4b1abb7decf143fdf418ad08fa8b22bd309:package.json']))
const serverRequests=[]
const server=http.createServer((req,res)=>{
 serverRequests.push({atUTC:new Date().toISOString(),path:req.url,method:req.method,origin:req.headers.origin??null,fetchMode:req.headers['sec-fetch-mode']??null})
 const headers={'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'}
 if(req.url==='/fixture')headers['Access-Control-Allow-Origin']='*'
 if(req.url!=='/fixture'&&req.url!=='/deny'){res.writeHead(404,headers);res.end();return}
 res.writeHead(200,headers);res.end(frozen)
})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const address=server.address(),localURL=`http://127.0.0.1:${address.port}/fixture`,denyURL=`http://127.0.0.1:${address.port}/deny`
const bootstrap=url=>`data:text/html,<script>fetch('${url}').then(r=>r.text()).then(t=>{document.open();document.write(t);document.close()})</script>`
await fs.writeFile(new URL('bootstrap-local.txt',directory),bootstrap(localURL)+'\n')
await fs.writeFile(new URL('bootstrap-immutable-template.txt',directory),bootstrap('https://raw.githubusercontent.com/bubkoo/html-to-image/COMMIT_SHA/docs/evidence/ios-offline.html')+'\n')
const report={startedUTC:new Date().toISOString(),scope:'Independent desktop bootstrap proof; no phone or network settings; default launch options. Local server uses text/plain+CORS to emulate raw GitHub response; actual immutable raw GitHub small file separately tested from data opaque origin.',frozen:{bytes:frozen.length,sha256:sha(frozen),umd:manifest.umd.sha256,sourceFingerprint:manifest.sourceFingerprint},server:{address:'127.0.0.1',port:address.port},cases:[],lifecycles:[]}
try{
 for(const [engine,type]of Object.entries({chromium,firefox,webkit})){
  const life={engine,launchStartedUTC:new Date().toISOString(),closed:false};report.lifecycles.push(life)
  const browser=await type.launch({headless:true});life.launchedUTC=new Date().toISOString();browser.on('disconnected',()=>life.disconnectedUTC=new Date().toISOString())
  let preflightContext,context
  const row={engine,version:browser.version(),passed:false,preflight:{},requests:[],responseRecords:[],errors:[],console:[]};report.cases.push(row)
  try{
   preflightContext=await browser.newContext({viewport:{width:414,height:896},deviceScaleFactor:1});const preflight=await preflightContext.newPage()
   const pending=[];preflight.on('response',response=>{if(response.url()===remoteSmall)pending.push((async()=>row.preflight.remoteResponse={status:response.status(),headers:await response.allHeaders()})())})
   await preflight.goto('data:text/html,<title>Opaque-origin fetch control</title>')
   row.preflight.remote=await preflight.evaluate(async url=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(new DOMException('Remote fetch diagnostic exceeded 15000ms','TimeoutError')),15000);try{const response=await fetch(url,{signal:controller.signal});const text=await response.text();return{origin:location.origin,secureContext:isSecureContext,ok:response.ok,status:response.status,type:response.type,text}}catch(error){return{origin:location.origin,secureContext:isSecureContext,error:String(error),diagnosticBudgetMs:15000}}finally{clearTimeout(timer)}},remoteSmall)
   await Promise.all(pending)
   if(row.preflight.remote.text!==undefined){row.preflight.remote.sha256=sha(Buffer.from(row.preflight.remote.text));row.preflight.remote.bytes=Buffer.byteLength(row.preflight.remote.text);delete row.preflight.remote.text}
   row.preflight.remote.expectedSHA256=remoteExpected
   row.preflight.corsDenied=await preflight.evaluate(async url=>{try{await fetch(url);return{rejected:false,origin:location.origin}}catch(error){return{rejected:true,error:String(error),origin:location.origin}}},denyURL)
   assert.equal(row.preflight.corsDenied.rejected,true)
   await preflightContext.close();preflightContext=undefined
   context=await browser.newContext({viewport:{width:414,height:896},deviceScaleFactor:1});const page=await context.newPage();const bodyReads=[]
   context.on('request',request=>row.requests.push({scheme:request.url().split(':')[0],url:['http','https'].includes(request.url().split(':')[0])?request.url():undefined,length:request.url().length}))
   page.on('pageerror',error=>row.errors.push(String(error)));page.on('console',message=>row.console.push({type:message.type(),text:message.text()}))
   page.on('response',response=>{if(response.url()===localURL)bodyReads.push((async()=>{const bytes=await response.body();row.responseRecords.push({url:response.url(),status:response.status(),headers:await response.allHeaders(),bytes:bytes.length,sha256:sha(bytes)})})())})
   const started=new Date().toISOString();await page.goto(bootstrap(localURL))
   await page.waitForFunction(()=>{const field=document.getElementById('diagnostic');if(!field)return false;try{return['ready','ready-with-failures','error'].includes(JSON.parse(field.value).state)}catch{return false}},null,{timeout:120000})
   await Promise.all(bodyReads)
   const initial=JSON.parse(await page.locator('#diagnostic').inputValue());row.initial=initial
   row.document={origin:await page.evaluate(()=>location.origin),url:page.url(),charset:await page.evaluate(()=>document.characterSet),inlineUMDPresent:await page.evaluate(()=>typeof htmlToImage.createRenderer==='function'),entryCharacters:bootstrap(localURL).length}
   assert.equal(row.document.origin,'null');assert.equal(row.document.inlineUMDPresent,true)
   assert.equal(initial.state,'ready',JSON.stringify(initial.events));assert.equal(initial.build.sourceFingerprint,manifest.sourceFingerprint)
   assert.equal(initial.integrity.umdMatches,true);assert.equal(initial.integrity.fontMatches,true);assert.equal(initial.cancellation.cases.length,14);assert.equal(initial.cancellation.allPassed,true)
   assert.equal(initial.crossRealmFont.passed,true,JSON.stringify(initial.crossRealmFont));assert.equal(initial.crossRealmFont.sourceIsCrossRealm,true);assert.equal(initial.crossRealmFont.sourceHasSVGText,true);assert.equal(initial.crossRealmFont.embeddedOriginalFontBytes,true);assert.equal(initial.crossRealmFont.canvasOwnerIsCaller,true)
   assert.equal(initial.prechecks.allPassed,true);assert.deepEqual(initial.prechecks.cleanup,{frames:0,renderers:0,snapshots:0,ownedFrameElements:0})
   assert.equal(initial.png.mime,'image/png');assert.equal(initial.png.allPixelsVerified,true);assert.equal(initial.png.redPixels,6400);assert.equal(initial.png.bluePixels,6400)
   const embedded=await page.locator('#embedded-umd').textContent();assert.equal(sha(Buffer.from(embedded)),manifest.umd.sha256)
   assert.equal(row.responseRecords.length,1);assert.equal(row.responseRecords[0].sha256,manifest.page.sha256);assert.equal(row.responseRecords[0].bytes,126151)
   const opening=context.waitForEvent('page');await page.locator('#preview').click();const popup=await opening;await popup.waitForLoadState('load');await popup.waitForFunction(()=>document.images.length===1&&document.images[0].complete&&document.images[0].naturalWidth>0)
   row.popup=await popup.evaluate(()=>{const image=document.images[0],canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight;const ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;let different=0;for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++)[...(x<80?[255,0,0,255]:[0,0,255,255])].forEach((value,n)=>different+=pixels[(y*canvas.width+x)*4+n]!==value);return{width:image.naturalWidth,height:image.naturalHeight,different,openerIsNull:window.opener===null,url:location.href,contentType:document.contentType}})
   assert.deepEqual([row.popup.width,row.popup.height,row.popup.different],[160,80,0]);assert.equal(row.popup.openerIsNull,true);assert.equal(row.popup.url,initial.activeURL);assert.equal(row.popup.contentType,'image/png')
   await popup.locator('img').screenshot({path:new URL(engine+'-bootstrap-preview.png',directory).pathname,scale:'css'});await popup.close();await page.bringToFront()
   const clicked=JSON.parse(await page.locator('#diagnostic').inputValue());row.trustedClick=clicked.events.find(event=>event.name==='preview-click');assert.equal(row.trustedClick.isTrusted,true)
   await page.locator('#cleanup').click();const cleaned=JSON.parse(await page.locator('#diagnostic').inputValue());assert.equal(cleaned.state,'cleaned');assert.equal(cleaned.activeURL,null);assert.equal(await page.locator('#preview').getAttribute('href'),null);assert.equal(await page.locator('#preview').isVisible(),false)
   row.revokedVerified=await page.evaluate(async url=>{try{await fetch(url);return false}catch{return true}},initial.activeURL);assert.equal(row.revokedVerified,true);assert.equal(row.errors.length,0)
   row.HTTPRequests=row.requests.filter(x=>['http','https'].includes(x.scheme));assert.deepEqual(row.HTTPRequests.map(x=>x.url),[localURL]);row.completedUTC=new Date().toISOString();row.passed=true
   await fs.writeFile(new URL(engine+'-diagnostic.json',directory),JSON.stringify(cleaned,null,2))
   console.log(JSON.stringify({engine,fullBootstrapPassed:true,cancellation:14,font:initial.crossRealmFont.passed,PNG:row.popup,rawGitHubSmallFetch:row.preflight.remote}))
  }catch(error){row.error=String(error);row.stack=error.stack;console.error(JSON.stringify({engine,error:row.error}))}
  finally{if(preflightContext)await preflightContext.close();if(context)await context.close();life.contextsClosedUTC=new Date().toISOString();await browser.close();life.closed=true;life.browserClosedUTC=new Date().toISOString();await fs.writeFile(new URL('desktop-bootstrap-results.json',directory),JSON.stringify(report,null,2))}
 }
}finally{
 await new Promise(resolve=>server.close(resolve));report.server.closedUTC=new Date().toISOString();report.server.requests=serverRequests;report.completedUTC=new Date().toISOString();report.allLocalBootstrapPassed=report.cases.length===3&&report.cases.every(x=>x.passed);report.allActualGitHubSmallFetchPassed=report.cases.length===3&&report.cases.every(x=>x.preflight.remote?.ok&&x.preflight.remote.sha256===remoteExpected);report.allBrowsersClosed=report.lifecycles.every(x=>x.closed)
 const after=await inputs();await fs.writeFile(new URL('inputs-after.json',directory),JSON.stringify(after,null,2));report.inputsStable=JSON.stringify(before)===JSON.stringify(after);assert.deepEqual(before,after)
 assert.equal(sha(await fs.readFile(new URL('blob-preview-offline.html',originalDirectory))),manifest.page.sha256);assert.deepEqual(await fs.readFile(root+'/docs/evidence/ios-offline.html'),frozen)
 await fs.writeFile(new URL('desktop-bootstrap-results.json',directory),JSON.stringify(report,null,2));console.log(JSON.stringify({allLocalBootstrapPassed:report.allLocalBootstrapPassed,allActualGitHubSmallFetchPassed:report.allActualGitHubSmallFetchPassed,allBrowsersClosed:report.allBrowsersClosed,inputsStable:report.inputsStable,serverClosed:report.server.closedUTC}))
}
