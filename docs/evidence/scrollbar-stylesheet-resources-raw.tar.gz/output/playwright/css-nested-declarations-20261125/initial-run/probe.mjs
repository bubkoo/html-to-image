import{chromium,firefox,webkit}from'playwright'
import{readFile,writeFile,mkdir}from'node:fs/promises'
import{createHash}from'node:crypto'
const dir=new URL('./',import.meta.url);await mkdir(dir,{recursive:true})
const prior=new URL('../stylesheet-encoding-20261125/',import.meta.url)
const bootstrap=await readFile(new URL('actual-loader-collector.js',prior),'utf8'),inputs=JSON.parse(await readFile(new URL('actual-loader-source-inputs.json',prior),'utf8'))
const hashes=[]
for(const record of inputs.files){const bytes=await readFile(record.name);const digest=createHash('sha256').update(bytes).digest('hex');if(digest!==record.sha256)throw Error('Current source differs from isolated collector: '+record.name);hashes.push({path:record.name,sha256:digest});await writeFile(new URL(record.name.replaceAll('/','__'),dir),bytes)}
await writeFile(new URL('isolated-collector.js',dir),bootstrap)
const cases=[
 ['direct-pseudo-tail','.panel::-webkit-scrollbar-thumb{background:black;@media(min-width:300px){background:blue}background:yellow}'],
 ['direct-pseudo-media-only','.panel::-webkit-scrollbar-thumb{background:black;@media(min-width:300px){background:blue}}'],
 ['direct-pseudo-inactive-tail','.panel::-webkit-scrollbar-thumb{background:black;@media(max-width:0px){background:blue}background:yellow}'],
 ['nested-pseudo-tail','.panel{&::-webkit-scrollbar-thumb{background:black;@media(min-width:300px){background:blue}background:yellow}}'],
 ['ordinary-parent-tail','.panel{&::-webkit-scrollbar-thumb{background:yellow}background:rgb(120,80,40);color:yellow}'],
 ['ordinary-parent-declaration-control','.panel{color:black;@media(min-width:300px){color:blue}color:yellow}&:invalid-selector-never-match{}'],
]
const base='.panel::-webkit-scrollbar{width:10px;height:10px;background:red}.panel::-webkit-scrollbar-track{background:red}.panel::-webkit-scrollbar-thumb{background:black;border-radius:0}.panel::-webkit-scrollbar-corner{background:blue}'
const report={at:new Date().toISOString(),sourceInputs:hashes,scope:'Independent native CSSOM/colour and unchanged isolated collector to SVG comparison; no project build/full capture API acceptance',cases:[]}
for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
const browser=await type.launch({headless:true,...(engine==='chromium'?{ignoreDefaultArgs:['--hide-scrollbars'],args:['--disable-features=OverlayScrollbar,FluentOverlayScrollbar']}: {})})
try{const page=await browser.newPage({viewport:{width:414,height:896},deviceScaleFactor:1});await page.setContent('<!doctype html><meta charset="utf-8"><body style="margin:0">');await page.addScriptTag({content:bootstrap})
for(const[name,css]of cases){
const state=await page.evaluate(({base,css})=>{
 document.body.innerHTML='<style id="styles"></style><div id="panel" class="panel" style="position:absolute;left:0;top:0;width:100px;height:100px;overflow:scroll"><div style="width:200px;height:300px;background:green"></div></div>'
 document.querySelector('#styles').textContent=base+css
 const root=document.querySelector('#panel'),sheet=document.querySelector('#styles').sheet
 const dump=r=>({type:r.type,tag:Object.prototype.toString.call(r),constructor:r.constructor.name,text:r.cssText,selector:r.selectorText,style:r.style?.cssText,hasStyle:'style'in r,hasSelector:'selectorText'in r,hasRules:'cssRules'in r,children:r.cssRules?Array.from(r.cssRules,dump):undefined})
 const style=getComputedStyle(root),supported=CSS.supports('selector(::-webkit-scrollbar)')
 return{supported,cssNestedDeclarationsConstructor:typeof CSSNestedDeclarations,sourceColor:style.color,sourceBackground:style.backgroundColor,pseudoBackground:supported?getComputedStyle(root,'::-webkit-scrollbar-thumb').backgroundColor:null,rules:Array.from(sheet.cssRules,dump),dto:window.__encodingProbe.takeSheetSnapshot(sheet,document.baseURI,document.characterSet),before:root.outerHTML}
},{base,css})
if(!state.supported){report.cases.push({engine,version:browser.version(),name,...state,before:undefined,unsupported:true});console.log(engine,name,'UNSUPPORTED');continue}
const native=await page.locator('#panel').screenshot({scale:'css'});await writeFile(new URL(`${engine}-${name}-native.png`,dir),native)
const captured=await page.evaluate(async()=>{
 const source=document.querySelector('#panel'),doc=document.implementation.createHTMLDocument('collector'),clone=doc.importNode(source,true),computed=getComputedStyle(source),warnings=[]
 // The actual clone stage freezes ordinary element styles separately. Preserve
 // its background/colour here while leaving authored geometry at100px.
 clone.style.backgroundColor=computed.backgroundColor;clone.style.color=computed.color
 const loader={load:()=>{throw Error('Unexpected network dependency')},responseURL:u=>u,warn:x=>warnings.push(x)}
 await window.__encodingProbe.cloneScrollbarStyles(source,clone,{signal:new AbortController().signal,__loader:loader})
 const svg='<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><foreignObject width="100" height="100">'+new XMLSerializer().serializeToString(clone)+'</foreignObject></svg>'
 const image=new Image();image.decoding='sync';image.src='data:image/svg+xml,'+encodeURIComponent(svg);await image.decode();const c=document.createElement('canvas');c.width=c.height=100;c.getContext('2d').drawImage(image,0,0)
 return{warnings,svg,png:c.toDataURL().split(',')[1],sourceAfter:source.outerHTML,cloneBackground:clone.style.backgroundColor,cloneColor:clone.style.color}
})
await writeFile(new URL(`${engine}-${name}.svg`,dir),captured.svg);await writeFile(new URL(`${engine}-${name}-capture.png`,dir),Buffer.from(captured.png,'base64'))
const comparison=await page.evaluate(async({native,capture})=>{const read=async s=>{const i=new Image();i.src='data:image/png;base64,'+s;await i.decode();const c=document.createElement('canvas');c.width=c.height=100;const x=c.getContext('2d');x.drawImage(i,0,0);return x.getImageData(0,0,100,100).data};const a=await read(native),b=await read(capture);let channels=0,maxDelta=0;const count=d=>{const r={black:0,blue:0,yellow:0};for(let n=0;n<d.length;n+=4){const p=Array.from(d.slice(n,n+4)).join();if(p==='0,0,0,255')r.black++;if(p==='0,0,255,255')r.blue++;if(p==='255,255,0,255')r.yellow++}return r};for(let n=0;n<a.length;n++){channels+=a[n]!==b[n];maxDelta=Math.max(maxDelta,Math.abs(a[n]-b[n]))}return{channels,maxDelta,native:count(a),capture:count(b)}},{native:native.toString('base64'),capture:captured.png})
const record={engine,version:browser.version(),name,css,...state,before:undefined,captured:{...captured,svg:undefined,png:undefined,sourceAfter:undefined},sourceUnchanged:state.before===captured.sourceAfter,comparison};report.cases.push(record);console.log(engine,name,JSON.stringify({sourceColor:state.sourceColor,pseudoBackground:state.pseudoBackground,comparison}));await writeFile(new URL('results.json',dir),JSON.stringify(report,null,2)+'\n')
}
}finally{await browser.close()}
}
report.inputsUnchanged=true;for(const row of hashes){const now=createHash('sha256').update(await readFile(row.path)).digest('hex');if(now!==row.sha256)report.inputsUnchanged=false}
await writeFile(new URL('results.json',dir),JSON.stringify(report,null,2)+'\n')
