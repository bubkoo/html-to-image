# CSSNestedDeclarations boundary

`assessment.json` is the finding entry point. The original measured collector source SHA is pinned in `source-inputs.json`, with copied source files and the isolated collector JavaScript.

From the checkout root, with the installed Playwright1.64.1 browsers:

```sh
node output/playwright/css-nested-declarations-20261125/replay.mjs
```

`replay.mjs` uses the archived collector and archived-source hash guard, allowing the original boundary to be reproduced after production source changes. It does not claim the current changed source still has the defect. It does not build the project, run existing tests, open servers or access a device. Replaying overwrites `results.json`, PNGs and SVGs; preserve this folder first.

The original `probe.mjs` checked the actual live source hashes against the captured collector before/after. It used the earlier encoding investigation's collector bootstrap, which is byte-for-byte copied here as `isolated-collector.js`; source inputs were unchanged during measurement.

Each condition first inspects the actual native CSSOM and computed pseudo color, then takes a native source PNG, executes the unchanged collector bodies against an inert clone, and compares the resulting SVG raster with the source PNG. Ordinary element background/color are frozen separately in the adapter, as the actual clone stage does; authored100px geometry is preserved. There are no external resources or delayed-image readiness controls in these scenes.

The confirmed conditions are direct pseudo declarations around active/inactive media rules, and the same sequence inside a nested `&::-webkit-scrollbar-thumb` rule. Ordinary parent tail declarations are positive controls: their normal element colors are captured separately, and the scrollbar representation remains exact. Firefox records the native CSSOM shape but is explicitly unsupported for legacy scrollbar rendering.

`initial-run` retains the first script/log/results. Its ordinary positive control had an extra ignored invalid selector appended after the actual fixture. It was removed and the complete matrix rerun; all confirmed failure differences and positive-control results remained identical. No unknown-rule behavior is used as evidence.
