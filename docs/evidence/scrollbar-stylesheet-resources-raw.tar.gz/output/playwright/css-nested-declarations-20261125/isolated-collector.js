(()=>{const exports={};"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceLoader = exports.ResourceResolverError = void 0;
exports.readDOMProperty = readDOMProperty;
exports.readDOMMethod = readDOMMethod;
exports.readOptionalDOMProperty = readOptionalDOMProperty;
exports.readOptionalDOMMethod = readOptionalDOMMethod;
exports.hasDOMProperty = hasDOMProperty;
exports.writeDOMProperty = writeDOMProperty;
exports.resolveNestedSelector = resolveNestedSelector;
exports.rewriteSVGStyleURLs = rewriteSVGStyleURLs;
exports.decodeCSS = decodeCSS;
exports.blobToDataURL = blobToDataURL;
exports.freezeScrollbarPresence = freezeScrollbarPresence;
exports.cloneScrollbarStyles = cloneScrollbarStyles;
exports.beginScrollbarStyleScope = beginScrollbarStyleScope;
// A self-hosted Reflect.get can itself cache a foreign DOM getter. Forward
// through a transparent proxy so that its property cache sees only the proxy.
// An explicit receiver preserves native accessors and existing proxy traps.
// The handler has no prototype or traps, and no proxy is retained after use.
const handler = Object.freeze(Object.create(null));
function readDOMProperty(target, key) {
    // Array-like and prototype helpers also accept erased primitive values.
    // Box the lookup target while preserving the original accessor receiver;
    // nullish targets must still throw instead of becoming empty objects.
    const object = target == null ? target : Object(target);
    return Reflect.get(new Proxy(object, handler), key, target);
}
// Resolve the method before evaluating arguments, then retain its receiver.
// Forwarding the original method type preserves DOM overloads.
function readDOMMethod(target, key) {
    const method = readDOMProperty(target, key);
    return ((...args) => Reflect.apply(method, target, args));
}
function readOptionalDOMProperty(target, key) {
    return target == null ? undefined : readDOMProperty(target, key);
}
function readOptionalDOMMethod(target, key) {
    return target == null ? undefined : readDOMMethod(target, key);
}
// Keep the argument order of `key in target`; Reflect.has also leaves getters
// uncalled while checking inherited properties.
function hasDOMProperty(key, target) {
    return Reflect.has(new Proxy(target, handler), key);
}
function writeDOMProperty(target, key, value) {
    // Preserve strict assignment failure and the RHS return value, even when a
    // native setter normalizes the value stored in the DOM.
    if (!Reflect.set(new Proxy(target, handler), key, value, target)) {
        throw new TypeError('Cannot assign a DOM property');
    }
    return value;
}
// Every nesting selector inherits the maximum specificity of the complete
// parent list. Keeping that list inside :is() lets the native selector parser
// apply its matching and specificity rules after the snapshot is flattened.
function resolveNestedSelector(selector, parent) {
    const scope = `:is(${parent})`;
    const selectors = [];
    let branch = '';
    let nested = false;
    let token = false;
    let quote = '';
    let brackets = 0;
    let parentheses = 0;
    const finish = () => {
        selectors.push(nested || !token ? branch : `${scope} ${branch}`);
        branch = '';
        nested = false;
        token = false;
    };
    for (let offset = 0; offset < selector.length; offset += 1) {
        const char = selector[offset];
        if (char === '\\') {
            branch += char;
            if (offset + 1 < selector.length)
                branch += selector[++offset];
            token = true;
            continue;
        }
        if (quote) {
            branch += char;
            if (char === quote)
                quote = '';
            continue;
        }
        if (char === '/' && selector[offset + 1] === '*') {
            const end = selector.indexOf('*/', offset + 2);
            const next = end < 0 ? selector.length : end + 2;
            branch += selector.slice(offset, next);
            offset = next - 1;
            continue;
        }
        if (char === '"' || char === "'")
            quote = char;
        if (char === '[')
            brackets += 1;
        else if (char === ']')
            brackets -= 1;
        else if (!brackets && char === '(')
            parentheses += 1;
        else if (!brackets && char === ')')
            parentheses -= 1;
        if (!brackets && !parentheses && char === ',') {
            finish();
        }
        else if (!brackets && char === '&') {
            branch += scope;
            nested = true;
            token = true;
        }
        else {
            branch += char;
            if (!/[ \t\r\n\f]/.test(char))
                token = true;
        }
    }
    finish();
    return selectors.join(',');
}
function rewriteSVGStyleURLs(text, resolve) {
    // Quoted data URLs can contain literal url(...) text. Visit CSS tokens rather
    // than rewriting such text inside strings or comments as another resource.
    text = text.split('\u0000').join('\ufffd');
    let result = '';
    let start = 0;
    const quotedEnd = (index) => {
        const quote = text[index++];
        let closed = false;
        while (index < text.length) {
            if (text[index] === '\\')
                index += text[index + 1] === '\r' && text[index + 2] === '\n' ? 3 : 2;
            else if (/[\r\n\f]/.test(text[index]))
                break;
            else if (text[index++] === quote) {
                closed = true;
                break;
            }
        }
        return { end: Math.min(index, text.length), closed };
    };
    for (let index = 0; index < text.length;) {
        if (text.slice(index, index + 2) === '/*') {
            const end = text.indexOf('*/', index + 2);
            index = end < 0 ? text.length : end + 2;
        }
        else if (text[index] === '"' || text[index] === "'") {
            index = quotedEnd(index).end;
        }
        else if (text.slice(index, index + 4).toLowerCase() === 'url(' &&
            (index === 0 || !/[\w\\\u0080-\uffff-]/.test(text[index - 1]))) {
            let cursor = index + 4;
            while (/[ \t\r\n\f]/.test(text[cursor] || '') && cursor < text.length)
                cursor++;
            const quoted = text[cursor] === '"' || text[cursor] === "'";
            const valueStart = cursor + (quoted ? 1 : 0);
            let valueEnd;
            let valid = true;
            if (quoted) {
                const end = quotedEnd(cursor);
                cursor = end.end;
                valid = end.closed;
                valueEnd = cursor - 1;
                while (/[ \t\r\n\f]/.test(text[cursor] || '') && cursor < text.length)
                    cursor++;
            }
            else {
                while (cursor < text.length && text[cursor] !== ')') {
                    const char = text[cursor];
                    if (char === '\\') {
                        const escape = /^\\(?:[0-9a-f]{1,6}(?:\r\n|[ \t\r\n\f])?|[^\r\n\f])/i.exec(text.slice(cursor));
                        if (!escape)
                            valid = false;
                        cursor += (escape === null || escape === void 0 ? void 0 : escape[0].length) || 1;
                    }
                    else if (/[ \t\r\n\f]/.test(char)) {
                        while (/[ \t\r\n\f]/.test(text[cursor] || '') &&
                            cursor < text.length)
                            cursor++;
                        if (text[cursor] !== ')')
                            valid = false;
                    }
                    else {
                        if (/["'(]/.test(char) ||
                            char.charCodeAt(0) < 0x20 ||
                            char.charCodeAt(0) === 0x7f)
                            valid = false;
                        cursor++;
                    }
                }
                valueEnd = cursor;
            }
            if (!valid && text[cursor] === ')') {
                index = cursor + 1;
                continue;
            }
            if (text[cursor] === ')' && valid) {
                const raw = quoted
                    ? text.slice(valueStart, valueEnd)
                    : text
                        .slice(valueStart, valueEnd)
                        .replace(/^[ \t\r\n\f]+|[ \t\r\n\f]+$/g, '');
                const value = raw.replace(/\\(?:([0-9a-f]{1,6})(?:\r\n|[ \t\r\n\f])?|(\r\n|[\r\n\f])|([\s\S]))/gi, (match, hex, newline, char) => {
                    if (hex) {
                        const point = parseInt(hex, 16);
                        return String.fromCodePoint(!point ||
                            point > 0x10ffff ||
                            (point >= 0xd800 && point <= 0xdfff)
                            ? 0xfffd
                            : point);
                    }
                    return newline ? '' : char;
                });
                const replacement = resolve(value);
                if (replacement !== undefined) {
                    result +=
                        text.slice(start, index) + `url(${JSON.stringify(replacement)})`;
                    start = cursor + 1;
                }
                index = cursor + 1;
            }
            else
                index++;
        }
        else
            index++;
    }
    return result + text.slice(start);
}
async function decodeCSS(blob, metadata, environment) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const decoder = (label) => {
        if (!label)
            return undefined;
        try {
            return new TextDecoder(label);
        }
        catch {
            return undefined;
        }
    };
    let encoding;
    if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf)
        encoding = new TextDecoder('utf-8');
    else if (bytes[0] === 0xff && bytes[1] === 0xfe)
        encoding = new TextDecoder('utf-16le');
    else if (bytes[0] === 0xfe && bytes[1] === 0xff)
        encoding = new TextDecoder('utf-16be');
    const charset = /;\s*charset\s*=\s*(?:"([^"]*)"|'([^']*)'|([^;\s]*))/i.exec(metadata);
    encoding || (encoding = decoder((charset && (charset[1] || charset[2] || charset[3])) || undefined));
    if (!encoding) {
        const prefix = Array.from(bytes.slice(0, 1024), (byte) => String.fromCharCode(byte)).join('');
        const declared = /^@charset "([^"]*)";/.exec(prefix);
        encoding = decoder(declared === null || declared === void 0 ? void 0 : declared[1]);
        if ((encoding === null || encoding === void 0 ? void 0 : encoding.encoding) === 'utf-16be' || (encoding === null || encoding === void 0 ? void 0 : encoding.encoding) === 'utf-16le')
            encoding = new TextDecoder('utf-8');
    }
    encoding || (encoding = decoder(environment) || new TextDecoder('utf-8'));
    return { text: encoding.decode(bytes), encoding: encoding.encoding };
}
const readDocumentProperty = readDOMProperty;
async function resolveWithAbort(resolver, request, context) {
    const { signal } = context;
    let abort;
    const cancelled = new Promise((resolve, reject) => {
        abort = () => reject(signal.reason);
        signal.addEventListener('abort', abort, { once: true });
        if (signal.aborted)
            abort();
    });
    const pending = Promise.resolve().then(() => {
        if (signal.aborted)
            throw signal.reason;
        return resolver(request, context);
    });
    try {
        return await Promise.race([pending, cancelled]);
    }
    finally {
        signal.removeEventListener('abort', abort);
    }
}
class ResourceResolverError extends Error {
    constructor(cause) {
        super('Custom resource resolver failed');
        this.cause = cause;
        this.name = 'ResourceResolverError';
        Object.setPrototypeOf(this, ResourceResolverError.prototype);
    }
}
exports.ResourceResolverError = ResourceResolverError;
function firstMediaType(type) {
    let quoted = false;
    let escaped = false;
    for (let i = 0; i < type.length; i += 1) {
        const char = type[i];
        if (escaped)
            escaped = false;
        else if (quoted && char === '\\')
            escaped = true;
        else if (char === '"')
            quoted = !quoted;
        else if (char === ',' && !quoted)
            return type.slice(0, i).trim();
    }
    return type;
}
function blobToDataURL(blob) {
    return new Promise((resolve, reject) => {
        // FileReader copies Blob.type into the data URL. A repeated Content-Type
        // header may arrive as "image/png, image/png", which is not a data URL MIME.
        const mediaType = firstMediaType(blob.type);
        const readable = mediaType === blob.type ? blob : blob.slice(0, blob.size, mediaType);
        const reader = new FileReader();
        reader.onerror = () => reject(reader.error);
        reader.onload = () => resolve(reader.result);
        reader.readAsDataURL(readable);
    });
}
class ResourceLoader {
    constructor(options, context, warn = () => { }) {
        this.options = options;
        this.context = context;
        this.warn = warn;
        this.pending = new Map();
        this.responseURLs = new Map();
        this.customResponses = new Set();
    }
    key(url, kind, contentType) {
        // Full URLs identify resources by default. The legacy option remains opt-in.
        const identity = this.options.includeQueryParams === false ? url.replace(/\?.*/, '') : url;
        return JSON.stringify([identity, kind, contentType]);
    }
    responseURL(url, kind, contentType) {
        return this.responseURLs.get(this.key(url, kind, contentType)) || url;
    }
    isCustomResponse(url, kind, contentType) {
        return this.customResponses.has(this.key(url, kind, contentType));
    }
    load(url, kind, contentType) {
        const key = this.key(url, kind, contentType);
        const existing = this.pending.get(key);
        if (existing)
            return existing;
        const request = this.fetch(url, kind, contentType).then((result) => {
            if (this.pending.get(key) === request) {
                this.responseURLs.set(key, result.url);
                if (result.custom)
                    this.customResponses.add(key);
            }
            return result.blob;
        });
        this.pending.set(key, request);
        request.catch(() => {
            if (this.pending.get(key) === request)
                this.pending.delete(key);
        });
        return request;
    }
    async fetch(url, kind, contentType) {
        var _a;
        const { signal } = this.context;
        if (signal.aborted)
            throw signal.reason;
        const request = Object.freeze({ url, kind, contentType });
        const resolvers = [
            (_a = this.options.resources) === null || _a === void 0 ? void 0 : _a.resolve,
            ...(this.options.plugins || []).map((plugin) => plugin.resolveResource),
        ];
        for (let i = 0; i < resolvers.length; i += 1) {
            const resolve = resolvers[i];
            if (resolve) {
                let result;
                try {
                    // eslint-disable-next-line no-await-in-loop
                    result = await resolveWithAbort(resolve, request, this.context);
                }
                catch (error) {
                    if (signal.aborted)
                        throw signal.reason;
                    throw new ResourceResolverError(error);
                }
                if (signal.aborted)
                    throw signal.reason;
                if (result !== undefined) {
                    if (result == null || typeof result.arrayBuffer !== 'function') {
                        throw new ResourceResolverError(new TypeError('Resource resolvers must return a Blob or undefined'));
                    }
                    return { blob: result, url, custom: true };
                }
            }
        }
        const requestURL = new URL(url, readDocumentProperty(document, 'baseURI'));
        requestURL.hash = '';
        const originalURL = requestURL.href;
        const originalNonce = requestURL.searchParams.getAll('_htmlToImage');
        let nonce;
        if (this.options.cacheBust) {
            nonce = String(Date.now());
            requestURL.searchParams.set('_htmlToImage', nonce);
        }
        const response = await fetch(requestURL.href, {
            ...this.options.fetchRequestInit,
            signal,
        });
        if (!response.ok) {
            throw new Error(`Resource request failed (${response.status}): ${url}`);
        }
        const finalURL = new URL(response.url || requestURL.href);
        if (nonce && finalURL.searchParams.get('_htmlToImage') === nonce) {
            finalURL.searchParams.delete('_htmlToImage');
            originalNonce.forEach((value) => finalURL.searchParams.append('_htmlToImage', value));
        }
        return {
            blob: await response.blob(),
            // A transport cache-buster is not part of the SVG document identity.
            url: response.url === requestURL.href ? originalURL : finalURL.href,
            custom: false,
        };
    }
    clear() {
        this.pending.clear();
        this.responseURLs.clear();
        this.customResponses.clear();
    }
}
exports.ResourceLoader = ResourceLoader;
const getTask = () => undefined;
const getResourceLoader = options => options.__loader;
const uuid = () => 'encoding-probe';
const getStyleProperties = (s, selected) => Array.from(s).filter(x => !selected || selected.includes(x));
const parts = [
    'scrollbar',
    'scrollbar-thumb',
    'scrollbar-track',
    'scrollbar-track-piece',
    'scrollbar-button',
    'scrollbar-corner',
    'resizer',
];
function freezeScrollbarPresence(source, clone, sourceStyle) {
    // Preserve a source auto bar that already occupies this axis. In an SVG
    // image, an auto bar can otherwise paint its fallback before its image is ready.
    if (!sourceStyle)
        return;
    const style = readDOMProperty(clone, 'style');
    const border = (name) => parseFloat(readDOMMethod(sourceStyle, 'getPropertyValue')(name)) || 0;
    const axes = [
        [
            'overflowX',
            'scrollWidth',
            'clientWidth',
            'offsetHeight',
            'clientHeight',
            'border-top-width',
            'border-bottom-width',
        ],
        [
            'overflowY',
            'scrollHeight',
            'clientHeight',
            'offsetWidth',
            'clientWidth',
            'border-left-width',
            'border-right-width',
        ],
    ];
    axes.forEach(([overflow, extent, client, offset, crossClient, start, end]) => {
        if (readDOMProperty(style, overflow) !== 'auto')
            return;
        if (readDOMProperty(source, extent) <= readDOMProperty(source, client))
            return;
        // Integer offset/client metrics can round fractional borders differently.
        // The upper border bound prevents a border from proving bar occupancy.
        const occupied = readDOMProperty(source, offset) -
            readDOMProperty(source, crossClient) -
            Math.ceil(border(start) + border(end));
        if (occupied > 0)
            writeDOMProperty(style, overflow, 'scroll');
    });
}
async function cloneScrollbarStyles(source, clone, options, selected) {
    const style = readDOMProperty(clone, 'style');
    if (!style ||
        (selected === null || selected === void 0 ? void 0 : selected.length) === 0 ||
        !['auto', 'scroll'].some((value) => readDOMProperty(style, 'overflowX') === value ||
            readDOMProperty(style, 'overflowY') === value) ||
        readDOMProperty(style, 'scrollbarWidth') === 'none')
        return;
    const view = readDOMProperty(readDOMProperty(source, 'ownerDocument'), 'defaultView') ||
        window;
    if (!readDOMMethod(readDOMProperty(view, 'CSS'), 'supports')('selector(::-webkit-scrollbar)'))
        return;
    // Non-auto standard properties override the legacy pseudo family. Their
    // values are already frozen by the normal element style copy.
    if ((readDOMProperty(style, 'scrollbarWidth') &&
        readDOMProperty(style, 'scrollbarWidth') !== 'auto') ||
        (readDOMProperty(style, 'scrollbarColor') &&
            readDOMProperty(style, 'scrollbarColor') !== 'auto'))
        return;
    const rules = [];
    const id = uuid();
    const cache = scrollbarCache(options);
    let authoredRules;
    try {
        authoredRules = await scrollbarRules(source, clone, id, options, cache, selected);
    }
    finally {
        if (!getTask(options))
            cache.release();
    }
    if (authoredRules)
        rules.push(authoredRules);
    else
        parts.forEach((part) => {
            const computed = readDOMMethod(view, 'getComputedStyle')(source, `::-webkit-${part}`);
            // Merely creating a rule for an unstyled button/track piece can make that
            // native part exist. Copy authored paint/geometry, not default empty parts.
            const painted = readDOMProperty(computed, 'backgroundImage') !== 'none' ||
                !['rgba(0, 0, 0, 0)', 'transparent', ''].includes(readDOMProperty(computed, 'backgroundColor')) ||
                readDOMProperty(computed, 'boxShadow') !== 'none' ||
                [
                    readDOMProperty(computed, 'width'),
                    readDOMProperty(computed, 'height'),
                ].some((value) => value && value !== 'auto') ||
                readDOMProperty(computed, 'display') === 'none' ||
                ['top', 'right', 'bottom', 'left'].some((side) => parseFloat(readDOMMethod(computed, 'getPropertyValue')(`border-${side}-width`)) > 0);
            if (!readDOMProperty(computed, 'length') || !painted)
                return;
            const names = getStyleProperties(computed, selected).filter((name) => {
                const value = readDOMMethod(computed, 'getPropertyValue')(name);
                return name === 'width' || name === 'height'
                    ? value !== 'auto'
                    : name === 'background-color'
                        ? !['transparent', 'rgba(0, 0, 0, 0)'].includes(value)
                        : name === 'background-image' || name === 'box-shadow'
                            ? value !== 'none'
                            : name === 'display' && value === 'none';
            });
            const text = names
                .filter((name) => !selected || selected.includes(name))
                .map((name) => `${name}:${readDOMMethod(computed, 'getPropertyValue')(name)};`)
                .join('');
            if (!text)
                return;
            rules.push(`:where(.${id})::-webkit-${part}{${text}}`);
        });
    if (!rules.length)
        return;
    readDOMMethod(readDOMProperty(clone, 'classList'), 'add')(id);
    const task = getTask(options);
    if (task)
        task.addClonedStyle(rules.join('\n'), `.${id}`);
    else {
        const sheet = readDOMMethod(readDOMProperty(clone, 'ownerDocument'), 'createElement')('style');
        writeDOMProperty(sheet, 'textContent', rules.join('\n'));
        readDOMMethod(clone, 'append')(sheet);
    }
}
// Only capture-local promises and primitive snapshots live here. In particular,
// do not cache a native sheet, rule, source element or its owner document.
const stylesheetCaches = new WeakMap();
const stylesheetRoots = new WeakMap();
function scrollbarCache(options) {
    const task = getTask(options);
    const existing = task && stylesheetCaches.get(task);
    if (existing)
        return existing;
    const signal = (task === null || task === void 0 ? void 0 : task.context.signal) || options.signal || new AbortController().signal;
    const cache = {
        signal,
        closed: false,
        remote: new Map(),
        parsed: new Map(),
        warned: new Set(),
        release: () => {
            cache.closed = true;
            cache.remote.clear();
            cache.parsed.clear();
            cache.warned.clear();
            signal.removeEventListener('abort', cache.release);
            if (task && stylesheetCaches.get(task) === cache)
                stylesheetCaches.delete(task);
        },
    };
    signal.addEventListener('abort', cache.release, { once: true });
    if (task)
        stylesheetCaches.set(task, cache);
    return cache;
}
function beginScrollbarStyleScope(options) {
    const task = getTask(options);
    if (!task)
        return () => { };
    stylesheetRoots.set(task, (stylesheetRoots.get(task) || 0) + 1);
    return () => {
        var _a;
        const remaining = (stylesheetRoots.get(task) || 1) - 1;
        if (remaining > 0)
            stylesheetRoots.set(task, remaining);
        else {
            stylesheetRoots.delete(task);
            (_a = stylesheetCaches.get(task)) === null || _a === void 0 ? void 0 : _a.release();
        }
    };
}
function checkStylesheetCache(cache) {
    if (cache.signal.aborted)
        throw cache.signal.reason;
    if (cache.closed)
        throw new Error('Scrollbar stylesheet snapshot was released');
}
function takeSheetSnapshot(sheet, base, encoding, active = new Set(), live = true) {
    const href = readDOMProperty(sheet, 'href');
    const value = {
        href,
        base: href || base,
        encoding,
        media: readDOMProperty(readDOMProperty(sheet, 'media'), 'mediaText'),
        disabled: readDOMProperty(sheet, 'disabled'),
    };
    if (active.has(sheet))
        return { ...value, rules: [] };
    active.add(sheet);
    try {
        value.rules = takeRulesSnapshot(readDOMProperty(sheet, 'cssRules'), value.base, encoding, active, live);
    }
    catch (error) {
        value.unreadable = error instanceof Error ? error.message : String(error);
    }
    finally {
        active.delete(sheet);
    }
    return value;
}
function takeRulesSnapshot(rules, base, encoding, active, live) {
    return Array.from(rules).map((rule) => {
        const type = readDOMProperty(rule, 'type');
        // CSSStyleRule also exposes cssRules for nesting. Its declarations must
        // not be mistaken for an empty grouping rule.
        if (type === CSSRule.STYLE_RULE) {
            const styleRule = rule;
            const style = readDOMProperty(styleRule, 'style');
            return {
                kind: 'style',
                selector: readDOMProperty(styleRule, 'selectorText'),
                declarations: Array.from(style, (name) => ({
                    name,
                    value: readDOMMethod(style, 'getPropertyValue')(name),
                    priority: readDOMMethod(style, 'getPropertyPriority')(name),
                })),
                rules: readDOMProperty(styleRule, 'cssRules')
                    ? takeRulesSnapshot(readDOMProperty(styleRule, 'cssRules'), base, encoding, active, live)
                    : [],
            };
        }
        if (type === CSSRule.IMPORT_RULE) {
            const imported = rule;
            const child = live ? readDOMProperty(imported, 'styleSheet') : undefined;
            return {
                kind: 'import',
                href: readDOMProperty(imported, 'href'),
                layer: readDOMProperty(imported, 'layerName'),
                supports: readDOMProperty(imported, 'supportsText'),
                media: readDOMProperty(readDOMProperty(imported, 'media'), 'mediaText'),
                sheet: child
                    ? takeSheetSnapshot(child, base, encoding, active, true)
                    : undefined,
            };
        }
        const text = readDOMProperty(rule, 'cssText');
        if (hasDOMProperty('cssRules', rule)) {
            return {
                kind: 'group',
                head: text.slice(0, text.indexOf('{')),
                condition: type === CSSRule.MEDIA_RULE
                    ? 'media'
                    : type === CSSRule.SUPPORTS_RULE
                        ? 'supports'
                        : undefined,
                text: type === CSSRule.MEDIA_RULE
                    ? readDOMProperty(rule, 'conditionText')
                    : type === CSSRule.SUPPORTS_RULE
                        ? readDOMProperty(rule, 'conditionText')
                        : undefined,
                rules: takeRulesSnapshot(readDOMProperty(rule, 'cssRules'), base, encoding, active, live),
            };
        }
        return { kind: 'text', text };
    });
}
function hasRelativeStyleURL(value) {
    let relative = false;
    rewriteSVGStyleURLs(value, (url) => {
        if (!url.startsWith('#')) {
            try {
                new URL(url);
            }
            catch {
                relative = true;
            }
        }
        return undefined;
    });
    return relative;
}
function remoteStylesheet(url, loader, cache) {
    let pending = cache.remote.get(url);
    if (!pending) {
        pending = (async () => {
            const blob = await loader.load(url, 'stylesheet');
            checkStylesheetCache(cache);
            return { blob, base: loader.responseURL(url, 'stylesheet') };
        })();
        cache.remote.set(url, pending);
    }
    return pending;
}
async function parseRemoteStylesheet(url, encoding, ownedDocument, loader, cache) {
    const key = JSON.stringify([url, encoding]);
    let pending = cache.parsed.get(key);
    if (!pending) {
        pending = (async () => {
            const { blob, base } = await remoteStylesheet(url, loader, cache);
            const decoded = await decodeCSS(blob, blob.type, encoding);
            checkStylesheetCache(cache);
            const parserDocument = readDOMMethod(readDOMProperty(ownedDocument, 'implementation'), 'createHTMLDocument')();
            const parser = readDOMMethod(parserDocument, 'createElement')('style');
            writeDOMProperty(parser, 'textContent', decoded.text);
            readDOMMethod(readDOMProperty(parserDocument, 'head'), 'append')(parser);
            try {
                const sheet = readDOMProperty(parser, 'sheet');
                if (!sheet)
                    throw new Error('Stylesheet parser did not create a CSS sheet');
                return takeSheetSnapshot(sheet, base, decoded.encoding, new Set(), false);
            }
            finally {
                readDOMMethod(parser, 'remove')();
            }
        })();
        cache.parsed.set(key, pending);
    }
    return pending;
}
// Native scrollbar parts have state (orientation, track side, button state)
// that getComputedStyle(element, pseudo) does not expose. Preserve those
// selectors and let the native renderer resolve their state in the snapshot.
async function scrollbarRules(source, clone, id, options, cache, selected) {
    const root = readDOMMethod(source, 'getRootNode')();
    const document = readDOMProperty(source, 'ownerDocument');
    const sheets = root === document
        ? Array.from(readDOMProperty(document, 'styleSheets'))
        : Array.from(readDOMMethod(root, 'querySelectorAll')('style,link'))
            .map((node) => readDOMProperty(node, 'sheet'))
            .filter((sheet) => !!sheet);
    sheets.push(...Array.from(readDOMProperty(root, 'adoptedStyleSheets') || []));
    const base = readDOMProperty(source, 'baseURI');
    const encoding = readDOMProperty(document, 'characterSet');
    // Snapshot native CSSOM before awaiting a foreign resolver. The cached
    // result is made only of strings; later capture results retain no source DOM.
    const snapshots = sheets.map((sheet) => takeSheetSnapshot(sheet, base, encoding));
    const ownedDocument = readDOMProperty(clone, 'ownerDocument');
    const view = readDOMProperty(document, 'defaultView') || window;
    const loader = getResourceLoader(options);
    const active = new Set();
    let matched = false;
    const report = (url, error) => {
        checkStylesheetCache(cache);
        if (error instanceof ResourceResolverError)
            throw error;
        if (cache.warned.has(url))
            return;
        cache.warned.add(url);
        loader.warn(Object.freeze({
            code: 'resource-error',
            resource: url,
            message: 'Native scrollbar stylesheet could not be fully read: ' +
                (error instanceof Error ? error.message : String(error)),
        }));
    };
    const mediaMatches = (media) => !media ||
        readDOMProperty(readDOMMethod(view, 'matchMedia')(media), 'matches');
    const supports = (condition) => readDOMMethod(readDOMProperty(view, 'CSS'), 'supports')(condition) ||
        readDOMMethod(readDOMProperty(view, 'CSS'), 'supports')(`(${condition})`);
    const selectorsFor = (text) => splitSelectors(text).flatMap((selector) => {
        const marker = scrollbarMarker(selector);
        if (!marker)
            return [];
        let prefix = selector.slice(0, marker.offset) || '*';
        if (/\s$|[>+~]$/.test(prefix))
            prefix += '*';
        try {
            if (!readDOMMethod(source, 'matches')(prefix))
                return [];
        }
        catch {
            return [];
        }
        return [
            `:is(:where(.${id}),${prefix}:not(*))${selector.slice(marker.offset)}`,
        ];
    });
    const needsFinalBase = (rules, parent = '') => rules.some((rule) => {
        var _a;
        if (rule.kind === 'style') {
            const selector = parent
                ? resolveNestedSelector(rule.selector, parent)
                : rule.selector;
            return ((selectorsFor(selector).length > 0 &&
                rule.declarations.some(({ value }) => hasRelativeStyleURL(value))) ||
                needsFinalBase(rule.rules, selector));
        }
        if (rule.kind === 'group') {
            if (rule.condition === 'media' && !mediaMatches(rule.text || ''))
                return false;
            if (rule.condition === 'supports' && !supports(rule.text || ''))
                return false;
            return needsFinalBase(rule.rules, parent);
        }
        if (rule.kind !== 'import' ||
            (rule.supports && !supports(rule.supports)) ||
            !mediaMatches(rule.media))
            return false;
        // A native imported sheet already carries its browser-resolved URL. Only
        // an unresolved relative import needs the parent's response directory.
        if ((_a = rule.sheet) === null || _a === void 0 ? void 0 : _a.href)
            return false;
        try {
            new URL(rule.href);
            return false;
        }
        catch {
            return true;
        }
    });
    const visit = async (rules, ruleBase, charset, parent = '') => {
        const values = [];
        for (let index = 0; index < rules.length; index++) {
            checkStylesheetCache(cache);
            const rule = rules[index];
            if (rule.kind === 'style') {
                const selector = parent
                    ? resolveNestedSelector(rule.selector, parent)
                    : rule.selector;
                const selectors = selectorsFor(selector);
                const declarations = rule.declarations
                    .filter(({ name }) => !selected || selected.includes(name))
                    .map(({ name, value, priority }) => {
                    const resolved = rewriteSVGStyleURLs(value, (url) => {
                        if (url.startsWith('#'))
                            return undefined;
                        try {
                            return new URL(url, ruleBase).href;
                        }
                        catch {
                            return undefined;
                        }
                    });
                    return `${name}:${resolved}${priority ? '!' + priority : ''};`;
                })
                    .join('');
                if (selectors.length && declarations) {
                    matched = true;
                    values.push(`${selectors.join(',')}{${declarations}}`);
                }
                if (rule.rules.length) {
                    // eslint-disable-next-line no-await-in-loop
                    const css = await visit(rule.rules, ruleBase, charset, selector);
                    if (css)
                        values.push(css);
                }
            }
            else if (rule.kind === 'import') {
                if ((rule.supports && !supports(rule.supports)) ||
                    !mediaMatches(rule.media))
                    continue;
                let href;
                try {
                    href = new URL(rule.href, ruleBase).href;
                }
                catch (error) {
                    report(rule.href, error);
                    continue;
                }
                // Native imported CSSOM remains authoritative when readable. Otherwise
                // the import must use the parent's actual final response directory.
                const sheet = rule.sheet || {
                    href,
                    base: href,
                    encoding: charset,
                    media: '',
                    disabled: false,
                };
                // eslint-disable-next-line no-await-in-loop
                const css = await visitSheet(sheet);
                values.push(rule.layer != null ? `@layer ${rule.layer}{${css}}` : css);
            }
            else if (rule.kind === 'group') {
                if (rule.condition === 'media' && !mediaMatches(rule.text || ''))
                    continue;
                if (rule.condition === 'supports' && !supports(rule.text || ''))
                    continue;
                // eslint-disable-next-line no-await-in-loop
                const css = await visit(rule.rules, ruleBase, charset, parent);
                if (css)
                    values.push(rule.condition ? css : `${rule.head}{${css}}`);
            }
            else if (rule.text.startsWith('@layer '))
                values.push(rule.text);
        }
        return values.join('\n');
    };
    const visitSheet = async (snapshot) => {
        if (snapshot.disabled || !mediaMatches(snapshot.media))
            return '';
        if (snapshot.href && active.has(snapshot.href))
            return '';
        let sheet = snapshot;
        try {
            if (!sheet.rules) {
                if (!sheet.href)
                    throw new Error(sheet.unreadable ||
                        'Unreadable native stylesheet has no resource URL');
                sheet = await parseRemoteStylesheet(sheet.href, sheet.encoding, ownedDocument, loader, cache);
            }
            else if (sheet.href && needsFinalBase(sheet.rules)) {
                // CSSStyleSheet.href can remain the pre-redirect URL. Keep live CSSOM
                // edits while taking only response-base metadata from the loader.
                const response = await remoteStylesheet(sheet.href, loader, cache);
                sheet = { ...sheet, base: response.base };
            }
            checkStylesheetCache(cache);
            if (active.has(sheet.base))
                return '';
            active.add(sheet.base);
            try {
                return await visit(sheet.rules || [], sheet.base, sheet.encoding);
            }
            finally {
                active.delete(sheet.base);
            }
        }
        catch (error) {
            report(snapshot.href || snapshot.base, error);
            return '';
        }
    };
    const result = [];
    for (let index = 0; index < snapshots.length; index++) {
        // eslint-disable-next-line no-await-in-loop
        result.push(await visitSheet(snapshots[index]));
    }
    return matched ? result.join('\n') : '';
}
function scrollbarMarker(selector) {
    let quote = '', bracket = 0, escaped = false;
    for (let offset = 0; offset < selector.length; offset++) {
        const char = selector[offset];
        if (escaped) {
            escaped = false;
            continue;
        }
        if (char === String.fromCharCode(92)) {
            escaped = true;
            continue;
        }
        if (quote) {
            if (char === quote)
                quote = '';
            continue;
        }
        if (char === '"' || char === "'") {
            quote = char;
            continue;
        }
        if (char === '[')
            bracket++;
        if (char === ']')
            bracket--;
        if (bracket || !selector.startsWith('::-webkit-', offset))
            continue;
        const part = parts.find((name) => {
            const end = offset + '::-webkit-'.length + name.length;
            return (selector.startsWith(name, offset + '::-webkit-'.length) &&
                (end === selector.length || selector[end] === ':'));
        });
        if (part)
            return { offset, part };
    }
    return undefined;
}
function splitSelectors(text) {
    const result = [];
    let start = 0, depth = 0, quote = '', escaped = false;
    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        if (escaped) {
            escaped = false;
            continue;
        }
        if (char === String.fromCharCode(92)) {
            escaped = true;
            continue;
        }
        if (quote) {
            if (char === quote)
                quote = '';
            continue;
        }
        if (char === '"' || char === "'") {
            quote = char;
            continue;
        }
        if (char === '(' || char === '[')
            depth++;
        if (char === ')' || char === ']')
            depth--;
        if (char === ',' && !depth) {
            result.push(text.slice(start, i));
            start = i + 1;
        }
    }
    result.push(text.slice(start));
    return result.map((selector) => selector.trim());
}
;window.__encodingProbe={cloneScrollbarStyles,takeSheetSnapshot,decodeCSS,ResourceLoader};})()