import {chromium,firefox,webkit} from 'playwright'
import {resolveNestedSelector} from '../../../src/css-nesting.ts'
import {mkdir,writeFile,readFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
const folder=new URL('./',import.meta.url);await mkdir(folder,{recursive:true})
const standard='<div class="scope" id="parent" data-probe><span id="target" data-probe class="target" data-text="&"></span><div><span id="deep" class="target" data-probe></span></div><span id="direct" class="direct" data-probe></span></div><div id="outside" class="target outside" data-probe data-text="&"></div>'
const cases=[
 {name:'explicit-parent',parent:'.scope',selector:'& > .target',html:standard},
 {name:'parent-list-max-specificity',parent:'#never, .scope',selector:'.target',html:standard,counter:'.scope .target{color:rgb(255,0,0)}'},
 {name:'child-list-implicit-and-relative',parent:'#never, .scope',selector:'.target, > .direct',html:standard},
 {name:'relative-sibling-combinators',parent:'.scope',selector:'+ .sibling, ~ .later',html:'<div class="scope" id="parent" data-probe></div><div id="sibling" class="sibling" data-probe></div><div id="later" class="later" data-probe></div>'},
 {name:'is-argument-parent',parent:'.scope',selector:':is(&, .outside)',html:standard},
 {name:'where-zero-specificity',parent:'#never, .scope',selector:':where(&) > .target',html:standard,counter:'.target{color:rgb(255,0,0)}'},
 {name:'double-nesting-specificity',parent:'#never, .scope',selector:'&& > .target',html:'<div id="counter">'+standard+'</div>',counter:'#counter .target{color:rgb(255,0,0)}'},
 {name:'attribute-string-ampersand',parent:'.scope',selector:'[data-text="&"]',html:standard},
 {name:'explicit-and-literal-ampersand',parent:'.scope',selector:'&[data-text="&"]',html:'<div class="scope" data-probe id="parent" data-text="&"></div><div data-probe id="outside" data-text="&"></div>'},
 {name:'attribute-string-comma',parent:'.scope, #never',selector:'[data-text="a,b"], .target',html:'<div class="scope"><span data-probe id="literal" data-text="a,b"></span><span data-probe id="target" class="target"></span></div><span data-probe id="outside" class="target"></span>'},
 {name:'escaped-literal-ampersand',parent:'.scope',selector:'.\\&',html:'<div class="scope"><span class="&" id="literal" data-probe></span></div><span class="&" id="outside" data-probe></span>'},
 {name:'escaped-comma-and-ampersand',parent:'.scope',selector:'.comma\\,amp\\&',html:'<div class="scope"><span class="comma,amp&" id="literal" data-probe></span></div><span class="comma,amp&" id="outside" data-probe></span>'},
 {name:'attribute-unquoted-escaped-ampersand',parent:'.scope',selector:'[data-text=\\&]',html:standard},
 {name:'quoted-escaped-quote-and-ampersand',parent:'.scope',selector:'[data-text="a\\\"&b"]',html:'<div class="scope"><span data-probe id="literal" data-text=\'a"&b\'></span></div><span data-probe id="outside" data-text=\'a"&b\'></span>'},
 {name:'comments-with-ampersand-and-comma',parent:'.scope',selector:'& /* a,& */ > .target, /* b,& */ [data-text="&"]',html:standard},
 {name:'parent-list-comment',parent:'.scope, /* ,& */ #never',selector:'& > .target',html:standard,counter:'.scope .target{color:rgb(255,0,0)}'},
 {name:'escaped-parent-ampersand',parent:'#root\\&, .scope',selector:'& > .target',html:'<div id="root&"><span class="target" data-probe id="target"></span></div><div class="scope"><span class="target" data-probe id="second"></span></div>'},
 {name:'escaped-trailing-space',parent:'.scope',selector:'#has\\ ',html:'<div class="scope"><span data-probe id="has "></span></div>'},
 {name:'nth-of-parent',parent:'.scope',selector:':nth-child(1 of &)',html:'<div><div class="scope" id="parent" data-probe></div><div class="scope" id="second" data-probe></div></div>'},
]
const source=await readFile(new URL('../../../src/css-nesting.ts',import.meta.url));const results={at:new Date().toISOString(),sourceSha256:createHash('sha256').update(source).digest('hex'),cases:[],libraryBuildUsed:false}
for(const[engine,type]of Object.entries({chromium,firefox,webkit})){
 const browser=await type.launch({headless:true})
 try{const page=await browser.newPage();await page.setContent('<!doctype html><meta charset="utf-8">')
 for(const c of cases){
  const expanded=resolveNestedSelector(c.selector,c.parent)
  const record=await page.evaluate(({c,expanded})=>{
   document.body.innerHTML=c.html
   const sheet=document.createElement('style');document.head.append(sheet)
   const base='[data-probe]{color:rgb(0,0,0);outline-color:rgb(0,0,0)}'
   const decl='color:rgb(0,128,0);outline-color:rgb(0,0,255)'
   sheet.textContent=base+c.parent+'{'+c.selector+'{'+decl+'}}'+(c.counter||'')
   const nativeRules=Array.from(sheet.sheet.cssRules,r=>({text:r.cssText,children:r.cssRules?Array.from(r.cssRules,x=>x.cssText):[]}))
   const values=()=>Array.from(document.querySelectorAll('[data-probe]'),x=>({id:x.id,color:getComputedStyle(x).color,outline:getComputedStyle(x).outlineColor}))
   const native=values()
   const nativeMeaningful=native.some(x=>x.outline==='rgb(0, 0, 255)')
   sheet.textContent=base+expanded+'{'+decl+'}'+(c.counter||'')
   const flatRules=Array.from(sheet.sheet.cssRules,r=>r.cssText)
   const flat=values()
   const same=JSON.stringify(native)===JSON.stringify(flat)
   const matchIds=Array.from(document.querySelectorAll(expanded),x=>x.id)
   sheet.remove()
   return {nativeRules,native,nativeMeaningful,flatRules,flat,same,matchIds}
  },{c,expanded})
  results.cases.push({engine,version:browser.version(),name:c.name,parent:c.parent,selector:c.selector,expanded,...record})
  console.log(engine,c.name,record.same&&record.nativeMeaningful?'PASS':'FAIL')
 }
 }finally{await browser.close()}
}
results.passed=results.cases.filter(x=>x.same&&x.nativeMeaningful).length;results.failed=results.cases.length-results.passed
const after=await readFile(new URL('../../../src/css-nesting.ts',import.meta.url));results.sourceUnchanged=createHash('sha256').update(after).digest('hex')===results.sourceSha256
await writeFile(new URL('native-results.json',folder),JSON.stringify(results,null,2)+'\n')
console.log(JSON.stringify({passed:results.passed,failed:results.failed,sourceUnchanged:results.sourceUnchanged}))
if(results.failed||!results.sourceUnchanged)process.exitCode=1
