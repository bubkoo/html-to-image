# CSS nesting selector resolver

The only production file written by this task is `src/css-nesting.ts`. It exports `resolveNestedSelector(selector: string, parent: string): string` and has no DOM or module dependencies.

Run the independent native comparison from the checkout root, using Node22's built-in type stripping and the installed Playwright1.64.1 browsers:

```sh
node --experimental-strip-types output/playwright/css-nesting-20261125/native-selectors.mjs
```

The script imports the actual TypeScript helper, constructs equivalent native CSS nesting and resolved flat stylesheets, and compares actual browser-computed color/outline values for every probe element. The outline property proves that the original nested rule matched something; cascade competitors check specificity behavior. This is not a string-expectation test.

`native-results.json` preserves native and expanded CSSOM, each element's computed values, matching IDs, engine versions and the helper SHA. All19 inputs are exercised in Chromium, Firefox and WebKit. No HTTP server, package build, existing test suite or phone is used. The helper bytes are hashed before/after. Each browser is closed in a finally block.

Replaying overwrites `native-results.json` and its console log if redirected. Preserve this evidence folder first when retaining the exact measured run.
