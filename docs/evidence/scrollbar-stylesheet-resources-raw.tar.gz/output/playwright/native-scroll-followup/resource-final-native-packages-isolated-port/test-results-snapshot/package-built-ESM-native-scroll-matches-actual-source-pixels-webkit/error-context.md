# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: package.test.ts >> built ESM: native scroll matches actual source pixels
- Location: test/browser/package.test.ts:59:9

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 23

- Array []
+ Array [
+   Object {
+     "error": "visible-text: native/capture channel 836: 255, expected 241
+ checkNativeScroll@http://127.0.0.1:4197/test/browser/fixtures/native-scroll.mjs:219:26
+ @
+ @",
+     "kind": "visible-text",
+   },
+   Object {
+     "error": "fractional: native/capture channel 657: 128, expected 96
+ checkNativeScroll@http://127.0.0.1:4197/test/browser/fixtures/native-scroll.mjs:219:26
+ @
+ @",
+     "kind": "fractional",
+   },
+   Object {
+     "error": "padding-shadow: native/capture channel 164: 0, expected 255
+ checkNativeScroll@http://127.0.0.1:4197/test/browser/fixtures/native-scroll.mjs:219:26
+ @
+ @",
+     "kind": "padding-shadow",
+   },
+ ]
```

# Test source

```ts
  82  |           if (!api?.createRenderer)
  83  |             throw new Error(`${format} createRenderer export is missing`)
  84  |           const fixtureURL =
  85  |             group === 'style-resources'
  86  |               ? '/test/browser/fixtures/scrollbar-style-resources.mjs'
  87  |               : `/test/browser/fixtures/native-${group}.mjs`
  88  |           const fixture = await import(fixtureURL)
  89  |           const kinds: string[] =
  90  |             group === 'scroll'
  91  |               ? fixture.nativeScrollCases
  92  |               : group === 'scrollbars'
  93  |                 ? fixture.nativeScrollbarCases
  94  |                 : fixture.scrollbarStyleResourceCases
  95  |           const check =
  96  |             group === 'scroll'
  97  |               ? fixture.checkNativeScroll
  98  |               : group === 'scrollbars'
  99  |                 ? fixture.checkNativeScrollbars
  100 |                 : fixture.checkScrollbarStyleResources
  101 |           const readNative = async (id: string) => {
  102 |             const png = await scope.__nativeScrollSourcePNG(id)
  103 |             const image = new Image()
  104 |             image.src = 'data:image/png;base64,' + png
  105 |             await image.decode()
  106 |             const canvas = document.createElement('canvas')
  107 |             canvas.width = image.naturalWidth
  108 |             canvas.height = image.naturalHeight
  109 |             const context = canvas.getContext('2d')!
  110 |             context.drawImage(image, 0, 0)
  111 |             return context.getImageData(0, 0, canvas.width, canvas.height)
  112 |           }
  113 |           const supportsLegacy = CSS.supports('selector(::-webkit-scrollbar)')
  114 |           const report = {
  115 |             format,
  116 |             group,
  117 |             userAgent: navigator.userAgent,
  118 |             dpr: devicePixelRatio,
  119 |             listed: kinds.length,
  120 |             executed: [] as string[],
  121 |             passed: [] as string[],
  122 |             failed: [] as { kind: string; error: string }[],
  123 |             unsupported: [] as { kind: string; reason: string }[],
  124 |           }
  125 |           for (let index = 0; index < kinds.length; index += 1) {
  126 |             const kind = kinds[index]
  127 |             if (
  128 |               (group === 'style-resources' ||
  129 |                 (group === 'scrollbars' && kind.startsWith('legacy'))) &&
  130 |               !supportsLegacy
  131 |             ) {
  132 |               report.unsupported.push({
  133 |                 kind,
  134 |                 reason: 'CSS.supports(selector(::-webkit-scrollbar)) is false',
  135 |               })
  136 |               continue
  137 |             }
  138 |             report.executed.push(kind)
  139 |             try {
  140 |               // Run every supported case even if another case fails. A warmed
  141 |               // replay or a successful later case never replaces its verdict.
  142 |               // eslint-disable-next-line no-await-in-loop
  143 |               await check(api, kind, readNative)
  144 |               report.passed.push(kind)
  145 |             } catch (error) {
  146 |               report.failed.push({
  147 |                 kind,
  148 |                 error:
  149 |                   ((error as Error).message || String(error)) +
  150 |                   '\n' +
  151 |                   ((error as Error).stack || ''),
  152 |               })
  153 |             }
  154 |           }
  155 |           return report
  156 |         },
  157 |         { format, group },
  158 |       )
  159 |       await testInfo.attach('native-source-pixel-verdicts', {
  160 |         body: JSON.stringify(report, null, 2),
  161 |         contentType: 'application/json',
  162 |       })
  163 |       report.unsupported.forEach(({ kind, reason }) => {
  164 |         testInfo.annotations.push({
  165 |           type: 'unsupported fixture',
  166 |           description: `${kind}: ${reason}`,
  167 |         })
  168 |       })
  169 |       expect(report.listed).toBeGreaterThan(0)
  170 |       if (
  171 |         !report.executed.length &&
  172 |         report.unsupported.length === report.listed
  173 |       )
  174 |         test.skip(true, 'Native scrollbar styling is not supported')
  175 |       expect(report.executed.length).toBeGreaterThan(0)
  176 |       expect(report.executed.length + report.unsupported.length).toBe(
  177 |         report.listed,
  178 |       )
  179 |       expect(report.passed.length + report.failed.length).toBe(
  180 |         report.executed.length,
  181 |       )
> 182 |       expect(report.failed).toEqual([])
      |                             ^ Error: expect(received).toEqual(expected) // deep equality
  183 |     })
  184 |   })
  185 | })
  186 | 
  187 | test('the full mobile smoke page completes without a hidden failure', async ({
  188 |   page,
  189 | }) => {
  190 |   await page.goto('/test/browser/smoke.html')
  191 |   const results = page.locator('#results')
  192 |   await expect(results).toContainText('REPORT SAVED', { timeout: 90000 })
  193 |   const text = await results.textContent()
  194 |   cases.forEach((name) => expect(text).toContain(`PASS ${name}`))
  195 |   expect(text).not.toContain('FAIL')
  196 |   expect(text).toContain('DPR=')
  197 |   const id = text?.match(/REPORT SAVED ([a-f0-9-]{36})/)?.[1]
  198 |   expect(id).toBeDefined()
  199 |   const report = JSON.parse(
  200 |     await readFile(`test-results/mobile-smoke-reports/${id}.json`, 'utf8'),
  201 |   )
  202 |   expect(report.id).toBe(id)
  203 |   expect(report.complete).toBe(true)
  204 |   expect(report.userAgent).toBeTruthy()
  205 |   expect(report.gitHead).toBe(
  206 |     execFileSync('git', ['rev-parse', 'HEAD']).toString().trim(),
  207 |   )
  208 |   expect(report.verdicts).toHaveLength(cases.length + 2)
  209 |   const rejected = await page.request.post(
  210 |     '/test/browser/mobile-smoke-report',
  211 |     { data: { complete: true } },
  212 |   )
  213 |   expect(rejected.status()).toBe(403)
  214 | })
  215 | 
  216 | test('built UMD global renders pixels in a browser', async ({ page }) => {
  217 |   await page.goto('/test/browser/umd.html')
  218 |   await page.addScriptTag({ url: '/dist/html-to-image.js' })
  219 |   const result = await page.evaluate(async () => {
  220 |     const node = document.getElementById('capture')!
  221 |     const api = (
  222 |       window as typeof window & {
  223 |         htmlToImage?: {
  224 |           toImageData: (
  225 |             node: HTMLElement,
  226 |             options: { pixelRatio: number; skipFonts: boolean },
  227 |           ) => Promise<ImageData>
  228 |         }
  229 |       }
  230 |     ).htmlToImage
  231 |     if (!api) throw new Error('UMD global missing')
  232 |     const image = await api.toImageData(node, {
  233 |       pixelRatio: 1,
  234 |       skipFonts: true,
  235 |     })
  236 |     const offset = 4 * (16 * image.width + 16)
  237 |     return {
  238 |       width: image.width,
  239 |       height: image.height,
  240 |       pixel: Array.from(image.data.slice(offset, offset + 4)),
  241 |     }
  242 |   })
  243 |   expect(result).toEqual({ width: 32, height: 32, pixel: [255, 0, 0, 255] })
  244 | })
  245 | 
  246 | test('built UMD validates explicit dimensions and preserves the scaled pixel buffer', async ({
  247 |   page,
  248 | }) => {
  249 |   await page.goto('/test/browser/umd.html')
  250 |   await page.addScriptTag({ url: '/dist/html-to-image.js' })
  251 |   const result = await page.evaluate(async () => {
  252 |     const api = (
  253 |       window as typeof window & {
  254 |         htmlToImage: typeof import('../../src')
  255 |       }
  256 |     ).htmlToImage
  257 |     const node = document.createElement('div')
  258 |     node.style.cssText = 'width:16px;height:12px;background:red'
  259 |     document.body.append(node)
  260 |     const renderer = api.createRenderer({ skipFonts: true, pixelRatio: 2 })
  261 |     try {
  262 |       const canvas = await renderer.toCanvas(node, {
  263 |         width: 24,
  264 |         height: 18,
  265 |         canvasWidth: 40,
  266 |         canvasHeight: 30,
  267 |       })
  268 |       const zeros = []
  269 |       const invalid = []
  270 |       const dimensions = ['width', 'height'] as const
  271 |       for (let i = 0; i < dimensions.length; i += 1) {
  272 |         const dimension = dimensions[i]
  273 |         // eslint-disable-next-line no-await-in-loop
  274 |         const capture = await renderer.capture(node, { [dimension]: 0 })
  275 |         let rasterError = ''
  276 |         try {
  277 |           // eslint-disable-next-line no-await-in-loop
  278 |           await capture.toCanvas()
  279 |         } catch (error) {
  280 |           rasterError = (error as Error).message
  281 |         }
  282 |         // eslint-disable-next-line no-await-in-loop
```