from pathlib import Path
import hashlib, json, tarfile, gzip, io, datetime, subprocess, sys, base64

root = Path('output/playwright')
base = root / 'native-scroll-followup'
dest = Path('docs/evidence')
source = sys.argv[1]
def sha(body): return hashlib.sha256(body).hexdigest()
def read(path): return json.loads(Path(path).read_text())
labels = ['resource-formatted-before-frozen', 'resource-formatted-after-frozen', 'resource-formatted-default', 'resource-formatted-full-source', 'resource-formatted-full-packages']
receipts = {label:read(base/label/'receipt.json') for label in labels}
for receipt in receipts.values(): assert receipt['inputsUnchanged'] and receipt['inputCount'] == 445
current_manifest = read(base/'resource-formatted-full-packages'/'inputs-after.json')
identity = {'sourceCommit': source, 'measuredHead': receipts[labels[-1]]['head'], 'inputCount':len(current_manifest), 'trackedMatches':True, 'generatedMatches':True, 'mismatches':[]}
for path, expected in current_manifest.items():
    current = Path(path).read_bytes()
    assert sha(current) == expected, path
    if path.startswith(('es/','lib/','dist/')): continue
    saved = subprocess.check_output(['git','show',source+':'+path])
    if sha(saved) != expected: identity['mismatches'].append(path)
assert not identity['mismatches']
(base/'resource-formatted-source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')

package = read(base/'resource-formatted-full-packages'/'run.log')
native = {'executed':0,'passed':0,'failed':0,'unsupported':0}
def walk(s):
    for spec in s.get('specs',[]):
        if ': native ' not in spec.get('title',''): continue
        for test in spec.get('tests',[]):
            for result in test.get('results',[]):
                for att in result.get('attachments',[]):
                    if att.get('contentType') != 'application/json' or not att.get('body'): continue
                    try: report = json.loads(base64.b64decode(att['body']))
                    except Exception: continue
                    if isinstance(report,dict) and all(isinstance(report.get(k),list) for k in native):
                        for k in native: native[k] += len(report[k])
    for child in s.get('suites',[]): walk(child)
for suite in package.get('suites',[]): walk(suite)

folders = [root/name for name in ['scrollbar-resource-validation-20261125','scrollbar-resource-plan-20261125','css-nesting-20261125','scrollbar-shadow-20261125','stylesheet-encoding-20261125','css-nested-declarations-20261125','stylesheet-cancellation-20261125','stylesheet-cancellation-20261125-after','native-svg-readiness-20261125']]
folders += [root/'webkit-followup-20261125'/name for name in ['nested-thumb-render','final-firefox-default-review','font-lifecycle-followup']]
folders += [p for p in base.iterdir() if p.is_dir() and p.name.startswith('resource-')]
files = {p for folder in folders for p in folder.rglob('*') if p.is_file()}
files |= {p for p in base.iterdir() if p.is_file() and (p.name.startswith(('run-resource','resource-formatted')) or p.name in ['run-source-check.py','run-default-check.py','run-package-check.py','compile-resource-evidence.py','audit-current-dom.cjs'])}
# Device screenshots contain unrelated phone UI and are deliberately not published.
files = sorted(p for p in files if not p.name.startswith(('iphone-mirroring','device-deferral')))
entries = [{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
archive = dest/'scrollbar-stylesheet-resources-raw.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for p in files:
                body=p.read_bytes(); info=tarfile.TarInfo(str(p)); info.size=len(body); info.mode=0o644; info.mtime=0; tar.addfile(info,io.BytesIO(body))
expected = {entry['path']:entry for entry in entries}
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers(); assert len(members)==len(entries)
    for member in members:
        body=tar.extractfile(member).read(); entry=expected[member.name]
        assert len(body)==entry['bytes'] and sha(body)==entry['sha256']
index={'schemaVersion':1,'sourceCommit':source,'fileCount':len(entries),'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'allMemberHashesVerified':True,'files':entries}
(dest/'scrollbar-stylesheet-resources-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
record={
 'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sourceCommit':source,'parentCheckpoint':'5c3b0fe309d0e37832318e54532b21805afc8bf5','originalNativeSource':'f3a00b069fadea920606b805221f1996711f09a9','branch':'codex/native-scroll-fidelity',
 'status':'scoped stylesheet resource repair verified; entire native fidelity candidate remains incomplete and unsubmitted',
 'relatedPRs':[376,407,408,585,427], 'relatedIssues':[81,345],
 'requirement':'Preserve the actual current browser page appearance; no change to the user-selected fidelity requirement.',
 'changes':['Snapshot live CSSOM into primitive DTOs before async work; preserve mutations, import ancestry and final-response URL bases.', 'Reuse capture ResourceLoader stylesheet policy/resolver/dedup; preserve response charset, parent import encoding, BOM/header/charset precedence.', 'Preserve nested selector specificity, CSSNestedDeclarations order and original pseudo-element parent selector; evaluate active source media/supports before relocation.', 'Freeze only clone auto axes with source overflow and actual physical scrollbar occupancy, after existing box restoration and before clone hooks.', 'Root-counted cache release; abort pending byte decode before source-owning async frames can resume; propagate exact warning-callback errors.'],
 'publicAPIChanged':False,
 'sameFinalFixtureComparison':{'onlyReplacedProductionFiles':['src/clone-node.ts','src/clone-scrollbars.ts','src/resource-loader.ts','src/svg-style-imports.ts'],'baseline':'f3a00b0','before':{'passed':2,'failed':62,'unsupportedFirefoxLegacy':32},'after':{'passed':64,'failed':0,'unsupportedFirefoxLegacy':32},'inputsStableWithinEachRun':True,'restoredCurrentFilesExactly':True,'evidence':'output/playwright/native-scroll-followup/resource-formatted-frozen-pair/receipt.json'},
 'validation':{
  'defaultPnpmTest':{'coveragePassed':1461,'coverageFailed':2,'coverageSkipped':45,'sourcePhase':'not run because coverage failed','failures':['WebKit visible-text','WebKit padding-shadow']},
  'separateFullSource':{'passed':1342,'failed':2,'skipped':45,'failures':['WebKit visible-text','WebKit padding-shadow']},
  'fullBuiltPackages':{'stats':package['stats'],'nativeFixtureCases':native,'nativeFailureCasesPerWebKitFormat':['visible-text','fractional','padding-shadow'],'fullResults':'output/playwright/native-scroll-followup/resource-formatted-full-packages/run.log'},
  'resourceSubset':{'sourceSupportedEngines':['chromium','webkit'],'sourceCasesPassed':64,'unsupportedFirefoxLegacy':32,'builtESMAndUMDResourceGroups':'all supported Chromium/WebKit groups passed; Firefox groups explicitly unsupported','notThreeEngineLegacyPixelAcceptance':True},
  'hostChecks':{'lint':'passed','buildESMCJSUMD':'passed','browserTypes':'passed','installedTarballConsumersAndTS49Current':'passed','DOMInterfaceStaticAuditDirectAccesses':0},
  'inputIdentity':identity,'remoteCI':'not run for this source; parent #650 green is separate','physicalDevice':'not performed; user deferred at least four hours from 2026-11-24T18:02:04Z; Mirroring connected then was quit, no product acceptance claimed'},
 'retainedEarlierFailures':{'initialDefault':{'passed':1458,'failed':5,'skipped':45,'extraFirefoxFailures':['positioned local-nested native screenshot timeout','SVG attribute-page native screenshot timeout','external SVG whole-style native preparation failed']},'initialFullSource':{'passed':1341,'failed':3,'skipped':45,'extraFirefoxFailure':'native HTTP SVG policy fixture not ready before source capture'},'sameInputFirefoxThreeFileRecheck':{'passed':117,'failed':0,'inputsMatchInitialDefault':True},'rootCause':'not established; later pass does not erase earlier failure. Original native controls, deadlines, retries and assertions retained.'},
 'independentFindings':{'cancelDecode':'same-script bounded Chromium native/source owner control passes after fix; WebKit native control inconclusive and Firefox legacy unsupported; not full capture GC proof','shadowSelectors':'simple host capability cannot generalize to complex :is/:where branches; per-rule native application remains open','nativeSVGReadiness':'25 original native-only probes pass; offscreen iframe scheduling delays established, original zero-geometry failure not reproduced','fontLifecycle':'61 fresh contexts distinguish SVGImage font cache initial-layout order; default Canvas retains 21-channel residual and software-zero result is bounded to one glyph input; no general runtime fix'},
 'remaining':['WebKit native glyph, inset shadow and DPR2 fractional SVG-image composition strict differences.','Actual native scrollbar part hover and ShadowRoot qualified-selector application.','Relative external SVG paint page/file provenance and original Windows/Edge/absent #81 fixture boundaries.','Failure-time evidence for intermittent Firefox native SVG preparation/screenshot gates.','Exact final source remote CI and deferred real-device acceptance.'],
 'rawEvidence':{'index':'scrollbar-stylesheet-resources-index.json','archive':archive.name,'fileCount':len(entries),'allMemberHashesVerified':True},
 'replay':'Checkout sourceCommit, build, then run recorded commands. Unpack raw archive at repository root for before/after source snapshots, receipts, HTTP probes, logs and failure traces. Each measured run kept 445 inputs unchanged; formatting is separately recorded and only changed 5 generated source maps, not runtime bundles. Never replace strict WebKit assertions or default DPR. Scope must remain explicit.',
 'oldPRCommentOrClosureActions':0,'npmPublished':False,'macNetworkConfigurationChanged':False
}
(dest/'scrollbar-stylesheet-resources.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(entries),'archiveBytes':archive.stat().st_size,'allMemberHashesVerified':True,'nativeCases':native}))
