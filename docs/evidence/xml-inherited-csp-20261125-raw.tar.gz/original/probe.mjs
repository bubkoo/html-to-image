import fs from 'node:fs/promises'
import { createHash, randomBytes } from 'node:crypto'
import { chromium, firefox, webkit } from 'playwright'

const dir = new URL('./', import.meta.url)
const umd = await fs.readFile(new URL('../../../dist/html-to-image.js', dir), 'utf8')
const sha = value => createHash('sha256').update(value).digest('hex')
const plan = ['unrestricted', 'script-none', 'different-nonce']
const results = { startedUTC: new Date().toISOString(), UMDsha256: sha(umd), guardMs: 2500, plan, cases: [] }
for (const [engine, implementation] of Object.entries({ chromium, firefox, webkit })) {
  for (const mode of plan) {
    const row = { engine, mode, HTTP: [], consoleErrors: [], navigation: [] }
    results.cases.push(row)
    const browser = await implementation.launch({ headless: true })
    let context
    try {
      context = await browser.newContext({ viewport: { width: 400, height: 200 } })
      const page = await context.newPage()
      row.version = browser.version()
      page.on('request', request => { if (/^https?:/.test(request.url())) row.HTTP.push(request.url()) })
      page.on('console', message => { if (message.type() === 'error') row.consoleErrors.push(message.text()) })
      page.on('framenavigated', frame => row.navigation.push(frame.url().slice(0, 150)))
      await page.addScriptTag({ content: umd })
      const callerPolicy = mode === 'script-none' ? "script-src 'none'" : mode === 'different-nonce' ? "script-src 'nonce-caller-only'" : ''
      row.callerPolicy = callerPolicy
      await page.setContent(`${callerPolicy ? `<meta http-equiv="Content-Security-Policy" content="${callerPolicy}">` : ''}<style>html,body{margin:0}</style><div id="source" style="width:40px;height:20px;background:red"></div>`)
      row.capture = await page.evaluate(async () => {
        const source = document.getElementById('source'), before = source.outerHTML
        const png = await htmlToImage.toPng(source)
        const image = new Image(); image.src = png; await image.decode()
        const canvas = document.createElement('canvas'); canvas.width = 40; canvas.height = 20
        const ctx = canvas.getContext('2d'); ctx.drawImage(image, 0, 0)
        const data = ctx.getImageData(0, 0, 40, 20).data
        let red = 0
        for (let i = 0; i < data.length; i += 4) if (data[i] === 255 && data[i + 1] === 0 && data[i + 2] === 0 && data[i + 3] === 255) red++
        return { width: image.width, height: image.height, redPixels: red, sourceUnchanged: source.outerHTML === before, png }
      })
      await fs.writeFile(new URL(`${engine}-${mode}-current.png`, dir), Buffer.from(row.capture.png.split(',')[1], 'base64'))
      delete row.capture.png
      const nonce = randomBytes(16).toString('base64'), marker = randomBytes(16).toString('hex')
      const measurement = `(()=>{const own=document.currentScript;own.remove();top.postMessage({marker:${JSON.stringify(marker)},kind:'xml-ready',contentType:document.contentType,width:document.documentElement.getBoundingClientRect().width,scriptRemoved:!own.isConnected},'*')})()`
      const xml = `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="20"><rect width="40" height="20" fill="red"/><script nonce="${nonce}"><![CDATA[${measurement}]]></script></svg>`
      const childURL = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml)
      const parentPolicy = `default-src 'none';script-src 'nonce-${nonce}';frame-src data:;style-src 'unsafe-inline' data:;img-src data:;font-src data:;connect-src 'none';object-src 'none';base-uri 'none';form-action 'none'`
      const parentScript = `(()=>{const frame=document.createElement('iframe');frame.sandbox='allow-scripts';frame.style.cssText='width:40px;height:20px;border:0';frame.src=${JSON.stringify(childURL)};document.body.append(frame)})()`
      const parentHTML = `<!doctype html><meta http-equiv="Content-Security-Policy" content="${parentPolicy}"><body><script nonce="${nonce}">${parentScript}</script>`
      row.parentPolicy = parentPolicy
      row.protocol = await page.evaluate(async ({ parentHTML, marker }) => {
        const owner = document.createElement('iframe'), source = document.getElementById('source'), before = source.outerHTML
        owner.sandbox = 'allow-scripts'; owner.inert = true
        owner.style.cssText = 'position:fixed;left:-10000px;width:40px;height:20px;border:0;opacity:0'
        let timer, listener
        try {
          return await new Promise(resolve => {
            listener = event => {
              if (event.data?.marker !== marker) return
              let sourceMatches = false
              try { sourceMatches = event.source === owner.contentWindow[0] } catch {}
              if (sourceMatches && event.origin === 'null') resolve({ message: event.data, sourceMatches, origin: event.origin })
            }
            addEventListener('message', listener)
            timer = setTimeout(() => resolve({ guardExpired: true }), 2500)
            owner.srcdoc = parentHTML; document.documentElement.append(owner)
          })
        } finally {
          clearTimeout(timer); removeEventListener('message', listener); owner.remove()
          window.__cleanup = { frames: document.querySelectorAll('iframe').length, sourceUnchanged: source.outerHTML === before }
        }
      }, { parentHTML, marker })
      row.cleanup = await page.evaluate(() => window.__cleanup)
    } catch (error) {
      row.error = String(error)
      row.stack = error.stack
    } finally {
      if (context) await context.close()
      await browser.close()
      row.closedUTC = new Date().toISOString()
      row.closed = true
      await fs.writeFile(new URL('results.json', dir), JSON.stringify(results, null, 2))
      console.log(JSON.stringify({ engine, mode, capture: row.capture, protocol: row.protocol, errors: row.consoleErrors.length, cleanup: row.cleanup, error: row.error }))
    }
  }
}
results.completedUTC = new Date().toISOString()
results.allBrowsersClosed = results.cases.every(row => row.closed)
await fs.writeFile(new URL('results.json', dir), JSON.stringify(results, null, 2))
