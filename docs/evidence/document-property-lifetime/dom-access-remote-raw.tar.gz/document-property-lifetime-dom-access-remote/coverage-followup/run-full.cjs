const fs=require('node:fs'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process')
const folder='.codex-linux-control/dom-coverage-followup';fs.mkdirSync(folder,{recursive:true})
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')
const browser='/ms-playwright/firefox-1555/firefox/omni.ja', stock='f975f204199e40fcb5a7545b44b90ca4e365c1344825c0a2248d1556b35951a3'
if(hash(browser)!==stock)throw Error('Firefox is not stock')
const receipt=[];const cache='node_modules/.vite/vitest';if(fs.existsSync(cache))for(const p of fs.readdirSync(cache,{recursive:true}).filter(p=>p.endsWith('results.json'))){const f=cache+'/'+p,bytes=fs.readFileSync(f);receipt.push({path:f,sha256:hash(f),base64:bytes.toString('base64')});fs.unlinkSync(f)}
fs.writeFileSync(folder+'/saved-results.json',JSON.stringify(receipt,null,2))
const manifest=label=>{if(spawnSync('node',['/tmp/hash-reflective-inputs.mjs',label],{stdio:'inherit'}).status!==0)throw Error('Hash collection failed');return JSON.parse(fs.readFileSync('.codex-linux-control/'+label+'-inputs.json'))}
const before=manifest('coverage-followup-before'),commands=[]
function run(name,args){const log=fs.openSync(folder+'/'+name+'.log','w'),start=new Date().toISOString();const r=spawnSync('pnpm',args,{stdio:['ignore',log,log]});fs.closeSync(log);commands.push({name,args,code:r.status,signal:r.signal,start,end:new Date().toISOString()});fs.writeFileSync(folder+'/progress.json',JSON.stringify(commands,null,2));console.log(name,r.status);return r.status===0}
try{if(run('targeted',['exec','vitest','run','--config','vitest.browser.config.mts','test/browser-unit/canvas-compatibility.test.ts'])){run('normal',['run','test'])}}
finally{const after=manifest('coverage-followup-after');const result={commands,inputs:Object.keys(before.files).length,allInputHashesStable:JSON.stringify(before.files)===JSON.stringify(after.files),stockBrowserSHA256:hash(browser)};fs.writeFileSync(folder+'/execution.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(!result.allInputHashesStable)throw Error('Measured inputs changed')}
if(commands.some(x=>x.code!==0))process.exitCode=1
