from pathlib import Path
import json,urllib.request,urllib.error,subprocess,hashlib,time,sys
folder=Path(__file__).parent

def manifest():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],text=True).split('\0')
    top={'package.json','pnpm-lock.yaml','vitest.browser.config.mts','playwright.config.ts','rollup.config.js','eslint.config.mjs','tsconfig.json','tsconfig.browser-tests.json'}
    paths=[p for p in paths if p.startswith(('src/','test/','scripts/')) or p in top]
    for name in ['es','lib','dist']:
        paths.extend(str(p) for p in Path(name).rglob('*') if p.is_file())
    paths.extend(str(folder/name) for name in ['entry.mjs','harness.js','run.py'])
    return {'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(set(paths))}}

before=manifest();assert before['gitHead']=='79faeece5fc11e8568a2126e296ad4a970a8d56c'
(folder/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
payload={'capabilities':{'alwaysMatch':{'browserName':'Safari','platformName':'iOS','safari:deviceType':'iPhone','safari:useSimulator':False}}}
request=urllib.request.Request('http://localhost:4444/session',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
try:
    session=json.load(urllib.request.urlopen(request,timeout=45))
except urllib.error.HTTPError as e:
    (folder/'session-error-private.json').write_bytes(e.read());print('Physical session could not be created; raw error retained locally',flush=True);sys.exit(2)
(folder/'session-private.json').write_text(json.dumps(session,indent=2)+'\n')
sid=session['value']['sessionId'];cap=session['value']['capabilities']
public={k:cap.get(k) for k in ['platformName','browserVersion','safari:platformVersion','safari:deviceType','safari:useSimulator']}
(folder/'capabilities-public.json').write_text(json.dumps(public,indent=2)+'\n')
print('Connected',json.dumps(public),flush=True)

def call(path,data=None,method=None,timeout=40):
    request=urllib.request.Request('http://localhost:4444/session/'+sid+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'},method=method)
    try:return json.load(urllib.request.urlopen(request,timeout=timeout))['value']
    except urllib.error.HTTPError as e:raise RuntimeError(e.read().decode())

def execute(script,args=None):return call('/execute/sync',{'script':script,'args':args or []})

try:
    call('/timeouts',{'pageLoad':20000,'script':60000})
    call('/url',{'url':'about:blank'})
    execute("document.open();document.write('<!doctype html><html lang=\"en\"><meta charset=\"utf-8\"><title>USB offline capture checks</title><style>body{font:16px system-ui}.case{margin:12px;padding:4px}</style><body><h1>USB offline capture checks</h1><pre id=\"results\">Running...</pre></body></html>');document.close();return document.readyState")
    for name in ['dist/html-to-image.js',str(folder/'harness.js')]:
        execute("const script=document.createElement('script');script.textContent=arguments[0];document.head.append(script);return typeof window.htmlToImage",[Path(name).read_text()])
    print('Loaded exact UMD SHA256',before['files']['dist/html-to-image.js'],flush=True)
    execute("window.__htiUSBPromise=window.runHTIUSBOffline().catch(error=>{window.__htiUSBOffline.fatal=String(error.stack||error);window.__htiUSBOffline.complete=true});return {started:true}")
    last=-1;state=None
    for step in range(600):
        state=execute('return window.__htiUSBOffline')
        (folder/'latest-state.json').write_text(json.dumps(state,indent=2)+'\n')
        count=len(state.get('verdicts',[]))
        if count!=last and (count//10!=last//10 or state.get('complete')):
            print('Progress',count,'/',state.get('total'),'current',state.get('currentCase'),flush=True);last=count
        if state.get('complete'):break
        time.sleep(1)
    assert state and state.get('complete'),'Offline fixture suite did not complete; preserve current live page and state'
    state['gitHead']=before['gitHead'];state['capabilities']=public
    state['passed']=sum(v['status']=='PASS' for v in state['verdicts']);state['failed']=sum(v['status']=='FAIL' for v in state['verdicts'])
    (folder/'result.json').write_text(json.dumps(state,indent=2)+'\n')
    print('Result',json.dumps({k:state.get(k) for k in ['complete','total','passed','failed','fatal','httpResources']}),flush=True)
    assert not state.get('fatal') and not state['failed']
    assert state['passed']==state['total']
    assert state['httpResources']==[],'Unexpected HTTP resource in offline probe'
finally:
    after=manifest();(folder/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
    same=before==after
    print('Inputs unchanged',same,'files',len(before['files']),flush=True)
    try:
        value=call('',method='DELETE')
        (folder/'session-ended.json').write_text(json.dumps({'ended':True,'value':value})+'\n')
    except Exception as e:
        (folder/'session-ended.json').write_text(json.dumps({'ended':False,'error':str(e)})+'\n')
    assert same,'Measured inputs changed during phone validation'
