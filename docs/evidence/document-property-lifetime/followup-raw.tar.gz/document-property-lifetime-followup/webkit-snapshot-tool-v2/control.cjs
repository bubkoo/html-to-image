const fs = require('node:fs');
const path = require('node:path');
const { spawn, execFileSync } = require('node:child_process');
const { webkit } = require('playwright');
const folder = __dirname;
const serverLog = fs.openSync(path.join(folder, 'server.log'), 'a');
const server = spawn(process.execPath, ['test/browser/server.mjs'], {
  cwd: '/work', env: { ...process.env, HTML_TO_IMAGE_SMOKE_HOST: '127.0.0.1', HTML_TO_IMAGE_SMOKE_PORT: '4173' },
  stdio: ['ignore', serverLog, serverLog],
});
let browser;
(async () => {
  for (let i = 0; i < 100; i++) {
    try { await fetch('http://127.0.0.1:4173/test/browser/control-not-found.html'); break; }
    catch { await new Promise(resolve => setTimeout(resolve, 30)); }
  }
  browser = await webkit.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  await page.goto('http://127.0.0.1:4173/test/browser/control-not-found.html');
  await page.setContent('<!doctype html><iframe id="test" src="/test/browser/inner-control-not-found.html" style="width:1280px;height:720px;border:0"></iframe>');
  const target = page.frames().find(frame => frame.parentFrame());
  if (!target) throw new Error('Test frame missing');
  await target.waitForLoadState('load');
  await target.evaluate(async () => {
    const api = await import('/es/index.js');
    const fixture = await import('/test/browser/fixtures/svg-fragment-paint.mjs');
    globalThis.__wkPolicy = await fixture.getSVGFragmentFixturePolicy();
    globalThis.__wkSamples = [];
    globalThis.__wkMake = async (kind) => {
      const source = document.implementation.createHTMLDocument();
      if (kind !== 'bare') {
        source.body.style.cssText = 'display:flex;margin:0;width:60px;height:20px;background:white';
        const href = new URL('/test/browser/fixtures/svg-fragment-pattern.svg#inline', location.href).href;
        source.body.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute"><defs><pattern id="fragment-paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="blue"/></pattern></defs></svg><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><use href="' + href + '" width="20" height="20"/></svg><div style="width:20px;height:20px;background:blue"></div><div style="width:20px;height:20px;background:yellow"></div>';
      }
      if (kind === 'held') globalThis.__wkHeld = { knownOwnedDocument: source };
      if (kind === 'native-clone') source.body.cloneNode(true);
      if (kind === 'capture') {
        const renderer = api.createRenderer({ width: 60, height: 20, pixelRatio: 1, skipFonts: true });
        try { return { reference: new WeakRef(source), capture: await renderer.capture(source.body), renderer }; }
        catch (error) { renderer.dispose(); throw error; }
      }
      return { reference: new WeakRef(source), completion: await Promise.resolve(0) };
    };
  });
  const receipts = [];
  const cases = ['bare', 'held'];
  for (let index = 0; index < cases.length; index++) {
    const kind = cases[index];
    await target.evaluate(async ({kind,index}) => { globalThis.__wkSamples[index] = await globalThis.__wkMake(kind); }, {kind,index});
    for (let i = 0; i < 3; i++) { await page.requestGC(); await target.evaluate(() => undefined); }
    const collected = await target.evaluate(index => globalThis.__wkSamples[index].reference.deref() === undefined, index);
    const record = { index, kind, collected, primaryCollections: 3, sampledBeforeRendering: true };
    receipts.push(record);
    fs.writeFileSync(path.join(folder, 'primaries.json'), JSON.stringify(receipts, null, 2) + '\n');
    console.log(JSON.stringify(record));
    if (kind === 'capture') {
      record.afterPrimaryOutput = await target.evaluate(async index => {
        const sample = globalThis.__wkSamples[index];
        try {
          const image = await sample.capture.toImageData();
          const offset = 4 * (10 * image.width + 10);
          const color = Array.from(image.data.slice(offset, offset + 4));
          const expected = globalThis.__wkPolicy.fragmentPage ? [0,0,255,255] : [0,128,0,255];
          return { width: image.width, height: image.height, color, expected, matches: color.join(',') === expected.join(',') };
        } finally { sample.renderer.dispose(); sample.capture = undefined; sample.renderer = undefined; }
      }, index);
    }
    fs.writeFileSync(path.join(folder, 'results.json'), JSON.stringify({ head: execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), browser: await browser.version(), receipts,
      scope: 'Separate standalone native/clone/capture controls in a nested frame; default browser, three GC requests plus original frame roundtrip; no inspection, no changed original assertion. Not actual full-suite failure graph or acceptance rerun.' }, null, 2) + '\n');
  }
  if (receipts[0].collected !== true || receipts[1].collected !== false) throw new Error('Weak/strong controls invalid');
  const implementation = page._connection.toImpl(page);
  const protocol = implementation.delegate._session;
  const snapshot = await protocol.send('Heap.snapshot');
  fs.writeFileSync(path.join(folder, 'snapshot.json'), snapshot.snapshotData);
  const graph = JSON.parse(snapshot.snapshotData);
  fs.writeFileSync(path.join(folder, 'snapshot-metadata.json'), JSON.stringify({timestamp:snapshot.timestamp,fields:Object.keys(graph), source:'stock WebKit Heap.snapshot after cached native positive/negative primaries; no SDK/browser patch'},null,2)+'\n');
  console.log('Snapshot fields',Object.keys(graph),'bytes',snapshot.snapshotData.length);

})().catch(error => { fs.writeFileSync(path.join(folder,'error.txt'),String(error.stack || error)); console.error(error); process.exitCode = 1; })
.finally(async () => { if (browser) await browser.close(); server.kill('SIGTERM'); fs.closeSync(serverLog); });
