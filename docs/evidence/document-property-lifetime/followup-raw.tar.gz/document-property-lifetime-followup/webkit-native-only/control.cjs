const fs = require('node:fs');
const path = require('node:path');
const { spawn, execFileSync } = require('node:child_process');
const { webkit } = require('playwright');
const folder = __dirname;
const serverLog = fs.openSync(path.join(folder, 'server.log'), 'a');
const server = spawn(process.execPath, ['test/browser/server.mjs'], {
  cwd: '/work', env: { ...process.env, HTML_TO_IMAGE_SMOKE_HOST: '127.0.0.1', HTML_TO_IMAGE_SMOKE_PORT: '4173' },
  stdio: ['ignore', serverLog, serverLog],
});
let browser;
(async () => {
  for (let i = 0; i < 100; i++) {
    try { await fetch('http://127.0.0.1:4173/test/browser/control-not-found.html'); break; }
    catch { await new Promise(resolve => setTimeout(resolve, 30)); }
  }
  browser = await webkit.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  await page.goto('http://127.0.0.1:4173/test/browser/control-not-found.html');
  await page.setContent('<!doctype html><iframe id="test" src="/test/browser/inner-control-not-found.html" style="width:1280px;height:720px;border:0"></iframe>');
  const target = page.frames().find(frame => frame.parentFrame());
  if (!target) throw new Error('Test frame missing');
  await target.waitForLoadState('load');
  await target.evaluate(async () => {
    const api = null;
    const fixture = await import('/test/browser/fixtures/svg-fragment-paint.mjs');
    globalThis.__wkPolicy = await fixture.getSVGFragmentFixturePolicy();
    globalThis.__wkSamples = []; globalThis.__wkNativeCopies = []; globalThis.__wkNativeSerials = [];
    globalThis.__wkMake = async (kind) => {
      const source = document.implementation.createHTMLDocument();
      if (kind !== 'bare') {
        source.body.style.cssText = 'display:flex;margin:0;width:60px;height:20px;background:white';
        const href = new URL('/test/browser/fixtures/svg-fragment-pattern.svg#inline', location.href).href;
        source.body.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute"><defs><pattern id="fragment-paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="blue"/></pattern></defs></svg><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><use href="' + href + '" width="20" height="20"/></svg><div style="width:20px;height:20px;background:blue"></div><div style="width:20px;height:20px;background:yellow"></div>';
      }
      if (kind === 'held') globalThis.__wkHeld = { knownOwnedDocument: source };
      if (kind === 'native-clone') source.body.cloneNode(true);
      if (kind.startsWith('native-style') || kind.startsWith('native-import') || kind.startsWith('source-')) {
        const before = source.body.outerHTML;
        const sourceNodes = [source.body, ...source.body.querySelectorAll('*')];
        let copyDocument;
        if (kind.startsWith('source-direct')) {
          copyDocument = source.implementation.createHTMLDocument();
          const base = copyDocument.createElement('base'); base.href = source.baseURI; copyDocument.head.append(base);
        } else if (kind.startsWith('source-reflect')) {
          copyDocument = Reflect.get(source,'implementation').createHTMLDocument();
          const base = Reflect.apply(Reflect.get(copyDocument,'createElement'),copyDocument,['base']); base.href = Reflect.get(source,'baseURI'); Reflect.get(copyDocument,'head').append(base);
        } else if (kind.startsWith('native-import')) copyDocument = document.implementation.createHTMLDocument();
        const copy = copyDocument?.importNode(source.body, true);
        if (copy && (copy.ownerDocument !== copyDocument || copy.ownerDocument === source)) throw new Error('Import document controls invalid');
        const copyNodes = copy ? [copy, ...copy.querySelectorAll('*')] : [];
        if (kind.includes('style')) {
          const strings = [];
          for (let i=0; i<sourceNodes.length; i++) {
            const style = window.getComputedStyle(sourceNodes[i]);
            let text = '';
            for (let j=0; j<style.length; j++) {
              const name = style[j];
              const value = style.getPropertyValue(name);
              text += name + ':' + value + ';';
              if (copyNodes[i]) copyNodes[i].style.setProperty(name,value,style.getPropertyPriority(name));
            }
            strings.push(text);
          }
          globalThis.__wkNativeSerials.push(strings.join('\n'));
        }
        if (copy) {
          globalThis.__wkNativeSerials.push(new XMLSerializer().serializeToString(copy));
          if (kind.endsWith('held')) globalThis.__wkNativeCopies.push({copyDocument,copy});
        }
        if (source.body.outerHTML !== before) throw new Error('Native control changed its source');
      }


      return { reference: new WeakRef(source), completion: await Promise.resolve(0) };
    };
  });
  const receipts = [];
  const requests=[]; page.on('request',request=>requests.push(request.url()));
  const kinds=['native','native-style','native-import-style','source-direct-import-style','source-reflect-import-style'];
  const cases=['bare','held',...Array.from({length:80},(_,i)=>kinds[i%kinds.length])];
  for (let index = 0; index < cases.length; index++) {
    const kind = cases[index];
    await target.evaluate(async ({kind,index}) => { globalThis.__wkSamples[index] = await globalThis.__wkMake(kind); }, {kind,index});
    for (let i = 0; i < 3; i++) { await page.requestGC(); await target.evaluate(() => undefined); }
    const collected = await target.evaluate(index => globalThis.__wkSamples[index].reference.deref() === undefined, index);
    const record = { index, kind, collected, primaryCollections: 3, sampledBeforeRendering: true };
    receipts.push(record);
    fs.writeFileSync(path.join(folder, 'primaries.json'), JSON.stringify(receipts, null, 2) + '\n');
    console.log(JSON.stringify(record));
    fs.writeFileSync(path.join(folder, 'results.json'), JSON.stringify({ head: execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), browser: await browser.version(), receipts,
      requests, libraryModuleRequested:requests.some(url=>/\/(es|src|dist)\//.test(new URL(url).pathname)), scope: 'Native-only style/import/serialization controls. No library imported or invoked, stock browser, three GC requests and original frame roundtrip. Original failure and production gates remain separate.' }, null, 2) + '\n');
  }
  if (requests.some(url=>/\/(es|src|dist)\//.test(new URL(url).pathname))) throw new Error('Native-only control loaded library code');
  if (receipts[0].collected !== true || receipts[1].collected !== false) throw new Error('Weak/strong controls invalid');
})().catch(error => { fs.writeFileSync(path.join(folder,'error.txt'),String(error.stack || error)); console.error(error); process.exitCode = 1; })
.finally(async () => { if (browser) await browser.close(); server.kill('SIGTERM'); fs.closeSync(serverLog); });
