const fs = require('node:fs');
const path = require('node:path');
const { spawn, execFileSync } = require('node:child_process');
const { webkit } = require('playwright');
const folder = __dirname;
const serverLog = fs.openSync(path.join(folder, 'server.log'), 'a');
const server = spawn(process.execPath, ['test/browser/server.mjs'], {
  cwd: '/work', env: { ...process.env, HTML_TO_IMAGE_SMOKE_HOST: '127.0.0.1', HTML_TO_IMAGE_SMOKE_PORT: '4173' },
  stdio: ['ignore', serverLog, serverLog],
});
let browser;
(async () => {
  for (let i = 0; i < 100; i++) {
    try { await fetch('http://127.0.0.1:4173/test/browser/control-not-found.html'); break; }
    catch { await new Promise(resolve => setTimeout(resolve, 30)); }
  }
  browser = await webkit.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  await page.goto('http://127.0.0.1:4173/test/browser/control-not-found.html');
  await page.setContent('<!doctype html><iframe id="test" src="/test/browser/inner-control-not-found.html" style="width:1280px;height:720px;border:0"></iframe>');
  const target = page.frames().find(frame => frame.parentFrame());
  if (!target) throw new Error('Test frame missing');
  await target.waitForLoadState('load');
  await target.evaluate(async () => {
    const api = await import('/es/index.js');
    const fixture = await import('/test/browser/fixtures/svg-fragment-paint.mjs');
    globalThis.__wkPolicy = await fixture.getSVGFragmentFixturePolicy();
    globalThis.__wkSamples = [];
    globalThis.__wkMake = async (kind) => {
      const source = document.implementation.createHTMLDocument();
      if (kind !== 'bare') {
        source.body.style.cssText = 'display:flex;margin:0;width:60px;height:20px;background:white';
        const href = new URL('/test/browser/fixtures/svg-fragment-pattern.svg#inline', location.href).href;
        source.body.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute"><defs><pattern id="fragment-paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="blue"/></pattern></defs></svg><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><use href="' + href + '" width="20" height="20"/></svg><div style="width:20px;height:20px;background:blue"></div><div style="width:20px;height:20px;background:yellow"></div>';
      }
      if (kind === 'held') globalThis.__wkHeld = { knownOwnedDocument: source };
      if (kind === 'native-clone') source.body.cloneNode(true);
      if (kind === 'capture') {
        const renderer = api.createRenderer({ width: 60, height: 20, pixelRatio: 1, skipFonts: true });
        try { return { reference: new WeakRef(source), capture: await renderer.capture(source.body), renderer }; }
        catch (error) { renderer.dispose(); throw error; }
      }
      return { reference: new WeakRef(source), completion: await Promise.resolve(0) };
    };
  });
  const takeRetainedSnapshot = async (retainedIndex) => {
  const implementation = page._connection.toImpl(page);
  const protocol = implementation.delegate._session;
  const snapshot = await protocol.send('Heap.snapshot');
  fs.writeFileSync(path.join(folder, 'snapshot.json'), snapshot.snapshotData);
  const graph = JSON.parse(snapshot.snapshotData);
  const afterSnapshot = await target.evaluate(index => globalThis.__wkSamples[index].reference.deref() === undefined, retainedIndex);
  fs.writeFileSync(path.join(folder,'post-snapshot-state.json'),JSON.stringify({retainedIndex,collectedAfterSnapshot:afterSnapshot,phase:'after immutable raw snapshot; does not replace primary false'})+'\n');
  fs.writeFileSync(path.join(folder, 'snapshot-metadata.json'), JSON.stringify({timestamp:snapshot.timestamp,fields:Object.keys(graph), source:'stock WebKit Heap.snapshot after saved retained primary and one post-primary task; native identity handles only after immutable snapshot; no SDK/browser patch'},null,2)+'\n');
  console.log('Snapshot fields',Object.keys(graph),'bytes',snapshot.snapshotData.length);

  if (graph.version !== 3 || graph.type !== 'Inspector' || graph.nodes.length % 4 || graph.edges.length % 4) throw new Error('Unexpected heap format');
  const ids = new Set(); const documents = [];
  for (let i=0; i<graph.nodes.length; i+=4) {
    if (ids.has(graph.nodes[i])) throw new Error('Duplicate heap node');
    ids.add(graph.nodes[i]);
    if (graph.nodeClassNames[graph.nodes[i+2]] === 'HTMLDocument') documents.push(graph.nodes[i]);
  }
  const known = [];
  for (let i=0; i<graph.edges.length; i+=4) {
    if (!ids.has(graph.edges[i]) || !ids.has(graph.edges[i+1])) throw new Error('Invalid heap edge');
    if (graph.edgeTypes[graph.edges[i+2]] === 'Property' && graph.edgeNames[graph.edges[i+3]] === 'knownOwnedDocument') known.push(graph.edges[i+1]);
  }
  const group = 'hti-mapping-only-after-snapshot';
  const mappings = []; const errors = []; const excludedWorlds = [];
  for (const [label,index] of [['negative',0],['positive',1],['retained',retainedIndex]]) {
    const handle = await target.evaluateHandle(index => globalThis.__wkSamples[index].reference, index);
    const referenceId = page._connection.toImpl(handle)._objectId;
    const matches = [];
    try {
      for (const heapObjectId of documents) {
        try {
          const remote = await protocol.send('Heap.getRemoteObject', {heapObjectId,objectGroup:group});
          if (!remote.result.objectId) continue;
          if (JSON.parse(remote.result.objectId).injectedScriptId !== JSON.parse(referenceId).injectedScriptId) { excludedWorlds.push({label,heapObjectId,reason:'different injected-script world'}); continue; }
          const comparison = await protocol.send('Runtime.callFunctionOn', {
            objectId: remote.result.objectId,
            functionDeclaration: 'function(reference) { return reference.deref() === this; }',
            arguments: [{objectId:referenceId}],returnByValue:true,
          });
          if (comparison.wasThrown) throw new Error(comparison.result.description);
          if (comparison.result.value === true) matches.push(heapObjectId);
        } catch (error) { errors.push({label,heapObjectId,error:String(error)}); }
      }
    } finally { await handle.dispose(); }
    mappings.push({label,index,matches});
  }
  await protocol.send('Runtime.releaseObjectGroup',{objectGroup:group});
  const mapping = {knownOwnedDocument:known,mappings,candidateDocuments:documents,errors,excludedWorlds,
    phase:'All native getRemoteObject strong handles and WeakRef dereferences occur strictly after the immutable raw snapshot. Mapping roots are not claimed as raw-snapshot roots. Handles released before browser close.'};
  fs.writeFileSync(path.join(folder,'mapping.json'),JSON.stringify(mapping,null,2)+'\n');
  if (known.length !== 1 || mappings[0].matches.length || mappings[1].matches.length !== 1 || mappings[1].matches[0] !== known[0]) throw new Error('Snapshot identity controls did not match');
  console.log('Snapshot identity controls matched',JSON.stringify(mappings),'candidate errors',errors.length);
  if (errors.length) throw new Error('Unexpected mapping errors');

  };
  const receipts = [];
  const cases = ['bare', 'held', 'native', 'native-clone', ...Array.from({ length: 128 }, (_, i) => i % 2 ? 'capture' : 'native')];
  for (let index = 0; index < cases.length; index++) {
    const kind = cases[index];
    await target.evaluate(async ({kind,index}) => { globalThis.__wkSamples[index] = await globalThis.__wkMake(kind); }, {kind,index});
    for (let i = 0; i < 3; i++) { await page.requestGC(); await target.evaluate(() => undefined); }
    const collected = await target.evaluate(index => globalThis.__wkSamples[index].reference.deref() === undefined, index);
    const record = { index, kind, collected, primaryCollections: 3, sampledBeforeRendering: true };
    receipts.push(record);
    fs.writeFileSync(path.join(folder, 'primaries.json'), JSON.stringify(receipts, null, 2) + '\n');
    console.log(JSON.stringify(record));
    if (kind === 'capture' && !collected) {
      fs.writeFileSync(path.join(folder,'retained-primary.json'),JSON.stringify({...record,phase:'before task yield, heap snapshot, native object mapping or rendering'},null,2)+'\n');
      await target.evaluate(() => new Promise(resolve => setTimeout(resolve, 0)));
      await takeRetainedSnapshot(index);
      fs.writeFileSync(path.join(folder,'retained-result.json'),JSON.stringify({retainedIndex:index,originalPrimaryFailed:true,postPrimaryTaskYields:1,heapSnapshotTaken:true,originalCollections:3,sourceRenderedBeforeSnapshot:false},null,2)+'\n');
      process.exitCode = 1;
      break;
    }

    if (kind === 'capture') {
      record.afterPrimaryOutput = await target.evaluate(async index => {
        const sample = globalThis.__wkSamples[index];
        try {
          const image = await sample.capture.toImageData();
          const offset = 4 * (10 * image.width + 10);
          const color = Array.from(image.data.slice(offset, offset + 4));
          const expected = globalThis.__wkPolicy.fragmentPage ? [0,0,255,255] : [0,128,0,255];
          return { width: image.width, height: image.height, color, expected, matches: color.join(',') === expected.join(',') };
        } finally { sample.renderer.dispose(); sample.capture = undefined; sample.renderer = undefined; }
      }, index);
    }
    fs.writeFileSync(path.join(folder, 'results.json'), JSON.stringify({ head: execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), browser: await browser.version(), receipts,
      scope: 'Separate standalone native/clone/capture controls in a nested frame; default browser, three GC requests plus original frame roundtrip; no inspection, no changed original assertion. Not actual full-suite failure graph or acceptance rerun.' }, null, 2) + '\n');
  }
  if (receipts[0].collected !== true || receipts[1].collected !== false) throw new Error('Weak/strong controls invalid');
})().catch(error => { fs.writeFileSync(path.join(folder,'error.txt'),String(error.stack || error)); console.error(error); process.exitCode = 1; })
.finally(async () => { if (browser) await browser.close(); server.kill('SIGTERM'); fs.closeSync(serverLog); });
