const { firefox } = require('playwright')
const fs = require('node:fs')
const path = require('node:path')
const http = require('node:http')
const folder = __dirname
const records = []
const server = http.createServer((request, response) => {
  const pathname = new URL(request.url, 'http://localhost').pathname
  let file
  let type = 'text/javascript'
  if (pathname === '/') {
    response.writeHead(200, { 'Content-Type': 'text/html' }).end(
      '<!doctype html><body><script type="module">import{startCase}from"/fixture.mjs";window.startCase=startCase</script>',
    )
    return
  }
  if (pathname === '/fixture.mjs') file = path.join(folder, 'fixture.mjs')
  else if (pathname.startsWith('/es/')) {
    file = path.resolve('.' + pathname)
    if (!file.startsWith(path.resolve('es') + path.sep)) file = undefined
  } else if (pathname === '/test/browser/fixtures/font-metrics.ttf') {
    file = path.resolve('.' + pathname)
    type = 'font/ttf'
  }
  if (!file) return response.writeHead(404).end()
  try {
    response.writeHead(200, { 'Content-Type': type }).end(fs.readFileSync(file))
  } catch {
    response.writeHead(404).end()
  }
})

async function inspect(page, primary) {
  await page.evaluate((targetKind) => {
    Reflect.set(globalThis, '__codex_ref_probe', {
      __codexHeap: true,
      reference: globalThis.__sourcePair[targetKind].reference,
    })
  }, primary.targetKind)
  const handle = await page.evaluateHandle(() => globalThis.__codex_ref_probe)
  try {
    const properties = await handle.getProperties()
    const value = await properties.get('__codex_heap_paths')?.jsonValue()
    if (typeof value !== 'string') throw new Error('Probe result missing')
    const graph = JSON.parse(value)
    fs.writeFileSync(path.join(folder, 'first-retained-graph.json'), JSON.stringify({ primary, graph }, null, 2))
    for (const [source, name] of [
      [graph.file, 'first-retained.fxsnapshot'],
      [graph.cc?.gcFile, 'first-retained.gc.log'],
      [graph.cc?.file, 'first-retained.cc.log'],
    ]) if (source) fs.copyFileSync(source, path.join(folder, name))
    return { targetPresent: !!graph.ids?.target, errors: graph.errors, targetState: graph.targetState }
  } finally {
    await handle.dispose()
    await page.evaluate(() => Reflect.deleteProperty(globalThis, '__codex_ref_probe'))
  }
}

;(async () => {
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const browser = await firefox.launch()
  let result
  try {
    const page = await browser.newPage()
    await page.goto(`http://127.0.0.1:${server.address().port}/`)
    await page.waitForFunction(() => typeof window.startCase === 'function')
    await page.evaluate(() => {
      const positive = document.implementation.createHTMLDocument()
      const negative = document.implementation.createHTMLDocument()
      globalThis.__codexKnownOwner = { knownOwnedDocument: positive }
      globalThis.__positiveReference = new WeakRef(positive)
      globalThis.__negativeReference = new WeakRef(negative)
    })
    const states = [[false, false], [true, false], [false, true], [true, true]]
    for (let index = 0; index < 64; index++) {
      const [font, opened] = states[index % states.length]
      const preserved = await page.evaluate(async ({ font, opened }) => window.startCase(font, opened), { font, opened })
      for (let request = 0; request < 3; request++) {
        await page.requestGC()
        await page.evaluate(() => undefined)
      }
      const primary = await page.evaluate(() => ({
        nativeCollected: globalThis.__sourcePair.native.reference.deref() === undefined,
        heldCollected: globalThis.__sourcePair.held.reference.deref() === undefined,
        positiveHeld: globalThis.__positiveReference.deref() !== undefined,
        negativeCollected: globalThis.__negativeReference.deref() === undefined,
      }))
      Object.assign(primary, { index, font, opened, preserved, collectionRequests: 3, phase: 'cached-before-inspection' })
      records.push(primary)
      fs.writeFileSync(path.join(folder, 'primaries.json'), JSON.stringify(records, null, 2))
      if (!primary.positiveHeld || !primary.negativeCollected) throw new Error('Native collection controls invalid')
      if (!primary.nativeCollected || !primary.heldCollected) {
        primary.targetKind = primary.nativeCollected ? 'held' : 'native'
        fs.writeFileSync(path.join(folder, 'first-retained-primary.json'), JSON.stringify(primary, null, 2))
        console.log('Cached retained primary', JSON.stringify(primary))
        result = { outcome: 'retained-primary', inspection: await inspect(page, primary) }
        break
      }
      if ((index + 1) % 8 === 0) console.log('Collected pairs', index + 1)
    }
    result ||= { outcome: 'all-collected-within-bound', inspection: 'not run; no failed primary' }
    result.attemptedPairs = records.length
    result.source = JSON.parse(fs.readFileSync(path.join(folder, 'fixture-origin.json')))
    result.scope = 'Standalone repeated original source/font/environment helpers using current built ESM; not the original Vitest gate or a pure no-library control'
    fs.writeFileSync(path.join(folder, 'result.json'), JSON.stringify(result, null, 2))
    console.log('Result', JSON.stringify(result))
    if (result.outcome === 'retained-primary') process.exitCode = 1
  } finally {
    await browser.close()
    await new Promise((resolve) => server.close(resolve))
  }
})().catch((error) => {
  fs.writeFileSync(path.join(folder, 'error.json'), JSON.stringify({ message: error.message, stack: error.stack }, null, 2))
  console.error(error)
  server.close()
  process.exitCode = 2
})
