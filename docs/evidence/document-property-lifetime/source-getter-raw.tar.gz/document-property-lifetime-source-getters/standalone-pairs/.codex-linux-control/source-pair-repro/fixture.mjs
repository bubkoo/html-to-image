import { createSVGStyleEnvironment } from '/es/svg-style-scope.js';
function fontState(doc) {
    const state = [];
    doc.fonts.forEach((font) => state.push(font.family + ':' + font.status));
    return state;
}
async function sourceFrame(font, opened, keepOwner) {
    const frame = document.createElement('iframe');
    const loaded = new Promise((resolve) => {
        frame.onload = () => resolve();
    });
    const family = 'Source Lifetime ' + crypto.randomUUID();
    frame.srcdoc =
        '<!doctype html><style>' +
            (font
                ? `@font-face{font-family:"${family}";src:url("/test/browser/fixtures/font-metrics.ttf")}`
                : '') +
            '</style><body>Owned source font lifetime</body>';
    document.body.append(frame);
    let environment;
    try {
        await loaded;
        frame.onload = null;
        const doc = frame.contentDocument;
        if (font) {
            const faces = await doc.fonts.load(`20px "${family}"`, 'A');
            if (faces.length !== 1 || faces[0].status !== 'loaded')
                throw new Error('Source font positive control did not load');
            await doc.fonts.ready;
        }
        const markup = doc.documentElement.outerHTML;
        const fonts = fontState(doc);
        if (keepOwner) {
            environment = createSVGStyleEnvironment(doc);
            if (opened)
                await environment.getDocument();
            environment.dispose();
        }
        return {
            environment,
            reference: new WeakRef(doc),
            sourceUnchanged: markup === doc.documentElement.outerHTML,
            beforeFonts: fonts,
            afterFonts: fontState(doc),
        };
    }
    finally {
        environment?.dispose();
        frame.remove();
    }
}
export async function startCase(font, opened) {
    const frames = Array.from(document.querySelectorAll('iframe'));
    const native = await sourceFrame(font, opened, false);
    const held = await sourceFrame(font, opened, true);
    const valid = native.sourceUnchanged && held.sourceUnchanged && JSON.stringify(native.beforeFonts) === JSON.stringify(native.afterFonts) && JSON.stringify(held.beforeFonts) === JSON.stringify(held.afterFonts) && held.beforeFonts.length === (font ? 1 : 0) && Array.from(document.querySelectorAll('iframe')).length === frames.length && frames.every((frame,index) => document.querySelectorAll('iframe')[index] === frame);
    if (!valid)
        throw new Error('Original DOM/font/frame preservation control failed');
    globalThis.__sourcePair = { native, held };
    return { valid, font, opened, fonts: held.beforeFonts.length, frames: frames.length };
}
