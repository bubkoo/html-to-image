// Keep a Document-specific property access out of long-lived caller scripts.
// Reflect.get uses the same receiver and own/inherited getters as target[key].
export function readDocumentProperty(target, key) {
	return Reflect.get(target, key);
}
// Resolve the getter before the caller evaluates its arguments, then use the
// original receiver. Forwarding the method type preserves DOM overloads.
export function readDocumentMethod(target, key) {
	const method = Reflect.get(target, key);
	return ((...args) => Reflect.apply(method, target, args));
}
export function readOptionalDocumentProperty(target, key) {
	return target == null ? undefined : readDocumentProperty(target, key);
}
