import { readDocumentMethod, readDocumentProperty, readOptionalDocumentProperty } from "./document.js";
import { clonePseudoElements } from "./clone-pseudos.js";
import { createImage, toArray, isInstanceOfElement, getStyleProperties } from "./util.js";
import { getMimeType } from "./mimes.js";
import { resourceToDataURL } from "./dataurl.js";
import { getTask } from "./task.js";
import { embedSVGReferences, getSVGReference } from "./svg-references.js";
import { cloneScrollState } from "./clone-scroll.js";
function createCloneDocument(source) {
	// A detached element in a browsing document can still load resources in
	// WebKit when styles or image loading attributes change.
	const copy = readDocumentProperty(source, "implementation").createHTMLDocument();
	const base = Reflect.apply(readDocumentProperty(copy, "createElement"), copy, ["base"]);
	base.href = readDocumentProperty(source, "baseURI");
	readDocumentProperty(copy, "head").append(base);
	return copy;
}
async function cloneCanvasElement(canvas, options) {
	const dataURL = canvas.toDataURL();
	if (dataURL === "data:,") {
		return canvas.cloneNode(false);
	}
	return createImage(dataURL, options);
}
async function cloneVideoElement(video, options) {
	if (!video.poster && video.readyState === video.HAVE_NOTHING) {
		// No media image exists yet; preserve the styled, transparent replaced box.
		const empty = readDocumentMethod(document, "createElement")("canvas");
		return createImage(empty.toDataURL(), options);
	}
	if (video.currentSrc) {
		const canvas = readDocumentMethod(document, "createElement")("canvas");
		const ctx = canvas.getContext("2d");
		canvas.width = video.videoWidth;
		canvas.height = video.videoHeight;
		ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
		const dataURL = canvas.toDataURL();
		return createImage(dataURL, options);
	}
	const poster = video.poster;
	const contentType = getMimeType(poster);
	const dataURL = await resourceToDataURL(poster, contentType, options);
	return createImage(dataURL, options);
}
async function cloneIFrameElement(iframe, options, targetDocument, resolveSymbols) {
	let sourceBody = null;
	try {
		sourceBody = readOptionalDocumentProperty(iframe.contentDocument, "body") || null;
	} catch {}
	if (sourceBody) {
		const body = await cloneNode(sourceBody, options, true, resolveSymbols, targetDocument);
		const viewport = readDocumentMethod(targetDocument, "createElement")("div");
		viewport.appendChild(body);
		return viewport;
	}
	return readDocumentMethod(targetDocument, "importNode")(iframe, false);
}
async function cloneSingleNode(node, options, targetDocument, resolveSymbols) {
	if (isInstanceOfElement(node, HTMLCanvasElement)) {
		return readDocumentMethod(targetDocument, "adoptNode")(await cloneCanvasElement(node, options));
	}
	if (isInstanceOfElement(node, HTMLVideoElement)) {
		return readDocumentMethod(targetDocument, "adoptNode")(await cloneVideoElement(node, options));
	}
	if (isInstanceOfElement(node, HTMLIFrameElement)) {
		return cloneIFrameElement(node, options, targetDocument, resolveSymbols);
	}
	const copy = readDocumentMethod(targetDocument, "importNode")(node, false);
	if (isInstanceOfElement(node, HTMLImageElement)) {
		// Keep the source document's URL resolution when importing iframe content.
		;
		copy.src = node.src;
	} else if (isInstanceOfElement(node, SVGImageElement)) {
		const href = getSVGReference(node);
		if (href) {
			try {
				copy.setAttribute("href", new URL(href, node.baseURI).href);
				copy.removeAttributeNS("http://www.w3.org/1999/xlink", "href");
			} catch {}
		}
	}
	return copy;
}
const isSlotElement = (node) => node.tagName != null && node.tagName.toUpperCase() === "SLOT";
async function cloneChildren(nativeNode, clonedNode, options, targetDocument, resolveSymbols) {
	let children;
	if (isSlotElement(nativeNode) && nativeNode.assignedNodes) {
		const assigned = nativeNode.assignedNodes();
		children = toArray(assigned.length ? assigned : nativeNode.childNodes);
	} else if (isInstanceOfElement(nativeNode, HTMLIFrameElement)) {
		// The iframe adapter has already cloned its body and descendants.
		return clonedNode;
	} else {
		children = toArray((nativeNode.shadowRoot ?? nativeNode).childNodes);
	}
	if (children.length === 0 || isInstanceOfElement(nativeNode, HTMLVideoElement)) {
		return clonedNode;
	}
	await children.reduce((deferred, child) => deferred.then(() => cloneNode(child, options, false, resolveSymbols, targetDocument)).then((clonedChild) => {
		if (clonedChild) {
			clonedNode.appendChild(clonedChild);
		}
	}), Promise.resolve());
	return clonedNode;
}
function cloneCSSStyle(nativeNode, clonedNode, options, selected, isRoot) {
	const targetStyle = clonedNode.style;
	if (!targetStyle) {
		return;
	}
	const sourceStyle = (readDocumentProperty(nativeNode.ownerDocument, "defaultView") || window).getComputedStyle(nativeNode);
	if (sourceStyle.cssText && selected == null) {
		targetStyle.cssText = sourceStyle.cssText;
		targetStyle.transformOrigin = sourceStyle.transformOrigin;
	} else {
		let inheritedStyle;
		const task = getTask(options);
		const shadowHost = nativeNode.getRootNode().host;
		const parent = isRoot ? null : nativeNode.assignedSlot || nativeNode.parentElement || shadowHost;
		getStyleProperties(sourceStyle, selected).forEach((name) => {
			let value = sourceStyle.getPropertyValue(name);
			if (selected == null && parent && name.startsWith("--")) {
				// Equal inherited variables are already available from the copied ancestor.
				if (task) {
					if (value === task.getInheritedStyleValue(parent, name)) return;
				} else {
					inheritedStyle ||= (readDocumentProperty(nativeNode.ownerDocument, "defaultView") || window).getComputedStyle(parent);
					if (value === inheritedStyle.getPropertyValue(name)) return;
				}
			}
			if (name === "display" && value === "inline" && isInstanceOfElement(nativeNode, HTMLIFrameElement)) {
				value = "block";
			}
			if (name === "d" && clonedNode.getAttribute("d")) {
				value = `path(${clonedNode.getAttribute("d")})`;
			}
			targetStyle.setProperty(name, value, sourceStyle.getPropertyPriority(name));
		});
	}
	return sourceStyle;
}
function restoreScrollbarBox(nativeNode, clonedNode, sourceStyle, selected) {
	const targetStyle = clonedNode.style;
	if (sourceStyle.boxSizing === "content-box" && [
		"auto",
		"scroll",
		"hidden"
	].some((value) => sourceStyle.overflowX === value || sourceStyle.overflowY === value)) {
		const px = (name) => parseFloat(sourceStyle.getPropertyValue(name)) || 0;
		const restore = (dimension, offset, start, end) => {
			const horizontal = sourceStyle.writingMode === "horizontal-tb";
			const logical = dimension === "width" ? horizontal ? "inline-size" : "block-size" : horizontal ? "block-size" : "inline-size";
			if (selected && !selected.includes(dimension) && !selected.includes(logical)) return;
			const axis = dimension === "width" ? "overflow-y" : "overflow-x";
			const targetOverflow = targetStyle.getPropertyValue(axis) || targetStyle.getPropertyValue(logical === "inline-size" ? "overflow-block" : "overflow-inline");
			// Legacy scroll encoding hides the native gutter and uses its content
			// viewport. Restore the outer box only when that gutter is retained.
			const keepsStableGutter = targetOverflow === "hidden" && logical === "inline-size" && sourceStyle.getPropertyValue("scrollbar-gutter").includes("stable");
			if (targetOverflow !== sourceStyle.getPropertyValue(axis) && !keepsStableGutter) return;
			const used = parseFloat(sourceStyle.getPropertyValue(dimension));
			if (!Number.isFinite(used) || !Number.isFinite(offset)) return;
			const edges = px(`padding-${start}`) + px(`padding-${end}`) + px(`border-${start}-width`) + px(`border-${end}-width`);
			const gutter = offset - Math.round(used + edges);
			if (gutter <= 0) return;
			// CSSOM resolves a content-box dimension after subtracting its gutter.
			// A second scroll container must start from the original box dimension,
			// otherwise it subtracts the same scrollbar space again.
			const property = selected && !selected.includes(dimension) ? logical : dimension;
			targetStyle.removeProperty(property);
			targetStyle.setProperty(property, `${used + gutter}px`);
		};
		restore("width", nativeNode.offsetWidth, "left", "right");
		restore("height", nativeNode.offsetHeight, "top", "bottom");
	}
}
function cloneInputValue(nativeNode, clonedNode) {
	if (isInstanceOfElement(nativeNode, HTMLTextAreaElement)) {
		clonedNode.textContent = nativeNode.value;
	}
	if (isInstanceOfElement(nativeNode, HTMLInputElement)) {
		clonedNode.setAttribute("value", nativeNode.value);
	}
}
function cloneOptionSelection(nativeNode, clonedNode) {
	if (isInstanceOfElement(nativeNode, HTMLOptionElement)) {
		if (nativeNode.selected) {
			clonedNode.setAttribute("selected", "");
		} else {
			clonedNode.removeAttribute("selected");
		}
	}
}
function normalizeClipPathURLs(value, sourceDocument) {
	return value.replace(/url\(\s*(?:(["'])(.*?)\1|([^'"\s)]+))\s*\)/gi, (original, _quote, quoted, bare) => {
		const reference = quoted ?? bare;
		if (!reference || reference.startsWith("#")) return original;
		try {
			const target = new URL(reference, readDocumentProperty(sourceDocument, "baseURI"));
			if (!target.hash) return original;
			const source = new URL(readDocumentProperty(sourceDocument, "URL"));
			source.hash = "";
			const fragment = target.hash;
			target.hash = "";
			return target.href === source.href ? `url(${fragment})` : original;
		} catch {
			return original;
		}
	});
}
function cloneClipPathReferences(nativeNode, clonedNode) {
	const sourceDocument = nativeNode.ownerDocument;
	const attribute = clonedNode.getAttribute("clip-path");
	if (attribute && /url\(/i.test(attribute)) {
		const normalized = normalizeClipPathURLs(attribute, sourceDocument);
		if (normalized !== attribute) clonedNode.setAttribute("clip-path", normalized);
	}
	const style = clonedNode.style;
	const value = style?.getPropertyValue("clip-path");
	if (value?.includes("url(")) {
		const normalized = normalizeClipPathURLs(value, sourceDocument);
		if (normalized !== value) {
			style.setProperty("clip-path", normalized, style.getPropertyPriority("clip-path"));
		}
	}
}
function decorate(nativeNode, clonedNode, options, isRoot) {
	if (isInstanceOfElement(clonedNode, Element)) {
		const selected = options.stylePropertiesForNode ? options.stylePropertiesForNode(nativeNode) : options.includeStyleProperties;
		const sourceStyle = cloneCSSStyle(nativeNode, clonedNode, options, selected, isRoot);
		clonePseudoElements(nativeNode, clonedNode, selected);
		cloneInputValue(nativeNode, clonedNode);
		cloneOptionSelection(nativeNode, clonedNode);
		cloneClipPathReferences(nativeNode, clonedNode);
		if (isInstanceOfElement(nativeNode, HTMLIFrameElement) && clonedNode.tagName === "DIV") {
			let scrollLeft = 0;
			let scrollTop = 0;
			try {
				scrollLeft = nativeNode.contentWindow.scrollX;
				scrollTop = nativeNode.contentWindow.scrollY;
			} catch {}
			cloneScrollState(nativeNode, clonedNode.firstElementChild, options, scrollLeft, scrollTop);
			// The iframe viewport clips its body even when it has not scrolled.
			clonedNode.style.overflow = "hidden";
			// A transformed viewport anchors fixed descendants to this iframe.
			if (!clonedNode.style.transform || clonedNode.style.transform === "none") {
				clonedNode.style.transform = "translate(0px, 0px)";
			}
		} else {
			cloneScrollState(nativeNode, clonedNode, options);
		}
		if (sourceStyle) restoreScrollbarBox(nativeNode, clonedNode, sourceStyle, selected);
		options.onCloneNode?.(nativeNode, clonedNode);
	}
	return clonedNode;
}
export async function ensureSVGSymbols(source, clone, options) {
	await embedSVGReferences(source, clone, options, (definition) => cloneNode(definition, options, true, false, clone.ownerDocument));
	return clone;
}
export async function cloneNode(node, options, isRoot, resolveSymbols = true, targetDocument) {
	const task = getTask(options);
	task?.check();
	const yieldToBrowser = task?.maybeYieldClone();
	if (yieldToBrowser) await yieldToBrowser;
	task?.check();
	// HTML permits comment contents that XML forbids; comments have no pixels.
	if (node.nodeType === Node.COMMENT_NODE) return null;
	if (!isRoot && node.nodeType === 1 && options.exclude?.some((selector) => node.matches(selector))) {
		task?.excludeSource(node);
		return null;
	}
	if (!isRoot && options.filter && !options.filter(node)) {
		task?.excludeSource(node);
		return null;
	}
	const copyDocument = targetDocument || createCloneDocument(node.ownerDocument);
	return Promise.resolve(node).then((clonedNode) => cloneSingleNode(clonedNode, options, copyDocument, resolveSymbols)).then((clonedNode) => {
		if (isInstanceOfElement(node, Element)) {
			task?.registerClone(clonedNode, node);
		}
		return cloneChildren(node, clonedNode, options, copyDocument, resolveSymbols);
	}).then((clonedNode) => decorate(node, clonedNode, options, isRoot)).then((clonedNode) => isRoot && resolveSymbols ? ensureSVGSymbols(node, clonedNode, options) : clonedNode);
}
