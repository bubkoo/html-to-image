import { readDocumentMethod, readDocumentProperty } from "./document.js";
import { uuid, getStyleProperties } from "./util.js";
function formatCSSText(style) {
	const content = style.getPropertyValue("content");
	return `${style.cssText} content: '${content.replace(/'|"/g, "")}';`;
}
function formatCSSProperties(style, selected) {
	return getStyleProperties(style, selected).map((name) => {
		const value = style.getPropertyValue(name);
		const priority = style.getPropertyPriority(name);
		return `${name}: ${value}${priority ? " !important" : ""};`;
	}).join(" ");
}
function getPseudoElementStyle(className, pseudo, style, selected) {
	const selector = `.${className}:${pseudo}`;
	const cssText = style.cssText && selected == null ? formatCSSText(style) : formatCSSProperties(style, selected);
	return readDocumentMethod(document, "createTextNode")(`${selector}{${cssText}}`);
}
function clonePseudoElement(nativeNode, clonedNode, pseudo, selected) {
	const style = (readDocumentProperty(nativeNode.ownerDocument, "defaultView") || window).getComputedStyle(nativeNode, pseudo);
	const content = style.getPropertyValue("content");
	if (content === "" || content === "none") {
		return;
	}
	const className = uuid();
	try {
		clonedNode.className = `${clonedNode.className} ${className}`;
	} catch (err) {
		return;
	}
	const styleElement = readDocumentMethod(document, "createElement")("style");
	styleElement.appendChild(getPseudoElementStyle(className, pseudo, style, selected));
	clonedNode.appendChild(styleElement);
}
export function clonePseudoElements(nativeNode, clonedNode, selected) {
	clonePseudoElement(nativeNode, clonedNode, ":before", selected);
	clonePseudoElement(nativeNode, clonedNode, ":after", selected);
}
