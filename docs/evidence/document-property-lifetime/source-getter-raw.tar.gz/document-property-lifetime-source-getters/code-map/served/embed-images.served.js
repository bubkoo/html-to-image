function cov_21zvoivb8g() {
  var path = "/work/src/embed-images.ts";
  var hash = "a337512636f5174db505b7cb6831d6ac4d70b5be";
  var global = globalThis;
  var gcv = "__VITEST_COVERAGE__";
  var coverageData = {
    path: "/work/src/embed-images.ts",
    statementMap: {
      "0": {
        start: {
          line: 9,
          column: 19
        },
        end: {
          line: 9,
          column: 51
        }
      },
      "1": {
        start: {
          line: 10,
          column: 1
        },
        end: {
          line: 14,
          column: 2
        }
      },
      "2": {
        start: {
          line: 11,
          column: 20
        },
        end: {
          line: 11,
          column: 69
        }
      },
      "3": {
        start: {
          line: 12,
          column: 2
        },
        end: {
          line: 12,
          column: 78
        }
      },
      "4": {
        start: {
          line: 13,
          column: 2
        },
        end: {
          line: 13,
          column: 14
        }
      },
      "5": {
        start: {
          line: 15,
          column: 1
        },
        end: {
          line: 15,
          column: 14
        }
      },
      "6": {
        start: {
          line: 18,
          column: 1
        },
        end: {
          line: 18,
          column: 20
        }
      },
      "7": {
        start: {
          line: 18,
          column: 13
        },
        end: {
          line: 18,
          column: 20
        }
      },
      "8": {
        start: {
          line: 19,
          column: 1
        },
        end: {
          line: 19,
          column: 120
        }
      },
      "9": {
        start: {
          line: 20,
          column: 1
        },
        end: {
          line: 20,
          column: 234
        }
      },
      "10": {
        start: {
          line: 23,
          column: 1
        },
        end: {
          line: 23,
          column: 61
        }
      },
      "11": {
        start: {
          line: 23,
          column: 54
        },
        end: {
          line: 23,
          column: 61
        }
      },
      "12": {
        start: {
          line: 26,
          column: 24
        },
        end: {
          line: 26,
          column: 130
        }
      },
      "13": {
        start: {
          line: 27,
          column: 16
        },
        end: {
          line: 27,
          column: 111
        }
      },
      "14": {
        start: {
          line: 28,
          column: 14
        },
        end: {
          line: 28,
          column: 39
        }
      },
      "15": {
        start: {
          line: 29,
          column: 1
        },
        end: {
          line: 29,
          column: 45
        }
      },
      "16": {
        start: {
          line: 29,
          column: 11
        },
        end: {
          line: 29,
          column: 45
        }
      },
      "17": {
        start: {
          line: 30,
          column: 1
        },
        end: {
          line: 30,
          column: 39
        }
      },
      "18": {
        start: {
          line: 31,
          column: 1
        },
        end: {
          line: 31,
          column: 61
        }
      },
      "19": {
        start: {
          line: 32,
          column: 1
        },
        end: {
          line: 58,
          column: 2
        }
      },
      "20": {
        start: {
          line: 33,
          column: 16
        },
        end: {
          line: 33,
          column: 28
        }
      },
      "21": {
        start: {
          line: 34,
          column: 2
        },
        end: {
          line: 34,
          column: 21
        }
      },
      "22": {
        start: {
          line: 34,
          column: 14
        },
        end: {
          line: 34,
          column: 21
        }
      },
      "23": {
        start: {
          line: 35,
          column: 18
        },
        end: {
          line: 35,
          column: 30
        }
      },
      "24": {
        start: {
          line: 36,
          column: 16
        },
        end: {
          line: 36,
          column: 21
        }
      },
      "25": {
        start: {
          line: 37,
          column: 16
        },
        end: {
          line: 49,
          column: 3
        }
      },
      "26": {
        start: {
          line: 38,
          column: 3
        },
        end: {
          line: 48,
          column: 7
        }
      },
      "27": {
        start: {
          line: 39,
          column: 4
        },
        end: {
          line: 44,
          column: 5
        }
      },
      "28": {
        start: {
          line: 40,
          column: 23
        },
        end: {
          line: 40,
          column: 27
        }
      },
      "29": {
        start: {
          line: 41,
          column: 20
        },
        end: {
          line: 41,
          column: 33
        }
      },
      "30": {
        start: {
          line: 42,
          column: 5
        },
        end: {
          line: 42,
          column: 52
        }
      },
      "31": {
        start: {
          line: 43,
          column: 5
        },
        end: {
          line: 43,
          column: 51
        }
      },
      "32": {
        start: {
          line: 45,
          column: 4
        },
        end: {
          line: 47,
          column: 5
        }
      },
      "33": {
        start: {
          line: 46,
          column: 5
        },
        end: {
          line: 46,
          column: 32
        }
      },
      "34": {
        start: {
          line: 50,
          column: 2
        },
        end: {
          line: 50,
          column: 30
        }
      },
      "35": {
        start: {
          line: 51,
          column: 2
        },
        end: {
          line: 53,
          column: 3
        }
      },
      "36": {
        start: {
          line: 52,
          column: 3
        },
        end: {
          line: 52,
          column: 88
        }
      },
      "37": {
        start: {
          line: 52,
          column: 63
        },
        end: {
          line: 52,
          column: 75
        }
      },
      "38": {
        start: {
          line: 57,
          column: 2
        },
        end: {
          line: 57,
          column: 67
        }
      },
      "39": {
        start: {
          line: 61,
          column: 24
        },
        end: {
          line: 61,
          column: 73
        }
      },
      "40": {
        start: {
          line: 62,
          column: 20
        },
        end: {
          line: 62,
          column: 150
        }
      },
      "41": {
        start: {
          line: 63,
          column: 1
        },
        end: {
          line: 63,
          column: 44
        }
      },
      "42": {
        start: {
          line: 63,
          column: 37
        },
        end: {
          line: 63,
          column: 44
        }
      },
      "43": {
        start: {
          line: 64,
          column: 11
        },
        end: {
          line: 64,
          column: 78
        }
      },
      "44": {
        start: {
          line: 65,
          column: 1
        },
        end: {
          line: 65,
          column: 32
        }
      },
      "45": {
        start: {
          line: 65,
          column: 25
        },
        end: {
          line: 65,
          column: 32
        }
      },
      "46": {
        start: {
          line: 66,
          column: 1
        },
        end: {
          line: 70,
          column: 2
        }
      },
      "47": {
        start: {
          line: 67,
          column: 2
        },
        end: {
          line: 69,
          column: 12
        }
      },
      "48": {
        start: {
          line: 68,
          column: 3
        },
        end: {
          line: 68,
          column: 47
        }
      },
      "49": {
        start: {
          line: 71,
          column: 17
        },
        end: {
          line: 71,
          column: 95
        }
      },
      "50": {
        start: {
          line: 72,
          column: 1
        },
        end: {
          line: 81,
          column: 2
        }
      },
      "51": {
        start: {
          line: 73,
          column: 16
        },
        end: {
          line: 73,
          column: 26
        }
      },
      "52": {
        start: {
          line: 74,
          column: 2
        },
        end: {
          line: 74,
          column: 26
        }
      },
      "53": {
        start: {
          line: 75,
          column: 2
        },
        end: {
          line: 75,
          column: 20
        }
      },
      "54": {
        start: {
          line: 76,
          column: 2
        },
        end: {
          line: 80,
          column: 3
        }
      },
      "55": {
        start: {
          line: 77,
          column: 3
        },
        end: {
          line: 77,
          column: 27
        }
      },
      "56": {
        start: {
          line: 78,
          column: 3
        },
        end: {
          line: 78,
          column: 35
        }
      },
      "57": {
        start: {
          line: 79,
          column: 3
        },
        end: {
          line: 79,
          column: 23
        }
      },
      "58": {
        start: {
          line: 82,
          column: 1
        },
        end: {
          line: 92,
          column: 2
        }
      },
      "59": {
        start: {
          line: 83,
          column: 2
        },
        end: {
          line: 83,
          column: 144
        }
      },
      "60": {
        start: {
          line: 85,
          column: 2
        },
        end: {
          line: 85,
          column: 28
        }
      },
      "61": {
        start: {
          line: 86,
          column: 2
        },
        end: {
          line: 86,
          column: 42
        }
      },
      "62": {
        start: {
          line: 86,
          column: 22
        },
        end: {
          line: 86,
          column: 42
        }
      },
      "63": {
        start: {
          line: 87,
          column: 2
        },
        end: {
          line: 90,
          column: 3
        }
      },
      "64": {
        start: {
          line: 88,
          column: 3
        },
        end: {
          line: 88,
          column: 74
        }
      },
      "65": {
        start: {
          line: 89,
          column: 3
        },
        end: {
          line: 89,
          column: 10
        }
      },
      "66": {
        start: {
          line: 91,
          column: 2
        },
        end: {
          line: 91,
          column: 14
        }
      },
      "67": {
        start: {
          line: 93,
          column: 1
        },
        end: {
          line: 96,
          column: 2
        }
      },
      "68": {
        start: {
          line: 94,
          column: 2
        },
        end: {
          line: 94,
          column: 43
        }
      },
      "69": {
        start: {
          line: 95,
          column: 2
        },
        end: {
          line: 95,
          column: 71
        }
      },
      "70": {
        start: {
          line: 99,
          column: 18
        },
        end: {
          line: 99,
          column: 48
        }
      },
      "71": {
        start: {
          line: 100,
          column: 19
        },
        end: {
          line: 100,
          column: 78
        }
      },
      "72": {
        start: {
          line: 100,
          column: 43
        },
        end: {
          line: 100,
          column: 77
        }
      },
      "73": {
        start: {
          line: 101,
          column: 1
        },
        end: {
          line: 101,
          column: 53
        }
      },
      "74": {
        start: {
          line: 101,
          column: 41
        },
        end: {
          line: 101,
          column: 51
        }
      },
      "75": {
        start: {
          line: 104,
          column: 1
        },
        end: {
          line: 109,
          column: 2
        }
      },
      "76": {
        start: {
          line: 105,
          column: 2
        },
        end: {
          line: 105,
          column: 71
        }
      },
      "77": {
        start: {
          line: 106,
          column: 2
        },
        end: {
          line: 106,
          column: 44
        }
      },
      "78": {
        start: {
          line: 107,
          column: 2
        },
        end: {
          line: 107,
          column: 54
        }
      },
      "79": {
        start: {
          line: 108,
          column: 2
        },
        end: {
          line: 108,
          column: 52
        }
      },
      "80": {
        start: {
          line: 112,
          column: 1
        },
        end: {
          line: 112,
          column: 42
        }
      }
    },
    fnMap: {
      "0": {
        name: "embedProp",
        decl: {
          start: {
            line: 8,
            column: 15
          },
          end: {
            line: 8,
            column: 24
          }
        },
        loc: {
          start: {
            line: 8,
            column: 60
          },
          end: {
            line: 16,
            column: 1
          }
        },
        line: 8
      },
      "1": {
        name: "embedBackground",
        decl: {
          start: {
            line: 17,
            column: 15
          },
          end: {
            line: 17,
            column: 30
          }
        },
        loc: {
          start: {
            line: 17,
            column: 56
          },
          end: {
            line: 21,
            column: 1
          }
        },
        line: 17
      },
      "2": {
        name: "embedStyleRules",
        decl: {
          start: {
            line: 22,
            column: 15
          },
          end: {
            line: 22,
            column: 30
          }
        },
        loc: {
          start: {
            line: 22,
            column: 55
          },
          end: {
            line: 59,
            column: 1
          }
        },
        line: 22
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 37,
            column: 16
          },
          end: {
            line: 37,
            column: 17
          }
        },
        loc: {
          start: {
            line: 37,
            column: 33
          },
          end: {
            line: 49,
            column: 3
          }
        },
        line: 37
      },
      "4": {
        name: "(anonymous_4)",
        decl: {
          start: {
            line: 38,
            column: 43
          },
          end: {
            line: 38,
            column: 44
          }
        },
        loc: {
          start: {
            line: 38,
            column: 59
          },
          end: {
            line: 48,
            column: 4
          }
        },
        line: 38
      },
      "5": {
        name: "(anonymous_5)",
        decl: {
          start: {
            line: 52,
            column: 53
          },
          end: {
            line: 52,
            column: 54
          }
        },
        loc: {
          start: {
            line: 52,
            column: 63
          },
          end: {
            line: 52,
            column: 75
          }
        },
        line: 52
      },
      "6": {
        name: "embedImageNode",
        decl: {
          start: {
            line: 60,
            column: 15
          },
          end: {
            line: 60,
            column: 29
          }
        },
        loc: {
          start: {
            line: 60,
            column: 51
          },
          end: {
            line: 97,
            column: 1
          }
        },
        line: 60
      },
      "7": {
        name: "embedChildren",
        decl: {
          start: {
            line: 98,
            column: 15
          },
          end: {
            line: 98,
            column: 28
          }
        },
        loc: {
          start: {
            line: 98,
            column: 59
          },
          end: {
            line: 102,
            column: 1
          }
        },
        line: 98
      },
      "8": {
        name: "(anonymous_8)",
        decl: {
          start: {
            line: 100,
            column: 32
          },
          end: {
            line: 100,
            column: 33
          }
        },
        loc: {
          start: {
            line: 100,
            column: 43
          },
          end: {
            line: 100,
            column: 77
          }
        },
        line: 100
      },
      "9": {
        name: "(anonymous_9)",
        decl: {
          start: {
            line: 101,
            column: 35
          },
          end: {
            line: 101,
            column: 36
          }
        },
        loc: {
          start: {
            line: 101,
            column: 41
          },
          end: {
            line: 101,
            column: 51
          }
        },
        line: 101
      },
      "10": {
        name: "embedNode",
        decl: {
          start: {
            line: 103,
            column: 15
          },
          end: {
            line: 103,
            column: 24
          }
        },
        loc: {
          start: {
            line: 103,
            column: 55
          },
          end: {
            line: 110,
            column: 1
          }
        },
        line: 103
      },
      "11": {
        name: "embedImages",
        decl: {
          start: {
            line: 111,
            column: 22
          },
          end: {
            line: 111,
            column: 33
          }
        },
        loc: {
          start: {
            line: 111,
            column: 55
          },
          end: {
            line: 113,
            column: 1
          }
        },
        line: 111
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 10,
            column: 1
          },
          end: {
            line: 14,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 10,
            column: 1
          },
          end: {
            line: 14,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 10
      },
      "1": {
        loc: {
          start: {
            line: 18,
            column: 1
          },
          end: {
            line: 18,
            column: 20
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 18,
            column: 1
          },
          end: {
            line: 18,
            column: 20
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 18
      },
      "2": {
        loc: {
          start: {
            line: 19,
            column: 1
          },
          end: {
            line: 19,
            column: 119
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 19,
            column: 1
          },
          end: {
            line: 19,
            column: 55
          }
        }, {
          start: {
            line: 19,
            column: 59
          },
          end: {
            line: 19,
            column: 119
          }
        }],
        line: 19
      },
      "3": {
        loc: {
          start: {
            line: 20,
            column: 1
          },
          end: {
            line: 20,
            column: 233
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 20,
            column: 1
          },
          end: {
            line: 20,
            column: 49
          }
        }, {
          start: {
            line: 20,
            column: 53
          },
          end: {
            line: 20,
            column: 109
          }
        }, {
          start: {
            line: 20,
            column: 113
          },
          end: {
            line: 20,
            column: 167
          }
        }, {
          start: {
            line: 20,
            column: 171
          },
          end: {
            line: 20,
            column: 233
          }
        }],
        line: 20
      },
      "4": {
        loc: {
          start: {
            line: 23,
            column: 1
          },
          end: {
            line: 23,
            column: 61
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 23,
            column: 1
          },
          end: {
            line: 23,
            column: 61
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 23
      },
      "5": {
        loc: {
          start: {
            line: 23,
            column: 5
          },
          end: {
            line: 23,
            column: 52
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 23,
            column: 5
          },
          end: {
            line: 23,
            column: 31
          }
        }, {
          start: {
            line: 23,
            column: 35
          },
          end: {
            line: 23,
            column: 52
          }
        }],
        line: 23
      },
      "6": {
        loc: {
          start: {
            line: 29,
            column: 1
          },
          end: {
            line: 29,
            column: 45
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 29,
            column: 1
          },
          end: {
            line: 29,
            column: 45
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 29
      },
      "7": {
        loc: {
          start: {
            line: 34,
            column: 2
          },
          end: {
            line: 34,
            column: 21
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 34,
            column: 2
          },
          end: {
            line: 34,
            column: 21
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 34
      },
      "8": {
        loc: {
          start: {
            line: 39,
            column: 4
          },
          end: {
            line: 44,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 39,
            column: 4
          },
          end: {
            line: 44,
            column: 5
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 39
      },
      "9": {
        loc: {
          start: {
            line: 43,
            column: 15
          },
          end: {
            line: 43,
            column: 50
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 43,
            column: 15
          },
          end: {
            line: 43,
            column: 22
          }
        }, {
          start: {
            line: 43,
            column: 26
          },
          end: {
            line: 43,
            column: 50
          }
        }],
        line: 43
      },
      "10": {
        loc: {
          start: {
            line: 45,
            column: 4
          },
          end: {
            line: 47,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 45,
            column: 4
          },
          end: {
            line: 47,
            column: 5
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 45
      },
      "11": {
        loc: {
          start: {
            line: 51,
            column: 2
          },
          end: {
            line: 53,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 51,
            column: 2
          },
          end: {
            line: 53,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 51
      },
      "12": {
        loc: {
          start: {
            line: 62,
            column: 20
          },
          end: {
            line: 62,
            column: 150
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 62,
            column: 20
          },
          end: {
            line: 62,
            column: 68
          }
        }, {
          start: {
            line: 62,
            column: 72
          },
          end: {
            line: 62,
            column: 112
          }
        }, {
          start: {
            line: 62,
            column: 116
          },
          end: {
            line: 62,
            column: 150
          }
        }],
        line: 62
      },
      "13": {
        loc: {
          start: {
            line: 63,
            column: 1
          },
          end: {
            line: 63,
            column: 44
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 63,
            column: 1
          },
          end: {
            line: 63,
            column: 44
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 63
      },
      "14": {
        loc: {
          start: {
            line: 63,
            column: 5
          },
          end: {
            line: 63,
            column: 35
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 63,
            column: 5
          },
          end: {
            line: 63,
            column: 20
          }
        }, {
          start: {
            line: 63,
            column: 24
          },
          end: {
            line: 63,
            column: 35
          }
        }],
        line: 63
      },
      "15": {
        loc: {
          start: {
            line: 64,
            column: 11
          },
          end: {
            line: 64,
            column: 78
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 64,
            column: 28
          },
          end: {
            line: 64,
            column: 42
          }
        }, {
          start: {
            line: 64,
            column: 45
          },
          end: {
            line: 64,
            column: 78
          }
        }],
        line: 64
      },
      "16": {
        loc: {
          start: {
            line: 64,
            column: 45
          },
          end: {
            line: 64,
            column: 78
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 64,
            column: 45
          },
          end: {
            line: 64,
            column: 72
          }
        }, {
          start: {
            line: 64,
            column: 76
          },
          end: {
            line: 64,
            column: 78
          }
        }],
        line: 64
      },
      "17": {
        loc: {
          start: {
            line: 65,
            column: 1
          },
          end: {
            line: 65,
            column: 32
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 65,
            column: 1
          },
          end: {
            line: 65,
            column: 32
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 65
      },
      "18": {
        loc: {
          start: {
            line: 65,
            column: 5
          },
          end: {
            line: 65,
            column: 23
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 65,
            column: 5
          },
          end: {
            line: 65,
            column: 15
          }
        }, {
          start: {
            line: 65,
            column: 19
          },
          end: {
            line: 65,
            column: 23
          }
        }],
        line: 65
      },
      "19": {
        loc: {
          start: {
            line: 66,
            column: 1
          },
          end: {
            line: 70,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 66,
            column: 1
          },
          end: {
            line: 70,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 66
      },
      "20": {
        loc: {
          start: {
            line: 71,
            column: 17
          },
          end: {
            line: 71,
            column: 95
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 71,
            column: 34
          },
          end: {
            line: 71,
            column: 37
          }
        }, {
          start: {
            line: 71,
            column: 40
          },
          end: {
            line: 71,
            column: 95
          }
        }],
        line: 71
      },
      "21": {
        loc: {
          start: {
            line: 72,
            column: 1
          },
          end: {
            line: 81,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 72,
            column: 1
          },
          end: {
            line: 81,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 72
      },
      "22": {
        loc: {
          start: {
            line: 76,
            column: 2
          },
          end: {
            line: 80,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 76,
            column: 2
          },
          end: {
            line: 80,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 76
      },
      "23": {
        loc: {
          start: {
            line: 83,
            column: 38
          },
          end: {
            line: 83,
            column: 142
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 83,
            column: 120
          },
          end: {
            line: 83,
            column: 130
          }
        }, {
          start: {
            line: 83,
            column: 133
          },
          end: {
            line: 83,
            column: 142
          }
        }],
        line: 83
      },
      "24": {
        loc: {
          start: {
            line: 83,
            column: 38
          },
          end: {
            line: 83,
            column: 117
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 83,
            column: 38
          },
          end: {
            line: 83,
            column: 52
          }
        }, {
          start: {
            line: 83,
            column: 56
          },
          end: {
            line: 83,
            column: 117
          }
        }],
        line: 83
      },
      "25": {
        loc: {
          start: {
            line: 86,
            column: 2
          },
          end: {
            line: 86,
            column: 42
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 86,
            column: 2
          },
          end: {
            line: 86,
            column: 42
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 86
      },
      "26": {
        loc: {
          start: {
            line: 87,
            column: 2
          },
          end: {
            line: 90,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 87,
            column: 2
          },
          end: {
            line: 90,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 87
      },
      "27": {
        loc: {
          start: {
            line: 93,
            column: 1
          },
          end: {
            line: 96,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 93,
            column: 1
          },
          end: {
            line: 96,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 93
      },
      "28": {
        loc: {
          start: {
            line: 104,
            column: 1
          },
          end: {
            line: 109,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 104,
            column: 1
          },
          end: {
            line: 109,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 104
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0, 0, 0],
      "4": [0, 0],
      "5": [0, 0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0],
      "10": [0, 0],
      "11": [0, 0],
      "12": [0, 0, 0],
      "13": [0, 0],
      "14": [0, 0],
      "15": [0, 0],
      "16": [0, 0],
      "17": [0, 0],
      "18": [0, 0],
      "19": [0, 0],
      "20": [0, 0],
      "21": [0, 0],
      "22": [0, 0],
      "23": [0, 0],
      "24": [0, 0],
      "25": [0, 0],
      "26": [0, 0],
      "27": [0, 0],
      "28": [0, 0]
    },
    inputSourceMap: {
      mappings: "AAAA,SAAS,4BAA4B;AAErC,SAAS,sBAAsB;AAC/B,SAAS,SAAS,qBAAqB,mBAAmB;AAC1D,SAAS,eAAe;AACxB,SAAS,WAAW,yBAAyB;AAC7C,SAAS,mBAAmB;AAC5B,SAAS,iBAAiB,oBAAoB;AAE9C,eAAe,UACb,UACA,OACA,SACA,SACA;CACA,MAAM,YAAY,MAAM,iBAAiB,QAAQ;CACjD,IAAI,WAAW;EACb,MAAM,YAAY,MAAM,eAAe,WAAW,SAAS,OAAO;EAClE,MAAM,YAAY,UAAU,WAAW,MAAM,oBAAoB,QAAQ,CAAC;EAC1E,OAAO;CACT;CACA,OAAO;AACT;AAEA,eAAe,gBACb,OACA,SACA,SACA;CACA,IAAI,CAAC,OAAO;CACX,AAAC,MAAM,UAAU,cAAc,OAAO,SAAS,OAAO,KACpD,MAAM,UAAU,oBAAoB,OAAO,SAAS,OAAO;CAC7D,AAAC,MAAM,UAAU,QAAQ,OAAO,SAAS,OAAO,KAC9C,MAAM,UAAU,gBAAgB,OAAO,SAAS,OAAO,KACvD,MAAM,UAAU,cAAc,OAAO,SAAS,OAAO,KACrD,MAAM,UAAU,sBAAsB,OAAO,SAAS,OAAO;AAClE;AAMA,eAAe,gBACb,MACA,SACA,SACA;CACA,IAAI,KAAK,cAAc,WAAW,CAAC,KAAK,aAAa;;;CAGrD,MAAM,iBAAkB,QAAQ,mBAAmB,qBACjD,KAAK,eACL,gBACF,CAAC,CAAC,mBAAmB;CACrB,MAAM,SAAS,QAAQ,MACrB,qBAAqB,gBAAgB,eAAe,GACpD,gBACA,CAAC,OAAO,CACV;CACA,MAAM,OAAO,KAAK,aAAa,MAAM;CACrC,IAAI,MAAM,OAAO,aAAa,QAAQ,IAAI;CAC1C,OAAO,cAAc,KAAK;CAC1B,qBAAqB,gBAAgB,MAAM,CAAC,CAAC,OAAO,MAAM;CAC1D,IAAI;EACF,MAAM,QAAQ,OAAO;EACrB,IAAI,CAAC,OAAO;EACZ,MAAM,UAAU,KAAK;EACrB,IAAI,UAAU;EACd,MAAM,QAAQ,OAAO,UAAsC;GACzD,MAAM,QAAQ,IACZ,MAAM,KAAK,KAAK,CAAC,CAAC,IAAI,OAAO,SAAS;IACpC,IAAI,KAAK,SAAS,QAAQ,YAAY;KACpC,MAAM,EAAE,UAAU;KAClB,MAAM,SAAS,MAAM;KACrB,MAAM,gBAAgB,OAAO,SAAS,OAAO;KAC7C,UAAU,WAAW,WAAW,MAAM;IACxC;IACA,IAAI,cAAc,MAAM;KACtB,MAAM,MAAO,KAAyB,QAAQ;IAChD;GACF,CAAC,CACH;EACF;EACA,MAAM,MAAM,MAAM,QAAQ;EAC1B,IAAI,SAAS;GACX,KAAK,cAAc,MAAM,KAAK,MAAM,QAAQ,CAAC,CAC1C,KAAK,SAAS,KAAK,OAAO,CAAC,CAC3B,KAAK,IAAI;EACd;CACF,UAAU;;;EAGR,qBAAqB,gBAAgB,MAAM,CAAC,CAAC,YAAY,MAAM;CACjE;AACF;AAEA,eAAe,eACb,YACA,SACA;CACA,MAAM,iBAAiB,oBAAoB,YAAY,gBAAgB;CACvE,MAAM,aACJ,oBAAoB,YAAY,eAAe,KAC9C,WAAW,iBAAiB,gBAC3B,WAAW,cAAc;CAC7B,IAAI,CAAC,kBAAkB,CAAC,YAAY;CACpC,IAAI,MAAM,iBAAiB,WAAW,MAAM,gBAAgB,UAAU,KAAK;CAC3E,IAAI,cAAc,CAAC,KAAK;CACxB,IAAI,CAAC,UAAU,GAAG,GAAG;EACnB,IAAI;GACF,MAAM,IAAI,IAAI,KAAK,WAAW,OAAO,CAAC,CAAC;EACzC,QAAQ,CAER;CACF;CACA,MAAM,UAAU,UAAU,GAAG,IACzB,MACA,MAAM,kBAAkB,KAAK,YAAY,GAAG,GAAG,OAAO;CAC1D,IAAI,gBAAgB;EAClB,MAAM,QAAQ;EACd,MAAM,UAAU;EAChB,MAAM,SAAS;EACf,IAAI,CAAC,qBAAqB,MAAM,eAAe,aAAa,GAAG;GAC7D,MAAM,WAAW;GACjB,MAAM,cAAc;GACpB,MAAM,MAAM;EACd;CACF;CACA,IAAI;EACF,MAAM,YACJ,SACA,SACA,kBACE,qBAAqB,WAAW,eAAe,aAAa,IACzD,aACD,SACN;CACF,SAAS,OAAO;EACd,QAAQ,OAAO,CAAC,EAAE,MAAM;EACxB,IAAI,gBAAgB,AAAC,WAAgC,MAAM;EAC3D,IAAI,QAAQ,qBAAqB;GAC/B,MAAM,QAAQ,oBAAoB,KAAK,YAAY,IAAI,MAAM,OAAO,CAAC;GACrE;EACF;EACA,MAAM;CACR;CACA,IAAI,CAAC,gBAAgB;EACnB,WAAW,aAAa,QAAQ,OAAO;EACvC,WAAW,kBAAkB,gCAAgC,MAAM;CACrE;AACF;AAEA,eAAe,cACb,YACA,SACA,SACA;CACA,MAAM,WAAW,QAAqB,WAAW,UAAU;CAC3D,MAAM,YAAY,SAAS,KAAK,UAAU,UAAU,OAAO,SAAS,OAAO,CAAC;CAC5E,MAAM,QAAQ,IAAI,SAAS,CAAC,CAAC,WAAW,UAAU;AACpD;AAEA,eAAe,UACb,YACA,SACA,SACA;CACA,IAAI,oBAAoB,YAAY,OAAO,GAAG;EAC5C,MAAM,gBAAgB,WAAW,OAAO,WAAW,SAAS,OAAO;EACnE,MAAM,eAAe,YAAY,OAAO;EACxC,MAAM,gBAAgB,YAAY,SAAS,OAAO;EAClD,MAAM,cAAc,YAAY,SAAS,OAAO;CAClD;AACF;AAEA,OAAO,eAAe,YACpB,YACA,SACA;CACA,MAAM,UAAU,YAAY,SAAS,CAAC,CAAC;AACzC",
      names: [],
      sources: ["/work/src/embed-images.ts"],
      version: 3,
      sourcesContent: ["import { readDocumentProperty } from './document.js'\nimport { Options } from './types.js'\nimport { embedResources } from './embed-resources.js'\nimport { toArray, isInstanceOfElement, createImage } from './util.js'\nimport { getTask } from './task.js'\nimport { isDataUrl, resourceToDataURL } from './dataurl.js'\nimport { getMimeType } from './mimes.js'\nimport { getSVGReference, svgNamespace } from './svg-references.js'\n\nasync function embedProp(\n  propName: string,\n  style: CSSStyleDeclaration,\n  baseURI: string,\n  options: Options,\n) {\n  const propValue = style.getPropertyValue(propName)\n  if (propValue) {\n    const cssString = await embedResources(propValue, baseURI, options)\n    style.setProperty(propName, cssString, style.getPropertyPriority(propName))\n    return true\n  }\n  return false\n}\n\nasync function embedBackground(\n  style: CSSStyleDeclaration | undefined,\n  baseURI: string,\n  options: Options,\n) {\n  if (!style) return\n  ;(await embedProp('background', style, baseURI, options)) ||\n    (await embedProp('background-image', style, baseURI, options))\n  ;(await embedProp('mask', style, baseURI, options)) ||\n    (await embedProp('-webkit-mask', style, baseURI, options)) ||\n    (await embedProp('mask-image', style, baseURI, options)) ||\n    (await embedProp('-webkit-mask-image', style, baseURI, options))\n}\n\ninterface EmbedContext {\n  parserDocument?: Document\n}\n\nasync function embedStyleRules(\n  node: HTMLElement,\n  options: Options,\n  context: EmbedContext,\n) {\n  if (node.localName !== 'style' || !node.textContent) return\n  // An inert stylesheet preserves @import rules without loading them. A\n  // constructed CSSStyleSheet.replaceSync would silently remove those rules.\n  const parserDocument = (context.parserDocument ||= readDocumentProperty(\n    node.ownerDocument,\n    'implementation',\n  ).createHTMLDocument())\n  const parser = Reflect.apply(\n    readDocumentProperty(parserDocument, 'createElement'),\n    parserDocument,\n    ['style'],\n  ) as HTMLStyleElement\n  const type = node.getAttribute('type')\n  if (type) parser.setAttribute('type', type)\n  parser.textContent = node.textContent\n  readDocumentProperty(parserDocument, 'head').append(parser)\n  try {\n    const sheet = parser.sheet\n    if (!sheet) return\n    const baseURI = node.baseURI\n    let changed = false\n    const visit = async (rules: CSSRuleList): Promise<void> => {\n      await Promise.all(\n        Array.from(rules).map(async (rule) => {\n          if (rule.type === CSSRule.STYLE_RULE) {\n            const { style } = rule as CSSStyleRule\n            const before = style.cssText\n            await embedBackground(style, baseURI, options)\n            changed = changed || before !== style.cssText\n          }\n          if ('cssRules' in rule) {\n            await visit((rule as CSSGroupingRule).cssRules)\n          }\n        }),\n      )\n    }\n    await visit(sheet.cssRules)\n    if (changed) {\n      node.textContent = Array.from(sheet.cssRules)\n        .map((rule) => rule.cssText)\n        .join('\\n')\n    }\n  } finally {\n    // Retain the parser document across asynchronous embedding, as with the\n    // clone document; its nodes alone are insufficient ownership in WebKit.\n    readDocumentProperty(parserDocument, 'head').removeChild(parser)\n  }\n}\n\nasync function embedImageNode<T extends HTMLElement | SVGImageElement>(\n  clonedNode: T,\n  options: Options,\n) {\n  const isImageElement = isInstanceOfElement(clonedNode, HTMLImageElement)\n  const isSVGImage =\n    isInstanceOfElement(clonedNode, SVGImageElement) ||\n    (clonedNode.namespaceURI === svgNamespace &&\n      clonedNode.localName === 'feImage')\n  if (!isImageElement && !isSVGImage) return\n  let url = isImageElement ? clonedNode.src : getSVGReference(clonedNode) || ''\n  if (isSVGImage && !url) return\n  if (!isDataUrl(url)) {\n    try {\n      url = new URL(url, clonedNode.baseURI).href\n    } catch {\n      // Let the resource loader and image error handler recover invalid URLs.\n    }\n  }\n  const dataURL = isDataUrl(url)\n    ? url\n    : await resourceToDataURL(url, getMimeType(url), options)\n  if (isImageElement) {\n    const image = clonedNode as HTMLImageElement\n    image.loading = 'eager'\n    image.srcset = ''\n    if (!readDocumentProperty(image.ownerDocument, 'defaultView')) {\n      image.decoding = 'sync'\n      image.crossOrigin = 'anonymous'\n      image.src = dataURL\n    }\n  }\n  try {\n    await createImage(\n      dataURL,\n      options,\n      isImageElement &&\n        readDocumentProperty(clonedNode.ownerDocument, 'defaultView')\n        ? (clonedNode as HTMLImageElement)\n        : undefined,\n    )\n  } catch (error) {\n    getTask(options)?.check()\n    if (isImageElement) (clonedNode as HTMLImageElement).src = ''\n    if (options.onImageErrorHandler) {\n      await options.onImageErrorHandler.call(clonedNode, new Event('error'))\n      return\n    }\n    throw error\n  }\n  if (!isImageElement) {\n    clonedNode.setAttribute('href', dataURL)\n    clonedNode.removeAttributeNS('http://www.w3.org/1999/xlink', 'href')\n  }\n}\n\nasync function embedChildren<T extends HTMLElement>(\n  clonedNode: T,\n  options: Options,\n  context: EmbedContext,\n) {\n  const children = toArray<HTMLElement>(clonedNode.childNodes)\n  const deferreds = children.map((child) => embedNode(child, options, context))\n  await Promise.all(deferreds).then(() => clonedNode)\n}\n\nasync function embedNode<T extends HTMLElement>(\n  clonedNode: T,\n  options: Options,\n  context: EmbedContext,\n) {\n  if (isInstanceOfElement(clonedNode, Element)) {\n    await embedBackground(clonedNode.style, clonedNode.baseURI, options)\n    await embedImageNode(clonedNode, options)\n    await embedStyleRules(clonedNode, options, context)\n    await embedChildren(clonedNode, options, context)\n  }\n}\n\nexport async function embedImages<T extends HTMLElement>(\n  clonedNode: T,\n  options: Options,\n) {\n  await embedNode(clonedNode, options, {})\n}\n"]
    },
    _coverageSchema: "de0df54ae17f6b36de740b46d31f7cdddb68e251",
    hash: "a337512636f5174db505b7cb6831d6ac4d70b5be"
  };
  var coverage = global[gcv] || (global[gcv] = {});
  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }
  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_21zvoivb8g = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}
cov_21zvoivb8g();
import { readDocumentProperty } from "/src/document.ts";
import { embedResources } from "/src/embed-resources.ts";
import { toArray, isInstanceOfElement, createImage } from "/src/util.ts";
import { getTask } from "/src/task.ts";
import { isDataUrl, resourceToDataURL } from "/src/dataurl.ts";
import { getMimeType } from "/src/mimes.ts";
import { getSVGReference, svgNamespace } from "/src/svg-references.ts";
async function embedProp(propName, style, baseURI, options) {
  cov_21zvoivb8g().f[0]++;
  const propValue = (cov_21zvoivb8g().s[0]++, style.getPropertyValue(propName));
  cov_21zvoivb8g().s[1]++;
  if (propValue) {
    cov_21zvoivb8g().b[0][0]++;
    const cssString = (cov_21zvoivb8g().s[2]++, await embedResources(propValue, baseURI, options));
    cov_21zvoivb8g().s[3]++;
    style.setProperty(propName, cssString, style.getPropertyPriority(propName));
    cov_21zvoivb8g().s[4]++;
    return true;
  } else {
    cov_21zvoivb8g().b[0][1]++;
  }
  cov_21zvoivb8g().s[5]++;
  return false;
}
async function embedBackground(style, baseURI, options) {
  cov_21zvoivb8g().f[1]++;
  cov_21zvoivb8g().s[6]++;
  if (!style) {
    cov_21zvoivb8g().b[1][0]++;
    cov_21zvoivb8g().s[7]++;
    return;
  } else {
    cov_21zvoivb8g().b[1][1]++;
  }
  cov_21zvoivb8g().s[8]++;
  (cov_21zvoivb8g().b[2][0]++, await embedProp("background", style, baseURI, options)) || (cov_21zvoivb8g().b[2][1]++, await embedProp("background-image", style, baseURI, options));
  cov_21zvoivb8g().s[9]++;
  (cov_21zvoivb8g().b[3][0]++, await embedProp("mask", style, baseURI, options)) || (cov_21zvoivb8g().b[3][1]++, await embedProp("-webkit-mask", style, baseURI, options)) || (cov_21zvoivb8g().b[3][2]++, await embedProp("mask-image", style, baseURI, options)) || (cov_21zvoivb8g().b[3][3]++, await embedProp("-webkit-mask-image", style, baseURI, options));
}
async function embedStyleRules(node, options, context) {
  cov_21zvoivb8g().f[2]++;
  cov_21zvoivb8g().s[10]++;
  if ((cov_21zvoivb8g().b[5][0]++, node.localName !== "style") || (cov_21zvoivb8g().b[5][1]++, !node.textContent)) {
    cov_21zvoivb8g().b[4][0]++;
    cov_21zvoivb8g().s[11]++;
    return;
  } else {
    cov_21zvoivb8g().b[4][1]++;
  }
  // An inert stylesheet preserves @import rules without loading them. A
  // constructed CSSStyleSheet.replaceSync would silently remove those rules.
  const parserDocument = (cov_21zvoivb8g().s[12]++, context.parserDocument ||= readDocumentProperty(node.ownerDocument, "implementation").createHTMLDocument());
  const parser = (cov_21zvoivb8g().s[13]++, Reflect.apply(readDocumentProperty(parserDocument, "createElement"), parserDocument, ["style"]));
  const type = (cov_21zvoivb8g().s[14]++, node.getAttribute("type"));
  cov_21zvoivb8g().s[15]++;
  if (type) {
    cov_21zvoivb8g().b[6][0]++;
    cov_21zvoivb8g().s[16]++;
    parser.setAttribute("type", type);
  } else {
    cov_21zvoivb8g().b[6][1]++;
  }
  cov_21zvoivb8g().s[17]++;
  parser.textContent = node.textContent;
  cov_21zvoivb8g().s[18]++;
  readDocumentProperty(parserDocument, "head").append(parser);
  cov_21zvoivb8g().s[19]++;
  try {
    const sheet = (cov_21zvoivb8g().s[20]++, parser.sheet);
    cov_21zvoivb8g().s[21]++;
    if (!sheet) {
      cov_21zvoivb8g().b[7][0]++;
      cov_21zvoivb8g().s[22]++;
      return;
    } else {
      cov_21zvoivb8g().b[7][1]++;
    }
    const baseURI = (cov_21zvoivb8g().s[23]++, node.baseURI);
    let changed = (cov_21zvoivb8g().s[24]++, false);
    cov_21zvoivb8g().s[25]++;
    const visit = async rules => {
      cov_21zvoivb8g().f[3]++;
      cov_21zvoivb8g().s[26]++;
      await Promise.all(Array.from(rules).map(async rule => {
        cov_21zvoivb8g().f[4]++;
        cov_21zvoivb8g().s[27]++;
        if (rule.type === CSSRule.STYLE_RULE) {
          cov_21zvoivb8g().b[8][0]++;
          const {
            style
          } = (cov_21zvoivb8g().s[28]++, rule);
          const before = (cov_21zvoivb8g().s[29]++, style.cssText);
          cov_21zvoivb8g().s[30]++;
          await embedBackground(style, baseURI, options);
          cov_21zvoivb8g().s[31]++;
          changed = (cov_21zvoivb8g().b[9][0]++, changed) || (cov_21zvoivb8g().b[9][1]++, before !== style.cssText);
        } else {
          cov_21zvoivb8g().b[8][1]++;
        }
        cov_21zvoivb8g().s[32]++;
        if ("cssRules" in rule) {
          cov_21zvoivb8g().b[10][0]++;
          cov_21zvoivb8g().s[33]++;
          await visit(rule.cssRules);
        } else {
          cov_21zvoivb8g().b[10][1]++;
        }
      }));
    };
    cov_21zvoivb8g().s[34]++;
    await visit(sheet.cssRules);
    cov_21zvoivb8g().s[35]++;
    if (changed) {
      cov_21zvoivb8g().b[11][0]++;
      cov_21zvoivb8g().s[36]++;
      node.textContent = Array.from(sheet.cssRules).map(rule => {
        cov_21zvoivb8g().f[5]++;
        cov_21zvoivb8g().s[37]++;
        return rule.cssText;
      }).join("\n");
    } else {
      cov_21zvoivb8g().b[11][1]++;
    }
  } finally {
    cov_21zvoivb8g().s[38]++;
    // Retain the parser document across asynchronous embedding, as with the
    // clone document; its nodes alone are insufficient ownership in WebKit.
    readDocumentProperty(parserDocument, "head").removeChild(parser);
  }
}
async function embedImageNode(clonedNode, options) {
  cov_21zvoivb8g().f[6]++;
  const isImageElement = (cov_21zvoivb8g().s[39]++, isInstanceOfElement(clonedNode, HTMLImageElement));
  const isSVGImage = (cov_21zvoivb8g().s[40]++, (cov_21zvoivb8g().b[12][0]++, isInstanceOfElement(clonedNode, SVGImageElement)) || (cov_21zvoivb8g().b[12][1]++, clonedNode.namespaceURI === svgNamespace) && (cov_21zvoivb8g().b[12][2]++, clonedNode.localName === "feImage"));
  cov_21zvoivb8g().s[41]++;
  if ((cov_21zvoivb8g().b[14][0]++, !isImageElement) && (cov_21zvoivb8g().b[14][1]++, !isSVGImage)) {
    cov_21zvoivb8g().b[13][0]++;
    cov_21zvoivb8g().s[42]++;
    return;
  } else {
    cov_21zvoivb8g().b[13][1]++;
  }
  let url = (cov_21zvoivb8g().s[43]++, isImageElement ? (cov_21zvoivb8g().b[15][0]++, clonedNode.src) : (cov_21zvoivb8g().b[15][1]++, (cov_21zvoivb8g().b[16][0]++, getSVGReference(clonedNode)) || (cov_21zvoivb8g().b[16][1]++, "")));
  cov_21zvoivb8g().s[44]++;
  if ((cov_21zvoivb8g().b[18][0]++, isSVGImage) && (cov_21zvoivb8g().b[18][1]++, !url)) {
    cov_21zvoivb8g().b[17][0]++;
    cov_21zvoivb8g().s[45]++;
    return;
  } else {
    cov_21zvoivb8g().b[17][1]++;
  }
  cov_21zvoivb8g().s[46]++;
  if (!isDataUrl(url)) {
    cov_21zvoivb8g().b[19][0]++;
    cov_21zvoivb8g().s[47]++;
    try {
      cov_21zvoivb8g().s[48]++;
      url = new URL(url, clonedNode.baseURI).href;
    } catch {}
  } else {
    cov_21zvoivb8g().b[19][1]++;
  }
  const dataURL = (cov_21zvoivb8g().s[49]++, isDataUrl(url) ? (cov_21zvoivb8g().b[20][0]++, url) : (cov_21zvoivb8g().b[20][1]++, await resourceToDataURL(url, getMimeType(url), options)));
  cov_21zvoivb8g().s[50]++;
  if (isImageElement) {
    cov_21zvoivb8g().b[21][0]++;
    const image = (cov_21zvoivb8g().s[51]++, clonedNode);
    cov_21zvoivb8g().s[52]++;
    image.loading = "eager";
    cov_21zvoivb8g().s[53]++;
    image.srcset = "";
    cov_21zvoivb8g().s[54]++;
    if (!readDocumentProperty(image.ownerDocument, "defaultView")) {
      cov_21zvoivb8g().b[22][0]++;
      cov_21zvoivb8g().s[55]++;
      image.decoding = "sync";
      cov_21zvoivb8g().s[56]++;
      image.crossOrigin = "anonymous";
      cov_21zvoivb8g().s[57]++;
      image.src = dataURL;
    } else {
      cov_21zvoivb8g().b[22][1]++;
    }
  } else {
    cov_21zvoivb8g().b[21][1]++;
  }
  cov_21zvoivb8g().s[58]++;
  try {
    cov_21zvoivb8g().s[59]++;
    await createImage(dataURL, options, (cov_21zvoivb8g().b[24][0]++, isImageElement) && (cov_21zvoivb8g().b[24][1]++, readDocumentProperty(clonedNode.ownerDocument, "defaultView")) ? (cov_21zvoivb8g().b[23][0]++, clonedNode) : (cov_21zvoivb8g().b[23][1]++, undefined));
  } catch (error) {
    cov_21zvoivb8g().s[60]++;
    getTask(options)?.check();
    cov_21zvoivb8g().s[61]++;
    if (isImageElement) {
      cov_21zvoivb8g().b[25][0]++;
      cov_21zvoivb8g().s[62]++;
      clonedNode.src = "";
    } else {
      cov_21zvoivb8g().b[25][1]++;
    }
    cov_21zvoivb8g().s[63]++;
    if (options.onImageErrorHandler) {
      cov_21zvoivb8g().b[26][0]++;
      cov_21zvoivb8g().s[64]++;
      await options.onImageErrorHandler.call(clonedNode, new Event("error"));
      cov_21zvoivb8g().s[65]++;
      return;
    } else {
      cov_21zvoivb8g().b[26][1]++;
    }
    cov_21zvoivb8g().s[66]++;
    throw error;
  }
  cov_21zvoivb8g().s[67]++;
  if (!isImageElement) {
    cov_21zvoivb8g().b[27][0]++;
    cov_21zvoivb8g().s[68]++;
    clonedNode.setAttribute("href", dataURL);
    cov_21zvoivb8g().s[69]++;
    clonedNode.removeAttributeNS("http://www.w3.org/1999/xlink", "href");
  } else {
    cov_21zvoivb8g().b[27][1]++;
  }
}
async function embedChildren(clonedNode, options, context) {
  cov_21zvoivb8g().f[7]++;
  const children = (cov_21zvoivb8g().s[70]++, toArray(clonedNode.childNodes));
  const deferreds = (cov_21zvoivb8g().s[71]++, children.map(child => {
    cov_21zvoivb8g().f[8]++;
    cov_21zvoivb8g().s[72]++;
    return embedNode(child, options, context);
  }));
  cov_21zvoivb8g().s[73]++;
  await Promise.all(deferreds).then(() => {
    cov_21zvoivb8g().f[9]++;
    cov_21zvoivb8g().s[74]++;
    return clonedNode;
  });
}
async function embedNode(clonedNode, options, context) {
  cov_21zvoivb8g().f[10]++;
  cov_21zvoivb8g().s[75]++;
  if (isInstanceOfElement(clonedNode, Element)) {
    cov_21zvoivb8g().b[28][0]++;
    cov_21zvoivb8g().s[76]++;
    await embedBackground(clonedNode.style, clonedNode.baseURI, options);
    cov_21zvoivb8g().s[77]++;
    await embedImageNode(clonedNode, options);
    cov_21zvoivb8g().s[78]++;
    await embedStyleRules(clonedNode, options, context);
    cov_21zvoivb8g().s[79]++;
    await embedChildren(clonedNode, options, context);
  } else {
    cov_21zvoivb8g().b[28][1]++;
  }
}
export async function embedImages(clonedNode, options) {
  cov_21zvoivb8g().f[11]++;
  cov_21zvoivb8g().s[80]++;
  await embedNode(clonedNode, options, {});
}