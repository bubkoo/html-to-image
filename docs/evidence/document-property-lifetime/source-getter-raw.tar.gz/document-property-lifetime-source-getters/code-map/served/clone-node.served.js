function cov_25saynlpeq() {
  var path = "/work/src/clone-node.ts";
  var hash = "deeceaa6e585e602ad332bdd2d64712cf54b356f";
  var global = globalThis;
  var gcv = "__VITEST_COVERAGE__";
  var coverageData = {
    path: "/work/src/clone-node.ts",
    statementMap: {
      "0": {
        start: {
          line: 12,
          column: 14
        },
        end: {
          line: 12,
          column: 81
        }
      },
      "1": {
        start: {
          line: 13,
          column: 14
        },
        end: {
          line: 13,
          column: 88
        }
      },
      "2": {
        start: {
          line: 14,
          column: 1
        },
        end: {
          line: 14,
          column: 53
        }
      },
      "3": {
        start: {
          line: 15,
          column: 1
        },
        end: {
          line: 15,
          column: 49
        }
      },
      "4": {
        start: {
          line: 16,
          column: 1
        },
        end: {
          line: 16,
          column: 13
        }
      },
      "5": {
        start: {
          line: 19,
          column: 17
        },
        end: {
          line: 19,
          column: 35
        }
      },
      "6": {
        start: {
          line: 20,
          column: 1
        },
        end: {
          line: 22,
          column: 2
        }
      },
      "7": {
        start: {
          line: 21,
          column: 2
        },
        end: {
          line: 21,
          column: 33
        }
      },
      "8": {
        start: {
          line: 23,
          column: 1
        },
        end: {
          line: 23,
          column: 38
        }
      },
      "9": {
        start: {
          line: 26,
          column: 1
        },
        end: {
          line: 30,
          column: 2
        }
      },
      "10": {
        start: {
          line: 28,
          column: 16
        },
        end: {
          line: 28,
          column: 71
        }
      },
      "11": {
        start: {
          line: 29,
          column: 2
        },
        end: {
          line: 29,
          column: 49
        }
      },
      "12": {
        start: {
          line: 31,
          column: 1
        },
        end: {
          line: 39,
          column: 2
        }
      },
      "13": {
        start: {
          line: 32,
          column: 17
        },
        end: {
          line: 32,
          column: 72
        }
      },
      "14": {
        start: {
          line: 33,
          column: 14
        },
        end: {
          line: 33,
          column: 37
        }
      },
      "15": {
        start: {
          line: 34,
          column: 2
        },
        end: {
          line: 34,
          column: 34
        }
      },
      "16": {
        start: {
          line: 35,
          column: 2
        },
        end: {
          line: 35,
          column: 36
        }
      },
      "17": {
        start: {
          line: 36,
          column: 2
        },
        end: {
          line: 36,
          column: 59
        }
      },
      "18": {
        start: {
          line: 37,
          column: 18
        },
        end: {
          line: 37,
          column: 36
        }
      },
      "19": {
        start: {
          line: 38,
          column: 2
        },
        end: {
          line: 38,
          column: 39
        }
      },
      "20": {
        start: {
          line: 40,
          column: 16
        },
        end: {
          line: 40,
          column: 28
        }
      },
      "21": {
        start: {
          line: 41,
          column: 21
        },
        end: {
          line: 41,
          column: 40
        }
      },
      "22": {
        start: {
          line: 42,
          column: 17
        },
        end: {
          line: 42,
          column: 70
        }
      },
      "23": {
        start: {
          line: 43,
          column: 1
        },
        end: {
          line: 43,
          column: 38
        }
      },
      "24": {
        start: {
          line: 46,
          column: 18
        },
        end: {
          line: 46,
          column: 22
        }
      },
      "25": {
        start: {
          line: 47,
          column: 1
        },
        end: {
          line: 49,
          column: 11
        }
      },
      "26": {
        start: {
          line: 48,
          column: 2
        },
        end: {
          line: 48,
          column: 84
        }
      },
      "27": {
        start: {
          line: 50,
          column: 1
        },
        end: {
          line: 55,
          column: 2
        }
      },
      "28": {
        start: {
          line: 51,
          column: 15
        },
        end: {
          line: 51,
          column: 89
        }
      },
      "29": {
        start: {
          line: 52,
          column: 19
        },
        end: {
          line: 52,
          column: 77
        }
      },
      "30": {
        start: {
          line: 53,
          column: 2
        },
        end: {
          line: 53,
          column: 29
        }
      },
      "31": {
        start: {
          line: 54,
          column: 2
        },
        end: {
          line: 54,
          column: 18
        }
      },
      "32": {
        start: {
          line: 56,
          column: 1
        },
        end: {
          line: 56,
          column: 72
        }
      },
      "33": {
        start: {
          line: 59,
          column: 1
        },
        end: {
          line: 61,
          column: 2
        }
      },
      "34": {
        start: {
          line: 60,
          column: 2
        },
        end: {
          line: 60,
          column: 98
        }
      },
      "35": {
        start: {
          line: 62,
          column: 1
        },
        end: {
          line: 64,
          column: 2
        }
      },
      "36": {
        start: {
          line: 63,
          column: 2
        },
        end: {
          line: 63,
          column: 97
        }
      },
      "37": {
        start: {
          line: 65,
          column: 1
        },
        end: {
          line: 67,
          column: 2
        }
      },
      "38": {
        start: {
          line: 66,
          column: 2
        },
        end: {
          line: 66,
          column: 75
        }
      },
      "39": {
        start: {
          line: 68,
          column: 14
        },
        end: {
          line: 68,
          column: 75
        }
      },
      "40": {
        start: {
          line: 69,
          column: 1
        },
        end: {
          line: 81,
          column: 2
        }
      },
      "41": {
        start: {
          line: 72,
          column: 2
        },
        end: {
          line: 72,
          column: 22
        }
      },
      "42": {
        start: {
          line: 73,
          column: 8
        },
        end: {
          line: 81,
          column: 2
        }
      },
      "43": {
        start: {
          line: 74,
          column: 15
        },
        end: {
          line: 74,
          column: 36
        }
      },
      "44": {
        start: {
          line: 75,
          column: 2
        },
        end: {
          line: 80,
          column: 3
        }
      },
      "45": {
        start: {
          line: 76,
          column: 3
        },
        end: {
          line: 79,
          column: 13
        }
      },
      "46": {
        start: {
          line: 77,
          column: 4
        },
        end: {
          line: 77,
          column: 64
        }
      },
      "47": {
        start: {
          line: 78,
          column: 4
        },
        end: {
          line: 78,
          column: 67
        }
      },
      "48": {
        start: {
          line: 82,
          column: 1
        },
        end: {
          line: 82,
          column: 13
        }
      },
      "49": {
        start: {
          line: 84,
          column: 22
        },
        end: {
          line: 84,
          column: 93
        }
      },
      "50": {
        start: {
          line: 84,
          column: 32
        },
        end: {
          line: 84,
          column: 93
        }
      },
      "51": {
        start: {
          line: 87,
          column: 1
        },
        end: {
          line: 95,
          column: 2
        }
      },
      "52": {
        start: {
          line: 88,
          column: 19
        },
        end: {
          line: 88,
          column: 45
        }
      },
      "53": {
        start: {
          line: 89,
          column: 2
        },
        end: {
          line: 89,
          column: 73
        }
      },
      "54": {
        start: {
          line: 90,
          column: 8
        },
        end: {
          line: 95,
          column: 2
        }
      },
      "55": {
        start: {
          line: 92,
          column: 2
        },
        end: {
          line: 92,
          column: 20
        }
      },
      "56": {
        start: {
          line: 94,
          column: 2
        },
        end: {
          line: 94,
          column: 71
        }
      },
      "57": {
        start: {
          line: 96,
          column: 1
        },
        end: {
          line: 98,
          column: 2
        }
      },
      "58": {
        start: {
          line: 97,
          column: 2
        },
        end: {
          line: 97,
          column: 20
        }
      },
      "59": {
        start: {
          line: 99,
          column: 1
        },
        end: {
          line: 103,
          column: 24
        }
      },
      "60": {
        start: {
          line: 99,
          column: 44
        },
        end: {
          line: 103,
          column: 3
        }
      },
      "61": {
        start: {
          line: 99,
          column: 64
        },
        end: {
          line: 99,
          column: 128
        }
      },
      "62": {
        start: {
          line: 100,
          column: 2
        },
        end: {
          line: 102,
          column: 3
        }
      },
      "63": {
        start: {
          line: 101,
          column: 3
        },
        end: {
          line: 101,
          column: 39
        }
      },
      "64": {
        start: {
          line: 104,
          column: 1
        },
        end: {
          line: 104,
          column: 19
        }
      },
      "65": {
        start: {
          line: 107,
          column: 21
        },
        end: {
          line: 107,
          column: 37
        }
      },
      "66": {
        start: {
          line: 108,
          column: 1
        },
        end: {
          line: 110,
          column: 2
        }
      },
      "67": {
        start: {
          line: 109,
          column: 2
        },
        end: {
          line: 109,
          column: 9
        }
      },
      "68": {
        start: {
          line: 111,
          column: 21
        },
        end: {
          line: 111,
          column: 123
        }
      },
      "69": {
        start: {
          line: 112,
          column: 1
        },
        end: {
          line: 139,
          column: 2
        }
      },
      "70": {
        start: {
          line: 113,
          column: 2
        },
        end: {
          line: 113,
          column: 44
        }
      },
      "71": {
        start: {
          line: 114,
          column: 2
        },
        end: {
          line: 114,
          column: 60
        }
      },
      "72": {
        start: {
          line: 117,
          column: 15
        },
        end: {
          line: 117,
          column: 31
        }
      },
      "73": {
        start: {
          line: 118,
          column: 21
        },
        end: {
          line: 118,
          column: 50
        }
      },
      "74": {
        start: {
          line: 119,
          column: 17
        },
        end: {
          line: 119,
          column: 98
        }
      },
      "75": {
        start: {
          line: 120,
          column: 2
        },
        end: {
          line: 138,
          column: 5
        }
      },
      "76": {
        start: {
          line: 121,
          column: 15
        },
        end: {
          line: 121,
          column: 49
        }
      },
      "77": {
        start: {
          line: 122,
          column: 3
        },
        end: {
          line: 130,
          column: 4
        }
      },
      "78": {
        start: {
          line: 124,
          column: 4
        },
        end: {
          line: 129,
          column: 5
        }
      },
      "79": {
        start: {
          line: 125,
          column: 5
        },
        end: {
          line: 125,
          column: 69
        }
      },
      "80": {
        start: {
          line: 125,
          column: 62
        },
        end: {
          line: 125,
          column: 69
        }
      },
      "81": {
        start: {
          line: 127,
          column: 5
        },
        end: {
          line: 127,
          column: 123
        }
      },
      "82": {
        start: {
          line: 128,
          column: 5
        },
        end: {
          line: 128,
          column: 65
        }
      },
      "83": {
        start: {
          line: 128,
          column: 58
        },
        end: {
          line: 128,
          column: 65
        }
      },
      "84": {
        start: {
          line: 131,
          column: 3
        },
        end: {
          line: 133,
          column: 4
        }
      },
      "85": {
        start: {
          line: 132,
          column: 4
        },
        end: {
          line: 132,
          column: 20
        }
      },
      "86": {
        start: {
          line: 134,
          column: 3
        },
        end: {
          line: 136,
          column: 4
        }
      },
      "87": {
        start: {
          line: 135,
          column: 4
        },
        end: {
          line: 135,
          column: 52
        }
      },
      "88": {
        start: {
          line: 137,
          column: 3
        },
        end: {
          line: 137,
          column: 79
        }
      },
      "89": {
        start: {
          line: 140,
          column: 1
        },
        end: {
          line: 140,
          column: 20
        }
      },
      "90": {
        start: {
          line: 143,
          column: 21
        },
        end: {
          line: 143,
          column: 37
        }
      },
      "91": {
        start: {
          line: 144,
          column: 1
        },
        end: {
          line: 174,
          column: 2
        }
      },
      "92": {
        start: {
          line: 148,
          column: 19
        },
        end: {
          line: 148,
          column: 85
        }
      },
      "93": {
        start: {
          line: 149,
          column: 13
        },
        end: {
          line: 149,
          column: 74
        }
      },
      "94": {
        start: {
          line: 149,
          column: 23
        },
        end: {
          line: 149,
          column: 74
        }
      },
      "95": {
        start: {
          line: 150,
          column: 18
        },
        end: {
          line: 171,
          column: 3
        }
      },
      "96": {
        start: {
          line: 151,
          column: 22
        },
        end: {
          line: 151,
          column: 65
        }
      },
      "97": {
        start: {
          line: 152,
          column: 19
        },
        end: {
          line: 152,
          column: 128
        }
      },
      "98": {
        start: {
          line: 153,
          column: 3
        },
        end: {
          line: 153,
          column: 88
        }
      },
      "99": {
        start: {
          line: 153,
          column: 81
        },
        end: {
          line: 153,
          column: 88
        }
      },
      "100": {
        start: {
          line: 154,
          column: 16
        },
        end: {
          line: 154,
          column: 67
        }
      },
      "101": {
        start: {
          line: 155,
          column: 26
        },
        end: {
          line: 155,
          column: 158
        }
      },
      "102": {
        start: {
          line: 158,
          column: 29
        },
        end: {
          line: 158,
          column: 156
        }
      },
      "103": {
        start: {
          line: 159,
          column: 3
        },
        end: {
          line: 159,
          column: 91
        }
      },
      "104": {
        start: {
          line: 159,
          column: 84
        },
        end: {
          line: 159,
          column: 91
        }
      },
      "105": {
        start: {
          line: 160,
          column: 16
        },
        end: {
          line: 160,
          column: 67
        }
      },
      "106": {
        start: {
          line: 161,
          column: 3
        },
        end: {
          line: 161,
          column: 66
        }
      },
      "107": {
        start: {
          line: 161,
          column: 59
        },
        end: {
          line: 161,
          column: 66
        }
      },
      "108": {
        start: {
          line: 162,
          column: 17
        },
        end: {
          line: 162,
          column: 120
        }
      },
      "109": {
        start: {
          line: 163,
          column: 18
        },
        end: {
          line: 163,
          column: 51
        }
      },
      "110": {
        start: {
          line: 164,
          column: 3
        },
        end: {
          line: 164,
          column: 27
        }
      },
      "111": {
        start: {
          line: 164,
          column: 20
        },
        end: {
          line: 164,
          column: 27
        }
      },
      "112": {
        start: {
          line: 168,
          column: 20
        },
        end: {
          line: 168,
          column: 83
        }
      },
      "113": {
        start: {
          line: 169,
          column: 3
        },
        end: {
          line: 169,
          column: 40
        }
      },
      "114": {
        start: {
          line: 170,
          column: 3
        },
        end: {
          line: 170,
          column: 59
        }
      },
      "115": {
        start: {
          line: 172,
          column: 2
        },
        end: {
          line: 172,
          column: 60
        }
      },
      "116": {
        start: {
          line: 173,
          column: 2
        },
        end: {
          line: 173,
          column: 62
        }
      },
      "117": {
        start: {
          line: 177,
          column: 1
        },
        end: {
          line: 179,
          column: 2
        }
      },
      "118": {
        start: {
          line: 178,
          column: 2
        },
        end: {
          line: 178,
          column: 44
        }
      },
      "119": {
        start: {
          line: 180,
          column: 1
        },
        end: {
          line: 182,
          column: 2
        }
      },
      "120": {
        start: {
          line: 181,
          column: 2
        },
        end: {
          line: 181,
          column: 53
        }
      },
      "121": {
        start: {
          line: 185,
          column: 1
        },
        end: {
          line: 191,
          column: 2
        }
      },
      "122": {
        start: {
          line: 186,
          column: 2
        },
        end: {
          line: 190,
          column: 3
        }
      },
      "123": {
        start: {
          line: 187,
          column: 3
        },
        end: {
          line: 187,
          column: 43
        }
      },
      "124": {
        start: {
          line: 189,
          column: 3
        },
        end: {
          line: 189,
          column: 42
        }
      },
      "125": {
        start: {
          line: 194,
          column: 1
        },
        end: {
          line: 208,
          column: 4
        }
      },
      "126": {
        start: {
          line: 195,
          column: 20
        },
        end: {
          line: 195,
          column: 34
        }
      },
      "127": {
        start: {
          line: 196,
          column: 2
        },
        end: {
          line: 196,
          column: 63
        }
      },
      "128": {
        start: {
          line: 196,
          column: 47
        },
        end: {
          line: 196,
          column: 63
        }
      },
      "129": {
        start: {
          line: 197,
          column: 2
        },
        end: {
          line: 207,
          column: 3
        }
      },
      "130": {
        start: {
          line: 198,
          column: 18
        },
        end: {
          line: 198,
          column: 85
        }
      },
      "131": {
        start: {
          line: 199,
          column: 3
        },
        end: {
          line: 199,
          column: 37
        }
      },
      "132": {
        start: {
          line: 199,
          column: 21
        },
        end: {
          line: 199,
          column: 37
        }
      },
      "133": {
        start: {
          line: 200,
          column: 18
        },
        end: {
          line: 200,
          column: 70
        }
      },
      "134": {
        start: {
          line: 201,
          column: 3
        },
        end: {
          line: 201,
          column: 20
        }
      },
      "135": {
        start: {
          line: 202,
          column: 20
        },
        end: {
          line: 202,
          column: 31
        }
      },
      "136": {
        start: {
          line: 203,
          column: 3
        },
        end: {
          line: 203,
          column: 20
        }
      },
      "137": {
        start: {
          line: 204,
          column: 3
        },
        end: {
          line: 204,
          column: 70
        }
      },
      "138": {
        start: {
          line: 206,
          column: 3
        },
        end: {
          line: 206,
          column: 19
        }
      },
      "139": {
        start: {
          line: 211,
          column: 24
        },
        end: {
          line: 211,
          column: 48
        }
      },
      "140": {
        start: {
          line: 212,
          column: 19
        },
        end: {
          line: 212,
          column: 55
        }
      },
      "141": {
        start: {
          line: 213,
          column: 1
        },
        end: {
          line: 216,
          column: 2
        }
      },
      "142": {
        start: {
          line: 214,
          column: 21
        },
        end: {
          line: 214,
          column: 69
        }
      },
      "143": {
        start: {
          line: 215,
          column: 2
        },
        end: {
          line: 215,
          column: 81
        }
      },
      "144": {
        start: {
          line: 215,
          column: 32
        },
        end: {
          line: 215,
          column: 81
        }
      },
      "145": {
        start: {
          line: 217,
          column: 15
        },
        end: {
          line: 217,
          column: 31
        }
      },
      "146": {
        start: {
          line: 218,
          column: 15
        },
        end: {
          line: 218,
          column: 51
        }
      },
      "147": {
        start: {
          line: 219,
          column: 1
        },
        end: {
          line: 224,
          column: 2
        }
      },
      "148": {
        start: {
          line: 220,
          column: 21
        },
        end: {
          line: 220,
          column: 65
        }
      },
      "149": {
        start: {
          line: 221,
          column: 2
        },
        end: {
          line: 223,
          column: 3
        }
      },
      "150": {
        start: {
          line: 222,
          column: 3
        },
        end: {
          line: 222,
          column: 86
        }
      },
      "151": {
        start: {
          line: 227,
          column: 1
        },
        end: {
          line: 253,
          column: 2
        }
      },
      "152": {
        start: {
          line: 228,
          column: 19
        },
        end: {
          line: 228,
          column: 127
        }
      },
      "153": {
        start: {
          line: 229,
          column: 22
        },
        end: {
          line: 229,
          column: 86
        }
      },
      "154": {
        start: {
          line: 230,
          column: 2
        },
        end: {
          line: 230,
          column: 56
        }
      },
      "155": {
        start: {
          line: 231,
          column: 2
        },
        end: {
          line: 231,
          column: 42
        }
      },
      "156": {
        start: {
          line: 232,
          column: 2
        },
        end: {
          line: 232,
          column: 47
        }
      },
      "157": {
        start: {
          line: 233,
          column: 2
        },
        end: {
          line: 233,
          column: 50
        }
      },
      "158": {
        start: {
          line: 234,
          column: 2
        },
        end: {
          line: 250,
          column: 3
        }
      },
      "159": {
        start: {
          line: 235,
          column: 20
        },
        end: {
          line: 235,
          column: 21
        }
      },
      "160": {
        start: {
          line: 236,
          column: 19
        },
        end: {
          line: 236,
          column: 20
        }
      },
      "161": {
        start: {
          line: 237,
          column: 3
        },
        end: {
          line: 240,
          column: 13
        }
      },
      "162": {
        start: {
          line: 238,
          column: 4
        },
        end: {
          line: 238,
          column: 50
        }
      },
      "163": {
        start: {
          line: 239,
          column: 4
        },
        end: {
          line: 239,
          column: 49
        }
      },
      "164": {
        start: {
          line: 241,
          column: 3
        },
        end: {
          line: 241,
          column: 94
        }
      },
      "165": {
        start: {
          line: 243,
          column: 3
        },
        end: {
          line: 243,
          column: 40
        }
      },
      "166": {
        start: {
          line: 245,
          column: 3
        },
        end: {
          line: 247,
          column: 4
        }
      },
      "167": {
        start: {
          line: 246,
          column: 4
        },
        end: {
          line: 246,
          column: 55
        }
      },
      "168": {
        start: {
          line: 249,
          column: 3
        },
        end: {
          line: 249,
          column: 53
        }
      },
      "169": {
        start: {
          line: 251,
          column: 2
        },
        end: {
          line: 251,
          column: 86
        }
      },
      "170": {
        start: {
          line: 251,
          column: 19
        },
        end: {
          line: 251,
          column: 86
        }
      },
      "171": {
        start: {
          line: 252,
          column: 2
        },
        end: {
          line: 252,
          column: 48
        }
      },
      "172": {
        start: {
          line: 254,
          column: 1
        },
        end: {
          line: 254,
          column: 19
        }
      },
      "173": {
        start: {
          line: 257,
          column: 1
        },
        end: {
          line: 257,
          column: 132
        }
      },
      "174": {
        start: {
          line: 257,
          column: 66
        },
        end: {
          line: 257,
          column: 130
        }
      },
      "175": {
        start: {
          line: 258,
          column: 1
        },
        end: {
          line: 258,
          column: 14
        }
      },
      "176": {
        start: {
          line: 261,
          column: 14
        },
        end: {
          line: 261,
          column: 30
        }
      },
      "177": {
        start: {
          line: 262,
          column: 1
        },
        end: {
          line: 262,
          column: 15
        }
      },
      "178": {
        start: {
          line: 263,
          column: 24
        },
        end: {
          line: 263,
          column: 47
        }
      },
      "179": {
        start: {
          line: 264,
          column: 1
        },
        end: {
          line: 264,
          column: 42
        }
      },
      "180": {
        start: {
          line: 264,
          column: 21
        },
        end: {
          line: 264,
          column: 42
        }
      },
      "181": {
        start: {
          line: 265,
          column: 1
        },
        end: {
          line: 265,
          column: 15
        }
      },
      "182": {
        start: {
          line: 267,
          column: 1
        },
        end: {
          line: 267,
          column: 54
        }
      },
      "183": {
        start: {
          line: 267,
          column: 42
        },
        end: {
          line: 267,
          column: 54
        }
      },
      "184": {
        start: {
          line: 268,
          column: 1
        },
        end: {
          line: 271,
          column: 2
        }
      },
      "185": {
        start: {
          line: 268,
          column: 75
        },
        end: {
          line: 268,
          column: 97
        }
      },
      "186": {
        start: {
          line: 269,
          column: 2
        },
        end: {
          line: 269,
          column: 28
        }
      },
      "187": {
        start: {
          line: 270,
          column: 2
        },
        end: {
          line: 270,
          column: 14
        }
      },
      "188": {
        start: {
          line: 272,
          column: 1
        },
        end: {
          line: 275,
          column: 2
        }
      },
      "189": {
        start: {
          line: 273,
          column: 2
        },
        end: {
          line: 273,
          column: 28
        }
      },
      "190": {
        start: {
          line: 274,
          column: 2
        },
        end: {
          line: 274,
          column: 14
        }
      },
      "191": {
        start: {
          line: 276,
          column: 22
        },
        end: {
          line: 276,
          column: 79
        }
      },
      "192": {
        start: {
          line: 277,
          column: 1
        },
        end: {
          line: 282,
          column: 176
        }
      },
      "193": {
        start: {
          line: 277,
          column: 51
        },
        end: {
          line: 277,
          column: 117
        }
      },
      "194": {
        start: {
          line: 278,
          column: 2
        },
        end: {
          line: 280,
          column: 3
        }
      },
      "195": {
        start: {
          line: 279,
          column: 3
        },
        end: {
          line: 279,
          column: 41
        }
      },
      "196": {
        start: {
          line: 281,
          column: 2
        },
        end: {
          line: 281,
          column: 80
        }
      },
      "197": {
        start: {
          line: 282,
          column: 25
        },
        end: {
          line: 282,
          column: 68
        }
      },
      "198": {
        start: {
          line: 282,
          column: 91
        },
        end: {
          line: 282,
          column: 174
        }
      }
    },
    fnMap: {
      "0": {
        name: "createCloneDocument",
        decl: {
          start: {
            line: 9,
            column: 9
          },
          end: {
            line: 9,
            column: 28
          }
        },
        loc: {
          start: {
            line: 9,
            column: 37
          },
          end: {
            line: 17,
            column: 1
          }
        },
        line: 9
      },
      "1": {
        name: "cloneCanvasElement",
        decl: {
          start: {
            line: 18,
            column: 15
          },
          end: {
            line: 18,
            column: 33
          }
        },
        loc: {
          start: {
            line: 18,
            column: 51
          },
          end: {
            line: 24,
            column: 1
          }
        },
        line: 18
      },
      "2": {
        name: "cloneVideoElement",
        decl: {
          start: {
            line: 25,
            column: 15
          },
          end: {
            line: 25,
            column: 32
          }
        },
        loc: {
          start: {
            line: 25,
            column: 49
          },
          end: {
            line: 44,
            column: 1
          }
        },
        line: 25
      },
      "3": {
        name: "cloneIFrameElement",
        decl: {
          start: {
            line: 45,
            column: 15
          },
          end: {
            line: 45,
            column: 33
          }
        },
        loc: {
          start: {
            line: 45,
            column: 83
          },
          end: {
            line: 57,
            column: 1
          }
        },
        line: 45
      },
      "4": {
        name: "cloneSingleNode",
        decl: {
          start: {
            line: 58,
            column: 15
          },
          end: {
            line: 58,
            column: 30
          }
        },
        loc: {
          start: {
            line: 58,
            column: 78
          },
          end: {
            line: 83,
            column: 1
          }
        },
        line: 58
      },
      "5": {
        name: "(anonymous_5)",
        decl: {
          start: {
            line: 84,
            column: 22
          },
          end: {
            line: 84,
            column: 23
          }
        },
        loc: {
          start: {
            line: 84,
            column: 32
          },
          end: {
            line: 84,
            column: 93
          }
        },
        line: 84
      },
      "6": {
        name: "cloneChildren",
        decl: {
          start: {
            line: 85,
            column: 15
          },
          end: {
            line: 85,
            column: 28
          }
        },
        loc: {
          start: {
            line: 85,
            column: 94
          },
          end: {
            line: 105,
            column: 1
          }
        },
        line: 85
      },
      "7": {
        name: "(anonymous_7)",
        decl: {
          start: {
            line: 99,
            column: 23
          },
          end: {
            line: 99,
            column: 24
          }
        },
        loc: {
          start: {
            line: 99,
            column: 44
          },
          end: {
            line: 103,
            column: 3
          }
        },
        line: 99
      },
      "8": {
        name: "(anonymous_8)",
        decl: {
          start: {
            line: 99,
            column: 58
          },
          end: {
            line: 99,
            column: 59
          }
        },
        loc: {
          start: {
            line: 99,
            column: 64
          },
          end: {
            line: 99,
            column: 128
          }
        },
        line: 99
      },
      "9": {
        name: "(anonymous_9)",
        decl: {
          start: {
            line: 99,
            column: 135
          },
          end: {
            line: 99,
            column: 136
          }
        },
        loc: {
          start: {
            line: 99,
            column: 152
          },
          end: {
            line: 103,
            column: 2
          }
        },
        line: 99
      },
      "10": {
        name: "cloneCSSStyle",
        decl: {
          start: {
            line: 106,
            column: 9
          },
          end: {
            line: 106,
            column: 22
          }
        },
        loc: {
          start: {
            line: 106,
            column: 74
          },
          end: {
            line: 141,
            column: 1
          }
        },
        line: 106
      },
      "11": {
        name: "(anonymous_11)",
        decl: {
          start: {
            line: 120,
            column: 52
          },
          end: {
            line: 120,
            column: 53
          }
        },
        loc: {
          start: {
            line: 120,
            column: 62
          },
          end: {
            line: 138,
            column: 3
          }
        },
        line: 120
      },
      "12": {
        name: "restoreScrollbarBox",
        decl: {
          start: {
            line: 142,
            column: 9
          },
          end: {
            line: 142,
            column: 28
          }
        },
        loc: {
          start: {
            line: 142,
            column: 76
          },
          end: {
            line: 175,
            column: 1
          }
        },
        line: 142
      },
      "13": {
        name: "(anonymous_13)",
        decl: {
          start: {
            line: 148,
            column: 8
          },
          end: {
            line: 148,
            column: 9
          }
        },
        loc: {
          start: {
            line: 148,
            column: 19
          },
          end: {
            line: 148,
            column: 85
          }
        },
        line: 148
      },
      "14": {
        name: "(anonymous_14)",
        decl: {
          start: {
            line: 149,
            column: 13
          },
          end: {
            line: 149,
            column: 14
          }
        },
        loc: {
          start: {
            line: 149,
            column: 23
          },
          end: {
            line: 149,
            column: 74
          }
        },
        line: 149
      },
      "15": {
        name: "(anonymous_15)",
        decl: {
          start: {
            line: 150,
            column: 18
          },
          end: {
            line: 150,
            column: 19
          }
        },
        loc: {
          start: {
            line: 150,
            column: 53
          },
          end: {
            line: 171,
            column: 3
          }
        },
        line: 150
      },
      "16": {
        name: "cloneInputValue",
        decl: {
          start: {
            line: 176,
            column: 9
          },
          end: {
            line: 176,
            column: 24
          }
        },
        loc: {
          start: {
            line: 176,
            column: 49
          },
          end: {
            line: 183,
            column: 1
          }
        },
        line: 176
      },
      "17": {
        name: "cloneOptionSelection",
        decl: {
          start: {
            line: 184,
            column: 9
          },
          end: {
            line: 184,
            column: 29
          }
        },
        loc: {
          start: {
            line: 184,
            column: 54
          },
          end: {
            line: 192,
            column: 1
          }
        },
        line: 184
      },
      "18": {
        name: "normalizeClipPathURLs",
        decl: {
          start: {
            line: 193,
            column: 9
          },
          end: {
            line: 193,
            column: 30
          }
        },
        loc: {
          start: {
            line: 193,
            column: 54
          },
          end: {
            line: 209,
            column: 1
          }
        },
        line: 193
      },
      "19": {
        name: "(anonymous_19)",
        decl: {
          start: {
            line: 194,
            column: 70
          },
          end: {
            line: 194,
            column: 71
          }
        },
        loc: {
          start: {
            line: 194,
            column: 106
          },
          end: {
            line: 208,
            column: 2
          }
        },
        line: 194
      },
      "20": {
        name: "cloneClipPathReferences",
        decl: {
          start: {
            line: 210,
            column: 9
          },
          end: {
            line: 210,
            column: 32
          }
        },
        loc: {
          start: {
            line: 210,
            column: 57
          },
          end: {
            line: 225,
            column: 1
          }
        },
        line: 210
      },
      "21": {
        name: "decorate",
        decl: {
          start: {
            line: 226,
            column: 9
          },
          end: {
            line: 226,
            column: 17
          }
        },
        loc: {
          start: {
            line: 226,
            column: 59
          },
          end: {
            line: 255,
            column: 1
          }
        },
        line: 226
      },
      "22": {
        name: "ensureSVGSymbols",
        decl: {
          start: {
            line: 256,
            column: 22
          },
          end: {
            line: 256,
            column: 38
          }
        },
        loc: {
          start: {
            line: 256,
            column: 63
          },
          end: {
            line: 259,
            column: 1
          }
        },
        line: 256
      },
      "23": {
        name: "(anonymous_23)",
        decl: {
          start: {
            line: 257,
            column: 50
          },
          end: {
            line: 257,
            column: 51
          }
        },
        loc: {
          start: {
            line: 257,
            column: 66
          },
          end: {
            line: 257,
            column: 130
          }
        },
        line: 257
      },
      "24": {
        name: "cloneNode",
        decl: {
          start: {
            line: 260,
            column: 22
          },
          end: {
            line: 260,
            column: 31
          }
        },
        loc: {
          start: {
            line: 260,
            column: 94
          },
          end: {
            line: 283,
            column: 1
          }
        },
        line: 260
      },
      "25": {
        name: "(anonymous_25)",
        decl: {
          start: {
            line: 268,
            column: 61
          },
          end: {
            line: 268,
            column: 62
          }
        },
        loc: {
          start: {
            line: 268,
            column: 75
          },
          end: {
            line: 268,
            column: 97
          }
        },
        line: 268
      },
      "26": {
        name: "(anonymous_26)",
        decl: {
          start: {
            line: 277,
            column: 35
          },
          end: {
            line: 277,
            column: 36
          }
        },
        loc: {
          start: {
            line: 277,
            column: 51
          },
          end: {
            line: 277,
            column: 117
          }
        },
        line: 277
      },
      "27": {
        name: "(anonymous_27)",
        decl: {
          start: {
            line: 277,
            column: 124
          },
          end: {
            line: 277,
            column: 125
          }
        },
        loc: {
          start: {
            line: 277,
            column: 140
          },
          end: {
            line: 282,
            column: 2
          }
        },
        line: 277
      },
      "28": {
        name: "(anonymous_28)",
        decl: {
          start: {
            line: 282,
            column: 9
          },
          end: {
            line: 282,
            column: 10
          }
        },
        loc: {
          start: {
            line: 282,
            column: 25
          },
          end: {
            line: 282,
            column: 68
          }
        },
        line: 282
      },
      "29": {
        name: "(anonymous_29)",
        decl: {
          start: {
            line: 282,
            column: 75
          },
          end: {
            line: 282,
            column: 76
          }
        },
        loc: {
          start: {
            line: 282,
            column: 91
          },
          end: {
            line: 282,
            column: 174
          }
        },
        line: 282
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 20,
            column: 1
          },
          end: {
            line: 22,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 20,
            column: 1
          },
          end: {
            line: 22,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 20
      },
      "1": {
        loc: {
          start: {
            line: 26,
            column: 1
          },
          end: {
            line: 30,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 26,
            column: 1
          },
          end: {
            line: 30,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 26
      },
      "2": {
        loc: {
          start: {
            line: 26,
            column: 5
          },
          end: {
            line: 26,
            column: 61
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 26,
            column: 5
          },
          end: {
            line: 26,
            column: 18
          }
        }, {
          start: {
            line: 26,
            column: 22
          },
          end: {
            line: 26,
            column: 61
          }
        }],
        line: 26
      },
      "3": {
        loc: {
          start: {
            line: 31,
            column: 1
          },
          end: {
            line: 39,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 31,
            column: 1
          },
          end: {
            line: 39,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 31
      },
      "4": {
        loc: {
          start: {
            line: 48,
            column: 15
          },
          end: {
            line: 48,
            column: 83
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 48,
            column: 15
          },
          end: {
            line: 48,
            column: 75
          }
        }, {
          start: {
            line: 48,
            column: 79
          },
          end: {
            line: 48,
            column: 83
          }
        }],
        line: 48
      },
      "5": {
        loc: {
          start: {
            line: 50,
            column: 1
          },
          end: {
            line: 55,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 50,
            column: 1
          },
          end: {
            line: 55,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 50
      },
      "6": {
        loc: {
          start: {
            line: 59,
            column: 1
          },
          end: {
            line: 61,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 59,
            column: 1
          },
          end: {
            line: 61,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 59
      },
      "7": {
        loc: {
          start: {
            line: 62,
            column: 1
          },
          end: {
            line: 64,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 62,
            column: 1
          },
          end: {
            line: 64,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 62
      },
      "8": {
        loc: {
          start: {
            line: 65,
            column: 1
          },
          end: {
            line: 67,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 65,
            column: 1
          },
          end: {
            line: 67,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 65
      },
      "9": {
        loc: {
          start: {
            line: 69,
            column: 1
          },
          end: {
            line: 81,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 69,
            column: 1
          },
          end: {
            line: 81,
            column: 2
          }
        }, {
          start: {
            line: 73,
            column: 8
          },
          end: {
            line: 81,
            column: 2
          }
        }],
        line: 69
      },
      "10": {
        loc: {
          start: {
            line: 73,
            column: 8
          },
          end: {
            line: 81,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 73,
            column: 8
          },
          end: {
            line: 81,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 73
      },
      "11": {
        loc: {
          start: {
            line: 75,
            column: 2
          },
          end: {
            line: 80,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 75,
            column: 2
          },
          end: {
            line: 80,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 75
      },
      "12": {
        loc: {
          start: {
            line: 84,
            column: 32
          },
          end: {
            line: 84,
            column: 93
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 84,
            column: 32
          },
          end: {
            line: 84,
            column: 52
          }
        }, {
          start: {
            line: 84,
            column: 56
          },
          end: {
            line: 84,
            column: 93
          }
        }],
        line: 84
      },
      "13": {
        loc: {
          start: {
            line: 87,
            column: 1
          },
          end: {
            line: 95,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 87,
            column: 1
          },
          end: {
            line: 95,
            column: 2
          }
        }, {
          start: {
            line: 90,
            column: 8
          },
          end: {
            line: 95,
            column: 2
          }
        }],
        line: 87
      },
      "14": {
        loc: {
          start: {
            line: 87,
            column: 5
          },
          end: {
            line: 87,
            column: 58
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 87,
            column: 5
          },
          end: {
            line: 87,
            column: 30
          }
        }, {
          start: {
            line: 87,
            column: 34
          },
          end: {
            line: 87,
            column: 58
          }
        }],
        line: 87
      },
      "15": {
        loc: {
          start: {
            line: 89,
            column: 21
          },
          end: {
            line: 89,
            column: 71
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 89,
            column: 39
          },
          end: {
            line: 89,
            column: 47
          }
        }, {
          start: {
            line: 89,
            column: 50
          },
          end: {
            line: 89,
            column: 71
          }
        }],
        line: 89
      },
      "16": {
        loc: {
          start: {
            line: 90,
            column: 8
          },
          end: {
            line: 95,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 90,
            column: 8
          },
          end: {
            line: 95,
            column: 2
          }
        }, {
          start: {
            line: 93,
            column: 8
          },
          end: {
            line: 95,
            column: 2
          }
        }],
        line: 90
      },
      "17": {
        loc: {
          start: {
            line: 94,
            column: 22
          },
          end: {
            line: 94,
            column: 57
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 94,
            column: 22
          },
          end: {
            line: 94,
            column: 43
          }
        }, {
          start: {
            line: 94,
            column: 47
          },
          end: {
            line: 94,
            column: 57
          }
        }],
        line: 94
      },
      "18": {
        loc: {
          start: {
            line: 96,
            column: 1
          },
          end: {
            line: 98,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 96,
            column: 1
          },
          end: {
            line: 98,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 96
      },
      "19": {
        loc: {
          start: {
            line: 96,
            column: 5
          },
          end: {
            line: 96,
            column: 79
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 96,
            column: 5
          },
          end: {
            line: 96,
            column: 26
          }
        }, {
          start: {
            line: 96,
            column: 30
          },
          end: {
            line: 96,
            column: 79
          }
        }],
        line: 96
      },
      "20": {
        loc: {
          start: {
            line: 100,
            column: 2
          },
          end: {
            line: 102,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 100,
            column: 2
          },
          end: {
            line: 102,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 100
      },
      "21": {
        loc: {
          start: {
            line: 108,
            column: 1
          },
          end: {
            line: 110,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 108,
            column: 1
          },
          end: {
            line: 110,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 108
      },
      "22": {
        loc: {
          start: {
            line: 111,
            column: 22
          },
          end: {
            line: 111,
            column: 93
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 111,
            column: 22
          },
          end: {
            line: 111,
            column: 83
          }
        }, {
          start: {
            line: 111,
            column: 87
          },
          end: {
            line: 111,
            column: 93
          }
        }],
        line: 111
      },
      "23": {
        loc: {
          start: {
            line: 112,
            column: 1
          },
          end: {
            line: 139,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 112,
            column: 1
          },
          end: {
            line: 139,
            column: 2
          }
        }, {
          start: {
            line: 115,
            column: 8
          },
          end: {
            line: 139,
            column: 2
          }
        }],
        line: 112
      },
      "24": {
        loc: {
          start: {
            line: 112,
            column: 5
          },
          end: {
            line: 112,
            column: 44
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 112,
            column: 5
          },
          end: {
            line: 112,
            column: 24
          }
        }, {
          start: {
            line: 112,
            column: 28
          },
          end: {
            line: 112,
            column: 44
          }
        }],
        line: 112
      },
      "25": {
        loc: {
          start: {
            line: 119,
            column: 17
          },
          end: {
            line: 119,
            column: 98
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 119,
            column: 26
          },
          end: {
            line: 119,
            column: 30
          }
        }, {
          start: {
            line: 119,
            column: 33
          },
          end: {
            line: 119,
            column: 98
          }
        }],
        line: 119
      },
      "26": {
        loc: {
          start: {
            line: 119,
            column: 33
          },
          end: {
            line: 119,
            column: 98
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 119,
            column: 33
          },
          end: {
            line: 119,
            column: 56
          }
        }, {
          start: {
            line: 119,
            column: 60
          },
          end: {
            line: 119,
            column: 84
          }
        }, {
          start: {
            line: 119,
            column: 88
          },
          end: {
            line: 119,
            column: 98
          }
        }],
        line: 119
      },
      "27": {
        loc: {
          start: {
            line: 122,
            column: 3
          },
          end: {
            line: 130,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 122,
            column: 3
          },
          end: {
            line: 130,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 122
      },
      "28": {
        loc: {
          start: {
            line: 122,
            column: 7
          },
          end: {
            line: 122,
            column: 58
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 122,
            column: 7
          },
          end: {
            line: 122,
            column: 23
          }
        }, {
          start: {
            line: 122,
            column: 27
          },
          end: {
            line: 122,
            column: 33
          }
        }, {
          start: {
            line: 122,
            column: 37
          },
          end: {
            line: 122,
            column: 58
          }
        }],
        line: 122
      },
      "29": {
        loc: {
          start: {
            line: 124,
            column: 4
          },
          end: {
            line: 129,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 124,
            column: 4
          },
          end: {
            line: 129,
            column: 5
          }
        }, {
          start: {
            line: 126,
            column: 11
          },
          end: {
            line: 129,
            column: 5
          }
        }],
        line: 124
      },
      "30": {
        loc: {
          start: {
            line: 125,
            column: 5
          },
          end: {
            line: 125,
            column: 69
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 125,
            column: 5
          },
          end: {
            line: 125,
            column: 69
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 125
      },
      "31": {
        loc: {
          start: {
            line: 127,
            column: 25
          },
          end: {
            line: 127,
            column: 96
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 127,
            column: 25
          },
          end: {
            line: 127,
            column: 86
          }
        }, {
          start: {
            line: 127,
            column: 90
          },
          end: {
            line: 127,
            column: 96
          }
        }],
        line: 127
      },
      "32": {
        loc: {
          start: {
            line: 128,
            column: 5
          },
          end: {
            line: 128,
            column: 65
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 128,
            column: 5
          },
          end: {
            line: 128,
            column: 65
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 128
      },
      "33": {
        loc: {
          start: {
            line: 131,
            column: 3
          },
          end: {
            line: 133,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 131,
            column: 3
          },
          end: {
            line: 133,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 131
      },
      "34": {
        loc: {
          start: {
            line: 131,
            column: 7
          },
          end: {
            line: 131,
            column: 101
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 131,
            column: 7
          },
          end: {
            line: 131,
            column: 25
          }
        }, {
          start: {
            line: 131,
            column: 29
          },
          end: {
            line: 131,
            column: 47
          }
        }, {
          start: {
            line: 131,
            column: 51
          },
          end: {
            line: 131,
            column: 101
          }
        }],
        line: 131
      },
      "35": {
        loc: {
          start: {
            line: 134,
            column: 3
          },
          end: {
            line: 136,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 134,
            column: 3
          },
          end: {
            line: 136,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 134
      },
      "36": {
        loc: {
          start: {
            line: 134,
            column: 7
          },
          end: {
            line: 134,
            column: 51
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 134,
            column: 7
          },
          end: {
            line: 134,
            column: 19
          }
        }, {
          start: {
            line: 134,
            column: 23
          },
          end: {
            line: 134,
            column: 51
          }
        }],
        line: 134
      },
      "37": {
        loc: {
          start: {
            line: 144,
            column: 1
          },
          end: {
            line: 174,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 144,
            column: 1
          },
          end: {
            line: 174,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 144
      },
      "38": {
        loc: {
          start: {
            line: 144,
            column: 5
          },
          end: {
            line: 148,
            column: 86
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 144,
            column: 5
          },
          end: {
            line: 144,
            column: 44
          }
        }, {
          start: {
            line: 144,
            column: 48
          },
          end: {
            line: 148,
            column: 86
          }
        }],
        line: 144
      },
      "39": {
        loc: {
          start: {
            line: 148,
            column: 19
          },
          end: {
            line: 148,
            column: 85
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 148,
            column: 19
          },
          end: {
            line: 148,
            column: 50
          }
        }, {
          start: {
            line: 148,
            column: 54
          },
          end: {
            line: 148,
            column: 85
          }
        }],
        line: 148
      },
      "40": {
        loc: {
          start: {
            line: 149,
            column: 23
          },
          end: {
            line: 149,
            column: 74
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 149,
            column: 23
          },
          end: {
            line: 149,
            column: 69
          }
        }, {
          start: {
            line: 149,
            column: 73
          },
          end: {
            line: 149,
            column: 74
          }
        }],
        line: 149
      },
      "41": {
        loc: {
          start: {
            line: 152,
            column: 19
          },
          end: {
            line: 152,
            column: 128
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 152,
            column: 43
          },
          end: {
            line: 152,
            column: 84
          }
        }, {
          start: {
            line: 152,
            column: 87
          },
          end: {
            line: 152,
            column: 128
          }
        }],
        line: 152
      },
      "42": {
        loc: {
          start: {
            line: 152,
            column: 43
          },
          end: {
            line: 152,
            column: 84
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 152,
            column: 56
          },
          end: {
            line: 152,
            column: 69
          }
        }, {
          start: {
            line: 152,
            column: 72
          },
          end: {
            line: 152,
            column: 84
          }
        }],
        line: 152
      },
      "43": {
        loc: {
          start: {
            line: 152,
            column: 87
          },
          end: {
            line: 152,
            column: 128
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 152,
            column: 100
          },
          end: {
            line: 152,
            column: 112
          }
        }, {
          start: {
            line: 152,
            column: 115
          },
          end: {
            line: 152,
            column: 128
          }
        }],
        line: 152
      },
      "44": {
        loc: {
          start: {
            line: 153,
            column: 3
          },
          end: {
            line: 153,
            column: 88
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 153,
            column: 3
          },
          end: {
            line: 153,
            column: 88
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 153
      },
      "45": {
        loc: {
          start: {
            line: 153,
            column: 7
          },
          end: {
            line: 153,
            column: 79
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 153,
            column: 7
          },
          end: {
            line: 153,
            column: 15
          }
        }, {
          start: {
            line: 153,
            column: 19
          },
          end: {
            line: 153,
            column: 48
          }
        }, {
          start: {
            line: 153,
            column: 52
          },
          end: {
            line: 153,
            column: 79
          }
        }],
        line: 153
      },
      "46": {
        loc: {
          start: {
            line: 154,
            column: 16
          },
          end: {
            line: 154,
            column: 67
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 154,
            column: 40
          },
          end: {
            line: 154,
            column: 52
          }
        }, {
          start: {
            line: 154,
            column: 55
          },
          end: {
            line: 154,
            column: 67
          }
        }],
        line: 154
      },
      "47": {
        loc: {
          start: {
            line: 155,
            column: 26
          },
          end: {
            line: 155,
            column: 158
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 155,
            column: 26
          },
          end: {
            line: 155,
            column: 60
          }
        }, {
          start: {
            line: 155,
            column: 64
          },
          end: {
            line: 155,
            column: 158
          }
        }],
        line: 155
      },
      "48": {
        loc: {
          start: {
            line: 155,
            column: 93
          },
          end: {
            line: 155,
            column: 157
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 155,
            column: 121
          },
          end: {
            line: 155,
            column: 137
          }
        }, {
          start: {
            line: 155,
            column: 140
          },
          end: {
            line: 155,
            column: 157
          }
        }],
        line: 155
      },
      "49": {
        loc: {
          start: {
            line: 158,
            column: 29
          },
          end: {
            line: 158,
            column: 156
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 158,
            column: 29
          },
          end: {
            line: 158,
            column: 56
          }
        }, {
          start: {
            line: 158,
            column: 60
          },
          end: {
            line: 158,
            column: 85
          }
        }, {
          start: {
            line: 158,
            column: 89
          },
          end: {
            line: 158,
            column: 156
          }
        }],
        line: 158
      },
      "50": {
        loc: {
          start: {
            line: 159,
            column: 3
          },
          end: {
            line: 159,
            column: 91
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 159,
            column: 3
          },
          end: {
            line: 159,
            column: 91
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 159
      },
      "51": {
        loc: {
          start: {
            line: 159,
            column: 7
          },
          end: {
            line: 159,
            column: 82
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 159,
            column: 7
          },
          end: {
            line: 159,
            column: 60
          }
        }, {
          start: {
            line: 159,
            column: 64
          },
          end: {
            line: 159,
            column: 82
          }
        }],
        line: 159
      },
      "52": {
        loc: {
          start: {
            line: 161,
            column: 3
          },
          end: {
            line: 161,
            column: 66
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 161,
            column: 3
          },
          end: {
            line: 161,
            column: 66
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 161
      },
      "53": {
        loc: {
          start: {
            line: 161,
            column: 7
          },
          end: {
            line: 161,
            column: 57
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 161,
            column: 7
          },
          end: {
            line: 161,
            column: 29
          }
        }, {
          start: {
            line: 161,
            column: 33
          },
          end: {
            line: 161,
            column: 57
          }
        }],
        line: 161
      },
      "54": {
        loc: {
          start: {
            line: 164,
            column: 3
          },
          end: {
            line: 164,
            column: 27
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 164,
            column: 3
          },
          end: {
            line: 164,
            column: 27
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 164
      },
      "55": {
        loc: {
          start: {
            line: 168,
            column: 20
          },
          end: {
            line: 168,
            column: 83
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 168,
            column: 64
          },
          end: {
            line: 168,
            column: 71
          }
        }, {
          start: {
            line: 168,
            column: 74
          },
          end: {
            line: 168,
            column: 83
          }
        }],
        line: 168
      },
      "56": {
        loc: {
          start: {
            line: 168,
            column: 20
          },
          end: {
            line: 168,
            column: 61
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 168,
            column: 20
          },
          end: {
            line: 168,
            column: 28
          }
        }, {
          start: {
            line: 168,
            column: 32
          },
          end: {
            line: 168,
            column: 61
          }
        }],
        line: 168
      },
      "57": {
        loc: {
          start: {
            line: 177,
            column: 1
          },
          end: {
            line: 179,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 177,
            column: 1
          },
          end: {
            line: 179,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 177
      },
      "58": {
        loc: {
          start: {
            line: 180,
            column: 1
          },
          end: {
            line: 182,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 180,
            column: 1
          },
          end: {
            line: 182,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 180
      },
      "59": {
        loc: {
          start: {
            line: 185,
            column: 1
          },
          end: {
            line: 191,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 185,
            column: 1
          },
          end: {
            line: 191,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 185
      },
      "60": {
        loc: {
          start: {
            line: 186,
            column: 2
          },
          end: {
            line: 190,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 186,
            column: 2
          },
          end: {
            line: 190,
            column: 3
          }
        }, {
          start: {
            line: 188,
            column: 9
          },
          end: {
            line: 190,
            column: 3
          }
        }],
        line: 186
      },
      "61": {
        loc: {
          start: {
            line: 195,
            column: 20
          },
          end: {
            line: 195,
            column: 34
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 195,
            column: 20
          },
          end: {
            line: 195,
            column: 26
          }
        }, {
          start: {
            line: 195,
            column: 30
          },
          end: {
            line: 195,
            column: 34
          }
        }],
        line: 195
      },
      "62": {
        loc: {
          start: {
            line: 196,
            column: 2
          },
          end: {
            line: 196,
            column: 63
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 196,
            column: 2
          },
          end: {
            line: 196,
            column: 63
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 196
      },
      "63": {
        loc: {
          start: {
            line: 196,
            column: 6
          },
          end: {
            line: 196,
            column: 45
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 196,
            column: 6
          },
          end: {
            line: 196,
            column: 16
          }
        }, {
          start: {
            line: 196,
            column: 20
          },
          end: {
            line: 196,
            column: 45
          }
        }],
        line: 196
      },
      "64": {
        loc: {
          start: {
            line: 199,
            column: 3
          },
          end: {
            line: 199,
            column: 37
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 199,
            column: 3
          },
          end: {
            line: 199,
            column: 37
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 199
      },
      "65": {
        loc: {
          start: {
            line: 204,
            column: 10
          },
          end: {
            line: 204,
            column: 69
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 204,
            column: 40
          },
          end: {
            line: 204,
            column: 58
          }
        }, {
          start: {
            line: 204,
            column: 61
          },
          end: {
            line: 204,
            column: 69
          }
        }],
        line: 204
      },
      "66": {
        loc: {
          start: {
            line: 213,
            column: 1
          },
          end: {
            line: 216,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 213,
            column: 1
          },
          end: {
            line: 216,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 213
      },
      "67": {
        loc: {
          start: {
            line: 213,
            column: 5
          },
          end: {
            line: 213,
            column: 42
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 213,
            column: 5
          },
          end: {
            line: 213,
            column: 14
          }
        }, {
          start: {
            line: 213,
            column: 18
          },
          end: {
            line: 213,
            column: 42
          }
        }],
        line: 213
      },
      "68": {
        loc: {
          start: {
            line: 215,
            column: 2
          },
          end: {
            line: 215,
            column: 81
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 215,
            column: 2
          },
          end: {
            line: 215,
            column: 81
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 215
      },
      "69": {
        loc: {
          start: {
            line: 219,
            column: 1
          },
          end: {
            line: 224,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 219,
            column: 1
          },
          end: {
            line: 224,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 219
      },
      "70": {
        loc: {
          start: {
            line: 221,
            column: 2
          },
          end: {
            line: 223,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 221,
            column: 2
          },
          end: {
            line: 223,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 221
      },
      "71": {
        loc: {
          start: {
            line: 227,
            column: 1
          },
          end: {
            line: 253,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 227,
            column: 1
          },
          end: {
            line: 253,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 227
      },
      "72": {
        loc: {
          start: {
            line: 228,
            column: 19
          },
          end: {
            line: 228,
            column: 127
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 228,
            column: 52
          },
          end: {
            line: 228,
            column: 94
          }
        }, {
          start: {
            line: 228,
            column: 97
          },
          end: {
            line: 228,
            column: 127
          }
        }],
        line: 228
      },
      "73": {
        loc: {
          start: {
            line: 234,
            column: 2
          },
          end: {
            line: 250,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 234,
            column: 2
          },
          end: {
            line: 250,
            column: 3
          }
        }, {
          start: {
            line: 248,
            column: 9
          },
          end: {
            line: 250,
            column: 3
          }
        }],
        line: 234
      },
      "74": {
        loc: {
          start: {
            line: 234,
            column: 6
          },
          end: {
            line: 234,
            column: 88
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 234,
            column: 6
          },
          end: {
            line: 234,
            column: 56
          }
        }, {
          start: {
            line: 234,
            column: 60
          },
          end: {
            line: 234,
            column: 88
          }
        }],
        line: 234
      },
      "75": {
        loc: {
          start: {
            line: 245,
            column: 3
          },
          end: {
            line: 247,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 245,
            column: 3
          },
          end: {
            line: 247,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 245
      },
      "76": {
        loc: {
          start: {
            line: 245,
            column: 7
          },
          end: {
            line: 245,
            column: 75
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 245,
            column: 7
          },
          end: {
            line: 245,
            column: 34
          }
        }, {
          start: {
            line: 245,
            column: 38
          },
          end: {
            line: 245,
            column: 75
          }
        }],
        line: 245
      },
      "77": {
        loc: {
          start: {
            line: 251,
            column: 2
          },
          end: {
            line: 251,
            column: 86
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 251,
            column: 2
          },
          end: {
            line: 251,
            column: 86
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 251
      },
      "78": {
        loc: {
          start: {
            line: 260,
            column: 55
          },
          end: {
            line: 260,
            column: 76
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 260,
            column: 72
          },
          end: {
            line: 260,
            column: 76
          }
        }],
        line: 260
      },
      "79": {
        loc: {
          start: {
            line: 264,
            column: 1
          },
          end: {
            line: 264,
            column: 42
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 264,
            column: 1
          },
          end: {
            line: 264,
            column: 42
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 264
      },
      "80": {
        loc: {
          start: {
            line: 267,
            column: 1
          },
          end: {
            line: 267,
            column: 54
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 267,
            column: 1
          },
          end: {
            line: 267,
            column: 54
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 267
      },
      "81": {
        loc: {
          start: {
            line: 268,
            column: 1
          },
          end: {
            line: 271,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 268,
            column: 1
          },
          end: {
            line: 271,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 268
      },
      "82": {
        loc: {
          start: {
            line: 268,
            column: 5
          },
          end: {
            line: 268,
            column: 98
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 268,
            column: 5
          },
          end: {
            line: 268,
            column: 12
          }
        }, {
          start: {
            line: 268,
            column: 16
          },
          end: {
            line: 268,
            column: 35
          }
        }, {
          start: {
            line: 268,
            column: 39
          },
          end: {
            line: 268,
            column: 98
          }
        }],
        line: 268
      },
      "83": {
        loc: {
          start: {
            line: 272,
            column: 1
          },
          end: {
            line: 275,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 272,
            column: 1
          },
          end: {
            line: 275,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 272
      },
      "84": {
        loc: {
          start: {
            line: 272,
            column: 5
          },
          end: {
            line: 272,
            column: 55
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 272,
            column: 5
          },
          end: {
            line: 272,
            column: 12
          }
        }, {
          start: {
            line: 272,
            column: 16
          },
          end: {
            line: 272,
            column: 30
          }
        }, {
          start: {
            line: 272,
            column: 34
          },
          end: {
            line: 272,
            column: 55
          }
        }],
        line: 272
      },
      "85": {
        loc: {
          start: {
            line: 276,
            column: 22
          },
          end: {
            line: 276,
            column: 79
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 276,
            column: 22
          },
          end: {
            line: 276,
            column: 36
          }
        }, {
          start: {
            line: 276,
            column: 40
          },
          end: {
            line: 276,
            column: 79
          }
        }],
        line: 276
      },
      "86": {
        loc: {
          start: {
            line: 278,
            column: 2
          },
          end: {
            line: 280,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 278,
            column: 2
          },
          end: {
            line: 280,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 278
      },
      "87": {
        loc: {
          start: {
            line: 282,
            column: 91
          },
          end: {
            line: 282,
            column: 174
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 282,
            column: 118
          },
          end: {
            line: 282,
            column: 161
          }
        }, {
          start: {
            line: 282,
            column: 164
          },
          end: {
            line: 282,
            column: 174
          }
        }],
        line: 282
      },
      "88": {
        loc: {
          start: {
            line: 282,
            column: 91
          },
          end: {
            line: 282,
            column: 115
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 282,
            column: 91
          },
          end: {
            line: 282,
            column: 97
          }
        }, {
          start: {
            line: 282,
            column: 101
          },
          end: {
            line: 282,
            column: 115
          }
        }],
        line: 282
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0,
      "81": 0,
      "82": 0,
      "83": 0,
      "84": 0,
      "85": 0,
      "86": 0,
      "87": 0,
      "88": 0,
      "89": 0,
      "90": 0,
      "91": 0,
      "92": 0,
      "93": 0,
      "94": 0,
      "95": 0,
      "96": 0,
      "97": 0,
      "98": 0,
      "99": 0,
      "100": 0,
      "101": 0,
      "102": 0,
      "103": 0,
      "104": 0,
      "105": 0,
      "106": 0,
      "107": 0,
      "108": 0,
      "109": 0,
      "110": 0,
      "111": 0,
      "112": 0,
      "113": 0,
      "114": 0,
      "115": 0,
      "116": 0,
      "117": 0,
      "118": 0,
      "119": 0,
      "120": 0,
      "121": 0,
      "122": 0,
      "123": 0,
      "124": 0,
      "125": 0,
      "126": 0,
      "127": 0,
      "128": 0,
      "129": 0,
      "130": 0,
      "131": 0,
      "132": 0,
      "133": 0,
      "134": 0,
      "135": 0,
      "136": 0,
      "137": 0,
      "138": 0,
      "139": 0,
      "140": 0,
      "141": 0,
      "142": 0,
      "143": 0,
      "144": 0,
      "145": 0,
      "146": 0,
      "147": 0,
      "148": 0,
      "149": 0,
      "150": 0,
      "151": 0,
      "152": 0,
      "153": 0,
      "154": 0,
      "155": 0,
      "156": 0,
      "157": 0,
      "158": 0,
      "159": 0,
      "160": 0,
      "161": 0,
      "162": 0,
      "163": 0,
      "164": 0,
      "165": 0,
      "166": 0,
      "167": 0,
      "168": 0,
      "169": 0,
      "170": 0,
      "171": 0,
      "172": 0,
      "173": 0,
      "174": 0,
      "175": 0,
      "176": 0,
      "177": 0,
      "178": 0,
      "179": 0,
      "180": 0,
      "181": 0,
      "182": 0,
      "183": 0,
      "184": 0,
      "185": 0,
      "186": 0,
      "187": 0,
      "188": 0,
      "189": 0,
      "190": 0,
      "191": 0,
      "192": 0,
      "193": 0,
      "194": 0,
      "195": 0,
      "196": 0,
      "197": 0,
      "198": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0],
      "4": [0, 0],
      "5": [0, 0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0],
      "10": [0, 0],
      "11": [0, 0],
      "12": [0, 0],
      "13": [0, 0],
      "14": [0, 0],
      "15": [0, 0],
      "16": [0, 0],
      "17": [0, 0],
      "18": [0, 0],
      "19": [0, 0],
      "20": [0, 0],
      "21": [0, 0],
      "22": [0, 0],
      "23": [0, 0],
      "24": [0, 0],
      "25": [0, 0],
      "26": [0, 0, 0],
      "27": [0, 0],
      "28": [0, 0, 0],
      "29": [0, 0],
      "30": [0, 0],
      "31": [0, 0],
      "32": [0, 0],
      "33": [0, 0],
      "34": [0, 0, 0],
      "35": [0, 0],
      "36": [0, 0],
      "37": [0, 0],
      "38": [0, 0],
      "39": [0, 0],
      "40": [0, 0],
      "41": [0, 0],
      "42": [0, 0],
      "43": [0, 0],
      "44": [0, 0],
      "45": [0, 0, 0],
      "46": [0, 0],
      "47": [0, 0],
      "48": [0, 0],
      "49": [0, 0, 0],
      "50": [0, 0],
      "51": [0, 0],
      "52": [0, 0],
      "53": [0, 0],
      "54": [0, 0],
      "55": [0, 0],
      "56": [0, 0],
      "57": [0, 0],
      "58": [0, 0],
      "59": [0, 0],
      "60": [0, 0],
      "61": [0, 0],
      "62": [0, 0],
      "63": [0, 0],
      "64": [0, 0],
      "65": [0, 0],
      "66": [0, 0],
      "67": [0, 0],
      "68": [0, 0],
      "69": [0, 0],
      "70": [0, 0],
      "71": [0, 0],
      "72": [0, 0],
      "73": [0, 0],
      "74": [0, 0],
      "75": [0, 0],
      "76": [0, 0],
      "77": [0, 0],
      "78": [0],
      "79": [0, 0],
      "80": [0, 0],
      "81": [0, 0],
      "82": [0, 0, 0],
      "83": [0, 0],
      "84": [0, 0, 0],
      "85": [0, 0],
      "86": [0, 0],
      "87": [0, 0],
      "88": [0, 0]
    },
    inputSourceMap: {
      mappings: "AAAA,SACE,oBACA,sBACA,oCACK;AAEP,SAAS,2BAA2B;AACpC,SACE,aACA,SACA,qBACA,0BACK;AACP,SAAS,mBAAmB;AAC5B,SAAS,yBAAyB;AAClC,SAAS,eAAe;AACxB,SAAS,oBAAoB,uBAAuB;AACpD,SAAS,wBAAwB;AAEjC,SAAS,oBAAoB,QAAkB;;;CAG7C,MAAM,OAAO,qBACX,QACA,gBACF,CAAC,CAAC,mBAAmB;CACrB,MAAM,OAAO,QAAQ,MACnB,qBAAqB,MAAM,eAAe,GAC1C,MACA,CAAC,MAAM,CACT;CACA,KAAK,OAAO,qBAAqB,QAAQ,SAAS;CAClD,qBAAqB,MAAM,MAAM,CAAC,CAAC,OAAO,IAAI;CAC9C,OAAO;AACT;AAEA,eAAe,mBAAmB,QAA2B,SAAkB;CAC7E,MAAM,UAAU,OAAO,UAAU;CACjC,IAAI,YAAY,UAAU;EACxB,OAAO,OAAO,UAAU,KAAK;CAC/B;CACA,OAAO,YAAY,SAAS,OAAO;AACrC;AAEA,eAAe,kBAAkB,OAAyB,SAAkB;CAC1E,IAAI,CAAC,MAAM,UAAU,MAAM,eAAe,MAAM,cAAc;;EAE5D,MAAM,QAAQ,mBAAmB,UAAU,eAAe,CAAC,CAAC,QAAQ;EACpE,OAAO,YAAY,MAAM,UAAU,GAAG,OAAO;CAC/C;CACA,IAAI,MAAM,YAAY;EACpB,MAAM,SAAS,mBAAmB,UAAU,eAAe,CAAC,CAAC,QAAQ;EACrE,MAAM,MAAM,OAAO,WAAW,IAAI;EAClC,OAAO,QAAQ,MAAM;EACrB,OAAO,SAAS,MAAM;EACtB,KAAK,UAAU,OAAO,GAAG,GAAG,OAAO,OAAO,OAAO,MAAM;EACvD,MAAM,UAAU,OAAO,UAAU;EACjC,OAAO,YAAY,SAAS,OAAO;CACrC;CAEA,MAAM,SAAS,MAAM;CACrB,MAAM,cAAc,YAAY,MAAM;CACtC,MAAM,UAAU,MAAM,kBAAkB,QAAQ,aAAa,OAAO;CACpE,OAAO,YAAY,SAAS,OAAO;AACrC;AAEA,eAAe,mBACb,QACA,SACA,gBACA,gBACA;CACA,IAAI,aAAiC;CACrC,IAAI;EACF,aACE,6BAA6B,OAAO,iBAAiB,MAAM,KAAK;CACpE,QAAQ,CAER;CACA,IAAI,YAAY;EACd,MAAM,OAAO,MAAM,UACjB,YACA,SACA,MACA,gBACA,cACF;EACA,MAAM,WAAW,mBAAmB,gBAAgB,eAAe,CAAC,CAAC,KAAK;EAC1E,SAAS,YAAY,IAAK;EAC1B,OAAO;CACT;CAEA,OAAO,mBAAmB,gBAAgB,YAAY,CAAC,CAAC,QAAQ,KAAK;AACvE;AAEA,eAAe,gBACb,MACA,SACA,gBACA,gBACsB;CACtB,IAAI,oBAAoB,MAAM,iBAAiB,GAAG;EAChD,OAAO,mBACL,gBACA,WACF,CAAC,CAAC,MAAM,mBAAmB,MAAM,OAAO,CAAC;CAC3C;CAEA,IAAI,oBAAoB,MAAM,gBAAgB,GAAG;EAC/C,OAAO,mBACL,gBACA,WACF,CAAC,CAAC,MAAM,kBAAkB,MAAM,OAAO,CAAC;CAC1C;CAEA,IAAI,oBAAoB,MAAM,iBAAiB,GAAG;EAChD,OAAO,mBAAmB,MAAM,SAAS,gBAAgB,cAAc;CACzE;CAEA,MAAM,OAAO,mBAAmB,gBAAgB,YAAY,CAAC,CAAC,MAAM,KAAK;CACzE,IAAI,oBAAoB,MAAM,gBAAgB,GAAG;;EAE/C;EAAC,AAAC,KAAqC,MAAM,KAAK;CACpD,OAAO,IAAI,oBAAoB,MAAM,eAAe,GAAG;EACrD,MAAM,OAAO,gBAAgB,IAAI;EACjC,IAAI,MAAM;GACR,IAAI;IACF,KAAK,aAAa,QAAQ,IAAI,IAAI,MAAM,KAAK,OAAO,CAAC,CAAC,IAAI;IAC1D,KAAK,kBAAkB,gCAAgC,MAAM;GAC/D,QAAQ,CAER;EACF;CACF;CACA,OAAO;AACT;AAEA,MAAM,iBAAiB,SACrB,KAAK,WAAW,QAAQ,KAAK,QAAQ,YAAY,MAAM;AAEzD,eAAe,cACb,YACA,YACA,SACA,gBACA,gBACY;CACZ,IAAI;CAEJ,IAAI,cAAc,UAAU,KAAK,WAAW,eAAe;EACzD,MAAM,WAAW,WAAW,cAAc;EAC1C,WAAW,QAAW,SAAS,SAAS,WAAW,WAAW,UAAU;CAC1E,OAAO,IAAI,oBAAoB,YAAY,iBAAiB,GAAG;;EAE7D,OAAO;CACT,OAAO;EACL,WAAW,SAAY,WAAW,cAAc,WAAU,CAAE,UAAU;CACxE;CAEA,IACE,SAAS,WAAW,KACpB,oBAAoB,YAAY,gBAAgB,GAChD;EACA,OAAO;CACT;CAEA,MAAM,SAAS,QACZ,UAAU,UACT,SACG,WACC,UAAU,OAAO,SAAS,OAAO,gBAAgB,cAAc,CACjE,CAAC,CACA,MAAM,gBAAoC;EACzC,IAAI,aAAa;GACf,WAAW,YAAY,WAAW;EACpC;CACF,CAAC,GACL,QAAQ,QAAQ,CAClB;CAEA,OAAO;AACT;AAEA,SAAS,cACP,YACA,YACA,SACA,UACA,QACA;CACA,MAAM,cAAc,WAAW;CAC/B,IAAI,CAAC,aAAa;EAChB;CACF;CAEA,MAAM,eACJ,qBAAqB,WAAW,eAAe,aAAa,KAAK,OAAM,CACvE,iBAAiB,UAAU;CAC7B,IAAI,YAAY,WAAW,YAAY,MAAM;EAC3C,YAAY,UAAU,YAAY;EAClC,YAAY,kBAAkB,YAAY;CAC5C,OAAO;EACL,IAAI;EACJ,MAAM,OAAO,QAAQ,OAAO;EAC5B,MAAM,aAAc,WAAW,YAAY,CAAC,CAAgB;EAC5D,MAAM,SAAS,SACX,OACA,WAAW,gBAAgB,WAAW,iBAAiB;EAC3D,mBAAmB,aAAa,QAAQ,CAAC,CAAC,SAAS,SAAS;GAC1D,IAAI,QAAQ,YAAY,iBAAiB,IAAI;GAC7C,IAAI,YAAY,QAAQ,UAAU,KAAK,WAAW,IAAI,GAAG;;IAEvD,IAAI,MAAM;KACR,IAAI,UAAU,KAAK,uBAAuB,QAAQ,IAAI,GAAG;IAC3D,OAAO;KACL,oBACE,qBAAqB,WAAW,eAAe,aAAa,KAC5D,OAAM,CACN,iBAAiB,MAAM;KACzB,IAAI,UAAU,eAAe,iBAAiB,IAAI,GAAG;IACvD;GACF;GACA,IACE,SAAS,aACT,UAAU,YACV,oBAAoB,YAAY,iBAAiB,GACjD;IACA,QAAQ;GACV;GAEA,IAAI,SAAS,OAAO,WAAW,aAAa,GAAG,GAAG;IAChD,QAAQ,QAAQ,WAAW,aAAa,GAAG,EAAE;GAC/C;GAEA,YAAY,YACV,MACA,OACA,YAAY,oBAAoB,IAAI,CACtC;EACF,CAAC;CACH;CACA,OAAO;AACT;AAEA,SAAS,oBACP,YACA,YACA,aACA,UACA;CACA,MAAM,cAAc,WAAW;CAC/B,IACE,YAAY,cAAc,iBAC1B;EAAC;EAAQ;EAAU;CAAQ,CAAC,CAAC,MAC1B,UACC,YAAY,cAAc,SAAS,YAAY,cAAc,KACjE,GACA;EACA,MAAM,MAAM,SACV,WAAW,YAAY,iBAAiB,IAAI,CAAC,KAAK;EACpD,MAAM,WACJ,WACA,QACA,OACA,QACG;GACH,MAAM,aAAa,YAAY,gBAAgB;GAC/C,MAAM,UACJ,cAAc,UACV,aACE,gBACA,eACF,aACE,eACA;GACR,IACE,YACA,CAAC,SAAS,SAAS,SAAS,KAC5B,CAAC,SAAS,SAAS,OAAO,GAE1B;GACF,MAAM,OAAO,cAAc,UAAU,eAAe;GACpD,MAAM,iBACJ,YAAY,iBAAiB,IAAI,KACjC,YAAY,iBACV,YAAY,gBAAgB,mBAAmB,iBACjD;;;GAGF,MAAM,oBACJ,mBAAmB,YACnB,YAAY,iBACZ,YAAY,iBAAiB,kBAAkB,CAAC,CAAC,SAAS,QAAQ;GACpE,IACE,mBAAmB,YAAY,iBAAiB,IAAI,KACpD,CAAC,mBAED;GACF,MAAM,OAAO,WAAW,YAAY,iBAAiB,SAAS,CAAC;GAC/D,IAAI,CAAC,OAAO,SAAS,IAAI,KAAK,CAAC,OAAO,SAAS,MAAM,GAAG;GACxD,MAAM,QACJ,GAAG,WAAW,OAAO,IACrB,GAAG,WAAW,KAAK,IACnB,GAAG,UAAU,MAAM,OAAO,IAC1B,GAAG,UAAU,IAAI,OAAO;GAC1B,MAAM,SAAS,SAAS,KAAK,MAAM,OAAO,KAAK;GAC/C,IAAI,UAAU,GAAG;;;;GAIjB,MAAM,WACJ,YAAY,CAAC,SAAS,SAAS,SAAS,IAAI,UAAU;GACxD,YAAY,eAAe,QAAQ;GACnC,YAAY,YAAY,UAAU,GAAG,OAAO,OAAO,GAAG;EACxD;EACA,QAAQ,SAAS,WAAW,aAAa,QAAQ,OAAO;EACxD,QAAQ,UAAU,WAAW,cAAc,OAAO,QAAQ;CAC5D;AACF;AAEA,SAAS,gBAAuC,YAAe,YAAe;CAC5E,IAAI,oBAAoB,YAAY,mBAAmB,GAAG;EACxD,WAAW,cAAc,WAAW;CACtC;CAEA,IAAI,oBAAoB,YAAY,gBAAgB,GAAG;EACrD,WAAW,aAAa,SAAS,WAAW,KAAK;CACnD;AACF;AAEA,SAAS,qBACP,YACA,YACA;CACA,IAAI,oBAAoB,YAAY,iBAAiB,GAAG;EACtD,IAAI,WAAW,UAAU;GACvB,WAAW,aAAa,YAAY,EAAE;EACxC,OAAO;GACL,WAAW,gBAAgB,UAAU;EACvC;CACF;AACF;AAEA,SAAS,sBACP,OACA,gBACQ;CACR,OAAO,MAAM,QACX,iDAEE,UACA,QACA,QACA,SACG;EACH,MAAM,YAAY,UAAU;EAC5B,IAAI,CAAC,aAAa,UAAU,WAAW,GAAG,GAAG,OAAO;EACpD,IAAI;GACF,MAAM,SAAS,IAAI,IACjB,WACA,qBAAqB,gBAAgB,SAAS,CAChD;GACA,IAAI,CAAC,OAAO,MAAM,OAAO;GACzB,MAAM,SAAS,IAAI,IAAI,qBAAqB,gBAAgB,KAAK,CAAC;GAClE,OAAO,OAAO;GACd,MAAM,WAAW,OAAO;GACxB,OAAO,OAAO;GACd,OAAO,OAAO,SAAS,OAAO,OAAO,OAAO,SAAS,KAAK;EAC5D,QAAQ;GACN,OAAO;EACT;CACF,CACF;AACF;AAEA,SAAS,wBACP,YACA,YACA;CACA,MAAM,iBAAiB,WAAW;CAClC,MAAM,YAAY,WAAW,aAAa,WAAW;CACrD,IAAI,aAAa,SAAS,KAAK,SAAS,GAAG;EACzC,MAAM,aAAa,sBAAsB,WAAW,cAAc;EAClE,IAAI,eAAe,WACjB,WAAW,aAAa,aAAa,UAAU;CACnD;CACA,MAAM,QAAQ,WAAW;CACzB,MAAM,QAAQ,OAAO,iBAAiB,WAAW;CACjD,IAAI,OAAO,SAAS,MAAM,GAAG;EAC3B,MAAM,aAAa,sBAAsB,OAAO,cAAc;EAC9D,IAAI,eAAe,OAAO;GACxB,MAAM,YACJ,aACA,YACA,MAAM,oBAAoB,WAAW,CACvC;EACF;CACF;AACF;AAEA,SAAS,SACP,YACA,YACA,SACA,QACG;CACH,IAAI,oBAAoB,YAAY,OAAO,GAAG;EAC5C,MAAM,WAAW,QAAQ,yBACrB,QAAQ,uBAAuB,UAAU,IACzC,QAAQ;EACZ,MAAM,cAAc,cAClB,YACA,YACA,SACA,UACA,MACF;EACA,oBAAoB,YAAY,YAAY,QAAQ;EACpD,gBAAgB,YAAY,UAAU;EACtC,qBAAqB,YAAY,UAAU;EAC3C,wBAAwB,YAAY,UAAU;EAC9C,IACE,oBAAoB,YAAY,iBAAiB,KACjD,WAAW,YAAY,OACvB;GACA,IAAI,aAAa;GACjB,IAAI,YAAY;GAChB,IAAI;IACF,aAAa,WAAW,cAAe;IACvC,YAAY,WAAW,cAAe;GACxC,QAAQ,CAER;GACA,iBACE,YACA,WAAW,mBACX,SACA,YACA,SACF;;GAEA,WAAW,MAAM,WAAW;;GAE5B,IACE,CAAC,WAAW,MAAM,aAClB,WAAW,MAAM,cAAc,QAC/B;IACA,WAAW,MAAM,YAAY;GAC/B;EACF,OAAO;GACL,iBAAiB,YAAY,YAAY,OAAO;EAClD;EACA,IAAI,aACF,oBAAoB,YAAY,YAAY,aAAa,QAAQ;EACnE,QAAQ,cAAc,YAAY,UAAU;CAC9C;CAEA,OAAO;AACT;AAEA,OAAO,eAAe,iBACpB,QACA,OACA,SACA;CACA,MAAM,mBAAmB,QAAQ,OAAO,UAAU,eAChD,UACE,YACA,SACA,MACA,OACA,MAAM,aACR,CACF;CACA,OAAO;AACT;AAEA,OAAO,eAAe,UACpB,MACA,SACA,QACA,iBAAiB,MACjB,gBACmB;CACnB,MAAM,OAAO,QAAQ,OAAO;CAC5B,MAAM,MAAM;CACZ,MAAM,iBAAiB,MAAM,gBAAgB;CAC7C,IAAI,gBAAgB,MAAM;CAC1B,MAAM,MAAM;;CAEZ,IAAI,KAAK,aAAa,KAAK,cAAc,OAAO;CAChD,IACE,CAAC,UACD,KAAK,aAAa,KAClB,QAAQ,SAAS,MAAM,aAAa,KAAK,QAAQ,QAAQ,CAAC,GAC1D;EACA,MAAM,cAAc,IAAI;EACxB,OAAO;CACT;CACA,IAAI,CAAC,UAAU,QAAQ,UAAU,CAAC,QAAQ,OAAO,IAAI,GAAG;EACtD,MAAM,cAAc,IAAI;EACxB,OAAO;CACT;CAEA,MAAM,eAAe,kBAAkB,oBAAoB,KAAK,aAAa;CAC7E,OAAO,QAAQ,QAAQ,IAAI,CAAC,CACzB,MACE,eACC,gBACE,YACA,SACA,cACA,cACF,CACJ,CAAC,CACA,MAAM,eAAe;EACpB,IAAI,oBAAoB,MAAM,OAAO,GAAG;GACtC,MAAM,cAAc,YAAY,IAAI;EACtC;EACA,OAAO,cACL,MACA,YACA,SACA,cACA,cACF;CACF,CAAC,CAAC,CACD,MAAM,eAAe,SAAS,MAAM,YAAY,SAAS,MAAM,CAAC,CAAC,CACjE,MAAM,eACL,UAAU,iBACN,iBAAiB,MAAM,YAAY,OAAO,IAC1C,UACN;AACJ",
      names: [],
      sources: ["/work/src/clone-node.ts"],
      version: 3,
      sourcesContent: ["import {\n  readDocumentMethod,\n  readDocumentProperty,\n  readOptionalDocumentProperty,\n} from './document.js'\nimport type { Options } from './types.js'\nimport { clonePseudoElements } from './clone-pseudos.js'\nimport {\n  createImage,\n  toArray,\n  isInstanceOfElement,\n  getStyleProperties,\n} from './util.js'\nimport { getMimeType } from './mimes.js'\nimport { resourceToDataURL } from './dataurl.js'\nimport { getTask } from './task.js'\nimport { embedSVGReferences, getSVGReference } from './svg-references.js'\nimport { cloneScrollState } from './clone-scroll.js'\n\nfunction createCloneDocument(source: Document) {\n  // A detached element in a browsing document can still load resources in\n  // WebKit when styles or image loading attributes change.\n  const copy = readDocumentProperty(\n    source,\n    'implementation',\n  ).createHTMLDocument()\n  const base = Reflect.apply(\n    readDocumentProperty(copy, 'createElement'),\n    copy,\n    ['base'],\n  ) as HTMLBaseElement\n  base.href = readDocumentProperty(source, 'baseURI')\n  readDocumentProperty(copy, 'head').append(base)\n  return copy\n}\n\nasync function cloneCanvasElement(canvas: HTMLCanvasElement, options: Options) {\n  const dataURL = canvas.toDataURL()\n  if (dataURL === 'data:,') {\n    return canvas.cloneNode(false) as HTMLCanvasElement\n  }\n  return createImage(dataURL, options)\n}\n\nasync function cloneVideoElement(video: HTMLVideoElement, options: Options) {\n  if (!video.poster && video.readyState === video.HAVE_NOTHING) {\n    // No media image exists yet; preserve the styled, transparent replaced box.\n    const empty = readDocumentMethod(document, 'createElement')('canvas')\n    return createImage(empty.toDataURL(), options)\n  }\n  if (video.currentSrc) {\n    const canvas = readDocumentMethod(document, 'createElement')('canvas')\n    const ctx = canvas.getContext('2d')\n    canvas.width = video.videoWidth\n    canvas.height = video.videoHeight\n    ctx?.drawImage(video, 0, 0, canvas.width, canvas.height)\n    const dataURL = canvas.toDataURL()\n    return createImage(dataURL, options)\n  }\n\n  const poster = video.poster\n  const contentType = getMimeType(poster)\n  const dataURL = await resourceToDataURL(poster, contentType, options)\n  return createImage(dataURL, options)\n}\n\nasync function cloneIFrameElement(\n  iframe: HTMLIFrameElement,\n  options: Options,\n  targetDocument: Document,\n  resolveSymbols: boolean,\n) {\n  let sourceBody: HTMLElement | null = null\n  try {\n    sourceBody =\n      readOptionalDocumentProperty(iframe.contentDocument, 'body') || null\n  } catch {\n    // Reading an inaccessible document may fail; user clone failures must not.\n  }\n  if (sourceBody) {\n    const body = await cloneNode(\n      sourceBody,\n      options,\n      true,\n      resolveSymbols,\n      targetDocument,\n    )\n    const viewport = readDocumentMethod(targetDocument, 'createElement')('div')\n    viewport.appendChild(body!)\n    return viewport\n  }\n\n  return readDocumentMethod(targetDocument, 'importNode')(iframe, false)\n}\n\nasync function cloneSingleNode<T extends HTMLElement>(\n  node: T,\n  options: Options,\n  targetDocument: Document,\n  resolveSymbols: boolean,\n): Promise<HTMLElement> {\n  if (isInstanceOfElement(node, HTMLCanvasElement)) {\n    return readDocumentMethod(\n      targetDocument,\n      'adoptNode',\n    )(await cloneCanvasElement(node, options))\n  }\n\n  if (isInstanceOfElement(node, HTMLVideoElement)) {\n    return readDocumentMethod(\n      targetDocument,\n      'adoptNode',\n    )(await cloneVideoElement(node, options))\n  }\n\n  if (isInstanceOfElement(node, HTMLIFrameElement)) {\n    return cloneIFrameElement(node, options, targetDocument, resolveSymbols)\n  }\n\n  const copy = readDocumentMethod(targetDocument, 'importNode')(node, false)\n  if (isInstanceOfElement(node, HTMLImageElement)) {\n    // Keep the source document's URL resolution when importing iframe content.\n    ;(copy as unknown as HTMLImageElement).src = node.src\n  } else if (isInstanceOfElement(node, SVGImageElement)) {\n    const href = getSVGReference(node)\n    if (href) {\n      try {\n        copy.setAttribute('href', new URL(href, node.baseURI).href)\n        copy.removeAttributeNS('http://www.w3.org/1999/xlink', 'href')\n      } catch {\n        // Keep malformed references for the normal resource error path.\n      }\n    }\n  }\n  return copy\n}\n\nconst isSlotElement = (node: HTMLElement): node is HTMLSlotElement =>\n  node.tagName != null && node.tagName.toUpperCase() === 'SLOT'\n\nasync function cloneChildren<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n  options: Options,\n  targetDocument: Document,\n  resolveSymbols: boolean,\n): Promise<T> {\n  let children: T[]\n\n  if (isSlotElement(nativeNode) && nativeNode.assignedNodes) {\n    const assigned = nativeNode.assignedNodes()\n    children = toArray<T>(assigned.length ? assigned : nativeNode.childNodes)\n  } else if (isInstanceOfElement(nativeNode, HTMLIFrameElement)) {\n    // The iframe adapter has already cloned its body and descendants.\n    return clonedNode\n  } else {\n    children = toArray<T>((nativeNode.shadowRoot ?? nativeNode).childNodes)\n  }\n\n  if (\n    children.length === 0 ||\n    isInstanceOfElement(nativeNode, HTMLVideoElement)\n  ) {\n    return clonedNode\n  }\n\n  await children.reduce(\n    (deferred, child) =>\n      deferred\n        .then(() =>\n          cloneNode(child, options, false, resolveSymbols, targetDocument),\n        )\n        .then((clonedChild: HTMLElement | null) => {\n          if (clonedChild) {\n            clonedNode.appendChild(clonedChild)\n          }\n        }),\n    Promise.resolve(),\n  )\n\n  return clonedNode\n}\n\nfunction cloneCSSStyle<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n  options: Options,\n  selected?: readonly string[],\n  isRoot?: boolean,\n) {\n  const targetStyle = clonedNode.style\n  if (!targetStyle) {\n    return\n  }\n\n  const sourceStyle = (\n    readDocumentProperty(nativeNode.ownerDocument, 'defaultView') || window\n  ).getComputedStyle(nativeNode)\n  if (sourceStyle.cssText && selected == null) {\n    targetStyle.cssText = sourceStyle.cssText\n    targetStyle.transformOrigin = sourceStyle.transformOrigin\n  } else {\n    let inheritedStyle: CSSStyleDeclaration | undefined\n    const task = getTask(options)\n    const shadowHost = (nativeNode.getRootNode() as ShadowRoot).host\n    const parent = isRoot\n      ? null\n      : nativeNode.assignedSlot || nativeNode.parentElement || shadowHost\n    getStyleProperties(sourceStyle, selected).forEach((name) => {\n      let value = sourceStyle.getPropertyValue(name)\n      if (selected == null && parent && name.startsWith('--')) {\n        // Equal inherited variables are already available from the copied ancestor.\n        if (task) {\n          if (value === task.getInheritedStyleValue(parent, name)) return\n        } else {\n          inheritedStyle ||= (\n            readDocumentProperty(nativeNode.ownerDocument, 'defaultView') ||\n            window\n          ).getComputedStyle(parent)\n          if (value === inheritedStyle.getPropertyValue(name)) return\n        }\n      }\n      if (\n        name === 'display' &&\n        value === 'inline' &&\n        isInstanceOfElement(nativeNode, HTMLIFrameElement)\n      ) {\n        value = 'block'\n      }\n\n      if (name === 'd' && clonedNode.getAttribute('d')) {\n        value = `path(${clonedNode.getAttribute('d')})`\n      }\n\n      targetStyle.setProperty(\n        name,\n        value,\n        sourceStyle.getPropertyPriority(name),\n      )\n    })\n  }\n  return sourceStyle\n}\n\nfunction restoreScrollbarBox<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n  sourceStyle: CSSStyleDeclaration,\n  selected?: readonly string[],\n) {\n  const targetStyle = clonedNode.style\n  if (\n    sourceStyle.boxSizing === 'content-box' &&\n    ['auto', 'scroll', 'hidden'].some(\n      (value) =>\n        sourceStyle.overflowX === value || sourceStyle.overflowY === value,\n    )\n  ) {\n    const px = (name: string) =>\n      parseFloat(sourceStyle.getPropertyValue(name)) || 0\n    const restore = (\n      dimension: 'width' | 'height',\n      offset: number,\n      start: string,\n      end: string,\n    ) => {\n      const horizontal = sourceStyle.writingMode === 'horizontal-tb'\n      const logical =\n        dimension === 'width'\n          ? horizontal\n            ? 'inline-size'\n            : 'block-size'\n          : horizontal\n            ? 'block-size'\n            : 'inline-size'\n      if (\n        selected &&\n        !selected.includes(dimension) &&\n        !selected.includes(logical)\n      )\n        return\n      const axis = dimension === 'width' ? 'overflow-y' : 'overflow-x'\n      const targetOverflow =\n        targetStyle.getPropertyValue(axis) ||\n        targetStyle.getPropertyValue(\n          logical === 'inline-size' ? 'overflow-block' : 'overflow-inline',\n        )\n      // Legacy scroll encoding hides the native gutter and uses its content\n      // viewport. Restore the outer box only when that gutter is retained.\n      const keepsStableGutter =\n        targetOverflow === 'hidden' &&\n        logical === 'inline-size' &&\n        sourceStyle.getPropertyValue('scrollbar-gutter').includes('stable')\n      if (\n        targetOverflow !== sourceStyle.getPropertyValue(axis) &&\n        !keepsStableGutter\n      )\n        return\n      const used = parseFloat(sourceStyle.getPropertyValue(dimension))\n      if (!Number.isFinite(used) || !Number.isFinite(offset)) return\n      const edges =\n        px(`padding-${start}`) +\n        px(`padding-${end}`) +\n        px(`border-${start}-width`) +\n        px(`border-${end}-width`)\n      const gutter = offset - Math.round(used + edges)\n      if (gutter <= 0) return\n      // CSSOM resolves a content-box dimension after subtracting its gutter.\n      // A second scroll container must start from the original box dimension,\n      // otherwise it subtracts the same scrollbar space again.\n      const property =\n        selected && !selected.includes(dimension) ? logical : dimension\n      targetStyle.removeProperty(property)\n      targetStyle.setProperty(property, `${used + gutter}px`)\n    }\n    restore('width', nativeNode.offsetWidth, 'left', 'right')\n    restore('height', nativeNode.offsetHeight, 'top', 'bottom')\n  }\n}\n\nfunction cloneInputValue<T extends HTMLElement>(nativeNode: T, clonedNode: T) {\n  if (isInstanceOfElement(nativeNode, HTMLTextAreaElement)) {\n    clonedNode.textContent = nativeNode.value\n  }\n\n  if (isInstanceOfElement(nativeNode, HTMLInputElement)) {\n    clonedNode.setAttribute('value', nativeNode.value)\n  }\n}\n\nfunction cloneOptionSelection<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n) {\n  if (isInstanceOfElement(nativeNode, HTMLOptionElement)) {\n    if (nativeNode.selected) {\n      clonedNode.setAttribute('selected', '')\n    } else {\n      clonedNode.removeAttribute('selected')\n    }\n  }\n}\n\nfunction normalizeClipPathURLs(\n  value: string,\n  sourceDocument: Document,\n): string {\n  return value.replace(\n    /url\\(\\s*(?:([\"'])(.*?)\\1|([^'\"\\s)]+))\\s*\\)/gi,\n    (\n      original,\n      _quote,\n      quoted: string | undefined,\n      bare: string | undefined,\n    ) => {\n      const reference = quoted ?? bare\n      if (!reference || reference.startsWith('#')) return original\n      try {\n        const target = new URL(\n          reference,\n          readDocumentProperty(sourceDocument, 'baseURI'),\n        )\n        if (!target.hash) return original\n        const source = new URL(readDocumentProperty(sourceDocument, 'URL'))\n        source.hash = ''\n        const fragment = target.hash\n        target.hash = ''\n        return target.href === source.href ? `url(${fragment})` : original\n      } catch {\n        return original\n      }\n    },\n  )\n}\n\nfunction cloneClipPathReferences<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n) {\n  const sourceDocument = nativeNode.ownerDocument\n  const attribute = clonedNode.getAttribute('clip-path')\n  if (attribute && /url\\(/i.test(attribute)) {\n    const normalized = normalizeClipPathURLs(attribute, sourceDocument)\n    if (normalized !== attribute)\n      clonedNode.setAttribute('clip-path', normalized)\n  }\n  const style = clonedNode.style\n  const value = style?.getPropertyValue('clip-path')\n  if (value?.includes('url(')) {\n    const normalized = normalizeClipPathURLs(value, sourceDocument)\n    if (normalized !== value) {\n      style.setProperty(\n        'clip-path',\n        normalized,\n        style.getPropertyPriority('clip-path'),\n      )\n    }\n  }\n}\n\nfunction decorate<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n  options: Options,\n  isRoot?: boolean,\n): T {\n  if (isInstanceOfElement(clonedNode, Element)) {\n    const selected = options.stylePropertiesForNode\n      ? options.stylePropertiesForNode(nativeNode)\n      : options.includeStyleProperties\n    const sourceStyle = cloneCSSStyle(\n      nativeNode,\n      clonedNode,\n      options,\n      selected,\n      isRoot,\n    )\n    clonePseudoElements(nativeNode, clonedNode, selected)\n    cloneInputValue(nativeNode, clonedNode)\n    cloneOptionSelection(nativeNode, clonedNode)\n    cloneClipPathReferences(nativeNode, clonedNode)\n    if (\n      isInstanceOfElement(nativeNode, HTMLIFrameElement) &&\n      clonedNode.tagName === 'DIV'\n    ) {\n      let scrollLeft = 0\n      let scrollTop = 0\n      try {\n        scrollLeft = nativeNode.contentWindow!.scrollX\n        scrollTop = nativeNode.contentWindow!.scrollY\n      } catch {\n        // The frame may navigate or detach after its body was cloned.\n      }\n      cloneScrollState(\n        nativeNode,\n        clonedNode.firstElementChild as HTMLElement,\n        options,\n        scrollLeft,\n        scrollTop,\n      )\n      // The iframe viewport clips its body even when it has not scrolled.\n      clonedNode.style.overflow = 'hidden'\n      // A transformed viewport anchors fixed descendants to this iframe.\n      if (\n        !clonedNode.style.transform ||\n        clonedNode.style.transform === 'none'\n      ) {\n        clonedNode.style.transform = 'translate(0px, 0px)'\n      }\n    } else {\n      cloneScrollState(nativeNode, clonedNode, options)\n    }\n    if (sourceStyle)\n      restoreScrollbarBox(nativeNode, clonedNode, sourceStyle, selected)\n    options.onCloneNode?.(nativeNode, clonedNode)\n  }\n\n  return clonedNode\n}\n\nexport async function ensureSVGSymbols<T extends HTMLElement>(\n  source: T,\n  clone: T,\n  options: Options,\n) {\n  await embedSVGReferences(source, clone, options, (definition) =>\n    cloneNode(\n      definition as HTMLElement,\n      options,\n      true,\n      false,\n      clone.ownerDocument,\n    ),\n  )\n  return clone\n}\n\nexport async function cloneNode<T extends HTMLElement>(\n  node: T,\n  options: Options,\n  isRoot?: boolean,\n  resolveSymbols = true,\n  targetDocument?: Document,\n): Promise<T | null> {\n  const task = getTask(options)\n  task?.check()\n  const yieldToBrowser = task?.maybeYieldClone()\n  if (yieldToBrowser) await yieldToBrowser\n  task?.check()\n  // HTML permits comment contents that XML forbids; comments have no pixels.\n  if (node.nodeType === Node.COMMENT_NODE) return null\n  if (\n    !isRoot &&\n    node.nodeType === 1 &&\n    options.exclude?.some((selector) => node.matches(selector))\n  ) {\n    task?.excludeSource(node)\n    return null\n  }\n  if (!isRoot && options.filter && !options.filter(node)) {\n    task?.excludeSource(node)\n    return null\n  }\n\n  const copyDocument = targetDocument || createCloneDocument(node.ownerDocument)\n  return Promise.resolve(node)\n    .then(\n      (clonedNode) =>\n        cloneSingleNode(\n          clonedNode,\n          options,\n          copyDocument,\n          resolveSymbols,\n        ) as Promise<T>,\n    )\n    .then((clonedNode) => {\n      if (isInstanceOfElement(node, Element)) {\n        task?.registerClone(clonedNode, node)\n      }\n      return cloneChildren(\n        node,\n        clonedNode,\n        options,\n        copyDocument,\n        resolveSymbols,\n      )\n    })\n    .then((clonedNode) => decorate(node, clonedNode, options, isRoot))\n    .then((clonedNode) =>\n      isRoot && resolveSymbols\n        ? ensureSVGSymbols(node, clonedNode, options)\n        : clonedNode,\n    )\n}\n"]
    },
    _coverageSchema: "de0df54ae17f6b36de740b46d31f7cdddb68e251",
    hash: "deeceaa6e585e602ad332bdd2d64712cf54b356f"
  };
  var coverage = global[gcv] || (global[gcv] = {});
  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }
  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_25saynlpeq = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}
cov_25saynlpeq();
import { readDocumentMethod, readDocumentProperty, readOptionalDocumentProperty } from "/src/document.ts";
import { clonePseudoElements } from "/src/clone-pseudos.ts";
import { createImage, toArray, isInstanceOfElement, getStyleProperties } from "/src/util.ts";
import { getMimeType } from "/src/mimes.ts";
import { resourceToDataURL } from "/src/dataurl.ts";
import { getTask } from "/src/task.ts";
import { embedSVGReferences, getSVGReference } from "/src/svg-references.ts";
import { cloneScrollState } from "/src/clone-scroll.ts";
function createCloneDocument(source) {
  cov_25saynlpeq().f[0]++;
  // A detached element in a browsing document can still load resources in
  // WebKit when styles or image loading attributes change.
  const copy = (cov_25saynlpeq().s[0]++, readDocumentProperty(source, "implementation").createHTMLDocument());
  const base = (cov_25saynlpeq().s[1]++, Reflect.apply(readDocumentProperty(copy, "createElement"), copy, ["base"]));
  cov_25saynlpeq().s[2]++;
  base.href = readDocumentProperty(source, "baseURI");
  cov_25saynlpeq().s[3]++;
  readDocumentProperty(copy, "head").append(base);
  cov_25saynlpeq().s[4]++;
  return copy;
}
async function cloneCanvasElement(canvas, options) {
  cov_25saynlpeq().f[1]++;
  const dataURL = (cov_25saynlpeq().s[5]++, canvas.toDataURL());
  cov_25saynlpeq().s[6]++;
  if (dataURL === "data:,") {
    cov_25saynlpeq().b[0][0]++;
    cov_25saynlpeq().s[7]++;
    return canvas.cloneNode(false);
  } else {
    cov_25saynlpeq().b[0][1]++;
  }
  cov_25saynlpeq().s[8]++;
  return createImage(dataURL, options);
}
async function cloneVideoElement(video, options) {
  cov_25saynlpeq().f[2]++;
  cov_25saynlpeq().s[9]++;
  if ((cov_25saynlpeq().b[2][0]++, !video.poster) && (cov_25saynlpeq().b[2][1]++, video.readyState === video.HAVE_NOTHING)) {
    cov_25saynlpeq().b[1][0]++;
    // No media image exists yet; preserve the styled, transparent replaced box.
    const empty = (cov_25saynlpeq().s[10]++, readDocumentMethod(document, "createElement")("canvas"));
    cov_25saynlpeq().s[11]++;
    return createImage(empty.toDataURL(), options);
  } else {
    cov_25saynlpeq().b[1][1]++;
  }
  cov_25saynlpeq().s[12]++;
  if (video.currentSrc) {
    cov_25saynlpeq().b[3][0]++;
    const canvas = (cov_25saynlpeq().s[13]++, readDocumentMethod(document, "createElement")("canvas"));
    const ctx = (cov_25saynlpeq().s[14]++, canvas.getContext("2d"));
    cov_25saynlpeq().s[15]++;
    canvas.width = video.videoWidth;
    cov_25saynlpeq().s[16]++;
    canvas.height = video.videoHeight;
    cov_25saynlpeq().s[17]++;
    ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataURL = (cov_25saynlpeq().s[18]++, canvas.toDataURL());
    cov_25saynlpeq().s[19]++;
    return createImage(dataURL, options);
  } else {
    cov_25saynlpeq().b[3][1]++;
  }
  const poster = (cov_25saynlpeq().s[20]++, video.poster);
  const contentType = (cov_25saynlpeq().s[21]++, getMimeType(poster));
  const dataURL = (cov_25saynlpeq().s[22]++, await resourceToDataURL(poster, contentType, options));
  cov_25saynlpeq().s[23]++;
  return createImage(dataURL, options);
}
async function cloneIFrameElement(iframe, options, targetDocument, resolveSymbols) {
  cov_25saynlpeq().f[3]++;
  let sourceBody = (cov_25saynlpeq().s[24]++, null);
  cov_25saynlpeq().s[25]++;
  try {
    cov_25saynlpeq().s[26]++;
    sourceBody = (cov_25saynlpeq().b[4][0]++, readOptionalDocumentProperty(iframe.contentDocument, "body")) || (cov_25saynlpeq().b[4][1]++, null);
  } catch {}
  cov_25saynlpeq().s[27]++;
  if (sourceBody) {
    cov_25saynlpeq().b[5][0]++;
    const body = (cov_25saynlpeq().s[28]++, await cloneNode(sourceBody, options, true, resolveSymbols, targetDocument));
    const viewport = (cov_25saynlpeq().s[29]++, readDocumentMethod(targetDocument, "createElement")("div"));
    cov_25saynlpeq().s[30]++;
    viewport.appendChild(body);
    cov_25saynlpeq().s[31]++;
    return viewport;
  } else {
    cov_25saynlpeq().b[5][1]++;
  }
  cov_25saynlpeq().s[32]++;
  return readDocumentMethod(targetDocument, "importNode")(iframe, false);
}
async function cloneSingleNode(node, options, targetDocument, resolveSymbols) {
  cov_25saynlpeq().f[4]++;
  cov_25saynlpeq().s[33]++;
  if (isInstanceOfElement(node, HTMLCanvasElement)) {
    cov_25saynlpeq().b[6][0]++;
    cov_25saynlpeq().s[34]++;
    return readDocumentMethod(targetDocument, "adoptNode")(await cloneCanvasElement(node, options));
  } else {
    cov_25saynlpeq().b[6][1]++;
  }
  cov_25saynlpeq().s[35]++;
  if (isInstanceOfElement(node, HTMLVideoElement)) {
    cov_25saynlpeq().b[7][0]++;
    cov_25saynlpeq().s[36]++;
    return readDocumentMethod(targetDocument, "adoptNode")(await cloneVideoElement(node, options));
  } else {
    cov_25saynlpeq().b[7][1]++;
  }
  cov_25saynlpeq().s[37]++;
  if (isInstanceOfElement(node, HTMLIFrameElement)) {
    cov_25saynlpeq().b[8][0]++;
    cov_25saynlpeq().s[38]++;
    return cloneIFrameElement(node, options, targetDocument, resolveSymbols);
  } else {
    cov_25saynlpeq().b[8][1]++;
  }
  const copy = (cov_25saynlpeq().s[39]++, readDocumentMethod(targetDocument, "importNode")(node, false));
  cov_25saynlpeq().s[40]++;
  if (isInstanceOfElement(node, HTMLImageElement)) {
    cov_25saynlpeq().b[9][0]++;
    // Keep the source document's URL resolution when importing iframe content.
    ;
    cov_25saynlpeq().s[41]++;
    copy.src = node.src;
  } else {
    cov_25saynlpeq().b[9][1]++;
    cov_25saynlpeq().s[42]++;
    if (isInstanceOfElement(node, SVGImageElement)) {
      cov_25saynlpeq().b[10][0]++;
      const href = (cov_25saynlpeq().s[43]++, getSVGReference(node));
      cov_25saynlpeq().s[44]++;
      if (href) {
        cov_25saynlpeq().b[11][0]++;
        cov_25saynlpeq().s[45]++;
        try {
          cov_25saynlpeq().s[46]++;
          copy.setAttribute("href", new URL(href, node.baseURI).href);
          cov_25saynlpeq().s[47]++;
          copy.removeAttributeNS("http://www.w3.org/1999/xlink", "href");
        } catch {}
      } else {
        cov_25saynlpeq().b[11][1]++;
      }
    } else {
      cov_25saynlpeq().b[10][1]++;
    }
  }
  cov_25saynlpeq().s[48]++;
  return copy;
}
cov_25saynlpeq().s[49]++;
const isSlotElement = node => {
  cov_25saynlpeq().f[5]++;
  cov_25saynlpeq().s[50]++;
  return (cov_25saynlpeq().b[12][0]++, node.tagName != null) && (cov_25saynlpeq().b[12][1]++, node.tagName.toUpperCase() === "SLOT");
};
async function cloneChildren(nativeNode, clonedNode, options, targetDocument, resolveSymbols) {
  cov_25saynlpeq().f[6]++;
  let children;
  cov_25saynlpeq().s[51]++;
  if ((cov_25saynlpeq().b[14][0]++, isSlotElement(nativeNode)) && (cov_25saynlpeq().b[14][1]++, nativeNode.assignedNodes)) {
    cov_25saynlpeq().b[13][0]++;
    const assigned = (cov_25saynlpeq().s[52]++, nativeNode.assignedNodes());
    cov_25saynlpeq().s[53]++;
    children = toArray(assigned.length ? (cov_25saynlpeq().b[15][0]++, assigned) : (cov_25saynlpeq().b[15][1]++, nativeNode.childNodes));
  } else {
    cov_25saynlpeq().b[13][1]++;
    cov_25saynlpeq().s[54]++;
    if (isInstanceOfElement(nativeNode, HTMLIFrameElement)) {
      cov_25saynlpeq().b[16][0]++;
      cov_25saynlpeq().s[55]++;
      // The iframe adapter has already cloned its body and descendants.
      return clonedNode;
    } else {
      cov_25saynlpeq().b[16][1]++;
      cov_25saynlpeq().s[56]++;
      children = toArray(((cov_25saynlpeq().b[17][0]++, nativeNode.shadowRoot) ?? (cov_25saynlpeq().b[17][1]++, nativeNode)).childNodes);
    }
  }
  cov_25saynlpeq().s[57]++;
  if ((cov_25saynlpeq().b[19][0]++, children.length === 0) || (cov_25saynlpeq().b[19][1]++, isInstanceOfElement(nativeNode, HTMLVideoElement))) {
    cov_25saynlpeq().b[18][0]++;
    cov_25saynlpeq().s[58]++;
    return clonedNode;
  } else {
    cov_25saynlpeq().b[18][1]++;
  }
  cov_25saynlpeq().s[59]++;
  await children.reduce((deferred, child) => {
    cov_25saynlpeq().f[7]++;
    cov_25saynlpeq().s[60]++;
    return deferred.then(() => {
      cov_25saynlpeq().f[8]++;
      cov_25saynlpeq().s[61]++;
      return cloneNode(child, options, false, resolveSymbols, targetDocument);
    }).then(clonedChild => {
      cov_25saynlpeq().f[9]++;
      cov_25saynlpeq().s[62]++;
      if (clonedChild) {
        cov_25saynlpeq().b[20][0]++;
        cov_25saynlpeq().s[63]++;
        clonedNode.appendChild(clonedChild);
      } else {
        cov_25saynlpeq().b[20][1]++;
      }
    });
  }, Promise.resolve());
  cov_25saynlpeq().s[64]++;
  return clonedNode;
}
function cloneCSSStyle(nativeNode, clonedNode, options, selected, isRoot) {
  cov_25saynlpeq().f[10]++;
  const targetStyle = (cov_25saynlpeq().s[65]++, clonedNode.style);
  cov_25saynlpeq().s[66]++;
  if (!targetStyle) {
    cov_25saynlpeq().b[21][0]++;
    cov_25saynlpeq().s[67]++;
    return;
  } else {
    cov_25saynlpeq().b[21][1]++;
  }
  const sourceStyle = (cov_25saynlpeq().s[68]++, ((cov_25saynlpeq().b[22][0]++, readDocumentProperty(nativeNode.ownerDocument, "defaultView")) || (cov_25saynlpeq().b[22][1]++, window)).getComputedStyle(nativeNode));
  cov_25saynlpeq().s[69]++;
  if ((cov_25saynlpeq().b[24][0]++, sourceStyle.cssText) && (cov_25saynlpeq().b[24][1]++, selected == null)) {
    cov_25saynlpeq().b[23][0]++;
    cov_25saynlpeq().s[70]++;
    targetStyle.cssText = sourceStyle.cssText;
    cov_25saynlpeq().s[71]++;
    targetStyle.transformOrigin = sourceStyle.transformOrigin;
  } else {
    cov_25saynlpeq().b[23][1]++;
    let inheritedStyle;
    const task = (cov_25saynlpeq().s[72]++, getTask(options));
    const shadowHost = (cov_25saynlpeq().s[73]++, nativeNode.getRootNode().host);
    const parent = (cov_25saynlpeq().s[74]++, isRoot ? (cov_25saynlpeq().b[25][0]++, null) : (cov_25saynlpeq().b[25][1]++, (cov_25saynlpeq().b[26][0]++, nativeNode.assignedSlot) || (cov_25saynlpeq().b[26][1]++, nativeNode.parentElement) || (cov_25saynlpeq().b[26][2]++, shadowHost)));
    cov_25saynlpeq().s[75]++;
    getStyleProperties(sourceStyle, selected).forEach(name => {
      cov_25saynlpeq().f[11]++;
      let value = (cov_25saynlpeq().s[76]++, sourceStyle.getPropertyValue(name));
      cov_25saynlpeq().s[77]++;
      if ((cov_25saynlpeq().b[28][0]++, selected == null) && (cov_25saynlpeq().b[28][1]++, parent) && (cov_25saynlpeq().b[28][2]++, name.startsWith("--"))) {
        cov_25saynlpeq().b[27][0]++;
        cov_25saynlpeq().s[78]++;
        // Equal inherited variables are already available from the copied ancestor.
        if (task) {
          cov_25saynlpeq().b[29][0]++;
          cov_25saynlpeq().s[79]++;
          if (value === task.getInheritedStyleValue(parent, name)) {
            cov_25saynlpeq().b[30][0]++;
            cov_25saynlpeq().s[80]++;
            return;
          } else {
            cov_25saynlpeq().b[30][1]++;
          }
        } else {
          cov_25saynlpeq().b[29][1]++;
          cov_25saynlpeq().s[81]++;
          inheritedStyle ||= ((cov_25saynlpeq().b[31][0]++, readDocumentProperty(nativeNode.ownerDocument, "defaultView")) || (cov_25saynlpeq().b[31][1]++, window)).getComputedStyle(parent);
          cov_25saynlpeq().s[82]++;
          if (value === inheritedStyle.getPropertyValue(name)) {
            cov_25saynlpeq().b[32][0]++;
            cov_25saynlpeq().s[83]++;
            return;
          } else {
            cov_25saynlpeq().b[32][1]++;
          }
        }
      } else {
        cov_25saynlpeq().b[27][1]++;
      }
      cov_25saynlpeq().s[84]++;
      if ((cov_25saynlpeq().b[34][0]++, name === "display") && (cov_25saynlpeq().b[34][1]++, value === "inline") && (cov_25saynlpeq().b[34][2]++, isInstanceOfElement(nativeNode, HTMLIFrameElement))) {
        cov_25saynlpeq().b[33][0]++;
        cov_25saynlpeq().s[85]++;
        value = "block";
      } else {
        cov_25saynlpeq().b[33][1]++;
      }
      cov_25saynlpeq().s[86]++;
      if ((cov_25saynlpeq().b[36][0]++, name === "d") && (cov_25saynlpeq().b[36][1]++, clonedNode.getAttribute("d"))) {
        cov_25saynlpeq().b[35][0]++;
        cov_25saynlpeq().s[87]++;
        value = `path(${clonedNode.getAttribute("d")})`;
      } else {
        cov_25saynlpeq().b[35][1]++;
      }
      cov_25saynlpeq().s[88]++;
      targetStyle.setProperty(name, value, sourceStyle.getPropertyPriority(name));
    });
  }
  cov_25saynlpeq().s[89]++;
  return sourceStyle;
}
function restoreScrollbarBox(nativeNode, clonedNode, sourceStyle, selected) {
  cov_25saynlpeq().f[12]++;
  const targetStyle = (cov_25saynlpeq().s[90]++, clonedNode.style);
  cov_25saynlpeq().s[91]++;
  if ((cov_25saynlpeq().b[38][0]++, sourceStyle.boxSizing === "content-box") && (cov_25saynlpeq().b[38][1]++, ["auto", "scroll", "hidden"].some(value => {
    cov_25saynlpeq().f[13]++;
    cov_25saynlpeq().s[92]++;
    return (cov_25saynlpeq().b[39][0]++, sourceStyle.overflowX === value) || (cov_25saynlpeq().b[39][1]++, sourceStyle.overflowY === value);
  }))) {
    cov_25saynlpeq().b[37][0]++;
    cov_25saynlpeq().s[93]++;
    const px = name => {
      cov_25saynlpeq().f[14]++;
      cov_25saynlpeq().s[94]++;
      return (cov_25saynlpeq().b[40][0]++, parseFloat(sourceStyle.getPropertyValue(name))) || (cov_25saynlpeq().b[40][1]++, 0);
    };
    cov_25saynlpeq().s[95]++;
    const restore = (dimension, offset, start, end) => {
      cov_25saynlpeq().f[15]++;
      const horizontal = (cov_25saynlpeq().s[96]++, sourceStyle.writingMode === "horizontal-tb");
      const logical = (cov_25saynlpeq().s[97]++, dimension === "width" ? (cov_25saynlpeq().b[41][0]++, horizontal ? (cov_25saynlpeq().b[42][0]++, "inline-size") : (cov_25saynlpeq().b[42][1]++, "block-size")) : (cov_25saynlpeq().b[41][1]++, horizontal ? (cov_25saynlpeq().b[43][0]++, "block-size") : (cov_25saynlpeq().b[43][1]++, "inline-size")));
      cov_25saynlpeq().s[98]++;
      if ((cov_25saynlpeq().b[45][0]++, selected) && (cov_25saynlpeq().b[45][1]++, !selected.includes(dimension)) && (cov_25saynlpeq().b[45][2]++, !selected.includes(logical))) {
        cov_25saynlpeq().b[44][0]++;
        cov_25saynlpeq().s[99]++;
        return;
      } else {
        cov_25saynlpeq().b[44][1]++;
      }
      const axis = (cov_25saynlpeq().s[100]++, dimension === "width" ? (cov_25saynlpeq().b[46][0]++, "overflow-y") : (cov_25saynlpeq().b[46][1]++, "overflow-x"));
      const targetOverflow = (cov_25saynlpeq().s[101]++, (cov_25saynlpeq().b[47][0]++, targetStyle.getPropertyValue(axis)) || (cov_25saynlpeq().b[47][1]++, targetStyle.getPropertyValue(logical === "inline-size" ? (cov_25saynlpeq().b[48][0]++, "overflow-block") : (cov_25saynlpeq().b[48][1]++, "overflow-inline"))));
      // Legacy scroll encoding hides the native gutter and uses its content
      // viewport. Restore the outer box only when that gutter is retained.
      const keepsStableGutter = (cov_25saynlpeq().s[102]++, (cov_25saynlpeq().b[49][0]++, targetOverflow === "hidden") && (cov_25saynlpeq().b[49][1]++, logical === "inline-size") && (cov_25saynlpeq().b[49][2]++, sourceStyle.getPropertyValue("scrollbar-gutter").includes("stable")));
      cov_25saynlpeq().s[103]++;
      if ((cov_25saynlpeq().b[51][0]++, targetOverflow !== sourceStyle.getPropertyValue(axis)) && (cov_25saynlpeq().b[51][1]++, !keepsStableGutter)) {
        cov_25saynlpeq().b[50][0]++;
        cov_25saynlpeq().s[104]++;
        return;
      } else {
        cov_25saynlpeq().b[50][1]++;
      }
      const used = (cov_25saynlpeq().s[105]++, parseFloat(sourceStyle.getPropertyValue(dimension)));
      cov_25saynlpeq().s[106]++;
      if ((cov_25saynlpeq().b[53][0]++, !Number.isFinite(used)) || (cov_25saynlpeq().b[53][1]++, !Number.isFinite(offset))) {
        cov_25saynlpeq().b[52][0]++;
        cov_25saynlpeq().s[107]++;
        return;
      } else {
        cov_25saynlpeq().b[52][1]++;
      }
      const edges = (cov_25saynlpeq().s[108]++, px(`padding-${start}`) + px(`padding-${end}`) + px(`border-${start}-width`) + px(`border-${end}-width`));
      const gutter = (cov_25saynlpeq().s[109]++, offset - Math.round(used + edges));
      cov_25saynlpeq().s[110]++;
      if (gutter <= 0) {
        cov_25saynlpeq().b[54][0]++;
        cov_25saynlpeq().s[111]++;
        return;
      } else {
        cov_25saynlpeq().b[54][1]++;
      }
      // CSSOM resolves a content-box dimension after subtracting its gutter.
      // A second scroll container must start from the original box dimension,
      // otherwise it subtracts the same scrollbar space again.
      const property = (cov_25saynlpeq().s[112]++, (cov_25saynlpeq().b[56][0]++, selected) && (cov_25saynlpeq().b[56][1]++, !selected.includes(dimension)) ? (cov_25saynlpeq().b[55][0]++, logical) : (cov_25saynlpeq().b[55][1]++, dimension));
      cov_25saynlpeq().s[113]++;
      targetStyle.removeProperty(property);
      cov_25saynlpeq().s[114]++;
      targetStyle.setProperty(property, `${used + gutter}px`);
    };
    cov_25saynlpeq().s[115]++;
    restore("width", nativeNode.offsetWidth, "left", "right");
    cov_25saynlpeq().s[116]++;
    restore("height", nativeNode.offsetHeight, "top", "bottom");
  } else {
    cov_25saynlpeq().b[37][1]++;
  }
}
function cloneInputValue(nativeNode, clonedNode) {
  cov_25saynlpeq().f[16]++;
  cov_25saynlpeq().s[117]++;
  if (isInstanceOfElement(nativeNode, HTMLTextAreaElement)) {
    cov_25saynlpeq().b[57][0]++;
    cov_25saynlpeq().s[118]++;
    clonedNode.textContent = nativeNode.value;
  } else {
    cov_25saynlpeq().b[57][1]++;
  }
  cov_25saynlpeq().s[119]++;
  if (isInstanceOfElement(nativeNode, HTMLInputElement)) {
    cov_25saynlpeq().b[58][0]++;
    cov_25saynlpeq().s[120]++;
    clonedNode.setAttribute("value", nativeNode.value);
  } else {
    cov_25saynlpeq().b[58][1]++;
  }
}
function cloneOptionSelection(nativeNode, clonedNode) {
  cov_25saynlpeq().f[17]++;
  cov_25saynlpeq().s[121]++;
  if (isInstanceOfElement(nativeNode, HTMLOptionElement)) {
    cov_25saynlpeq().b[59][0]++;
    cov_25saynlpeq().s[122]++;
    if (nativeNode.selected) {
      cov_25saynlpeq().b[60][0]++;
      cov_25saynlpeq().s[123]++;
      clonedNode.setAttribute("selected", "");
    } else {
      cov_25saynlpeq().b[60][1]++;
      cov_25saynlpeq().s[124]++;
      clonedNode.removeAttribute("selected");
    }
  } else {
    cov_25saynlpeq().b[59][1]++;
  }
}
function normalizeClipPathURLs(value, sourceDocument) {
  cov_25saynlpeq().f[18]++;
  cov_25saynlpeq().s[125]++;
  return value.replace(/url\(\s*(?:(["'])(.*?)\1|([^'"\s)]+))\s*\)/gi, (original, _quote, quoted, bare) => {
    cov_25saynlpeq().f[19]++;
    const reference = (cov_25saynlpeq().s[126]++, (cov_25saynlpeq().b[61][0]++, quoted) ?? (cov_25saynlpeq().b[61][1]++, bare));
    cov_25saynlpeq().s[127]++;
    if ((cov_25saynlpeq().b[63][0]++, !reference) || (cov_25saynlpeq().b[63][1]++, reference.startsWith("#"))) {
      cov_25saynlpeq().b[62][0]++;
      cov_25saynlpeq().s[128]++;
      return original;
    } else {
      cov_25saynlpeq().b[62][1]++;
    }
    cov_25saynlpeq().s[129]++;
    try {
      const target = (cov_25saynlpeq().s[130]++, new URL(reference, readDocumentProperty(sourceDocument, "baseURI")));
      cov_25saynlpeq().s[131]++;
      if (!target.hash) {
        cov_25saynlpeq().b[64][0]++;
        cov_25saynlpeq().s[132]++;
        return original;
      } else {
        cov_25saynlpeq().b[64][1]++;
      }
      const source = (cov_25saynlpeq().s[133]++, new URL(readDocumentProperty(sourceDocument, "URL")));
      cov_25saynlpeq().s[134]++;
      source.hash = "";
      const fragment = (cov_25saynlpeq().s[135]++, target.hash);
      cov_25saynlpeq().s[136]++;
      target.hash = "";
      cov_25saynlpeq().s[137]++;
      return target.href === source.href ? (cov_25saynlpeq().b[65][0]++, `url(${fragment})`) : (cov_25saynlpeq().b[65][1]++, original);
    } catch {
      cov_25saynlpeq().s[138]++;
      return original;
    }
  });
}
function cloneClipPathReferences(nativeNode, clonedNode) {
  cov_25saynlpeq().f[20]++;
  const sourceDocument = (cov_25saynlpeq().s[139]++, nativeNode.ownerDocument);
  const attribute = (cov_25saynlpeq().s[140]++, clonedNode.getAttribute("clip-path"));
  cov_25saynlpeq().s[141]++;
  if ((cov_25saynlpeq().b[67][0]++, attribute) && (cov_25saynlpeq().b[67][1]++, /url\(/i.test(attribute))) {
    cov_25saynlpeq().b[66][0]++;
    const normalized = (cov_25saynlpeq().s[142]++, normalizeClipPathURLs(attribute, sourceDocument));
    cov_25saynlpeq().s[143]++;
    if (normalized !== attribute) {
      cov_25saynlpeq().b[68][0]++;
      cov_25saynlpeq().s[144]++;
      clonedNode.setAttribute("clip-path", normalized);
    } else {
      cov_25saynlpeq().b[68][1]++;
    }
  } else {
    cov_25saynlpeq().b[66][1]++;
  }
  const style = (cov_25saynlpeq().s[145]++, clonedNode.style);
  const value = (cov_25saynlpeq().s[146]++, style?.getPropertyValue("clip-path"));
  cov_25saynlpeq().s[147]++;
  if (value?.includes("url(")) {
    cov_25saynlpeq().b[69][0]++;
    const normalized = (cov_25saynlpeq().s[148]++, normalizeClipPathURLs(value, sourceDocument));
    cov_25saynlpeq().s[149]++;
    if (normalized !== value) {
      cov_25saynlpeq().b[70][0]++;
      cov_25saynlpeq().s[150]++;
      style.setProperty("clip-path", normalized, style.getPropertyPriority("clip-path"));
    } else {
      cov_25saynlpeq().b[70][1]++;
    }
  } else {
    cov_25saynlpeq().b[69][1]++;
  }
}
function decorate(nativeNode, clonedNode, options, isRoot) {
  cov_25saynlpeq().f[21]++;
  cov_25saynlpeq().s[151]++;
  if (isInstanceOfElement(clonedNode, Element)) {
    cov_25saynlpeq().b[71][0]++;
    const selected = (cov_25saynlpeq().s[152]++, options.stylePropertiesForNode ? (cov_25saynlpeq().b[72][0]++, options.stylePropertiesForNode(nativeNode)) : (cov_25saynlpeq().b[72][1]++, options.includeStyleProperties));
    const sourceStyle = (cov_25saynlpeq().s[153]++, cloneCSSStyle(nativeNode, clonedNode, options, selected, isRoot));
    cov_25saynlpeq().s[154]++;
    clonePseudoElements(nativeNode, clonedNode, selected);
    cov_25saynlpeq().s[155]++;
    cloneInputValue(nativeNode, clonedNode);
    cov_25saynlpeq().s[156]++;
    cloneOptionSelection(nativeNode, clonedNode);
    cov_25saynlpeq().s[157]++;
    cloneClipPathReferences(nativeNode, clonedNode);
    cov_25saynlpeq().s[158]++;
    if ((cov_25saynlpeq().b[74][0]++, isInstanceOfElement(nativeNode, HTMLIFrameElement)) && (cov_25saynlpeq().b[74][1]++, clonedNode.tagName === "DIV")) {
      cov_25saynlpeq().b[73][0]++;
      let scrollLeft = (cov_25saynlpeq().s[159]++, 0);
      let scrollTop = (cov_25saynlpeq().s[160]++, 0);
      cov_25saynlpeq().s[161]++;
      try {
        cov_25saynlpeq().s[162]++;
        scrollLeft = nativeNode.contentWindow.scrollX;
        cov_25saynlpeq().s[163]++;
        scrollTop = nativeNode.contentWindow.scrollY;
      } catch {}
      cov_25saynlpeq().s[164]++;
      cloneScrollState(nativeNode, clonedNode.firstElementChild, options, scrollLeft, scrollTop);
      // The iframe viewport clips its body even when it has not scrolled.
      cov_25saynlpeq().s[165]++;
      clonedNode.style.overflow = "hidden";
      // A transformed viewport anchors fixed descendants to this iframe.
      cov_25saynlpeq().s[166]++;
      if ((cov_25saynlpeq().b[76][0]++, !clonedNode.style.transform) || (cov_25saynlpeq().b[76][1]++, clonedNode.style.transform === "none")) {
        cov_25saynlpeq().b[75][0]++;
        cov_25saynlpeq().s[167]++;
        clonedNode.style.transform = "translate(0px, 0px)";
      } else {
        cov_25saynlpeq().b[75][1]++;
      }
    } else {
      cov_25saynlpeq().b[73][1]++;
      cov_25saynlpeq().s[168]++;
      cloneScrollState(nativeNode, clonedNode, options);
    }
    cov_25saynlpeq().s[169]++;
    if (sourceStyle) {
      cov_25saynlpeq().b[77][0]++;
      cov_25saynlpeq().s[170]++;
      restoreScrollbarBox(nativeNode, clonedNode, sourceStyle, selected);
    } else {
      cov_25saynlpeq().b[77][1]++;
    }
    cov_25saynlpeq().s[171]++;
    options.onCloneNode?.(nativeNode, clonedNode);
  } else {
    cov_25saynlpeq().b[71][1]++;
  }
  cov_25saynlpeq().s[172]++;
  return clonedNode;
}
export async function ensureSVGSymbols(source, clone, options) {
  cov_25saynlpeq().f[22]++;
  cov_25saynlpeq().s[173]++;
  await embedSVGReferences(source, clone, options, definition => {
    cov_25saynlpeq().f[23]++;
    cov_25saynlpeq().s[174]++;
    return cloneNode(definition, options, true, false, clone.ownerDocument);
  });
  cov_25saynlpeq().s[175]++;
  return clone;
}
export async function cloneNode(node, options, isRoot, resolveSymbols = (cov_25saynlpeq().b[78][0]++, true), targetDocument) {
  cov_25saynlpeq().f[24]++;
  const task = (cov_25saynlpeq().s[176]++, getTask(options));
  cov_25saynlpeq().s[177]++;
  task?.check();
  const yieldToBrowser = (cov_25saynlpeq().s[178]++, task?.maybeYieldClone());
  cov_25saynlpeq().s[179]++;
  if (yieldToBrowser) {
    cov_25saynlpeq().b[79][0]++;
    cov_25saynlpeq().s[180]++;
    await yieldToBrowser;
  } else {
    cov_25saynlpeq().b[79][1]++;
  }
  cov_25saynlpeq().s[181]++;
  task?.check();
  // HTML permits comment contents that XML forbids; comments have no pixels.
  cov_25saynlpeq().s[182]++;
  if (node.nodeType === Node.COMMENT_NODE) {
    cov_25saynlpeq().b[80][0]++;
    cov_25saynlpeq().s[183]++;
    return null;
  } else {
    cov_25saynlpeq().b[80][1]++;
  }
  cov_25saynlpeq().s[184]++;
  if ((cov_25saynlpeq().b[82][0]++, !isRoot) && (cov_25saynlpeq().b[82][1]++, node.nodeType === 1) && (cov_25saynlpeq().b[82][2]++, options.exclude?.some(selector => {
    cov_25saynlpeq().f[25]++;
    cov_25saynlpeq().s[185]++;
    return node.matches(selector);
  }))) {
    cov_25saynlpeq().b[81][0]++;
    cov_25saynlpeq().s[186]++;
    task?.excludeSource(node);
    cov_25saynlpeq().s[187]++;
    return null;
  } else {
    cov_25saynlpeq().b[81][1]++;
  }
  cov_25saynlpeq().s[188]++;
  if ((cov_25saynlpeq().b[84][0]++, !isRoot) && (cov_25saynlpeq().b[84][1]++, options.filter) && (cov_25saynlpeq().b[84][2]++, !options.filter(node))) {
    cov_25saynlpeq().b[83][0]++;
    cov_25saynlpeq().s[189]++;
    task?.excludeSource(node);
    cov_25saynlpeq().s[190]++;
    return null;
  } else {
    cov_25saynlpeq().b[83][1]++;
  }
  const copyDocument = (cov_25saynlpeq().s[191]++, (cov_25saynlpeq().b[85][0]++, targetDocument) || (cov_25saynlpeq().b[85][1]++, createCloneDocument(node.ownerDocument)));
  cov_25saynlpeq().s[192]++;
  return Promise.resolve(node).then(clonedNode => {
    cov_25saynlpeq().f[26]++;
    cov_25saynlpeq().s[193]++;
    return cloneSingleNode(clonedNode, options, copyDocument, resolveSymbols);
  }).then(clonedNode => {
    cov_25saynlpeq().f[27]++;
    cov_25saynlpeq().s[194]++;
    if (isInstanceOfElement(node, Element)) {
      cov_25saynlpeq().b[86][0]++;
      cov_25saynlpeq().s[195]++;
      task?.registerClone(clonedNode, node);
    } else {
      cov_25saynlpeq().b[86][1]++;
    }
    cov_25saynlpeq().s[196]++;
    return cloneChildren(node, clonedNode, options, copyDocument, resolveSymbols);
  }).then(clonedNode => {
    cov_25saynlpeq().f[28]++;
    cov_25saynlpeq().s[197]++;
    return decorate(node, clonedNode, options, isRoot);
  }).then(clonedNode => {
    cov_25saynlpeq().f[29]++;
    cov_25saynlpeq().s[198]++;
    return (cov_25saynlpeq().b[88][0]++, isRoot) && (cov_25saynlpeq().b[88][1]++, resolveSymbols) ? (cov_25saynlpeq().b[87][0]++, ensureSVGSymbols(node, clonedNode, options)) : (cov_25saynlpeq().b[87][1]++, clonedNode);
  });
}