function cov_ig8gpf7aj() {
  var path = "/work/src/clone-pseudos.ts";
  var hash = "a12e2746e7bd9673575a31425cbce0606404ba3e";
  var global = globalThis;
  var gcv = "__VITEST_COVERAGE__";
  var coverageData = {
    path: "/work/src/clone-pseudos.ts",
    statementMap: {
      "0": {
        start: {
          line: 4,
          column: 17
        },
        end: {
          line: 4,
          column: 50
        }
      },
      "1": {
        start: {
          line: 5,
          column: 1
        },
        end: {
          line: 5,
          column: 70
        }
      },
      "2": {
        start: {
          line: 8,
          column: 1
        },
        end: {
          line: 12,
          column: 14
        }
      },
      "3": {
        start: {
          line: 9,
          column: 16
        },
        end: {
          line: 9,
          column: 44
        }
      },
      "4": {
        start: {
          line: 10,
          column: 19
        },
        end: {
          line: 10,
          column: 50
        }
      },
      "5": {
        start: {
          line: 11,
          column: 2
        },
        end: {
          line: 11,
          column: 62
        }
      },
      "6": {
        start: {
          line: 15,
          column: 18
        },
        end: {
          line: 15,
          column: 43
        }
      },
      "7": {
        start: {
          line: 16,
          column: 17
        },
        end: {
          line: 16,
          column: 112
        }
      },
      "8": {
        start: {
          line: 17,
          column: 1
        },
        end: {
          line: 17,
          column: 82
        }
      },
      "9": {
        start: {
          line: 20,
          column: 15
        },
        end: {
          line: 20,
          column: 125
        }
      },
      "10": {
        start: {
          line: 21,
          column: 17
        },
        end: {
          line: 21,
          column: 50
        }
      },
      "11": {
        start: {
          line: 22,
          column: 1
        },
        end: {
          line: 24,
          column: 2
        }
      },
      "12": {
        start: {
          line: 23,
          column: 2
        },
        end: {
          line: 23,
          column: 9
        }
      },
      "13": {
        start: {
          line: 25,
          column: 19
        },
        end: {
          line: 25,
          column: 25
        }
      },
      "14": {
        start: {
          line: 26,
          column: 1
        },
        end: {
          line: 30,
          column: 2
        }
      },
      "15": {
        start: {
          line: 27,
          column: 2
        },
        end: {
          line: 27,
          column: 64
        }
      },
      "16": {
        start: {
          line: 29,
          column: 2
        },
        end: {
          line: 29,
          column: 9
        }
      },
      "17": {
        start: {
          line: 31,
          column: 22
        },
        end: {
          line: 31,
          column: 76
        }
      },
      "18": {
        start: {
          line: 32,
          column: 1
        },
        end: {
          line: 32,
          column: 85
        }
      },
      "19": {
        start: {
          line: 33,
          column: 1
        },
        end: {
          line: 33,
          column: 38
        }
      },
      "20": {
        start: {
          line: 36,
          column: 1
        },
        end: {
          line: 36,
          column: 65
        }
      },
      "21": {
        start: {
          line: 37,
          column: 1
        },
        end: {
          line: 37,
          column: 64
        }
      }
    },
    fnMap: {
      "0": {
        name: "formatCSSText",
        decl: {
          start: {
            line: 3,
            column: 9
          },
          end: {
            line: 3,
            column: 22
          }
        },
        loc: {
          start: {
            line: 3,
            column: 30
          },
          end: {
            line: 6,
            column: 1
          }
        },
        line: 3
      },
      "1": {
        name: "formatCSSProperties",
        decl: {
          start: {
            line: 7,
            column: 9
          },
          end: {
            line: 7,
            column: 28
          }
        },
        loc: {
          start: {
            line: 7,
            column: 46
          },
          end: {
            line: 13,
            column: 1
          }
        },
        line: 7
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 8,
            column: 48
          },
          end: {
            line: 8,
            column: 49
          }
        },
        loc: {
          start: {
            line: 8,
            column: 58
          },
          end: {
            line: 12,
            column: 2
          }
        },
        line: 8
      },
      "3": {
        name: "getPseudoElementStyle",
        decl: {
          start: {
            line: 14,
            column: 9
          },
          end: {
            line: 14,
            column: 30
          }
        },
        loc: {
          start: {
            line: 14,
            column: 67
          },
          end: {
            line: 18,
            column: 1
          }
        },
        line: 14
      },
      "4": {
        name: "clonePseudoElement",
        decl: {
          start: {
            line: 19,
            column: 9
          },
          end: {
            line: 19,
            column: 27
          }
        },
        loc: {
          start: {
            line: 19,
            column: 70
          },
          end: {
            line: 34,
            column: 1
          }
        },
        line: 19
      },
      "5": {
        name: "clonePseudoElements",
        decl: {
          start: {
            line: 35,
            column: 16
          },
          end: {
            line: 35,
            column: 35
          }
        },
        loc: {
          start: {
            line: 35,
            column: 70
          },
          end: {
            line: 38,
            column: 1
          }
        },
        line: 35
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 11,
            column: 29
          },
          end: {
            line: 11,
            column: 58
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 11,
            column: 40
          },
          end: {
            line: 11,
            column: 53
          }
        }, {
          start: {
            line: 11,
            column: 56
          },
          end: {
            line: 11,
            column: 58
          }
        }],
        line: 11
      },
      "1": {
        loc: {
          start: {
            line: 16,
            column: 17
          },
          end: {
            line: 16,
            column: 112
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 16,
            column: 53
          },
          end: {
            line: 16,
            column: 73
          }
        }, {
          start: {
            line: 16,
            column: 76
          },
          end: {
            line: 16,
            column: 112
          }
        }],
        line: 16
      },
      "2": {
        loc: {
          start: {
            line: 16,
            column: 17
          },
          end: {
            line: 16,
            column: 50
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 16,
            column: 17
          },
          end: {
            line: 16,
            column: 30
          }
        }, {
          start: {
            line: 16,
            column: 34
          },
          end: {
            line: 16,
            column: 50
          }
        }],
        line: 16
      },
      "3": {
        loc: {
          start: {
            line: 20,
            column: 16
          },
          end: {
            line: 20,
            column: 87
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 20,
            column: 16
          },
          end: {
            line: 20,
            column: 77
          }
        }, {
          start: {
            line: 20,
            column: 81
          },
          end: {
            line: 20,
            column: 87
          }
        }],
        line: 20
      },
      "4": {
        loc: {
          start: {
            line: 22,
            column: 1
          },
          end: {
            line: 24,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 22,
            column: 1
          },
          end: {
            line: 24,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 22
      },
      "5": {
        loc: {
          start: {
            line: 22,
            column: 5
          },
          end: {
            line: 22,
            column: 41
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 22,
            column: 5
          },
          end: {
            line: 22,
            column: 19
          }
        }, {
          start: {
            line: 22,
            column: 23
          },
          end: {
            line: 22,
            column: 41
          }
        }],
        line: 22
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0],
      "4": [0, 0],
      "5": [0, 0]
    },
    inputSourceMap: {
      mappings: "AAAA,SAAS,oBAAoB,4BAA4B;AACzD,SAAS,MAAM,0BAA0B;AAIzC,SAAS,cAAc,OAA4B;CACjD,MAAM,UAAU,MAAM,iBAAiB,SAAS;CAChD,OAAO,GAAG,MAAM,QAAQ,aAAa,QAAQ,QAAQ,QAAQ,EAAE,EAAE;AACnE;AAEA,SAAS,oBACP,OACA,UACA;CACA,OAAO,mBAAmB,OAAO,QAAQ,CAAC,CACvC,KAAK,SAAS;EACb,MAAM,QAAQ,MAAM,iBAAiB,IAAI;EACzC,MAAM,WAAW,MAAM,oBAAoB,IAAI;EAE/C,OAAO,GAAG,KAAK,IAAI,QAAQ,WAAW,gBAAgB,GAAG;CAC3D,CAAC,CAAC,CACD,KAAK,GAAG;AACb;AAEA,SAAS,sBACP,WACA,QACA,OACA,UACM;CACN,MAAM,WAAW,IAAI,UAAU,GAAG;CAClC,MAAM,UACJ,MAAM,WAAW,YAAY,OACzB,cAAc,KAAK,IACnB,oBAAoB,OAAO,QAAQ;CAEzC,OAAO,mBACL,UACA,gBACF,CAAC,CAAC,GAAG,SAAS,GAAG,QAAQ,EAAE;AAC7B;AAEA,SAAS,mBACP,YACA,YACA,QACA,UACA;CACA,MAAM,SACJ,qBAAqB,WAAW,eAAe,aAAa,KAAK,OAAM,CACvE,iBAAiB,YAAY,MAAM;CACrC,MAAM,UAAU,MAAM,iBAAiB,SAAS;CAChD,IAAI,YAAY,MAAM,YAAY,QAAQ;EACxC;CACF;CAEA,MAAM,YAAY,KAAK;CACvB,IAAI;EACF,WAAW,YAAY,GAAG,WAAW,UAAU,GAAG;CACpD,SAAS,KAAK;EACZ;CACF;CAEA,MAAM,eAAe,mBAAmB,UAAU,eAAe,CAAC,CAAC,OAAO;CAC1E,aAAa,YACX,sBAAsB,WAAW,QAAQ,OAAO,QAAQ,CAC1D;CACA,WAAW,YAAY,YAAY;AACrC;AAEA,OAAO,SAAS,oBACd,YACA,YACA,UACA;CACA,mBAAmB,YAAY,YAAY,WAAW,QAAQ;CAC9D,mBAAmB,YAAY,YAAY,UAAU,QAAQ;AAC/D",
      names: [],
      sources: ["/work/src/clone-pseudos.ts"],
      version: 3,
      sourcesContent: ["import { readDocumentMethod, readDocumentProperty } from './document.js'\nimport { uuid, getStyleProperties } from './util.js'\n\ntype Pseudo = ':before' | ':after'\n\nfunction formatCSSText(style: CSSStyleDeclaration) {\n  const content = style.getPropertyValue('content')\n  return `${style.cssText} content: '${content.replace(/'|\"/g, '')}';`\n}\n\nfunction formatCSSProperties(\n  style: CSSStyleDeclaration,\n  selected?: readonly string[],\n) {\n  return getStyleProperties(style, selected)\n    .map((name) => {\n      const value = style.getPropertyValue(name)\n      const priority = style.getPropertyPriority(name)\n\n      return `${name}: ${value}${priority ? ' !important' : ''};`\n    })\n    .join(' ')\n}\n\nfunction getPseudoElementStyle(\n  className: string,\n  pseudo: Pseudo,\n  style: CSSStyleDeclaration,\n  selected?: readonly string[],\n): Text {\n  const selector = `.${className}:${pseudo}`\n  const cssText =\n    style.cssText && selected == null\n      ? formatCSSText(style)\n      : formatCSSProperties(style, selected)\n\n  return readDocumentMethod(\n    document,\n    'createTextNode',\n  )(`${selector}{${cssText}}`)\n}\n\nfunction clonePseudoElement<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n  pseudo: Pseudo,\n  selected?: readonly string[],\n) {\n  const style = (\n    readDocumentProperty(nativeNode.ownerDocument, 'defaultView') || window\n  ).getComputedStyle(nativeNode, pseudo)\n  const content = style.getPropertyValue('content')\n  if (content === '' || content === 'none') {\n    return\n  }\n\n  const className = uuid()\n  try {\n    clonedNode.className = `${clonedNode.className} ${className}`\n  } catch (err) {\n    return\n  }\n\n  const styleElement = readDocumentMethod(document, 'createElement')('style')\n  styleElement.appendChild(\n    getPseudoElementStyle(className, pseudo, style, selected),\n  )\n  clonedNode.appendChild(styleElement)\n}\n\nexport function clonePseudoElements<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n  selected?: readonly string[],\n) {\n  clonePseudoElement(nativeNode, clonedNode, ':before', selected)\n  clonePseudoElement(nativeNode, clonedNode, ':after', selected)\n}\n"]
    },
    _coverageSchema: "de0df54ae17f6b36de740b46d31f7cdddb68e251",
    hash: "a12e2746e7bd9673575a31425cbce0606404ba3e"
  };
  var coverage = global[gcv] || (global[gcv] = {});
  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }
  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_ig8gpf7aj = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}
cov_ig8gpf7aj();
import { readDocumentMethod, readDocumentProperty } from "/src/document.ts";
import { uuid, getStyleProperties } from "/src/util.ts";
function formatCSSText(style) {
  cov_ig8gpf7aj().f[0]++;
  const content = (cov_ig8gpf7aj().s[0]++, style.getPropertyValue("content"));
  cov_ig8gpf7aj().s[1]++;
  return `${style.cssText} content: '${content.replace(/'|"/g, "")}';`;
}
function formatCSSProperties(style, selected) {
  cov_ig8gpf7aj().f[1]++;
  cov_ig8gpf7aj().s[2]++;
  return getStyleProperties(style, selected).map(name => {
    cov_ig8gpf7aj().f[2]++;
    const value = (cov_ig8gpf7aj().s[3]++, style.getPropertyValue(name));
    const priority = (cov_ig8gpf7aj().s[4]++, style.getPropertyPriority(name));
    cov_ig8gpf7aj().s[5]++;
    return `${name}: ${value}${priority ? (cov_ig8gpf7aj().b[0][0]++, " !important") : (cov_ig8gpf7aj().b[0][1]++, "")};`;
  }).join(" ");
}
function getPseudoElementStyle(className, pseudo, style, selected) {
  cov_ig8gpf7aj().f[3]++;
  const selector = (cov_ig8gpf7aj().s[6]++, `.${className}:${pseudo}`);
  const cssText = (cov_ig8gpf7aj().s[7]++, (cov_ig8gpf7aj().b[2][0]++, style.cssText) && (cov_ig8gpf7aj().b[2][1]++, selected == null) ? (cov_ig8gpf7aj().b[1][0]++, formatCSSText(style)) : (cov_ig8gpf7aj().b[1][1]++, formatCSSProperties(style, selected)));
  cov_ig8gpf7aj().s[8]++;
  return readDocumentMethod(document, "createTextNode")(`${selector}{${cssText}}`);
}
function clonePseudoElement(nativeNode, clonedNode, pseudo, selected) {
  cov_ig8gpf7aj().f[4]++;
  const style = (cov_ig8gpf7aj().s[9]++, ((cov_ig8gpf7aj().b[3][0]++, readDocumentProperty(nativeNode.ownerDocument, "defaultView")) || (cov_ig8gpf7aj().b[3][1]++, window)).getComputedStyle(nativeNode, pseudo));
  const content = (cov_ig8gpf7aj().s[10]++, style.getPropertyValue("content"));
  cov_ig8gpf7aj().s[11]++;
  if ((cov_ig8gpf7aj().b[5][0]++, content === "") || (cov_ig8gpf7aj().b[5][1]++, content === "none")) {
    cov_ig8gpf7aj().b[4][0]++;
    cov_ig8gpf7aj().s[12]++;
    return;
  } else {
    cov_ig8gpf7aj().b[4][1]++;
  }
  const className = (cov_ig8gpf7aj().s[13]++, uuid());
  cov_ig8gpf7aj().s[14]++;
  try {
    cov_ig8gpf7aj().s[15]++;
    clonedNode.className = `${clonedNode.className} ${className}`;
  } catch (err) {
    cov_ig8gpf7aj().s[16]++;
    return;
  }
  const styleElement = (cov_ig8gpf7aj().s[17]++, readDocumentMethod(document, "createElement")("style"));
  cov_ig8gpf7aj().s[18]++;
  styleElement.appendChild(getPseudoElementStyle(className, pseudo, style, selected));
  cov_ig8gpf7aj().s[19]++;
  clonedNode.appendChild(styleElement);
}
export function clonePseudoElements(nativeNode, clonedNode, selected) {
  cov_ig8gpf7aj().f[5]++;
  cov_ig8gpf7aj().s[20]++;
  clonePseudoElement(nativeNode, clonedNode, ":before", selected);
  cov_ig8gpf7aj().s[21]++;
  clonePseudoElement(nativeNode, clonedNode, ":after", selected);
}