function cov_xsf08iuw7() {
  var path = "/work/src/util.ts";
  var hash = "bd1ee789683e2207492823917c5059421e07d3eb";
  var global = globalThis;
  var gcv = "__VITEST_COVERAGE__";
  var coverageData = {
    path: "/work/src/util.ts",
    statementMap: {
      "0": {
        start: {
          line: 4,
          column: 1
        },
        end: {
          line: 9,
          column: 2
        }
      },
      "1": {
        start: {
          line: 5,
          column: 2
        },
        end: {
          line: 5,
          column: 81
        }
      },
      "2": {
        start: {
          line: 8,
          column: 2
        },
        end: {
          line: 8,
          column: 13
        }
      },
      "3": {
        start: {
          line: 11,
          column: 20
        },
        end: {
          line: 21,
          column: 4
        }
      },
      "4": {
        start: {
          line: 14,
          column: 15
        },
        end: {
          line: 14,
          column: 16
        }
      },
      "5": {
        start: {
          line: 16,
          column: 16
        },
        end: {
          line: 16,
          column: 84
        }
      },
      "6": {
        start: {
          line: 16,
          column: 22
        },
        end: {
          line: 16,
          column: 84
        }
      },
      "7": {
        start: {
          line: 17,
          column: 1
        },
        end: {
          line: 20,
          column: 3
        }
      },
      "8": {
        start: {
          line: 18,
          column: 2
        },
        end: {
          line: 18,
          column: 15
        }
      },
      "9": {
        start: {
          line: 19,
          column: 2
        },
        end: {
          line: 19,
          column: 34
        }
      },
      "10": {
        start: {
          line: 23,
          column: 1
        },
        end: {
          line: 25,
          column: 4
        }
      },
      "11": {
        start: {
          line: 23,
          column: 18
        },
        end: {
          line: 25,
          column: 3
        }
      },
      "12": {
        start: {
          line: 24,
          column: 2
        },
        end: {
          line: 24,
          column: 38
        }
      },
      "13": {
        start: {
          line: 24,
          column: 19
        },
        end: {
          line: 24,
          column: 32
        }
      },
      "14": {
        start: {
          line: 28,
          column: 13
        },
        end: {
          line: 28,
          column: 15
        }
      },
      "15": {
        start: {
          line: 29,
          column: 1
        },
        end: {
          line: 31,
          column: 2
        }
      },
      "16": {
        start: {
          line: 29,
          column: 14
        },
        end: {
          line: 29,
          column: 15
        }
      },
      "17": {
        start: {
          line: 29,
          column: 21
        },
        end: {
          line: 29,
          column: 37
        }
      },
      "18": {
        start: {
          line: 30,
          column: 2
        },
        end: {
          line: 30,
          column: 25
        }
      },
      "19": {
        start: {
          line: 32,
          column: 1
        },
        end: {
          line: 32,
          column: 12
        }
      },
      "20": {
        start: {
          line: 35,
          column: 1
        },
        end: {
          line: 35,
          column: 131
        }
      },
      "21": {
        start: {
          line: 38,
          column: 13
        },
        end: {
          line: 38,
          column: 78
        }
      },
      "22": {
        start: {
          line: 39,
          column: 13
        },
        end: {
          line: 39,
          column: 71
        }
      },
      "23": {
        start: {
          line: 40,
          column: 1
        },
        end: {
          line: 40,
          column: 52
        }
      },
      "24": {
        start: {
          line: 43,
          column: 20
        },
        end: {
          line: 43,
          column: 49
        }
      },
      "25": {
        start: {
          line: 44,
          column: 21
        },
        end: {
          line: 44,
          column: 51
        }
      },
      "26": {
        start: {
          line: 45,
          column: 1
        },
        end: {
          line: 45,
          column: 52
        }
      },
      "27": {
        start: {
          line: 48,
          column: 19
        },
        end: {
          line: 48,
          column: 47
        }
      },
      "28": {
        start: {
          line: 49,
          column: 22
        },
        end: {
          line: 49,
          column: 53
        }
      },
      "29": {
        start: {
          line: 50,
          column: 1
        },
        end: {
          line: 50,
          column: 53
        }
      },
      "30": {
        start: {
          line: 53,
          column: 15
        },
        end: {
          line: 53,
          column: 56
        }
      },
      "31": {
        start: {
          line: 54,
          column: 16
        },
        end: {
          line: 54,
          column: 59
        }
      },
      "32": {
        start: {
          line: 55,
          column: 1
        },
        end: {
          line: 58,
          column: 3
        }
      },
      "33": {
        start: {
          line: 63,
          column: 1
        },
        end: {
          line: 65,
          column: 15
        }
      },
      "34": {
        start: {
          line: 64,
          column: 2
        },
        end: {
          line: 64,
          column: 26
        }
      },
      "35": {
        start: {
          line: 66,
          column: 13
        },
        end: {
          line: 66,
          column: 91
        }
      },
      "36": {
        start: {
          line: 67,
          column: 1
        },
        end: {
          line: 72,
          column: 2
        }
      },
      "37": {
        start: {
          line: 68,
          column: 2
        },
        end: {
          line: 68,
          column: 28
        }
      },
      "38": {
        start: {
          line: 69,
          column: 2
        },
        end: {
          line: 71,
          column: 3
        }
      },
      "39": {
        start: {
          line: 70,
          column: 3
        },
        end: {
          line: 70,
          column: 13
        }
      },
      "40": {
        start: {
          line: 73,
          column: 1
        },
        end: {
          line: 73,
          column: 46
        }
      },
      "41": {
        start: {
          line: 76,
          column: 29
        },
        end: {
          line: 76,
          column: 34
        }
      },
      "42": {
        start: {
          line: 78,
          column: 1
        },
        end: {
          line: 94,
          column: 2
        }
      },
      "43": {
        start: {
          line: 79,
          column: 2
        },
        end: {
          line: 93,
          column: 3
        }
      },
      "44": {
        start: {
          line: 80,
          column: 3
        },
        end: {
          line: 86,
          column: 4
        }
      },
      "45": {
        start: {
          line: 81,
          column: 4
        },
        end: {
          line: 81,
          column: 57
        }
      },
      "46": {
        start: {
          line: 82,
          column: 4
        },
        end: {
          line: 82,
          column: 40
        }
      },
      "47": {
        start: {
          line: 84,
          column: 4
        },
        end: {
          line: 84,
          column: 57
        }
      },
      "48": {
        start: {
          line: 85,
          column: 4
        },
        end: {
          line: 85,
          column: 41
        }
      },
      "49": {
        start: {
          line: 87,
          column: 9
        },
        end: {
          line: 93,
          column: 3
        }
      },
      "50": {
        start: {
          line: 88,
          column: 3
        },
        end: {
          line: 88,
          column: 56
        }
      },
      "51": {
        start: {
          line: 89,
          column: 3
        },
        end: {
          line: 89,
          column: 39
        }
      },
      "52": {
        start: {
          line: 91,
          column: 3
        },
        end: {
          line: 91,
          column: 56
        }
      },
      "53": {
        start: {
          line: 92,
          column: 3
        },
        end: {
          line: 92,
          column: 40
        }
      },
      "54": {
        start: {
          line: 97,
          column: 1
        },
        end: {
          line: 101,
          column: 2
        }
      },
      "55": {
        start: {
          line: 98,
          column: 2
        },
        end: {
          line: 100,
          column: 5
        }
      },
      "56": {
        start: {
          line: 99,
          column: 3
        },
        end: {
          line: 99,
          column: 91
        }
      },
      "57": {
        start: {
          line: 102,
          column: 1
        },
        end: {
          line: 110,
          column: 4
        }
      },
      "58": {
        start: {
          line: 103,
          column: 23
        },
        end: {
          line: 103,
          column: 137
        }
      },
      "59": {
        start: {
          line: 104,
          column: 14
        },
        end: {
          line: 104,
          column: 33
        }
      },
      "60": {
        start: {
          line: 105,
          column: 22
        },
        end: {
          line: 105,
          column: 41
        }
      },
      "61": {
        start: {
          line: 106,
          column: 2
        },
        end: {
          line: 108,
          column: 3
        }
      },
      "62": {
        start: {
          line: 106,
          column: 15
        },
        end: {
          line: 106,
          column: 16
        }
      },
      "63": {
        start: {
          line: 107,
          column: 3
        },
        end: {
          line: 107,
          column: 47
        }
      },
      "64": {
        start: {
          line: 109,
          column: 2
        },
        end: {
          line: 109,
          column: 88
        }
      },
      "65": {
        start: {
          line: 113,
          column: 1
        },
        end: {
          line: 150,
          column: 4
        }
      },
      "66": {
        start: {
          line: 114,
          column: 14
        },
        end: {
          line: 114,
          column: 34
        }
      },
      "67": {
        start: {
          line: 115,
          column: 17
        },
        end: {
          line: 115,
          column: 67
        }
      },
      "68": {
        start: {
          line: 117,
          column: 16
        },
        end: {
          line: 122,
          column: 3
        }
      },
      "69": {
        start: {
          line: 118,
          column: 3
        },
        end: {
          line: 118,
          column: 42
        }
      },
      "70": {
        start: {
          line: 118,
          column: 22
        },
        end: {
          line: 118,
          column: 42
        }
      },
      "71": {
        start: {
          line: 119,
          column: 3
        },
        end: {
          line: 119,
          column: 21
        }
      },
      "72": {
        start: {
          line: 120,
          column: 3
        },
        end: {
          line: 120,
          column: 22
        }
      },
      "73": {
        start: {
          line: 121,
          column: 3
        },
        end: {
          line: 121,
          column: 47
        }
      },
      "74": {
        start: {
          line: 123,
          column: 15
        },
        end: {
          line: 127,
          column: 3
        }
      },
      "75": {
        start: {
          line: 124,
          column: 3
        },
        end: {
          line: 124,
          column: 11
        }
      },
      "76": {
        start: {
          line: 125,
          column: 3
        },
        end: {
          line: 125,
          column: 16
        }
      },
      "77": {
        start: {
          line: 126,
          column: 3
        },
        end: {
          line: 126,
          column: 17
        }
      },
      "78": {
        start: {
          line: 128,
          column: 16
        },
        end: {
          line: 128,
          column: 98
        }
      },
      "79": {
        start: {
          line: 128,
          column: 22
        },
        end: {
          line: 128,
          column: 98
        }
      },
      "80": {
        start: {
          line: 129,
          column: 2
        },
        end: {
          line: 132,
          column: 3
        }
      },
      "81": {
        start: {
          line: 130,
          column: 3
        },
        end: {
          line: 130,
          column: 11
        }
      },
      "82": {
        start: {
          line: 131,
          column: 3
        },
        end: {
          line: 131,
          column: 10
        }
      },
      "83": {
        start: {
          line: 133,
          column: 2
        },
        end: {
          line: 133,
          column: 59
        }
      },
      "84": {
        start: {
          line: 134,
          column: 18
        },
        end: {
          line: 134,
          column: 40
        }
      },
      "85": {
        start: {
          line: 135,
          column: 2
        },
        end: {
          line: 135,
          column: 117
        }
      },
      "86": {
        start: {
          line: 135,
          column: 19
        },
        end: {
          line: 135,
          column: 117
        }
      },
      "87": {
        start: {
          line: 135,
          column: 44
        },
        end: {
          line: 135,
          column: 106
        }
      },
      "88": {
        start: {
          line: 136,
          column: 2
        },
        end: {
          line: 143,
          column: 4
        }
      },
      "89": {
        start: {
          line: 137,
          column: 3
        },
        end: {
          line: 142,
          column: 12
        }
      },
      "90": {
        start: {
          line: 137,
          column: 32
        },
        end: {
          line: 137,
          column: 91
        }
      },
      "91": {
        start: {
          line: 138,
          column: 4
        },
        end: {
          line: 138,
          column: 73
        }
      },
      "92": {
        start: {
          line: 138,
          column: 27
        },
        end: {
          line: 138,
          column: 73
        }
      },
      "93": {
        start: {
          line: 140,
          column: 4
        },
        end: {
          line: 140,
          column: 12
        }
      },
      "94": {
        start: {
          line: 141,
          column: 4
        },
        end: {
          line: 141,
          column: 17
        }
      },
      "95": {
        start: {
          line: 144,
          column: 2
        },
        end: {
          line: 144,
          column: 67
        }
      },
      "96": {
        start: {
          line: 144,
          column: 22
        },
        end: {
          line: 144,
          column: 66
        }
      },
      "97": {
        start: {
          line: 145,
          column: 2
        },
        end: {
          line: 145,
          column: 32
        }
      },
      "98": {
        start: {
          line: 148,
          column: 2
        },
        end: {
          line: 148,
          column: 24
        }
      },
      "99": {
        start: {
          line: 149,
          column: 2
        },
        end: {
          line: 149,
          column: 16
        }
      },
      "100": {
        start: {
          line: 153,
          column: 1
        },
        end: {
          line: 153,
          column: 241
        }
      },
      "101": {
        start: {
          line: 153,
          column: 37
        },
        end: {
          line: 153,
          column: 79
        }
      },
      "102": {
        start: {
          line: 153,
          column: 95
        },
        end: {
          line: 153,
          column: 155
        }
      },
      "103": {
        start: {
          line: 153,
          column: 197
        },
        end: {
          line: 153,
          column: 239
        }
      },
      "104": {
        start: {
          line: 156,
          column: 15
        },
        end: {
          line: 156,
          column: 43
        }
      },
      "105": {
        start: {
          line: 157,
          column: 13
        },
        end: {
          line: 157,
          column: 79
        }
      },
      "106": {
        start: {
          line: 158,
          column: 23
        },
        end: {
          line: 158,
          column: 99
        }
      },
      "107": {
        start: {
          line: 159,
          column: 1
        },
        end: {
          line: 159,
          column: 39
        }
      },
      "108": {
        start: {
          line: 160,
          column: 1
        },
        end: {
          line: 160,
          column: 41
        }
      },
      "109": {
        start: {
          line: 161,
          column: 1
        },
        end: {
          line: 161,
          column: 55
        }
      },
      "110": {
        start: {
          line: 162,
          column: 1
        },
        end: {
          line: 162,
          column: 45
        }
      },
      "111": {
        start: {
          line: 163,
          column: 1
        },
        end: {
          line: 163,
          column: 46
        }
      },
      "112": {
        start: {
          line: 164,
          column: 1
        },
        end: {
          line: 164,
          column: 38
        }
      },
      "113": {
        start: {
          line: 165,
          column: 1
        },
        end: {
          line: 165,
          column: 38
        }
      },
      "114": {
        start: {
          line: 166,
          column: 1
        },
        end: {
          line: 166,
          column: 65
        }
      },
      "115": {
        start: {
          line: 167,
          column: 1
        },
        end: {
          line: 173,
          column: 2
        }
      },
      "116": {
        start: {
          line: 168,
          column: 16
        },
        end: {
          line: 168,
          column: 84
        }
      },
      "117": {
        start: {
          line: 171,
          column: 2
        },
        end: {
          line: 171,
          column: 61
        }
      },
      "118": {
        start: {
          line: 172,
          column: 2
        },
        end: {
          line: 172,
          column: 20
        }
      },
      "119": {
        start: {
          line: 174,
          column: 1
        },
        end: {
          line: 174,
          column: 32
        }
      },
      "120": {
        start: {
          line: 175,
          column: 1
        },
        end: {
          line: 175,
          column: 33
        }
      },
      "121": {
        start: {
          line: 176,
          column: 1
        },
        end: {
          line: 176,
          column: 26
        }
      },
      "122": {
        start: {
          line: 178,
          column: 35
        },
        end: {
          line: 183,
          column: 1
        }
      },
      "123": {
        start: {
          line: 179,
          column: 1
        },
        end: {
          line: 179,
          column: 43
        }
      },
      "124": {
        start: {
          line: 179,
          column: 31
        },
        end: {
          line: 179,
          column: 43
        }
      },
      "125": {
        start: {
          line: 180,
          column: 23
        },
        end: {
          line: 180,
          column: 50
        }
      },
      "126": {
        start: {
          line: 181,
          column: 1
        },
        end: {
          line: 181,
          column: 42
        }
      },
      "127": {
        start: {
          line: 181,
          column: 29
        },
        end: {
          line: 181,
          column: 42
        }
      },
      "128": {
        start: {
          line: 182,
          column: 1
        },
        end: {
          line: 182,
          column: 105
        }
      }
    },
    fnMap: {
      "0": {
        name: "resolveUrl",
        decl: {
          start: {
            line: 3,
            column: 16
          },
          end: {
            line: 3,
            column: 26
          }
        },
        loc: {
          start: {
            line: 3,
            column: 41
          },
          end: {
            line: 10,
            column: 1
          }
        },
        line: 3
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 11,
            column: 21
          },
          end: {
            line: 11,
            column: 22
          }
        },
        loc: {
          start: {
            line: 11,
            column: 27
          },
          end: {
            line: 21,
            column: 1
          }
        },
        line: 11
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 16,
            column: 16
          },
          end: {
            line: 16,
            column: 17
          }
        },
        loc: {
          start: {
            line: 16,
            column: 22
          },
          end: {
            line: 16,
            column: 84
          }
        },
        line: 16
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 17,
            column: 8
          },
          end: {
            line: 17,
            column: 9
          }
        },
        loc: {
          start: {
            line: 17,
            column: 14
          },
          end: {
            line: 20,
            column: 2
          }
        },
        line: 17
      },
      "4": {
        name: "delay",
        decl: {
          start: {
            line: 22,
            column: 16
          },
          end: {
            line: 22,
            column: 21
          }
        },
        loc: {
          start: {
            line: 22,
            column: 26
          },
          end: {
            line: 26,
            column: 1
          }
        },
        line: 22
      },
      "5": {
        name: "(anonymous_5)",
        decl: {
          start: {
            line: 23,
            column: 8
          },
          end: {
            line: 23,
            column: 9
          }
        },
        loc: {
          start: {
            line: 23,
            column: 18
          },
          end: {
            line: 25,
            column: 3
          }
        },
        line: 23
      },
      "6": {
        name: "(anonymous_6)",
        decl: {
          start: {
            line: 23,
            column: 30
          },
          end: {
            line: 23,
            column: 31
          }
        },
        loc: {
          start: {
            line: 23,
            column: 43
          },
          end: {
            line: 25,
            column: 2
          }
        },
        line: 23
      },
      "7": {
        name: "(anonymous_7)",
        decl: {
          start: {
            line: 24,
            column: 13
          },
          end: {
            line: 24,
            column: 14
          }
        },
        loc: {
          start: {
            line: 24,
            column: 19
          },
          end: {
            line: 24,
            column: 32
          }
        },
        line: 24
      },
      "8": {
        name: "toArray",
        decl: {
          start: {
            line: 27,
            column: 16
          },
          end: {
            line: 27,
            column: 23
          }
        },
        loc: {
          start: {
            line: 27,
            column: 35
          },
          end: {
            line: 33,
            column: 1
          }
        },
        line: 27
      },
      "9": {
        name: "getStyleProperties",
        decl: {
          start: {
            line: 34,
            column: 16
          },
          end: {
            line: 34,
            column: 34
          }
        },
        loc: {
          start: {
            line: 34,
            column: 52
          },
          end: {
            line: 36,
            column: 1
          }
        },
        line: 34
      },
      "10": {
        name: "px",
        decl: {
          start: {
            line: 37,
            column: 9
          },
          end: {
            line: 37,
            column: 11
          }
        },
        loc: {
          start: {
            line: 37,
            column: 33
          },
          end: {
            line: 41,
            column: 1
          }
        },
        line: 37
      },
      "11": {
        name: "getNodeWidth",
        decl: {
          start: {
            line: 42,
            column: 9
          },
          end: {
            line: 42,
            column: 21
          }
        },
        loc: {
          start: {
            line: 42,
            column: 28
          },
          end: {
            line: 46,
            column: 1
          }
        },
        line: 42
      },
      "12": {
        name: "getNodeHeight",
        decl: {
          start: {
            line: 47,
            column: 9
          },
          end: {
            line: 47,
            column: 22
          }
        },
        loc: {
          start: {
            line: 47,
            column: 29
          },
          end: {
            line: 51,
            column: 1
          }
        },
        line: 47
      },
      "13": {
        name: "getImageSize",
        decl: {
          start: {
            line: 52,
            column: 16
          },
          end: {
            line: 52,
            column: 28
          }
        },
        loc: {
          start: {
            line: 52,
            column: 55
          },
          end: {
            line: 59,
            column: 1
          }
        },
        line: 52
      },
      "14": {
        name: "getPixelRatio",
        decl: {
          start: {
            line: 60,
            column: 16
          },
          end: {
            line: 60,
            column: 29
          }
        },
        loc: {
          start: {
            line: 60,
            column: 32
          },
          end: {
            line: 74,
            column: 1
          }
        },
        line: 60
      },
      "15": {
        name: "checkCanvasDimensions",
        decl: {
          start: {
            line: 77,
            column: 16
          },
          end: {
            line: 77,
            column: 37
          }
        },
        loc: {
          start: {
            line: 77,
            column: 46
          },
          end: {
            line: 95,
            column: 1
          }
        },
        line: 77
      },
      "16": {
        name: "canvasToBlob",
        decl: {
          start: {
            line: 96,
            column: 16
          },
          end: {
            line: 96,
            column: 28
          }
        },
        loc: {
          start: {
            line: 96,
            column: 51
          },
          end: {
            line: 111,
            column: 1
          }
        },
        line: 96
      },
      "17": {
        name: "(anonymous_17)",
        decl: {
          start: {
            line: 98,
            column: 21
          },
          end: {
            line: 98,
            column: 22
          }
        },
        loc: {
          start: {
            line: 98,
            column: 34
          },
          end: {
            line: 100,
            column: 3
          }
        },
        line: 98
      },
      "18": {
        name: "(anonymous_18)",
        decl: {
          start: {
            line: 102,
            column: 20
          },
          end: {
            line: 102,
            column: 21
          }
        },
        loc: {
          start: {
            line: 102,
            column: 33
          },
          end: {
            line: 110,
            column: 2
          }
        },
        line: 102
      },
      "19": {
        name: "createImage",
        decl: {
          start: {
            line: 112,
            column: 16
          },
          end: {
            line: 112,
            column: 27
          }
        },
        loc: {
          start: {
            line: 112,
            column: 49
          },
          end: {
            line: 151,
            column: 1
          }
        },
        line: 112
      },
      "20": {
        name: "(anonymous_20)",
        decl: {
          start: {
            line: 113,
            column: 20
          },
          end: {
            line: 113,
            column: 21
          }
        },
        loc: {
          start: {
            line: 113,
            column: 41
          },
          end: {
            line: 150,
            column: 2
          }
        },
        line: 113
      },
      "21": {
        name: "(anonymous_21)",
        decl: {
          start: {
            line: 117,
            column: 16
          },
          end: {
            line: 117,
            column: 17
          }
        },
        loc: {
          start: {
            line: 117,
            column: 22
          },
          end: {
            line: 122,
            column: 3
          }
        },
        line: 117
      },
      "22": {
        name: "(anonymous_22)",
        decl: {
          start: {
            line: 123,
            column: 15
          },
          end: {
            line: 123,
            column: 16
          }
        },
        loc: {
          start: {
            line: 123,
            column: 26
          },
          end: {
            line: 127,
            column: 3
          }
        },
        line: 123
      },
      "23": {
        name: "(anonymous_23)",
        decl: {
          start: {
            line: 128,
            column: 16
          },
          end: {
            line: 128,
            column: 17
          }
        },
        loc: {
          start: {
            line: 128,
            column: 22
          },
          end: {
            line: 128,
            column: 98
          }
        },
        line: 128
      },
      "24": {
        name: "(anonymous_24)",
        decl: {
          start: {
            line: 135,
            column: 38
          },
          end: {
            line: 135,
            column: 39
          }
        },
        loc: {
          start: {
            line: 135,
            column: 44
          },
          end: {
            line: 135,
            column: 106
          }
        },
        line: 135
      },
      "25": {
        name: "(anonymous_25)",
        decl: {
          start: {
            line: 136,
            column: 15
          },
          end: {
            line: 136,
            column: 16
          }
        },
        loc: {
          start: {
            line: 136,
            column: 21
          },
          end: {
            line: 143,
            column: 3
          }
        },
        line: 136
      },
      "26": {
        name: "(anonymous_26)",
        decl: {
          start: {
            line: 137,
            column: 26
          },
          end: {
            line: 137,
            column: 27
          }
        },
        loc: {
          start: {
            line: 137,
            column: 32
          },
          end: {
            line: 137,
            column: 91
          }
        },
        line: 137
      },
      "27": {
        name: "(anonymous_27)",
        decl: {
          start: {
            line: 137,
            column: 99
          },
          end: {
            line: 137,
            column: 100
          }
        },
        loc: {
          start: {
            line: 137,
            column: 105
          },
          end: {
            line: 139,
            column: 4
          }
        },
        line: 137
      },
      "28": {
        name: "(anonymous_28)",
        decl: {
          start: {
            line: 139,
            column: 11
          },
          end: {
            line: 139,
            column: 12
          }
        },
        loc: {
          start: {
            line: 139,
            column: 17
          },
          end: {
            line: 142,
            column: 4
          }
        },
        line: 139
      },
      "29": {
        name: "(anonymous_29)",
        decl: {
          start: {
            line: 144,
            column: 16
          },
          end: {
            line: 144,
            column: 17
          }
        },
        loc: {
          start: {
            line: 144,
            column: 22
          },
          end: {
            line: 144,
            column: 66
          }
        },
        line: 144
      },
      "30": {
        name: "svgToDataURL",
        decl: {
          start: {
            line: 152,
            column: 22
          },
          end: {
            line: 152,
            column: 34
          }
        },
        loc: {
          start: {
            line: 152,
            column: 40
          },
          end: {
            line: 154,
            column: 1
          }
        },
        line: 152
      },
      "31": {
        name: "(anonymous_31)",
        decl: {
          start: {
            line: 153,
            column: 31
          },
          end: {
            line: 153,
            column: 32
          }
        },
        loc: {
          start: {
            line: 153,
            column: 37
          },
          end: {
            line: 153,
            column: 79
          }
        },
        line: 153
      },
      "32": {
        name: "(anonymous_32)",
        decl: {
          start: {
            line: 153,
            column: 86
          },
          end: {
            line: 153,
            column: 87
          }
        },
        loc: {
          start: {
            line: 153,
            column: 95
          },
          end: {
            line: 153,
            column: 155
          }
        },
        line: 153
      },
      "33": {
        name: "(anonymous_33)",
        decl: {
          start: {
            line: 153,
            column: 187
          },
          end: {
            line: 153,
            column: 188
          }
        },
        loc: {
          start: {
            line: 153,
            column: 197
          },
          end: {
            line: 153,
            column: 239
          }
        },
        line: 153
      },
      "34": {
        name: "nodeToDataURL",
        decl: {
          start: {
            line: 155,
            column: 22
          },
          end: {
            line: 155,
            column: 35
          }
        },
        loc: {
          start: {
            line: 155,
            column: 112
          },
          end: {
            line: 177,
            column: 1
          }
        },
        line: 155
      },
      "35": {
        name: "(anonymous_35)",
        decl: {
          start: {
            line: 178,
            column: 35
          },
          end: {
            line: 178,
            column: 36
          }
        },
        loc: {
          start: {
            line: 178,
            column: 55
          },
          end: {
            line: 183,
            column: 1
          }
        },
        line: 178
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 5,
            column: 22
          },
          end: {
            line: 5,
            column: 74
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 5,
            column: 22
          },
          end: {
            line: 5,
            column: 29
          }
        }, {
          start: {
            line: 5,
            column: 33
          },
          end: {
            line: 5,
            column: 74
          }
        }],
        line: 5
      },
      "1": {
        loc: {
          start: {
            line: 35,
            column: 8
          },
          end: {
            line: 35,
            column: 130
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 35,
            column: 27
          },
          end: {
            line: 35,
            column: 35
          }
        }, {
          start: {
            line: 35,
            column: 38
          },
          end: {
            line: 35,
            column: 130
          }
        }],
        line: 35
      },
      "2": {
        loc: {
          start: {
            line: 35,
            column: 46
          },
          end: {
            line: 35,
            column: 129
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 35,
            column: 46
          },
          end: {
            line: 35,
            column: 51
          }
        }, {
          start: {
            line: 35,
            column: 55
          },
          end: {
            line: 35,
            column: 129
          }
        }],
        line: 35
      },
      "3": {
        loc: {
          start: {
            line: 38,
            column: 13
          },
          end: {
            line: 38,
            column: 78
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 38,
            column: 13
          },
          end: {
            line: 38,
            column: 68
          }
        }, {
          start: {
            line: 38,
            column: 72
          },
          end: {
            line: 38,
            column: 78
          }
        }],
        line: 38
      },
      "4": {
        loc: {
          start: {
            line: 40,
            column: 8
          },
          end: {
            line: 40,
            column: 51
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 40,
            column: 14
          },
          end: {
            line: 40,
            column: 47
          }
        }, {
          start: {
            line: 40,
            column: 50
          },
          end: {
            line: 40,
            column: 51
          }
        }],
        line: 40
      },
      "5": {
        loc: {
          start: {
            line: 52,
            column: 41
          },
          end: {
            line: 52,
            column: 53
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 52,
            column: 51
          },
          end: {
            line: 52,
            column: 53
          }
        }],
        line: 52
      },
      "6": {
        loc: {
          start: {
            line: 53,
            column: 15
          },
          end: {
            line: 53,
            column: 56
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 53,
            column: 15
          },
          end: {
            line: 53,
            column: 28
          }
        }, {
          start: {
            line: 53,
            column: 32
          },
          end: {
            line: 53,
            column: 56
          }
        }],
        line: 53
      },
      "7": {
        loc: {
          start: {
            line: 54,
            column: 16
          },
          end: {
            line: 54,
            column: 59
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 54,
            column: 16
          },
          end: {
            line: 54,
            column: 30
          }
        }, {
          start: {
            line: 54,
            column: 34
          },
          end: {
            line: 54,
            column: 59
          }
        }],
        line: 54
      },
      "8": {
        loc: {
          start: {
            line: 66,
            column: 13
          },
          end: {
            line: 66,
            column: 91
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 66,
            column: 50
          },
          end: {
            line: 66,
            column: 84
          }
        }, {
          start: {
            line: 66,
            column: 87
          },
          end: {
            line: 66,
            column: 91
          }
        }],
        line: 66
      },
      "9": {
        loc: {
          start: {
            line: 66,
            column: 13
          },
          end: {
            line: 66,
            column: 47
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 66,
            column: 13
          },
          end: {
            line: 66,
            column: 26
          }
        }, {
          start: {
            line: 66,
            column: 30
          },
          end: {
            line: 66,
            column: 47
          }
        }],
        line: 66
      },
      "10": {
        loc: {
          start: {
            line: 67,
            column: 1
          },
          end: {
            line: 72,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 67,
            column: 1
          },
          end: {
            line: 72,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 67
      },
      "11": {
        loc: {
          start: {
            line: 69,
            column: 2
          },
          end: {
            line: 71,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 69,
            column: 2
          },
          end: {
            line: 71,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 69
      },
      "12": {
        loc: {
          start: {
            line: 73,
            column: 8
          },
          end: {
            line: 73,
            column: 45
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 73,
            column: 8
          },
          end: {
            line: 73,
            column: 13
          }
        }, {
          start: {
            line: 73,
            column: 17
          },
          end: {
            line: 73,
            column: 40
          }
        }, {
          start: {
            line: 73,
            column: 44
          },
          end: {
            line: 73,
            column: 45
          }
        }],
        line: 73
      },
      "13": {
        loc: {
          start: {
            line: 78,
            column: 1
          },
          end: {
            line: 94,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 78,
            column: 1
          },
          end: {
            line: 94,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 78
      },
      "14": {
        loc: {
          start: {
            line: 78,
            column: 5
          },
          end: {
            line: 78,
            column: 80
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 78,
            column: 5
          },
          end: {
            line: 78,
            column: 40
          }
        }, {
          start: {
            line: 78,
            column: 44
          },
          end: {
            line: 78,
            column: 80
          }
        }],
        line: 78
      },
      "15": {
        loc: {
          start: {
            line: 79,
            column: 2
          },
          end: {
            line: 93,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 79,
            column: 2
          },
          end: {
            line: 93,
            column: 3
          }
        }, {
          start: {
            line: 87,
            column: 9
          },
          end: {
            line: 93,
            column: 3
          }
        }],
        line: 79
      },
      "16": {
        loc: {
          start: {
            line: 79,
            column: 6
          },
          end: {
            line: 79,
            column: 81
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 79,
            column: 6
          },
          end: {
            line: 79,
            column: 41
          }
        }, {
          start: {
            line: 79,
            column: 45
          },
          end: {
            line: 79,
            column: 81
          }
        }],
        line: 79
      },
      "17": {
        loc: {
          start: {
            line: 80,
            column: 3
          },
          end: {
            line: 86,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 80,
            column: 3
          },
          end: {
            line: 86,
            column: 4
          }
        }, {
          start: {
            line: 83,
            column: 10
          },
          end: {
            line: 86,
            column: 4
          }
        }],
        line: 80
      },
      "18": {
        loc: {
          start: {
            line: 87,
            column: 9
          },
          end: {
            line: 93,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 87,
            column: 9
          },
          end: {
            line: 93,
            column: 3
          }
        }, {
          start: {
            line: 90,
            column: 9
          },
          end: {
            line: 93,
            column: 3
          }
        }],
        line: 87
      },
      "19": {
        loc: {
          start: {
            line: 96,
            column: 37
          },
          end: {
            line: 96,
            column: 49
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 96,
            column: 47
          },
          end: {
            line: 96,
            column: 49
          }
        }],
        line: 96
      },
      "20": {
        loc: {
          start: {
            line: 97,
            column: 1
          },
          end: {
            line: 101,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 97,
            column: 1
          },
          end: {
            line: 101,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 97
      },
      "21": {
        loc: {
          start: {
            line: 99,
            column: 26
          },
          end: {
            line: 99,
            column: 67
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 99,
            column: 41
          },
          end: {
            line: 99,
            column: 53
          }
        }, {
          start: {
            line: 99,
            column: 56
          },
          end: {
            line: 99,
            column: 67
          }
        }],
        line: 99
      },
      "22": {
        loc: {
          start: {
            line: 99,
            column: 69
          },
          end: {
            line: 99,
            column: 89
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 99,
            column: 69
          },
          end: {
            line: 99,
            column: 84
          }
        }, {
          start: {
            line: 99,
            column: 88
          },
          end: {
            line: 99,
            column: 89
          }
        }],
        line: 99
      },
      "23": {
        loc: {
          start: {
            line: 103,
            column: 52
          },
          end: {
            line: 103,
            column: 91
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 103,
            column: 67
          },
          end: {
            line: 103,
            column: 79
          }
        }, {
          start: {
            line: 103,
            column: 82
          },
          end: {
            line: 103,
            column: 91
          }
        }],
        line: 103
      },
      "24": {
        loc: {
          start: {
            line: 103,
            column: 93
          },
          end: {
            line: 103,
            column: 121
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 103,
            column: 93
          },
          end: {
            line: 103,
            column: 108
          }
        }, {
          start: {
            line: 103,
            column: 112
          },
          end: {
            line: 103,
            column: 121
          }
        }],
        line: 103
      },
      "25": {
        loc: {
          start: {
            line: 109,
            column: 42
          },
          end: {
            line: 109,
            column: 83
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 109,
            column: 57
          },
          end: {
            line: 109,
            column: 69
          }
        }, {
          start: {
            line: 109,
            column: 72
          },
          end: {
            line: 109,
            column: 83
          }
        }],
        line: 109
      },
      "26": {
        loc: {
          start: {
            line: 114,
            column: 14
          },
          end: {
            line: 114,
            column: 34
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 114,
            column: 14
          },
          end: {
            line: 114,
            column: 19
          }
        }, {
          start: {
            line: 114,
            column: 23
          },
          end: {
            line: 114,
            column: 34
          }
        }],
        line: 114
      },
      "27": {
        loc: {
          start: {
            line: 115,
            column: 17
          },
          end: {
            line: 115,
            column: 67
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 115,
            column: 17
          },
          end: {
            line: 115,
            column: 49
          }
        }, {
          start: {
            line: 115,
            column: 53
          },
          end: {
            line: 115,
            column: 67
          }
        }],
        line: 115
      },
      "28": {
        loc: {
          start: {
            line: 118,
            column: 3
          },
          end: {
            line: 118,
            column: 42
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 118,
            column: 3
          },
          end: {
            line: 118,
            column: 42
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 118
      },
      "29": {
        loc: {
          start: {
            line: 128,
            column: 27
          },
          end: {
            line: 128,
            column: 97
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 128,
            column: 27
          },
          end: {
            line: 128,
            column: 41
          }
        }, {
          start: {
            line: 128,
            column: 45
          },
          end: {
            line: 128,
            column: 97
          }
        }],
        line: 128
      },
      "30": {
        loc: {
          start: {
            line: 129,
            column: 2
          },
          end: {
            line: 132,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 129,
            column: 2
          },
          end: {
            line: 132,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 129
      },
      "31": {
        loc: {
          start: {
            line: 134,
            column: 18
          },
          end: {
            line: 134,
            column: 40
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 134,
            column: 18
          },
          end: {
            line: 134,
            column: 33
          }
        }, {
          start: {
            line: 134,
            column: 37
          },
          end: {
            line: 134,
            column: 40
          }
        }],
        line: 134
      },
      "32": {
        loc: {
          start: {
            line: 135,
            column: 2
          },
          end: {
            line: 135,
            column: 117
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 135,
            column: 2
          },
          end: {
            line: 135,
            column: 117
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 135
      },
      "33": {
        loc: {
          start: {
            line: 137,
            column: 32
          },
          end: {
            line: 137,
            column: 91
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 137,
            column: 67
          },
          end: {
            line: 137,
            column: 79
          }
        }, {
          start: {
            line: 137,
            column: 82
          },
          end: {
            line: 137,
            column: 91
          }
        }],
        line: 137
      },
      "34": {
        loc: {
          start: {
            line: 138,
            column: 4
          },
          end: {
            line: 138,
            column: 73
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 138,
            column: 4
          },
          end: {
            line: 138,
            column: 73
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 138
      },
      "35": {
        loc: {
          start: {
            line: 155,
            column: 57
          },
          end: {
            line: 155,
            column: 91
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 155,
            column: 73
          },
          end: {
            line: 155,
            column: 91
          }
        }],
        line: 155
      },
      "36": {
        loc: {
          start: {
            line: 155,
            column: 93
          },
          end: {
            line: 155,
            column: 110
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 155,
            column: 108
          },
          end: {
            line: 155,
            column: 110
          }
        }],
        line: 155
      },
      "37": {
        loc: {
          start: {
            line: 167,
            column: 1
          },
          end: {
            line: 173,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 167,
            column: 1
          },
          end: {
            line: 173,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 167
      },
      "38": {
        loc: {
          start: {
            line: 179,
            column: 1
          },
          end: {
            line: 179,
            column: 43
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 179,
            column: 1
          },
          end: {
            line: 179,
            column: 43
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 179
      },
      "39": {
        loc: {
          start: {
            line: 181,
            column: 1
          },
          end: {
            line: 181,
            column: 42
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 181,
            column: 1
          },
          end: {
            line: 181,
            column: 42
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 181
      },
      "40": {
        loc: {
          start: {
            line: 182,
            column: 8
          },
          end: {
            line: 182,
            column: 104
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 182,
            column: 8
          },
          end: {
            line: 182,
            column: 56
          }
        }, {
          start: {
            line: 182,
            column: 60
          },
          end: {
            line: 182,
            column: 104
          }
        }],
        line: 182
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0,
      "81": 0,
      "82": 0,
      "83": 0,
      "84": 0,
      "85": 0,
      "86": 0,
      "87": 0,
      "88": 0,
      "89": 0,
      "90": 0,
      "91": 0,
      "92": 0,
      "93": 0,
      "94": 0,
      "95": 0,
      "96": 0,
      "97": 0,
      "98": 0,
      "99": 0,
      "100": 0,
      "101": 0,
      "102": 0,
      "103": 0,
      "104": 0,
      "105": 0,
      "106": 0,
      "107": 0,
      "108": 0,
      "109": 0,
      "110": 0,
      "111": 0,
      "112": 0,
      "113": 0,
      "114": 0,
      "115": 0,
      "116": 0,
      "117": 0,
      "118": 0,
      "119": 0,
      "120": 0,
      "121": 0,
      "122": 0,
      "123": 0,
      "124": 0,
      "125": 0,
      "126": 0,
      "127": 0,
      "128": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0],
      "4": [0, 0],
      "5": [0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0],
      "10": [0, 0],
      "11": [0, 0],
      "12": [0, 0, 0],
      "13": [0, 0],
      "14": [0, 0],
      "15": [0, 0],
      "16": [0, 0],
      "17": [0, 0],
      "18": [0, 0],
      "19": [0],
      "20": [0, 0],
      "21": [0, 0],
      "22": [0, 0],
      "23": [0, 0],
      "24": [0, 0],
      "25": [0, 0],
      "26": [0, 0],
      "27": [0, 0],
      "28": [0, 0],
      "29": [0, 0],
      "30": [0, 0],
      "31": [0, 0],
      "32": [0, 0],
      "33": [0, 0],
      "34": [0, 0],
      "35": [0],
      "36": [0],
      "37": [0, 0],
      "38": [0, 0],
      "39": [0, 0],
      "40": [0, 0]
    },
    inputSourceMap: {
      mappings: "AAAA,SAAS,oBAAoB,4BAA4B;AAEzD,SAAS,eAAe;AAExB,OAAO,SAAS,WAAW,KAAa,SAAgC;CACtE,IAAI;EACF,OAAO,IAAI,IAAI,KAAK,WAAW,qBAAqB,UAAU,SAAS,CAAC,CAAC,CACtE;CACL,QAAQ;;EAEN,OAAO;CACT;AACF;AAEA,OAAO,MAAM,cAAc;;;CAGzB,IAAI,UAAU;;CAGd,MAAM,eAEJ,QAAS,KAAK,OAAO,IAAI,MAAM,KAAM,EAAC,CAAE,SAAS,EAAE,IAAI,MAAM,CAAC,CAAC;CAEjE,aAAa;EACX,WAAW;EACX,OAAO,IAAI,OAAO,IAAI;CACxB;AACF,EAAC,CAAE;AAEH,OAAO,SAAS,MAAS,IAAY;CACnC,QAAQ,SACN,IAAI,SAAY,YAAY;EAC1B,iBAAiB,QAAQ,IAAI,GAAG,EAAE;CACpC,CAAC;AACL;AAEA,OAAO,SAAS,QAAW,WAAqB;CAC9C,MAAM,MAAW,CAAC;CAElB,KAAK,IAAI,IAAI,GAAG,IAAI,UAAU,QAAQ,IAAI,GAAG,KAAK;EAChD,IAAI,KAAK,UAAU,EAAE;CACvB;CAEA,OAAO;AACT;AAEA,OAAO,SAAS,mBACd,OACA,UACmB;CACnB,OAAO,YAAY,OACf,WACA,QACE,SACE,OAAO,iBACL,qBAAqB,UAAU,iBAAiB,CAClD,CACJ;AACN;AAEA,SAAS,GAAG,MAAmB,eAAuB;CACpD,MAAM,MAAM,qBAAqB,KAAK,eAAe,aAAa,KAAK;CACvE,MAAM,MAAM,IAAI,iBAAiB,IAAI,CAAC,CAAC,iBAAiB,aAAa;CACrE,OAAO,MAAM,WAAW,IAAI,QAAQ,MAAM,EAAE,CAAC,IAAI;AACnD;AAEA,SAAS,aAAa,MAAmB;CACvC,MAAM,aAAa,GAAG,MAAM,mBAAmB;CAC/C,MAAM,cAAc,GAAG,MAAM,oBAAoB;CACjD,OAAO,KAAK,cAAc,aAAa;AACzC;AAEA,SAAS,cAAc,MAAmB;CACxC,MAAM,YAAY,GAAG,MAAM,kBAAkB;CAC7C,MAAM,eAAe,GAAG,MAAM,qBAAqB;CACnD,OAAO,KAAK,eAAe,YAAY;AACzC;AAEA,OAAO,SAAS,aAAa,YAAyB,UAAmB,CAAC,GAAG;CAC3E,MAAM,QAAQ,QAAQ,SAAS,aAAa,UAAU;CACtD,MAAM,SAAS,QAAQ,UAAU,cAAc,UAAU;CAEzD,OAAO;EAAE;EAAO;CAAO;AACzB;AAEA,OAAO,SAAS,gBAAgB;CAC9B,IAAI;CAEJ,IAAI;CACJ,IAAI;EACF,gBAAgB;CAClB,SAAS,GAAG,CAEZ;CAEA,MAAM,MACJ,iBAAiB,cAAc,MAC3B,cAAc,IAAI,mBAClB;CACN,IAAI,KAAK;EACP,QAAQ,SAAS,KAAK,EAAE;EACxB,IAAI,OAAO,MAAM,KAAK,GAAG;GACvB,QAAQ;EACV;CACF;CACA,OAAO,SAAS,OAAO,oBAAoB;AAC7C;;AAGA,MAAM,uBAAuB;AAE7B,OAAO,SAAS,sBAAsB,QAA2B;CAC/D,IACE,OAAO,QAAQ,wBACf,OAAO,SAAS,sBAChB;EACA,IACE,OAAO,QAAQ,wBACf,OAAO,SAAS,sBAChB;GACA,IAAI,OAAO,QAAQ,OAAO,QAAQ;IAChC,OAAO,UAAU,uBAAuB,OAAO;IAC/C,OAAO,QAAQ;GACjB,OAAO;IACL,OAAO,SAAS,uBAAuB,OAAO;IAC9C,OAAO,SAAS;GAClB;EACF,OAAO,IAAI,OAAO,QAAQ,sBAAsB;GAC9C,OAAO,UAAU,uBAAuB,OAAO;GAC/C,OAAO,QAAQ;EACjB,OAAO;GACL,OAAO,SAAS,uBAAuB,OAAO;GAC9C,OAAO,SAAS;EAClB;CACF;AACF;AAEA,OAAO,SAAS,aACd,QACA,UAAmB,CAAC,GACE;CACtB,IAAI,OAAO,QAAQ;EACjB,OAAO,IAAI,SAAS,YAAY;GAC9B,OAAO,OACL,SACA,QAAQ,OAAO,QAAQ,OAAO,aAC9B,QAAQ,WAAW,CACrB;EACF,CAAC;CACH;CAEA,OAAO,IAAI,SAAS,YAAY;EAC9B,MAAM,eAAe,OAAO,KAC1B,OACG,UACC,QAAQ,OAAO,QAAQ,OAAO,WAC9B,QAAQ,WAAW,SACrB,CAAC,CACA,MAAM,GAAG,CAAC,CAAC,EAChB;EACA,MAAM,MAAM,aAAa;EACzB,MAAM,cAAc,IAAI,WAAW,GAAG;EAEtC,KAAK,IAAI,IAAI,GAAG,IAAI,KAAK,KAAK,GAAG;GAC/B,YAAY,KAAK,aAAa,WAAW,CAAC;EAC5C;EAEA,QACE,IAAI,KAAK,CAAC,WAAW,GAAG,EACtB,MAAM,QAAQ,OAAO,QAAQ,OAAO,YACtC,CAAC,CACH;CACF,CAAC;AACH;AAEA,OAAO,SAAS,YACd,KACA,SACA,OAC2B;CAC3B,OAAO,IAAI,SAAS,SAAS,WAAW;EACtC,MAAM,MAAM,SAAS,IAAI,MAAM;EAC/B,MAAM,SAAS,QAAQ,OAAO,CAAC,EAAE,QAAQ,UAAU,QAAQ;EAC3D,IAAI;EACJ,MAAM,cAAc;GAClB,IAAI,SAAS,MAAM,aAAa,KAAK;GACrC,IAAI,SAAS;GACb,IAAI,UAAU;GACd,QAAQ,oBAAoB,SAAS,KAAK;EAC5C;EACA,MAAM,QAAQ,UAAmB;GAC/B,MAAM;GACN,IAAI,MAAM;GACV,OAAO,KAAK;EACd;EACA,MAAM,cACJ,KACE,QAAQ,UAAU,IAAI,aAAa,sBAAsB,YAAY,CACvE;EACF,IAAI,QAAQ,SAAS;GACnB,MAAM;GACN;EACF;EACA,QAAQ,iBAAiB,SAAS,OAAO,EAAE,MAAM,KAAK,CAAC;EACvD,MAAM,UAAU,QAAQ,WAAW;EACnC,IAAI,UAAU,GACZ,QAAQ,iBACA,KAAK,IAAI,aAAa,wBAAwB,cAAc,CAAC,GACnE,OACF;EACF,IAAI,eAAe;GACjB,QAAQ,QAAQ,CAAC,CACd,WACC,OAAO,IAAI,WAAW,aAAa,IAAI,OAAO,IAAI,SACpD,CAAC,CACA,YAAY;IACX,IAAI,CAAC,IAAI,cAAc,MAAM,IAAI,MAAM,4BAA4B;GACrE,CAAC,CAAC,CACD,WAAW;IACV,MAAM;IACN,QAAQ,GAAG;GACb,GAAG,IAAI;EACX;EACA,IAAI,gBAAgB,KAAK,IAAI,MAAM,2BAA2B,CAAC;EAC/D,IAAI,cAAc;;;EAGlB,IAAI,WAAW;EACf,IAAI,MAAM;CACZ,CAAC;AACH;AAEA,OAAO,eAAe,aAAa,KAAkC;CACnE,OAAO,QAAQ,QAAQ,CAAC,CACrB,WAAW,IAAI,cAAc,CAAC,CAAC,kBAAkB,GAAG,CAAC,CAAC,CACtD,MAAM,QAEL,IAAI,QAAQ,6CAA6C,EAAE,CAC7D,CAAC,CACA,KAAK,kBAAkB,CAAC,CACxB,MAAM,SAAS,oCAAoC,MAAM;AAC9D;AAEA,OAAO,eAAe,cACpB,MACA,OACA,QACA,gBAA0B,KAAK,eAC/B,eAAe,IACE;CACjB,MAAM,QAAQ;CACd,MAAM,MAAM,mBAAmB,eAAe,iBAAiB,CAAC,CAAC,OAAO,KAAK;CAC7E,MAAM,gBAAgB,mBAAmB,eAAe,iBAAiB,CAAC,CACxE,OACA,eACF;CAEA,IAAI,aAAa,SAAS,GAAG,OAAO;CACpC,IAAI,aAAa,UAAU,GAAG,QAAQ;CACtC,IAAI,aAAa,WAAW,OAAO,MAAM,GAAG,QAAQ;CAEpD,cAAc,aAAa,SAAS,MAAM;CAC1C,cAAc,aAAa,UAAU,MAAM;CAC3C,cAAc,aAAa,KAAK,GAAG;CACnC,cAAc,aAAa,KAAK,GAAG;CACnC,cAAc,aAAa,6BAA6B,MAAM;CAE9D,IAAI,cAAc;EAChB,MAAM,QAAQ,mBAAmB,eAAe,iBAAiB,CAAC,CAChE,OACA,OACF;;;EAGA,MAAM,cAAc,UAAU,KAAK,EAAE,KAAK,aAAa;EACvD,IAAI,OAAO,KAAK;CAClB;CACA,IAAI,YAAY,aAAa;CAC7B,cAAc,YAAY,IAAI;CAC9B,OAAO,aAAa,GAAG;AACzB;AAEA,OAAO,MAAM,uBAGX,MACA,aAC2B;CAC3B,IAAI,gBAAgB,UAAU,OAAO;CAErC,MAAM,gBAAgB,OAAO,eAAe,IAAI;CAEhD,IAAI,kBAAkB,MAAM,OAAO;CAEnC,OACE,cAAc,YAAY,SAAS,SAAS,QAC5C,oBAAoB,eAAe,QAAQ;AAE/C",
      names: [],
      sources: ["/work/src/util.ts"],
      version: 3,
      sourcesContent: ["import { readDocumentMethod, readDocumentProperty } from './document.js'\nimport type { Options } from './types.js'\nimport { getTask } from './task.js'\n\nexport function resolveUrl(url: string, baseUrl: string | null): string {\n  try {\n    return new URL(url, baseUrl || readDocumentProperty(document, 'baseURI'))\n      .href\n  } catch {\n    // Leave malformed references for the resource loader's recovery policy.\n    return url\n  }\n}\n\nexport const uuid = (() => {\n  // generate uuid for className of pseudo elements.\n  // We should not use GUIDs, otherwise pseudo elements sometimes cannot be captured.\n  let counter = 0\n\n  // ref: http://stackoverflow.com/a/6248722/2519373\n  const random = () =>\n    // eslint-disable-next-line no-bitwise\n    `0000${((Math.random() * 36 ** 4) << 0).toString(36)}`.slice(-4)\n\n  return () => {\n    counter += 1\n    return `u${random()}${counter}`\n  }\n})()\n\nexport function delay<T>(ms: number) {\n  return (args: T) =>\n    new Promise<T>((resolve) => {\n      setTimeout(() => resolve(args), ms)\n    })\n}\n\nexport function toArray<T>(arrayLike: any): T[] {\n  const arr: T[] = []\n\n  for (let i = 0, l = arrayLike.length; i < l; i++) {\n    arr.push(arrayLike[i])\n  }\n\n  return arr\n}\n\nexport function getStyleProperties(\n  style?: CSSStyleDeclaration,\n  selected?: readonly string[],\n): readonly string[] {\n  return selected != null\n    ? selected\n    : toArray(\n        style ||\n          window.getComputedStyle(\n            readDocumentProperty(document, 'documentElement'),\n          ),\n      )\n}\n\nfunction px(node: HTMLElement, styleProperty: string) {\n  const win = readDocumentProperty(node.ownerDocument, 'defaultView') || window\n  const val = win.getComputedStyle(node).getPropertyValue(styleProperty)\n  return val ? parseFloat(val.replace('px', '')) : 0\n}\n\nfunction getNodeWidth(node: HTMLElement) {\n  const leftBorder = px(node, 'border-left-width')\n  const rightBorder = px(node, 'border-right-width')\n  return node.clientWidth + leftBorder + rightBorder\n}\n\nfunction getNodeHeight(node: HTMLElement) {\n  const topBorder = px(node, 'border-top-width')\n  const bottomBorder = px(node, 'border-bottom-width')\n  return node.clientHeight + topBorder + bottomBorder\n}\n\nexport function getImageSize(targetNode: HTMLElement, options: Options = {}) {\n  const width = options.width ?? getNodeWidth(targetNode)\n  const height = options.height ?? getNodeHeight(targetNode)\n\n  return { width, height }\n}\n\nexport function getPixelRatio() {\n  let ratio\n\n  let FINAL_PROCESS\n  try {\n    FINAL_PROCESS = process\n  } catch (e) {\n    // pass\n  }\n\n  const val =\n    FINAL_PROCESS && FINAL_PROCESS.env\n      ? FINAL_PROCESS.env.devicePixelRatio\n      : null\n  if (val) {\n    ratio = parseInt(val, 10)\n    if (Number.isNaN(ratio)) {\n      ratio = 1\n    }\n  }\n  return ratio || window.devicePixelRatio || 1\n}\n\n// @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas#maximum_canvas_size\nconst canvasDimensionLimit = 16384\n\nexport function checkCanvasDimensions(canvas: HTMLCanvasElement) {\n  if (\n    canvas.width > canvasDimensionLimit ||\n    canvas.height > canvasDimensionLimit\n  ) {\n    if (\n      canvas.width > canvasDimensionLimit &&\n      canvas.height > canvasDimensionLimit\n    ) {\n      if (canvas.width > canvas.height) {\n        canvas.height *= canvasDimensionLimit / canvas.width\n        canvas.width = canvasDimensionLimit\n      } else {\n        canvas.width *= canvasDimensionLimit / canvas.height\n        canvas.height = canvasDimensionLimit\n      }\n    } else if (canvas.width > canvasDimensionLimit) {\n      canvas.height *= canvasDimensionLimit / canvas.width\n      canvas.width = canvasDimensionLimit\n    } else {\n      canvas.width *= canvasDimensionLimit / canvas.height\n      canvas.height = canvasDimensionLimit\n    }\n  }\n}\n\nexport function canvasToBlob(\n  canvas: HTMLCanvasElement,\n  options: Options = {},\n): Promise<Blob | null> {\n  if (canvas.toBlob) {\n    return new Promise((resolve) => {\n      canvas.toBlob(\n        resolve,\n        options.type ? options.type : 'image/png',\n        options.quality ?? 1,\n      )\n    })\n  }\n\n  return new Promise((resolve) => {\n    const binaryString = window.atob(\n      canvas\n        .toDataURL(\n          options.type ? options.type : undefined,\n          options.quality ?? undefined,\n        )\n        .split(',')[1],\n    )\n    const len = binaryString.length\n    const binaryArray = new Uint8Array(len)\n\n    for (let i = 0; i < len; i += 1) {\n      binaryArray[i] = binaryString.charCodeAt(i)\n    }\n\n    resolve(\n      new Blob([binaryArray], {\n        type: options.type ? options.type : 'image/png',\n      }),\n    )\n  })\n}\n\nexport function createImage(\n  url: string,\n  options: Options,\n  image?: HTMLImageElement,\n): Promise<HTMLImageElement> {\n  return new Promise((resolve, reject) => {\n    const img = image || new Image()\n    const signal = getTask(options)?.context.signal || options.signal\n    let timer: ReturnType<typeof setTimeout> | undefined\n    const clean = () => {\n      if (timer != null) clearTimeout(timer)\n      img.onload = null\n      img.onerror = null\n      signal?.removeEventListener('abort', abort)\n    }\n    const fail = (error: unknown) => {\n      clean()\n      img.src = ''\n      reject(error)\n    }\n    const abort = () =>\n      fail(\n        signal?.reason || new DOMException('Image load aborted', 'AbortError'),\n      )\n    if (signal?.aborted) {\n      abort()\n      return\n    }\n    signal?.addEventListener('abort', abort, { once: true })\n    const timeout = options.timeout ?? 30000\n    if (timeout > 0)\n      timer = setTimeout(\n        () => fail(new DOMException('Image load timed out', 'TimeoutError')),\n        timeout,\n      )\n    img.onload = () => {\n      Promise.resolve()\n        .then(() =>\n          typeof img.decode === 'function' ? img.decode() : undefined,\n        )\n        .catch(() => {\n          if (!img.naturalWidth) throw new Error('Image could not be decoded')\n        })\n        .then(() => {\n          clean()\n          resolve(img)\n        }, fail)\n    }\n    img.onerror = () => fail(new Error('Image could not be loaded'))\n    img.crossOrigin = 'anonymous'\n    // WebKit can paint a nested image inside the exported SVG before an\n    // async-decoded data URL is ready, leaving canvas and video pixels blank.\n    img.decoding = 'sync'\n    img.src = url\n  })\n}\n\nexport async function svgToDataURL(svg: SVGElement): Promise<string> {\n  return Promise.resolve()\n    .then(() => new XMLSerializer().serializeToString(svg))\n    .then((xml) =>\n      // eslint-disable-next-line no-control-regex\n      xml.replace(/[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F]/g, ''),\n    )\n    .then(encodeURIComponent)\n    .then((html) => `data:image/svg+xml;charset=utf-8,${html}`)\n}\n\nexport async function nodeToDataURL(\n  node: HTMLElement,\n  width: number,\n  height: number,\n  ownerDocument: Document = node.ownerDocument,\n  clonedStyles = '',\n): Promise<string> {\n  const xmlns = 'http://www.w3.org/2000/svg'\n  const svg = readDocumentMethod(ownerDocument, 'createElementNS')(xmlns, 'svg')\n  const foreignObject = readDocumentMethod(ownerDocument, 'createElementNS')(\n    xmlns,\n    'foreignObject',\n  )\n\n  svg.setAttribute('width', `${width}`)\n  svg.setAttribute('height', `${height}`)\n  svg.setAttribute('viewBox', `0 0 ${width} ${height}`)\n\n  foreignObject.setAttribute('width', '100%')\n  foreignObject.setAttribute('height', '100%')\n  foreignObject.setAttribute('x', '0')\n  foreignObject.setAttribute('y', '0')\n  foreignObject.setAttribute('externalResourcesRequired', 'true')\n\n  if (clonedStyles) {\n    const style = readDocumentMethod(ownerDocument, 'createElementNS')(\n      xmlns,\n      'style',\n    )\n    // First-layer important declarations protect private layout state from\n    // author pseudo rules, without inserting children into the captured tree.\n    style.textContent = `@layer ${uuid()} { ${clonedStyles} }`\n    svg.append(style)\n  }\n  svg.appendChild(foreignObject)\n  foreignObject.appendChild(node)\n  return svgToDataURL(svg)\n}\n\nexport const isInstanceOfElement = <\n  T extends typeof Element | typeof HTMLElement | typeof SVGImageElement,\n>(\n  node: Element | HTMLElement | SVGImageElement,\n  instance: T,\n): node is T['prototype'] => {\n  if (node instanceof instance) return true\n\n  const nodePrototype = Object.getPrototypeOf(node)\n\n  if (nodePrototype === null) return false\n\n  return (\n    nodePrototype.constructor.name === instance.name ||\n    isInstanceOfElement(nodePrototype, instance)\n  )\n}\n"]
    },
    _coverageSchema: "de0df54ae17f6b36de740b46d31f7cdddb68e251",
    hash: "bd1ee789683e2207492823917c5059421e07d3eb"
  };
  var coverage = global[gcv] || (global[gcv] = {});
  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }
  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_xsf08iuw7 = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}
cov_xsf08iuw7();
import { readDocumentMethod, readDocumentProperty } from "/src/document.ts";
import { getTask } from "/src/task.ts";
export function resolveUrl(url, baseUrl) {
  cov_xsf08iuw7().f[0]++;
  cov_xsf08iuw7().s[0]++;
  try {
    cov_xsf08iuw7().s[1]++;
    return new URL(url, (cov_xsf08iuw7().b[0][0]++, baseUrl) || (cov_xsf08iuw7().b[0][1]++, readDocumentProperty(document, "baseURI"))).href;
  } catch {
    cov_xsf08iuw7().s[2]++;
    // Leave malformed references for the resource loader's recovery policy.
    return url;
  }
}
export const uuid = (cov_xsf08iuw7().s[3]++, (() => {
  cov_xsf08iuw7().f[1]++;
  // generate uuid for className of pseudo elements.
  // We should not use GUIDs, otherwise pseudo elements sometimes cannot be captured.
  let counter = (cov_xsf08iuw7().s[4]++, 0);
  // ref: http://stackoverflow.com/a/6248722/2519373
  cov_xsf08iuw7().s[5]++;
  const random = () => {
    cov_xsf08iuw7().f[2]++;
    cov_xsf08iuw7().s[6]++;
    return `0000${(Math.random() * 36 ** 4 << 0).toString(36)}`.slice(-4);
  };
  cov_xsf08iuw7().s[7]++;
  return () => {
    cov_xsf08iuw7().f[3]++;
    cov_xsf08iuw7().s[8]++;
    counter += 1;
    cov_xsf08iuw7().s[9]++;
    return `u${random()}${counter}`;
  };
})());
export function delay(ms) {
  cov_xsf08iuw7().f[4]++;
  cov_xsf08iuw7().s[10]++;
  return args => {
    cov_xsf08iuw7().f[5]++;
    cov_xsf08iuw7().s[11]++;
    return new Promise(resolve => {
      cov_xsf08iuw7().f[6]++;
      cov_xsf08iuw7().s[12]++;
      setTimeout(() => {
        cov_xsf08iuw7().f[7]++;
        cov_xsf08iuw7().s[13]++;
        return resolve(args);
      }, ms);
    });
  };
}
export function toArray(arrayLike) {
  cov_xsf08iuw7().f[8]++;
  const arr = (cov_xsf08iuw7().s[14]++, []);
  cov_xsf08iuw7().s[15]++;
  for (let i = (cov_xsf08iuw7().s[16]++, 0), l = (cov_xsf08iuw7().s[17]++, arrayLike.length); i < l; i++) {
    cov_xsf08iuw7().s[18]++;
    arr.push(arrayLike[i]);
  }
  cov_xsf08iuw7().s[19]++;
  return arr;
}
export function getStyleProperties(style, selected) {
  cov_xsf08iuw7().f[9]++;
  cov_xsf08iuw7().s[20]++;
  return selected != null ? (cov_xsf08iuw7().b[1][0]++, selected) : (cov_xsf08iuw7().b[1][1]++, toArray((cov_xsf08iuw7().b[2][0]++, style) || (cov_xsf08iuw7().b[2][1]++, window.getComputedStyle(readDocumentProperty(document, "documentElement")))));
}
function px(node, styleProperty) {
  cov_xsf08iuw7().f[10]++;
  const win = (cov_xsf08iuw7().s[21]++, (cov_xsf08iuw7().b[3][0]++, readDocumentProperty(node.ownerDocument, "defaultView")) || (cov_xsf08iuw7().b[3][1]++, window));
  const val = (cov_xsf08iuw7().s[22]++, win.getComputedStyle(node).getPropertyValue(styleProperty));
  cov_xsf08iuw7().s[23]++;
  return val ? (cov_xsf08iuw7().b[4][0]++, parseFloat(val.replace("px", ""))) : (cov_xsf08iuw7().b[4][1]++, 0);
}
function getNodeWidth(node) {
  cov_xsf08iuw7().f[11]++;
  const leftBorder = (cov_xsf08iuw7().s[24]++, px(node, "border-left-width"));
  const rightBorder = (cov_xsf08iuw7().s[25]++, px(node, "border-right-width"));
  cov_xsf08iuw7().s[26]++;
  return node.clientWidth + leftBorder + rightBorder;
}
function getNodeHeight(node) {
  cov_xsf08iuw7().f[12]++;
  const topBorder = (cov_xsf08iuw7().s[27]++, px(node, "border-top-width"));
  const bottomBorder = (cov_xsf08iuw7().s[28]++, px(node, "border-bottom-width"));
  cov_xsf08iuw7().s[29]++;
  return node.clientHeight + topBorder + bottomBorder;
}
export function getImageSize(targetNode, options = (cov_xsf08iuw7().b[5][0]++, {})) {
  cov_xsf08iuw7().f[13]++;
  const width = (cov_xsf08iuw7().s[30]++, (cov_xsf08iuw7().b[6][0]++, options.width) ?? (cov_xsf08iuw7().b[6][1]++, getNodeWidth(targetNode)));
  const height = (cov_xsf08iuw7().s[31]++, (cov_xsf08iuw7().b[7][0]++, options.height) ?? (cov_xsf08iuw7().b[7][1]++, getNodeHeight(targetNode)));
  cov_xsf08iuw7().s[32]++;
  return {
    width,
    height
  };
}
export function getPixelRatio() {
  cov_xsf08iuw7().f[14]++;
  let ratio;
  let FINAL_PROCESS;
  cov_xsf08iuw7().s[33]++;
  try {
    cov_xsf08iuw7().s[34]++;
    FINAL_PROCESS = process;
  } catch (e) {}
  const val = (cov_xsf08iuw7().s[35]++, (cov_xsf08iuw7().b[9][0]++, FINAL_PROCESS) && (cov_xsf08iuw7().b[9][1]++, FINAL_PROCESS.env) ? (cov_xsf08iuw7().b[8][0]++, FINAL_PROCESS.env.devicePixelRatio) : (cov_xsf08iuw7().b[8][1]++, null));
  cov_xsf08iuw7().s[36]++;
  if (val) {
    cov_xsf08iuw7().b[10][0]++;
    cov_xsf08iuw7().s[37]++;
    ratio = parseInt(val, 10);
    cov_xsf08iuw7().s[38]++;
    if (Number.isNaN(ratio)) {
      cov_xsf08iuw7().b[11][0]++;
      cov_xsf08iuw7().s[39]++;
      ratio = 1;
    } else {
      cov_xsf08iuw7().b[11][1]++;
    }
  } else {
    cov_xsf08iuw7().b[10][1]++;
  }
  cov_xsf08iuw7().s[40]++;
  return (cov_xsf08iuw7().b[12][0]++, ratio) || (cov_xsf08iuw7().b[12][1]++, window.devicePixelRatio) || (cov_xsf08iuw7().b[12][2]++, 1);
}
// @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas#maximum_canvas_size
const canvasDimensionLimit = (cov_xsf08iuw7().s[41]++, 16384);
export function checkCanvasDimensions(canvas) {
  cov_xsf08iuw7().f[15]++;
  cov_xsf08iuw7().s[42]++;
  if ((cov_xsf08iuw7().b[14][0]++, canvas.width > canvasDimensionLimit) || (cov_xsf08iuw7().b[14][1]++, canvas.height > canvasDimensionLimit)) {
    cov_xsf08iuw7().b[13][0]++;
    cov_xsf08iuw7().s[43]++;
    if ((cov_xsf08iuw7().b[16][0]++, canvas.width > canvasDimensionLimit) && (cov_xsf08iuw7().b[16][1]++, canvas.height > canvasDimensionLimit)) {
      cov_xsf08iuw7().b[15][0]++;
      cov_xsf08iuw7().s[44]++;
      if (canvas.width > canvas.height) {
        cov_xsf08iuw7().b[17][0]++;
        cov_xsf08iuw7().s[45]++;
        canvas.height *= canvasDimensionLimit / canvas.width;
        cov_xsf08iuw7().s[46]++;
        canvas.width = canvasDimensionLimit;
      } else {
        cov_xsf08iuw7().b[17][1]++;
        cov_xsf08iuw7().s[47]++;
        canvas.width *= canvasDimensionLimit / canvas.height;
        cov_xsf08iuw7().s[48]++;
        canvas.height = canvasDimensionLimit;
      }
    } else {
      cov_xsf08iuw7().b[15][1]++;
      cov_xsf08iuw7().s[49]++;
      if (canvas.width > canvasDimensionLimit) {
        cov_xsf08iuw7().b[18][0]++;
        cov_xsf08iuw7().s[50]++;
        canvas.height *= canvasDimensionLimit / canvas.width;
        cov_xsf08iuw7().s[51]++;
        canvas.width = canvasDimensionLimit;
      } else {
        cov_xsf08iuw7().b[18][1]++;
        cov_xsf08iuw7().s[52]++;
        canvas.width *= canvasDimensionLimit / canvas.height;
        cov_xsf08iuw7().s[53]++;
        canvas.height = canvasDimensionLimit;
      }
    }
  } else {
    cov_xsf08iuw7().b[13][1]++;
  }
}
export function canvasToBlob(canvas, options = (cov_xsf08iuw7().b[19][0]++, {})) {
  cov_xsf08iuw7().f[16]++;
  cov_xsf08iuw7().s[54]++;
  if (canvas.toBlob) {
    cov_xsf08iuw7().b[20][0]++;
    cov_xsf08iuw7().s[55]++;
    return new Promise(resolve => {
      cov_xsf08iuw7().f[17]++;
      cov_xsf08iuw7().s[56]++;
      canvas.toBlob(resolve, options.type ? (cov_xsf08iuw7().b[21][0]++, options.type) : (cov_xsf08iuw7().b[21][1]++, "image/png"), (cov_xsf08iuw7().b[22][0]++, options.quality) ?? (cov_xsf08iuw7().b[22][1]++, 1));
    });
  } else {
    cov_xsf08iuw7().b[20][1]++;
  }
  cov_xsf08iuw7().s[57]++;
  return new Promise(resolve => {
    cov_xsf08iuw7().f[18]++;
    const binaryString = (cov_xsf08iuw7().s[58]++, window.atob(canvas.toDataURL(options.type ? (cov_xsf08iuw7().b[23][0]++, options.type) : (cov_xsf08iuw7().b[23][1]++, undefined), (cov_xsf08iuw7().b[24][0]++, options.quality) ?? (cov_xsf08iuw7().b[24][1]++, undefined)).split(",")[1]));
    const len = (cov_xsf08iuw7().s[59]++, binaryString.length);
    const binaryArray = (cov_xsf08iuw7().s[60]++, new Uint8Array(len));
    cov_xsf08iuw7().s[61]++;
    for (let i = (cov_xsf08iuw7().s[62]++, 0); i < len; i += 1) {
      cov_xsf08iuw7().s[63]++;
      binaryArray[i] = binaryString.charCodeAt(i);
    }
    cov_xsf08iuw7().s[64]++;
    resolve(new Blob([binaryArray], {
      type: options.type ? (cov_xsf08iuw7().b[25][0]++, options.type) : (cov_xsf08iuw7().b[25][1]++, "image/png")
    }));
  });
}
export function createImage(url, options, image) {
  cov_xsf08iuw7().f[19]++;
  cov_xsf08iuw7().s[65]++;
  return new Promise((resolve, reject) => {
    cov_xsf08iuw7().f[20]++;
    const img = (cov_xsf08iuw7().s[66]++, (cov_xsf08iuw7().b[26][0]++, image) || (cov_xsf08iuw7().b[26][1]++, new Image()));
    const signal = (cov_xsf08iuw7().s[67]++, (cov_xsf08iuw7().b[27][0]++, getTask(options)?.context.signal) || (cov_xsf08iuw7().b[27][1]++, options.signal));
    let timer;
    cov_xsf08iuw7().s[68]++;
    const clean = () => {
      cov_xsf08iuw7().f[21]++;
      cov_xsf08iuw7().s[69]++;
      if (timer != null) {
        cov_xsf08iuw7().b[28][0]++;
        cov_xsf08iuw7().s[70]++;
        clearTimeout(timer);
      } else {
        cov_xsf08iuw7().b[28][1]++;
      }
      cov_xsf08iuw7().s[71]++;
      img.onload = null;
      cov_xsf08iuw7().s[72]++;
      img.onerror = null;
      cov_xsf08iuw7().s[73]++;
      signal?.removeEventListener("abort", abort);
    };
    cov_xsf08iuw7().s[74]++;
    const fail = error => {
      cov_xsf08iuw7().f[22]++;
      cov_xsf08iuw7().s[75]++;
      clean();
      cov_xsf08iuw7().s[76]++;
      img.src = "";
      cov_xsf08iuw7().s[77]++;
      reject(error);
    };
    cov_xsf08iuw7().s[78]++;
    const abort = () => {
      cov_xsf08iuw7().f[23]++;
      cov_xsf08iuw7().s[79]++;
      return fail((cov_xsf08iuw7().b[29][0]++, signal?.reason) || (cov_xsf08iuw7().b[29][1]++, new DOMException("Image load aborted", "AbortError")));
    };
    cov_xsf08iuw7().s[80]++;
    if (signal?.aborted) {
      cov_xsf08iuw7().b[30][0]++;
      cov_xsf08iuw7().s[81]++;
      abort();
      cov_xsf08iuw7().s[82]++;
      return;
    } else {
      cov_xsf08iuw7().b[30][1]++;
    }
    cov_xsf08iuw7().s[83]++;
    signal?.addEventListener("abort", abort, {
      once: true
    });
    const timeout = (cov_xsf08iuw7().s[84]++, (cov_xsf08iuw7().b[31][0]++, options.timeout) ?? (cov_xsf08iuw7().b[31][1]++, 3e4));
    cov_xsf08iuw7().s[85]++;
    if (timeout > 0) {
      cov_xsf08iuw7().b[32][0]++;
      cov_xsf08iuw7().s[86]++;
      timer = setTimeout(() => {
        cov_xsf08iuw7().f[24]++;
        cov_xsf08iuw7().s[87]++;
        return fail(new DOMException("Image load timed out", "TimeoutError"));
      }, timeout);
    } else {
      cov_xsf08iuw7().b[32][1]++;
    }
    cov_xsf08iuw7().s[88]++;
    img.onload = () => {
      cov_xsf08iuw7().f[25]++;
      cov_xsf08iuw7().s[89]++;
      Promise.resolve().then(() => {
        cov_xsf08iuw7().f[26]++;
        cov_xsf08iuw7().s[90]++;
        return typeof img.decode === "function" ? (cov_xsf08iuw7().b[33][0]++, img.decode()) : (cov_xsf08iuw7().b[33][1]++, undefined);
      }).catch(() => {
        cov_xsf08iuw7().f[27]++;
        cov_xsf08iuw7().s[91]++;
        if (!img.naturalWidth) {
          cov_xsf08iuw7().b[34][0]++;
          cov_xsf08iuw7().s[92]++;
          throw new Error("Image could not be decoded");
        } else {
          cov_xsf08iuw7().b[34][1]++;
        }
      }).then(() => {
        cov_xsf08iuw7().f[28]++;
        cov_xsf08iuw7().s[93]++;
        clean();
        cov_xsf08iuw7().s[94]++;
        resolve(img);
      }, fail);
    };
    cov_xsf08iuw7().s[95]++;
    img.onerror = () => {
      cov_xsf08iuw7().f[29]++;
      cov_xsf08iuw7().s[96]++;
      return fail(new Error("Image could not be loaded"));
    };
    cov_xsf08iuw7().s[97]++;
    img.crossOrigin = "anonymous";
    // WebKit can paint a nested image inside the exported SVG before an
    // async-decoded data URL is ready, leaving canvas and video pixels blank.
    cov_xsf08iuw7().s[98]++;
    img.decoding = "sync";
    cov_xsf08iuw7().s[99]++;
    img.src = url;
  });
}
export async function svgToDataURL(svg) {
  cov_xsf08iuw7().f[30]++;
  cov_xsf08iuw7().s[100]++;
  return Promise.resolve().then(() => {
    cov_xsf08iuw7().f[31]++;
    cov_xsf08iuw7().s[101]++;
    return new XMLSerializer().serializeToString(svg);
  }).then(xml => {
    cov_xsf08iuw7().f[32]++;
    cov_xsf08iuw7().s[102]++;
    return xml.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
  }).then(encodeURIComponent).then(html => {
    cov_xsf08iuw7().f[33]++;
    cov_xsf08iuw7().s[103]++;
    return `data:image/svg+xml;charset=utf-8,${html}`;
  });
}
export async function nodeToDataURL(node, width, height, ownerDocument = (cov_xsf08iuw7().b[35][0]++, node.ownerDocument), clonedStyles = (cov_xsf08iuw7().b[36][0]++, "")) {
  cov_xsf08iuw7().f[34]++;
  const xmlns = (cov_xsf08iuw7().s[104]++, "http://www.w3.org/2000/svg");
  const svg = (cov_xsf08iuw7().s[105]++, readDocumentMethod(ownerDocument, "createElementNS")(xmlns, "svg"));
  const foreignObject = (cov_xsf08iuw7().s[106]++, readDocumentMethod(ownerDocument, "createElementNS")(xmlns, "foreignObject"));
  cov_xsf08iuw7().s[107]++;
  svg.setAttribute("width", `${width}`);
  cov_xsf08iuw7().s[108]++;
  svg.setAttribute("height", `${height}`);
  cov_xsf08iuw7().s[109]++;
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  cov_xsf08iuw7().s[110]++;
  foreignObject.setAttribute("width", "100%");
  cov_xsf08iuw7().s[111]++;
  foreignObject.setAttribute("height", "100%");
  cov_xsf08iuw7().s[112]++;
  foreignObject.setAttribute("x", "0");
  cov_xsf08iuw7().s[113]++;
  foreignObject.setAttribute("y", "0");
  cov_xsf08iuw7().s[114]++;
  foreignObject.setAttribute("externalResourcesRequired", "true");
  cov_xsf08iuw7().s[115]++;
  if (clonedStyles) {
    cov_xsf08iuw7().b[37][0]++;
    const style = (cov_xsf08iuw7().s[116]++, readDocumentMethod(ownerDocument, "createElementNS")(xmlns, "style"));
    // First-layer important declarations protect private layout state from
    // author pseudo rules, without inserting children into the captured tree.
    cov_xsf08iuw7().s[117]++;
    style.textContent = `@layer ${uuid()} { ${clonedStyles} }`;
    cov_xsf08iuw7().s[118]++;
    svg.append(style);
  } else {
    cov_xsf08iuw7().b[37][1]++;
  }
  cov_xsf08iuw7().s[119]++;
  svg.appendChild(foreignObject);
  cov_xsf08iuw7().s[120]++;
  foreignObject.appendChild(node);
  cov_xsf08iuw7().s[121]++;
  return svgToDataURL(svg);
}
cov_xsf08iuw7().s[122]++;
export const isInstanceOfElement = (node, instance) => {
  cov_xsf08iuw7().f[35]++;
  cov_xsf08iuw7().s[123]++;
  if (node instanceof instance) {
    cov_xsf08iuw7().b[38][0]++;
    cov_xsf08iuw7().s[124]++;
    return true;
  } else {
    cov_xsf08iuw7().b[38][1]++;
  }
  const nodePrototype = (cov_xsf08iuw7().s[125]++, Object.getPrototypeOf(node));
  cov_xsf08iuw7().s[126]++;
  if (nodePrototype === null) {
    cov_xsf08iuw7().b[39][0]++;
    cov_xsf08iuw7().s[127]++;
    return false;
  } else {
    cov_xsf08iuw7().b[39][1]++;
  }
  cov_xsf08iuw7().s[128]++;
  return (cov_xsf08iuw7().b[40][0]++, nodePrototype.constructor.name === instance.name) || (cov_xsf08iuw7().b[40][1]++, isInstanceOfElement(nodePrototype, instance));
};