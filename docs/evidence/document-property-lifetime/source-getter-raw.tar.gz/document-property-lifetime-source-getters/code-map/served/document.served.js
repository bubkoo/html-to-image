function cov_rxc46voo7() {
  var path = "/work/src/document.ts";
  var hash = "c52772bd1faaa7cd90d3f25305e27fc3586a969c";
  var global = globalThis;
  var gcv = "__VITEST_COVERAGE__";
  var coverageData = {
    path: "/work/src/document.ts",
    statementMap: {
      "0": {
        start: {
          line: 4,
          column: 1
        },
        end: {
          line: 4,
          column: 33
        }
      },
      "1": {
        start: {
          line: 9,
          column: 16
        },
        end: {
          line: 9,
          column: 40
        }
      },
      "2": {
        start: {
          line: 10,
          column: 1
        },
        end: {
          line: 10,
          column: 59
        }
      },
      "3": {
        start: {
          line: 10,
          column: 22
        },
        end: {
          line: 10,
          column: 57
        }
      },
      "4": {
        start: {
          line: 13,
          column: 1
        },
        end: {
          line: 13,
          column: 71
        }
      }
    },
    fnMap: {
      "0": {
        name: "readDocumentProperty",
        decl: {
          start: {
            line: 3,
            column: 16
          },
          end: {
            line: 3,
            column: 36
          }
        },
        loc: {
          start: {
            line: 3,
            column: 50
          },
          end: {
            line: 5,
            column: 1
          }
        },
        line: 3
      },
      "1": {
        name: "readDocumentMethod",
        decl: {
          start: {
            line: 8,
            column: 16
          },
          end: {
            line: 8,
            column: 34
          }
        },
        loc: {
          start: {
            line: 8,
            column: 48
          },
          end: {
            line: 11,
            column: 1
          }
        },
        line: 8
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 10,
            column: 9
          },
          end: {
            line: 10,
            column: 10
          }
        },
        loc: {
          start: {
            line: 10,
            column: 22
          },
          end: {
            line: 10,
            column: 57
          }
        },
        line: 10
      },
      "3": {
        name: "readOptionalDocumentProperty",
        decl: {
          start: {
            line: 12,
            column: 16
          },
          end: {
            line: 12,
            column: 44
          }
        },
        loc: {
          start: {
            line: 12,
            column: 58
          },
          end: {
            line: 14,
            column: 1
          }
        },
        line: 12
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 13,
            column: 8
          },
          end: {
            line: 13,
            column: 70
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 13,
            column: 25
          },
          end: {
            line: 13,
            column: 34
          }
        }, {
          start: {
            line: 13,
            column: 37
          },
          end: {
            line: 13,
            column: 70
          }
        }],
        line: 13
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0
    },
    b: {
      "0": [0, 0]
    },
    inputSourceMap: {
      mappings: ";;AAEA,OAAO,SAAS,qBACd,QACA,KACM;CACN,OAAO,QAAQ,IAAI,QAAQ,GAAG;AAChC;;;AAQA,OAAO,SAAS,mBACd,QACA,KACM;CACN,MAAM,SAAS,QAAQ,IAAI,QAAQ,GAAG;CACtC,SAAS,GAAG,SACV,QAAQ,MAAM,QAAQ,QAAQ,IAAI;AACtC;AAEA,OAAO,SAAS,6BAGd,QAA8B,KAA0B;CACxD,OAAO,UAAU,OAAO,YAAY,qBAAqB,QAAQ,GAAG;AACtE",
      names: [],
      sources: ["/work/src/document.ts"],
      version: 3,
      sourcesContent: ["// Keep a Document-specific property access out of long-lived caller scripts.\n// Reflect.get uses the same receiver and own/inherited getters as target[key].\nexport function readDocumentProperty<T extends object, K extends keyof T>(\n  target: T,\n  key: K,\n): T[K] {\n  return Reflect.get(target, key) as T[K]\n}\n\ntype MethodKey<T extends object> = {\n  [K in keyof T]-?: T[K] extends (...args: never[]) => unknown ? K : never\n}[keyof T]\n\n// Resolve the getter before the caller evaluates its arguments, then use the\n// original receiver. Forwarding the method type preserves DOM overloads.\nexport function readDocumentMethod<T extends object, K extends MethodKey<T>>(\n  target: T,\n  key: K,\n): T[K] {\n  const method = Reflect.get(target, key) as (...args: unknown[]) => unknown\n  return ((...args: unknown[]) =>\n    Reflect.apply(method, target, args)) as unknown as T[K]\n}\n\nexport function readOptionalDocumentProperty<\n  T extends object,\n  K extends keyof T,\n>(target: T | null | undefined, key: K): T[K] | undefined {\n  return target == null ? undefined : readDocumentProperty(target, key)\n}\n"]
    },
    _coverageSchema: "de0df54ae17f6b36de740b46d31f7cdddb68e251",
    hash: "c52772bd1faaa7cd90d3f25305e27fc3586a969c"
  };
  var coverage = global[gcv] || (global[gcv] = {});
  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }
  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_rxc46voo7 = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}
cov_rxc46voo7();
// Keep a Document-specific property access out of long-lived caller scripts.
// Reflect.get uses the same receiver and own/inherited getters as target[key].
export function readDocumentProperty(target, key) {
  cov_rxc46voo7().f[0]++;
  cov_rxc46voo7().s[0]++;
  return Reflect.get(target, key);
}
// Resolve the getter before the caller evaluates its arguments, then use the
// original receiver. Forwarding the method type preserves DOM overloads.
export function readDocumentMethod(target, key) {
  cov_rxc46voo7().f[1]++;
  const method = (cov_rxc46voo7().s[1]++, Reflect.get(target, key));
  cov_rxc46voo7().s[2]++;
  return (...args) => {
    cov_rxc46voo7().f[2]++;
    cov_rxc46voo7().s[3]++;
    return Reflect.apply(method, target, args);
  };
}
export function readOptionalDocumentProperty(target, key) {
  cov_rxc46voo7().f[3]++;
  cov_rxc46voo7().s[4]++;
  return target == null ? (cov_rxc46voo7().b[0][0]++, undefined) : (cov_rxc46voo7().b[0][1]++, readDocumentProperty(target, key));
}