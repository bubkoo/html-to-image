function cov_1z9mh2782k() {
  var path = "/work/src/clone-scroll.ts";
  var hash = "09b6176d4e743119f751aee947998492b8f1a22a";
  var global = globalThis;
  var gcv = "__VITEST_COVERAGE__";
  var coverageData = {
    path: "/work/src/clone-scroll.ts",
    statementMap: {
      "0": {
        start: {
          line: 5,
          column: 1
        },
        end: {
          line: 5,
          column: 39
        }
      },
      "1": {
        start: {
          line: 5,
          column: 32
        },
        end: {
          line: 5,
          column: 39
        }
      },
      "2": {
        start: {
          line: 6,
          column: 18
        },
        end: {
          line: 6,
          column: 49
        }
      },
      "3": {
        start: {
          line: 7,
          column: 23
        },
        end: {
          line: 7,
          column: 136
        }
      },
      "4": {
        start: {
          line: 7,
          column: 73
        },
        end: {
          line: 7,
          column: 135
        }
      },
      "5": {
        start: {
          line: 8,
          column: 19
        },
        end: {
          line: 8,
          column: 85
        }
      },
      "6": {
        start: {
          line: 8,
          column: 44
        },
        end: {
          line: 8,
          column: 84
        }
      },
      "7": {
        start: {
          line: 9,
          column: 14
        },
        end: {
          line: 9,
          column: 30
        }
      },
      "8": {
        start: {
          line: 10,
          column: 21
        },
        end: {
          line: 10,
          column: 65
        }
      },
      "9": {
        start: {
          line: 11,
          column: 20
        },
        end: {
          line: 11,
          column: 104
        }
      },
      "10": {
        start: {
          line: 11,
          column: 50
        },
        end: {
          line: 11,
          column: 103
        }
      },
      "11": {
        start: {
          line: 12,
          column: 15
        },
        end: {
          line: 12,
          column: 77
        }
      },
      "12": {
        start: {
          line: 12,
          column: 44
        },
        end: {
          line: 12,
          column: 76
        }
      },
      "13": {
        start: {
          line: 13,
          column: 18
        },
        end: {
          line: 13,
          column: 64
        }
      },
      "14": {
        start: {
          line: 14,
          column: 19
        },
        end: {
          line: 14,
          column: 82
        }
      },
      "15": {
        start: {
          line: 14,
          column: 47
        },
        end: {
          line: 14,
          column: 81
        }
      },
      "16": {
        start: {
          line: 15,
          column: 22
        },
        end: {
          line: 28,
          column: 2
        }
      },
      "17": {
        start: {
          line: 16,
          column: 20
        },
        end: {
          line: 16,
          column: 27
        }
      },
      "18": {
        start: {
          line: 17,
          column: 18
        },
        end: {
          line: 22,
          column: 3
        }
      },
      "19": {
        start: {
          line: 23,
          column: 2
        },
        end: {
          line: 27,
          column: 5
        }
      },
      "20": {
        start: {
          line: 24,
          column: 3
        },
        end: {
          line: 24,
          column: 22
        }
      },
      "21": {
        start: {
          line: 24,
          column: 15
        },
        end: {
          line: 24,
          column: 22
        }
      },
      "22": {
        start: {
          line: 25,
          column: 17
        },
        end: {
          line: 25,
          column: 58
        }
      },
      "23": {
        start: {
          line: 26,
          column: 3
        },
        end: {
          line: 26,
          column: 108
        }
      },
      "24": {
        start: {
          line: 29,
          column: 25
        },
        end: {
          line: 49,
          column: 2
        }
      },
      "25": {
        start: {
          line: 30,
          column: 17
        },
        end: {
          line: 30,
          column: 46
        }
      },
      "26": {
        start: {
          line: 31,
          column: 2
        },
        end: {
          line: 31,
          column: 48
        }
      },
      "27": {
        start: {
          line: 31,
          column: 41
        },
        end: {
          line: 31,
          column: 48
        }
      },
      "28": {
        start: {
          line: 35,
          column: 20
        },
        end: {
          line: 35,
          column: 27
        }
      },
      "29": {
        start: {
          line: 36,
          column: 16
        },
        end: {
          line: 46,
          column: 3
        }
      },
      "30": {
        start: {
          line: 37,
          column: 3
        },
        end: {
          line: 37,
          column: 23
        }
      },
      "31": {
        start: {
          line: 37,
          column: 16
        },
        end: {
          line: 37,
          column: 23
        }
      },
      "32": {
        start: {
          line: 38,
          column: 17
        },
        end: {
          line: 38,
          column: 46
        }
      },
      "33": {
        start: {
          line: 39,
          column: 20
        },
        end: {
          line: 39,
          column: 47
        }
      },
      "34": {
        start: {
          line: 40,
          column: 3
        },
        end: {
          line: 45,
          column: 4
        }
      },
      "35": {
        start: {
          line: 41,
          column: 4
        },
        end: {
          line: 41,
          column: 74
        }
      },
      "36": {
        start: {
          line: 42,
          column: 4
        },
        end: {
          line: 42,
          column: 48
        }
      },
      "37": {
        start: {
          line: 43,
          column: 10
        },
        end: {
          line: 45,
          column: 4
        }
      },
      "38": {
        start: {
          line: 44,
          column: 4
        },
        end: {
          line: 44,
          column: 75
        }
      },
      "39": {
        start: {
          line: 47,
          column: 2
        },
        end: {
          line: 47,
          column: 37
        }
      },
      "40": {
        start: {
          line: 48,
          column: 2
        },
        end: {
          line: 48,
          column: 36
        }
      },
      "41": {
        start: {
          line: 50,
          column: 1
        },
        end: {
          line: 66,
          column: 2
        }
      },
      "42": {
        start: {
          line: 51,
          column: 16
        },
        end: {
          line: 51,
          column: 27
        }
      },
      "43": {
        start: {
          line: 52,
          column: 2
        },
        end: {
          line: 52,
          column: 197
        }
      },
      "44": {
        start: {
          line: 58,
          column: 2
        },
        end: {
          line: 62,
          column: 5
        }
      },
      "45": {
        start: {
          line: 59,
          column: 21
        },
        end: {
          line: 59,
          column: 26
        }
      },
      "46": {
        start: {
          line: 60,
          column: 3
        },
        end: {
          line: 60,
          column: 62
        }
      },
      "47": {
        start: {
          line: 60,
          column: 55
        },
        end: {
          line: 60,
          column: 62
        }
      },
      "48": {
        start: {
          line: 61,
          column: 3
        },
        end: {
          line: 61,
          column: 46
        }
      },
      "49": {
        start: {
          line: 63,
          column: 2
        },
        end: {
          line: 63,
          column: 38
        }
      },
      "50": {
        start: {
          line: 64,
          column: 2
        },
        end: {
          line: 64,
          column: 39
        }
      },
      "51": {
        start: {
          line: 65,
          column: 2
        },
        end: {
          line: 65,
          column: 9
        }
      },
      "52": {
        start: {
          line: 67,
          column: 24
        },
        end: {
          line: 80,
          column: 3
        }
      },
      "53": {
        start: {
          line: 68,
          column: 20
        },
        end: {
          line: 68,
          column: 25
        }
      },
      "54": {
        start: {
          line: 71,
          column: 2
        },
        end: {
          line: 71,
          column: 63
        }
      },
      "55": {
        start: {
          line: 71,
          column: 51
        },
        end: {
          line: 71,
          column: 63
        }
      },
      "56": {
        start: {
          line: 72,
          column: 2
        },
        end: {
          line: 79,
          column: 141
        }
      },
      "57": {
        start: {
          line: 81,
          column: 29
        },
        end: {
          line: 88,
          column: 3
        }
      },
      "58": {
        start: {
          line: 82,
          column: 2
        },
        end: {
          line: 82,
          column: 58
        }
      },
      "59": {
        start: {
          line: 82,
          column: 45
        },
        end: {
          line: 82,
          column: 58
        }
      },
      "60": {
        start: {
          line: 83,
          column: 17
        },
        end: {
          line: 83,
          column: 46
        }
      },
      "61": {
        start: {
          line: 84,
          column: 17
        },
        end: {
          line: 84,
          column: 37
        }
      },
      "62": {
        start: {
          line: 87,
          column: 2
        },
        end: {
          line: 87,
          column: 51
        }
      },
      "63": {
        start: {
          line: 89,
          column: 1
        },
        end: {
          line: 125,
          column: 2
        }
      },
      "64": {
        start: {
          line: 90,
          column: 15
        },
        end: {
          line: 90,
          column: 84
        }
      },
      "65": {
        start: {
          line: 91,
          column: 17
        },
        end: {
          line: 91,
          column: 60
        }
      },
      "66": {
        start: {
          line: 92,
          column: 16
        },
        end: {
          line: 92,
          column: 83
        }
      },
      "67": {
        start: {
          line: 93,
          column: 16
        },
        end: {
          line: 93,
          column: 127
        }
      },
      "68": {
        start: {
          line: 93,
          column: 27
        },
        end: {
          line: 93,
          column: 127
        }
      },
      "69": {
        start: {
          line: 94,
          column: 20
        },
        end: {
          line: 99,
          column: 107
        }
      },
      "70": {
        start: {
          line: 94,
          column: 31
        },
        end: {
          line: 99,
          column: 107
        }
      },
      "71": {
        start: {
          line: 100,
          column: 2
        },
        end: {
          line: 124,
          column: 3
        }
      },
      "72": {
        start: {
          line: 101,
          column: 28
        },
        end: {
          line: 101,
          column: 30
        }
      },
      "73": {
        start: {
          line: 102,
          column: 3
        },
        end: {
          line: 107,
          column: 4
        }
      },
      "74": {
        start: {
          line: 103,
          column: 19
        },
        end: {
          line: 103,
          column: 82
        }
      },
      "75": {
        start: {
          line: 106,
          column: 4
        },
        end: {
          line: 106,
          column: 258
        }
      },
      "76": {
        start: {
          line: 108,
          column: 19
        },
        end: {
          line: 108,
          column: 219
        }
      },
      "77": {
        start: {
          line: 108,
          column: 30
        },
        end: {
          line: 108,
          column: 219
        }
      },
      "78": {
        start: {
          line: 109,
          column: 3
        },
        end: {
          line: 109,
          column: 41
        }
      },
      "79": {
        start: {
          line: 110,
          column: 29
        },
        end: {
          line: 110,
          column: 56
        }
      },
      "80": {
        start: {
          line: 111,
          column: 3
        },
        end: {
          line: 116,
          column: 4
        }
      },
      "81": {
        start: {
          line: 112,
          column: 22
        },
        end: {
          line: 112,
          column: 28
        }
      },
      "82": {
        start: {
          line: 113,
          column: 4
        },
        end: {
          line: 113,
          column: 40
        }
      },
      "83": {
        start: {
          line: 114,
          column: 4
        },
        end: {
          line: 114,
          column: 99
        }
      },
      "84": {
        start: {
          line: 114,
          column: 28
        },
        end: {
          line: 114,
          column: 99
        }
      },
      "85": {
        start: {
          line: 115,
          column: 4
        },
        end: {
          line: 115,
          column: 96
        }
      },
      "86": {
        start: {
          line: 115,
          column: 27
        },
        end: {
          line: 115,
          column: 96
        }
      },
      "87": {
        start: {
          line: 117,
          column: 3
        },
        end: {
          line: 120,
          column: 6
        }
      },
      "88": {
        start: {
          line: 117,
          column: 19
        },
        end: {
          line: 120,
          column: 6
        }
      },
      "89": {
        start: {
          line: 118,
          column: 20
        },
        end: {
          line: 118,
          column: 25
        }
      },
      "90": {
        start: {
          line: 119,
          column: 4
        },
        end: {
          line: 119,
          column: 102
        }
      },
      "91": {
        start: {
          line: 119,
          column: 65
        },
        end: {
          line: 119,
          column: 102
        }
      },
      "92": {
        start: {
          line: 121,
          column: 3
        },
        end: {
          line: 121,
          column: 39
        }
      },
      "93": {
        start: {
          line: 122,
          column: 3
        },
        end: {
          line: 122,
          column: 40
        }
      },
      "94": {
        start: {
          line: 123,
          column: 3
        },
        end: {
          line: 123,
          column: 10
        }
      },
      "95": {
        start: {
          line: 129,
          column: 1
        },
        end: {
          line: 144,
          column: 2
        }
      },
      "96": {
        start: {
          line: 129,
          column: 125
        },
        end: {
          line: 129,
          column: 158
        }
      },
      "97": {
        start: {
          line: 130,
          column: 32
        },
        end: {
          line: 130,
          column: 43
        }
      },
      "98": {
        start: {
          line: 131,
          column: 2
        },
        end: {
          line: 131,
          column: 92
        }
      },
      "99": {
        start: {
          line: 133,
          column: 25
        },
        end: {
          line: 136,
          column: 4
        }
      },
      "100": {
        start: {
          line: 134,
          column: 17
        },
        end: {
          line: 134,
          column: 28
        }
      },
      "101": {
        start: {
          line: 135,
          column: 3
        },
        end: {
          line: 135,
          column: 65
        }
      },
      "102": {
        start: {
          line: 137,
          column: 17
        },
        end: {
          line: 137,
          column: 57
        }
      },
      "103": {
        start: {
          line: 138,
          column: 2
        },
        end: {
          line: 143,
          column: 3
        }
      },
      "104": {
        start: {
          line: 139,
          column: 3
        },
        end: {
          line: 139,
          column: 71
        }
      },
      "105": {
        start: {
          line: 140,
          column: 3
        },
        end: {
          line: 140,
          column: 34
        }
      },
      "106": {
        start: {
          line: 141,
          column: 3
        },
        end: {
          line: 141,
          column: 40
        }
      },
      "107": {
        start: {
          line: 142,
          column: 3
        },
        end: {
          line: 142,
          column: 10
        }
      },
      "108": {
        start: {
          line: 145,
          column: 27
        },
        end: {
          line: 148,
          column: 2
        }
      },
      "109": {
        start: {
          line: 146,
          column: 16
        },
        end: {
          line: 146,
          column: 27
        }
      },
      "110": {
        start: {
          line: 147,
          column: 2
        },
        end: {
          line: 147,
          column: 149
        }
      },
      "111": {
        start: {
          line: 149,
          column: 32
        },
        end: {
          line: 152,
          column: 3
        }
      },
      "112": {
        start: {
          line: 150,
          column: 16
        },
        end: {
          line: 150,
          column: 27
        }
      },
      "113": {
        start: {
          line: 151,
          column: 2
        },
        end: {
          line: 151,
          column: 103
        }
      },
      "114": {
        start: {
          line: 153,
          column: 1
        },
        end: {
          line: 153,
          column: 53
        }
      },
      "115": {
        start: {
          line: 153,
          column: 46
        },
        end: {
          line: 153,
          column: 53
        }
      },
      "116": {
        start: {
          line: 154,
          column: 11
        },
        end: {
          line: 154,
          column: 22
        }
      },
      "117": {
        start: {
          line: 155,
          column: 11
        },
        end: {
          line: 155,
          column: 21
        }
      },
      "118": {
        start: {
          line: 156,
          column: 1
        },
        end: {
          line: 176,
          column: 4
        }
      },
      "119": {
        start: {
          line: 157,
          column: 18
        },
        end: {
          line: 157,
          column: 23
        }
      },
      "120": {
        start: {
          line: 158,
          column: 2
        },
        end: {
          line: 165,
          column: 3
        }
      },
      "121": {
        start: {
          line: 159,
          column: 3
        },
        end: {
          line: 159,
          column: 28
        }
      },
      "122": {
        start: {
          line: 161,
          column: 3
        },
        end: {
          line: 163,
          column: 4
        }
      },
      "123": {
        start: {
          line: 162,
          column: 4
        },
        end: {
          line: 162,
          column: 31
        }
      },
      "124": {
        start: {
          line: 164,
          column: 3
        },
        end: {
          line: 164,
          column: 10
        }
      },
      "125": {
        start: {
          line: 166,
          column: 2
        },
        end: {
          line: 173,
          column: 3
        }
      },
      "126": {
        start: {
          line: 169,
          column: 3
        },
        end: {
          line: 171,
          column: 4
        }
      },
      "127": {
        start: {
          line: 170,
          column: 4
        },
        end: {
          line: 170,
          column: 31
        }
      },
      "128": {
        start: {
          line: 172,
          column: 3
        },
        end: {
          line: 172,
          column: 10
        }
      },
      "129": {
        start: {
          line: 174,
          column: 20
        },
        end: {
          line: 174,
          column: 43
        }
      },
      "130": {
        start: {
          line: 175,
          column: 2
        },
        end: {
          line: 175,
          column: 117
        }
      },
      "131": {
        start: {
          line: 179,
          column: 1
        },
        end: {
          line: 179,
          column: 38
        }
      }
    },
    fnMap: {
      "0": {
        name: "cloneScrollState",
        decl: {
          start: {
            line: 4,
            column: 16
          },
          end: {
            line: 4,
            column: 32
          }
        },
        loc: {
          start: {
            line: 4,
            column: 136
          },
          end: {
            line: 180,
            column: 1
          }
        },
        line: 4
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 7,
            column: 62
          },
          end: {
            line: 7,
            column: 63
          }
        },
        loc: {
          start: {
            line: 7,
            column: 73
          },
          end: {
            line: 7,
            column: 135
          }
        },
        line: 7
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 8,
            column: 33
          },
          end: {
            line: 8,
            column: 34
          }
        },
        loc: {
          start: {
            line: 8,
            column: 44
          },
          end: {
            line: 8,
            column: 84
          }
        },
        line: 8
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 11,
            column: 39
          },
          end: {
            line: 11,
            column: 40
          }
        },
        loc: {
          start: {
            line: 11,
            column: 50
          },
          end: {
            line: 11,
            column: 103
          }
        },
        line: 11
      },
      "4": {
        name: "(anonymous_4)",
        decl: {
          start: {
            line: 12,
            column: 33
          },
          end: {
            line: 12,
            column: 34
          }
        },
        loc: {
          start: {
            line: 12,
            column: 44
          },
          end: {
            line: 12,
            column: 76
          }
        },
        line: 12
      },
      "5": {
        name: "(anonymous_5)",
        decl: {
          start: {
            line: 14,
            column: 36
          },
          end: {
            line: 14,
            column: 37
          }
        },
        loc: {
          start: {
            line: 14,
            column: 47
          },
          end: {
            line: 14,
            column: 81
          }
        },
        line: 14
      },
      "6": {
        name: "(anonymous_6)",
        decl: {
          start: {
            line: 15,
            column: 22
          },
          end: {
            line: 15,
            column: 23
          }
        },
        loc: {
          start: {
            line: 15,
            column: 46
          },
          end: {
            line: 28,
            column: 2
          }
        },
        line: 15
      },
      "7": {
        name: "(anonymous_7)",
        decl: {
          start: {
            line: 23,
            column: 18
          },
          end: {
            line: 23,
            column: 19
          }
        },
        loc: {
          start: {
            line: 23,
            column: 41
          },
          end: {
            line: 27,
            column: 3
          }
        },
        line: 23
      },
      "8": {
        name: "(anonymous_8)",
        decl: {
          start: {
            line: 29,
            column: 25
          },
          end: {
            line: 29,
            column: 26
          }
        },
        loc: {
          start: {
            line: 29,
            column: 38
          },
          end: {
            line: 49,
            column: 2
          }
        },
        line: 29
      },
      "9": {
        name: "(anonymous_9)",
        decl: {
          start: {
            line: 36,
            column: 16
          },
          end: {
            line: 36,
            column: 17
          }
        },
        loc: {
          start: {
            line: 36,
            column: 40
          },
          end: {
            line: 46,
            column: 3
          }
        },
        line: 36
      },
      "10": {
        name: "(anonymous_10)",
        decl: {
          start: {
            line: 50,
            column: 195
          },
          end: {
            line: 50,
            column: 196
          }
        },
        loc: {
          start: {
            line: 50,
            column: 206
          },
          end: {
            line: 53,
            column: 2
          }
        },
        line: 50
      },
      "11": {
        name: "(anonymous_11)",
        decl: {
          start: {
            line: 58,
            column: 19
          },
          end: {
            line: 58,
            column: 20
          }
        },
        loc: {
          start: {
            line: 58,
            column: 30
          },
          end: {
            line: 62,
            column: 3
          }
        },
        line: 58
      },
      "12": {
        name: "(anonymous_12)",
        decl: {
          start: {
            line: 67,
            column: 100
          },
          end: {
            line: 67,
            column: 101
          }
        },
        loc: {
          start: {
            line: 67,
            column: 111
          },
          end: {
            line: 80,
            column: 2
          }
        },
        line: 67
      },
      "13": {
        name: "(anonymous_13)",
        decl: {
          start: {
            line: 81,
            column: 45
          },
          end: {
            line: 81,
            column: 46
          }
        },
        loc: {
          start: {
            line: 81,
            column: 58
          },
          end: {
            line: 88,
            column: 2
          }
        },
        line: 81
      },
      "14": {
        name: "(anonymous_14)",
        decl: {
          start: {
            line: 93,
            column: 16
          },
          end: {
            line: 93,
            column: 17
          }
        },
        loc: {
          start: {
            line: 93,
            column: 27
          },
          end: {
            line: 93,
            column: 127
          }
        },
        line: 93
      },
      "15": {
        name: "(anonymous_15)",
        decl: {
          start: {
            line: 94,
            column: 20
          },
          end: {
            line: 94,
            column: 21
          }
        },
        loc: {
          start: {
            line: 94,
            column: 31
          },
          end: {
            line: 99,
            column: 107
          }
        },
        line: 94
      },
      "16": {
        name: "(anonymous_16)",
        decl: {
          start: {
            line: 108,
            column: 19
          },
          end: {
            line: 108,
            column: 20
          }
        },
        loc: {
          start: {
            line: 108,
            column: 30
          },
          end: {
            line: 108,
            column: 219
          }
        },
        line: 108
      },
      "17": {
        name: "(anonymous_17)",
        decl: {
          start: {
            line: 117,
            column: 36
          },
          end: {
            line: 117,
            column: 37
          }
        },
        loc: {
          start: {
            line: 117,
            column: 47
          },
          end: {
            line: 120,
            column: 4
          }
        },
        line: 117
      },
      "18": {
        name: "(anonymous_18)",
        decl: {
          start: {
            line: 129,
            column: 114
          },
          end: {
            line: 129,
            column: 115
          }
        },
        loc: {
          start: {
            line: 129,
            column: 125
          },
          end: {
            line: 129,
            column: 158
          }
        },
        line: 129
      },
      "19": {
        name: "(anonymous_19)",
        decl: {
          start: {
            line: 129,
            column: 178
          },
          end: {
            line: 129,
            column: 179
          }
        },
        loc: {
          start: {
            line: 129,
            column: 189
          },
          end: {
            line: 132,
            column: 2
          }
        },
        line: 129
      },
      "20": {
        name: "(anonymous_20)",
        decl: {
          start: {
            line: 133,
            column: 39
          },
          end: {
            line: 133,
            column: 40
          }
        },
        loc: {
          start: {
            line: 133,
            column: 50
          },
          end: {
            line: 136,
            column: 3
          }
        },
        line: 133
      },
      "21": {
        name: "(anonymous_21)",
        decl: {
          start: {
            line: 145,
            column: 27
          },
          end: {
            line: 145,
            column: 28
          }
        },
        loc: {
          start: {
            line: 145,
            column: 45
          },
          end: {
            line: 148,
            column: 2
          }
        },
        line: 145
      },
      "22": {
        name: "(anonymous_22)",
        decl: {
          start: {
            line: 149,
            column: 46
          },
          end: {
            line: 149,
            column: 47
          }
        },
        loc: {
          start: {
            line: 149,
            column: 64
          },
          end: {
            line: 152,
            column: 2
          }
        },
        line: 149
      },
      "23": {
        name: "(anonymous_23)",
        decl: {
          start: {
            line: 156,
            column: 18
          },
          end: {
            line: 156,
            column: 19
          }
        },
        loc: {
          start: {
            line: 156,
            column: 36
          },
          end: {
            line: 176,
            column: 2
          }
        },
        line: 156
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 4,
            column: 66
          },
          end: {
            line: 4,
            column: 100
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 4,
            column: 79
          },
          end: {
            line: 4,
            column: 100
          }
        }],
        line: 4
      },
      "1": {
        loc: {
          start: {
            line: 4,
            column: 102
          },
          end: {
            line: 4,
            column: 134
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 4,
            column: 114
          },
          end: {
            line: 4,
            column: 134
          }
        }],
        line: 4
      },
      "2": {
        loc: {
          start: {
            line: 5,
            column: 1
          },
          end: {
            line: 5,
            column: 39
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 5,
            column: 1
          },
          end: {
            line: 5,
            column: 39
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 5
      },
      "3": {
        loc: {
          start: {
            line: 5,
            column: 5
          },
          end: {
            line: 5,
            column: 30
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 5,
            column: 5
          },
          end: {
            line: 5,
            column: 16
          }
        }, {
          start: {
            line: 5,
            column: 20
          },
          end: {
            line: 5,
            column: 30
          }
        }],
        line: 5
      },
      "4": {
        loc: {
          start: {
            line: 7,
            column: 73
          },
          end: {
            line: 7,
            column: 135
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 7,
            column: 73
          },
          end: {
            line: 7,
            column: 106
          }
        }, {
          start: {
            line: 7,
            column: 110
          },
          end: {
            line: 7,
            column: 135
          }
        }],
        line: 7
      },
      "5": {
        loc: {
          start: {
            line: 13,
            column: 18
          },
          end: {
            line: 13,
            column: 64
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 13,
            column: 18
          },
          end: {
            line: 13,
            column: 50
          }
        }, {
          start: {
            line: 13,
            column: 54
          },
          end: {
            line: 13,
            column: 64
          }
        }],
        line: 13
      },
      "6": {
        loc: {
          start: {
            line: 24,
            column: 3
          },
          end: {
            line: 24,
            column: 22
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 24,
            column: 3
          },
          end: {
            line: 24,
            column: 22
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 24
      },
      "7": {
        loc: {
          start: {
            line: 25,
            column: 17
          },
          end: {
            line: 25,
            column: 58
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 25,
            column: 17
          },
          end: {
            line: 25,
            column: 49
          }
        }, {
          start: {
            line: 25,
            column: 53
          },
          end: {
            line: 25,
            column: 58
          }
        }],
        line: 25
      },
      "8": {
        loc: {
          start: {
            line: 26,
            column: 48
          },
          end: {
            line: 26,
            column: 69
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 26,
            column: 60
          },
          end: {
            line: 26,
            column: 63
          }
        }, {
          start: {
            line: 26,
            column: 66
          },
          end: {
            line: 26,
            column: 69
          }
        }],
        line: 26
      },
      "9": {
        loc: {
          start: {
            line: 31,
            column: 2
          },
          end: {
            line: 31,
            column: 48
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 31,
            column: 2
          },
          end: {
            line: 31,
            column: 48
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 31
      },
      "10": {
        loc: {
          start: {
            line: 37,
            column: 3
          },
          end: {
            line: 37,
            column: 23
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 37,
            column: 3
          },
          end: {
            line: 37,
            column: 23
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 37
      },
      "11": {
        loc: {
          start: {
            line: 40,
            column: 3
          },
          end: {
            line: 45,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 40,
            column: 3
          },
          end: {
            line: 45,
            column: 4
          }
        }, {
          start: {
            line: 43,
            column: 10
          },
          end: {
            line: 45,
            column: 4
          }
        }],
        line: 40
      },
      "12": {
        loc: {
          start: {
            line: 40,
            column: 7
          },
          end: {
            line: 40,
            column: 32
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 40,
            column: 7
          },
          end: {
            line: 40,
            column: 12
          }
        }, {
          start: {
            line: 40,
            column: 16
          },
          end: {
            line: 40,
            column: 32
          }
        }],
        line: 40
      },
      "13": {
        loc: {
          start: {
            line: 43,
            column: 10
          },
          end: {
            line: 45,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 43,
            column: 10
          },
          end: {
            line: 45,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 43
      },
      "14": {
        loc: {
          start: {
            line: 43,
            column: 14
          },
          end: {
            line: 43,
            column: 45
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 43,
            column: 14
          },
          end: {
            line: 43,
            column: 22
          }
        }, {
          start: {
            line: 43,
            column: 26
          },
          end: {
            line: 43,
            column: 45
          }
        }],
        line: 43
      },
      "15": {
        loc: {
          start: {
            line: 50,
            column: 1
          },
          end: {
            line: 66,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 50,
            column: 1
          },
          end: {
            line: 66,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 50
      },
      "16": {
        loc: {
          start: {
            line: 50,
            column: 5
          },
          end: {
            line: 53,
            column: 3
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 50,
            column: 5
          },
          end: {
            line: 50,
            column: 9
          }
        }, {
          start: {
            line: 50,
            column: 13
          },
          end: {
            line: 50,
            column: 30
          }
        }, {
          start: {
            line: 50,
            column: 34
          },
          end: {
            line: 50,
            column: 48
          }
        }, {
          start: {
            line: 50,
            column: 52
          },
          end: {
            line: 50,
            column: 110
          }
        }, {
          start: {
            line: 50,
            column: 114
          },
          end: {
            line: 50,
            column: 162
          }
        }, {
          start: {
            line: 50,
            column: 166
          },
          end: {
            line: 50,
            column: 176
          }
        }, {
          start: {
            line: 50,
            column: 180
          },
          end: {
            line: 53,
            column: 3
          }
        }],
        line: 50
      },
      "17": {
        loc: {
          start: {
            line: 52,
            column: 9
          },
          end: {
            line: 52,
            column: 196
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 52,
            column: 9
          },
          end: {
            line: 52,
            column: 37
          }
        }, {
          start: {
            line: 52,
            column: 42
          },
          end: {
            line: 52,
            column: 53
          }
        }, {
          start: {
            line: 52,
            column: 57
          },
          end: {
            line: 52,
            column: 84
          }
        }, {
          start: {
            line: 52,
            column: 88
          },
          end: {
            line: 52,
            column: 116
          }
        }, {
          start: {
            line: 52,
            column: 122
          },
          end: {
            line: 52,
            column: 132
          }
        }, {
          start: {
            line: 52,
            column: 136
          },
          end: {
            line: 52,
            column: 162
          }
        }, {
          start: {
            line: 52,
            column: 166
          },
          end: {
            line: 52,
            column: 195
          }
        }],
        line: 52
      },
      "18": {
        loc: {
          start: {
            line: 60,
            column: 3
          },
          end: {
            line: 60,
            column: 62
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 60,
            column: 3
          },
          end: {
            line: 60,
            column: 62
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 60
      },
      "19": {
        loc: {
          start: {
            line: 67,
            column: 24
          },
          end: {
            line: 80,
            column: 3
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 67,
            column: 24
          },
          end: {
            line: 67,
            column: 35
          }
        }, {
          start: {
            line: 67,
            column: 39
          },
          end: {
            line: 67,
            column: 53
          }
        }, {
          start: {
            line: 67,
            column: 57
          },
          end: {
            line: 67,
            column: 67
          }
        }, {
          start: {
            line: 67,
            column: 71
          },
          end: {
            line: 67,
            column: 81
          }
        }, {
          start: {
            line: 67,
            column: 85
          },
          end: {
            line: 80,
            column: 3
          }
        }],
        line: 67
      },
      "20": {
        loc: {
          start: {
            line: 71,
            column: 2
          },
          end: {
            line: 71,
            column: 63
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 71,
            column: 2
          },
          end: {
            line: 71,
            column: 63
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 71
      },
      "21": {
        loc: {
          start: {
            line: 71,
            column: 6
          },
          end: {
            line: 71,
            column: 49
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 71,
            column: 6
          },
          end: {
            line: 71,
            column: 31
          }
        }, {
          start: {
            line: 71,
            column: 35
          },
          end: {
            line: 71,
            column: 49
          }
        }],
        line: 71
      },
      "22": {
        loc: {
          start: {
            line: 72,
            column: 9
          },
          end: {
            line: 79,
            column: 140
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 72,
            column: 9
          },
          end: {
            line: 72,
            column: 55
          }
        }, {
          start: {
            line: 72,
            column: 59
          },
          end: {
            line: 79,
            column: 27
          }
        }, {
          start: {
            line: 79,
            column: 32
          },
          end: {
            line: 79,
            column: 47
          }
        }, {
          start: {
            line: 79,
            column: 51
          },
          end: {
            line: 79,
            column: 76
          }
        }, {
          start: {
            line: 79,
            column: 81
          },
          end: {
            line: 79,
            column: 108
          }
        }, {
          start: {
            line: 79,
            column: 112
          },
          end: {
            line: 79,
            column: 140
          }
        }],
        line: 72
      },
      "23": {
        loc: {
          start: {
            line: 82,
            column: 2
          },
          end: {
            line: 82,
            column: 58
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 82,
            column: 2
          },
          end: {
            line: 82,
            column: 58
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 82
      },
      "24": {
        loc: {
          start: {
            line: 87,
            column: 9
          },
          end: {
            line: 87,
            column: 50
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 87,
            column: 9
          },
          end: {
            line: 87,
            column: 16
          }
        }, {
          start: {
            line: 87,
            column: 20
          },
          end: {
            line: 87,
            column: 50
          }
        }],
        line: 87
      },
      "25": {
        loc: {
          start: {
            line: 89,
            column: 1
          },
          end: {
            line: 125,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 89,
            column: 1
          },
          end: {
            line: 125,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 89
      },
      "26": {
        loc: {
          start: {
            line: 89,
            column: 5
          },
          end: {
            line: 89,
            column: 214
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 89,
            column: 5
          },
          end: {
            line: 89,
            column: 9
          }
        }, {
          start: {
            line: 89,
            column: 14
          },
          end: {
            line: 89,
            column: 27
          }
        }, {
          start: {
            line: 89,
            column: 31
          },
          end: {
            line: 89,
            column: 40
          }
        }, {
          start: {
            line: 89,
            column: 44
          },
          end: {
            line: 89,
            column: 61
          }
        }, {
          start: {
            line: 89,
            column: 66
          },
          end: {
            line: 89,
            column: 80
          }
        }, {
          start: {
            line: 89,
            column: 84
          },
          end: {
            line: 89,
            column: 104
          }
        }, {
          start: {
            line: 89,
            column: 108
          },
          end: {
            line: 89,
            column: 122
          }
        }, {
          start: {
            line: 89,
            column: 126
          },
          end: {
            line: 89,
            column: 162
          }
        }, {
          start: {
            line: 89,
            column: 166
          },
          end: {
            line: 89,
            column: 214
          }
        }],
        line: 89
      },
      "27": {
        loc: {
          start: {
            line: 90,
            column: 15
          },
          end: {
            line: 90,
            column: 84
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 90,
            column: 15
          },
          end: {
            line: 90,
            column: 74
          }
        }, {
          start: {
            line: 90,
            column: 78
          },
          end: {
            line: 90,
            column: 84
          }
        }],
        line: 90
      },
      "28": {
        loc: {
          start: {
            line: 92,
            column: 16
          },
          end: {
            line: 92,
            column: 83
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 92,
            column: 29
          },
          end: {
            line: 92,
            column: 71
          }
        }, {
          start: {
            line: 92,
            column: 74
          },
          end: {
            line: 92,
            column: 83
          }
        }],
        line: 92
      },
      "29": {
        loc: {
          start: {
            line: 93,
            column: 27
          },
          end: {
            line: 93,
            column: 127
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 93,
            column: 27
          },
          end: {
            line: 93,
            column: 41
          }
        }, {
          start: {
            line: 93,
            column: 45
          },
          end: {
            line: 93,
            column: 69
          }
        }, {
          start: {
            line: 93,
            column: 73
          },
          end: {
            line: 93,
            column: 99
          }
        }, {
          start: {
            line: 93,
            column: 103
          },
          end: {
            line: 93,
            column: 127
          }
        }],
        line: 93
      },
      "30": {
        loc: {
          start: {
            line: 94,
            column: 31
          },
          end: {
            line: 99,
            column: 107
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 94,
            column: 31
          },
          end: {
            line: 94,
            column: 43
          }
        }, {
          start: {
            line: 94,
            column: 47
          },
          end: {
            line: 99,
            column: 27
          }
        }, {
          start: {
            line: 99,
            column: 32
          },
          end: {
            line: 99,
            column: 43
          }
        }, {
          start: {
            line: 99,
            column: 47
          },
          end: {
            line: 99,
            column: 74
          }
        }, {
          start: {
            line: 99,
            column: 78
          },
          end: {
            line: 99,
            column: 106
          }
        }],
        line: 94
      },
      "31": {
        loc: {
          start: {
            line: 100,
            column: 2
          },
          end: {
            line: 124,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 100,
            column: 2
          },
          end: {
            line: 124,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 100
      },
      "32": {
        loc: {
          start: {
            line: 100,
            column: 6
          },
          end: {
            line: 100,
            column: 55
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 100,
            column: 6
          },
          end: {
            line: 100,
            column: 23
          }
        }, {
          start: {
            line: 100,
            column: 28
          },
          end: {
            line: 100,
            column: 34
          }
        }, {
          start: {
            line: 100,
            column: 38
          },
          end: {
            line: 100,
            column: 54
          }
        }],
        line: 100
      },
      "33": {
        loc: {
          start: {
            line: 102,
            column: 3
          },
          end: {
            line: 107,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 102,
            column: 3
          },
          end: {
            line: 107,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 102
      },
      "34": {
        loc: {
          start: {
            line: 103,
            column: 19
          },
          end: {
            line: 103,
            column: 82
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 103,
            column: 49
          },
          end: {
            line: 103,
            column: 54
          }
        }, {
          start: {
            line: 103,
            column: 57
          },
          end: {
            line: 103,
            column: 82
          }
        }],
        line: 103
      },
      "35": {
        loc: {
          start: {
            line: 103,
            column: 57
          },
          end: {
            line: 103,
            column: 82
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 103,
            column: 57
          },
          end: {
            line: 103,
            column: 73
          }
        }, {
          start: {
            line: 103,
            column: 77
          },
          end: {
            line: 103,
            column: 82
          }
        }],
        line: 103
      },
      "36": {
        loc: {
          start: {
            line: 106,
            column: 25
          },
          end: {
            line: 106,
            column: 257
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 106,
            column: 41
          },
          end: {
            line: 106,
            column: 198
          }
        }, {
          start: {
            line: 106,
            column: 201
          },
          end: {
            line: 106,
            column: 257
          }
        }],
        line: 106
      },
      "37": {
        loc: {
          start: {
            line: 108,
            column: 30
          },
          end: {
            line: 108,
            column: 219
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 108,
            column: 60
          },
          end: {
            line: 108,
            column: 214
          }
        }, {
          start: {
            line: 108,
            column: 217
          },
          end: {
            line: 108,
            column: 219
          }
        }],
        line: 108
      },
      "38": {
        loc: {
          start: {
            line: 108,
            column: 30
          },
          end: {
            line: 108,
            column: 57
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 108,
            column: 30
          },
          end: {
            line: 108,
            column: 40
          }
        }, {
          start: {
            line: 108,
            column: 44
          },
          end: {
            line: 108,
            column: 57
          }
        }],
        line: 108
      },
      "39": {
        loc: {
          start: {
            line: 108,
            column: 80
          },
          end: {
            line: 108,
            column: 105
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 108,
            column: 80
          },
          end: {
            line: 108,
            column: 96
          }
        }, {
          start: {
            line: 108,
            column: 100
          },
          end: {
            line: 108,
            column: 105
          }
        }],
        line: 108
      },
      "40": {
        loc: {
          start: {
            line: 108,
            column: 156
          },
          end: {
            line: 108,
            column: 182
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 108,
            column: 156
          },
          end: {
            line: 108,
            column: 173
          }
        }, {
          start: {
            line: 108,
            column: 177
          },
          end: {
            line: 108,
            column: 182
          }
        }],
        line: 108
      },
      "41": {
        loc: {
          start: {
            line: 110,
            column: 29
          },
          end: {
            line: 110,
            column: 56
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 110,
            column: 37
          },
          end: {
            line: 110,
            column: 51
          }
        }, {
          start: {
            line: 110,
            column: 54
          },
          end: {
            line: 110,
            column: 56
          }
        }],
        line: 110
      },
      "42": {
        loc: {
          start: {
            line: 111,
            column: 3
          },
          end: {
            line: 116,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 111,
            column: 3
          },
          end: {
            line: 116,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 111
      },
      "43": {
        loc: {
          start: {
            line: 111,
            column: 7
          },
          end: {
            line: 111,
            column: 46
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 111,
            column: 7
          },
          end: {
            line: 111,
            column: 25
          }
        }, {
          start: {
            line: 111,
            column: 29
          },
          end: {
            line: 111,
            column: 46
          }
        }],
        line: 111
      },
      "44": {
        loc: {
          start: {
            line: 114,
            column: 4
          },
          end: {
            line: 114,
            column: 99
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 114,
            column: 4
          },
          end: {
            line: 114,
            column: 99
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 114
      },
      "45": {
        loc: {
          start: {
            line: 115,
            column: 4
          },
          end: {
            line: 115,
            column: 96
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 115,
            column: 4
          },
          end: {
            line: 115,
            column: 96
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 115
      },
      "46": {
        loc: {
          start: {
            line: 117,
            column: 3
          },
          end: {
            line: 120,
            column: 6
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 117,
            column: 3
          },
          end: {
            line: 120,
            column: 6
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 117
      },
      "47": {
        loc: {
          start: {
            line: 119,
            column: 4
          },
          end: {
            line: 119,
            column: 102
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 119,
            column: 4
          },
          end: {
            line: 119,
            column: 102
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 119
      },
      "48": {
        loc: {
          start: {
            line: 129,
            column: 1
          },
          end: {
            line: 144,
            column: 2
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 129,
            column: 1
          },
          end: {
            line: 144,
            column: 2
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 129
      },
      "49": {
        loc: {
          start: {
            line: 129,
            column: 5
          },
          end: {
            line: 132,
            column: 3
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 129,
            column: 5
          },
          end: {
            line: 129,
            column: 21
          }
        }, {
          start: {
            line: 129,
            column: 25
          },
          end: {
            line: 129,
            column: 38
          }
        }, {
          start: {
            line: 129,
            column: 42
          },
          end: {
            line: 129,
            column: 78
          }
        }, {
          start: {
            line: 129,
            column: 82
          },
          end: {
            line: 129,
            column: 96
          }
        }, {
          start: {
            line: 129,
            column: 100
          },
          end: {
            line: 129,
            column: 159
          }
        }, {
          start: {
            line: 129,
            column: 163
          },
          end: {
            line: 132,
            column: 3
          }
        }],
        line: 129
      },
      "50": {
        loc: {
          start: {
            line: 131,
            column: 9
          },
          end: {
            line: 131,
            column: 91
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 131,
            column: 9
          },
          end: {
            line: 131,
            column: 38
          }
        }, {
          start: {
            line: 131,
            column: 42
          },
          end: {
            line: 131,
            column: 64
          }
        }, {
          start: {
            line: 131,
            column: 68
          },
          end: {
            line: 131,
            column: 91
          }
        }],
        line: 131
      },
      "51": {
        loc: {
          start: {
            line: 135,
            column: 10
          },
          end: {
            line: 135,
            column: 64
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 135,
            column: 10
          },
          end: {
            line: 135,
            column: 34
          }
        }, {
          start: {
            line: 135,
            column: 38
          },
          end: {
            line: 135,
            column: 64
          }
        }],
        line: 135
      },
      "52": {
        loc: {
          start: {
            line: 137,
            column: 17
          },
          end: {
            line: 137,
            column: 57
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 137,
            column: 17
          },
          end: {
            line: 137,
            column: 48
          }
        }, {
          start: {
            line: 137,
            column: 52
          },
          end: {
            line: 137,
            column: 57
          }
        }],
        line: 137
      },
      "53": {
        loc: {
          start: {
            line: 138,
            column: 2
          },
          end: {
            line: 143,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 138,
            column: 2
          },
          end: {
            line: 143,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 138
      },
      "54": {
        loc: {
          start: {
            line: 138,
            column: 6
          },
          end: {
            line: 138,
            column: 41
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 138,
            column: 6
          },
          end: {
            line: 138,
            column: 20
          }
        }, {
          start: {
            line: 138,
            column: 24
          },
          end: {
            line: 138,
            column: 41
          }
        }],
        line: 138
      },
      "55": {
        loc: {
          start: {
            line: 147,
            column: 9
          },
          end: {
            line: 147,
            column: 148
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 147,
            column: 9
          },
          end: {
            line: 147,
            column: 20
          }
        }, {
          start: {
            line: 147,
            column: 24
          },
          end: {
            line: 147,
            column: 40
          }
        }, {
          start: {
            line: 147,
            column: 44
          },
          end: {
            line: 147,
            column: 71
          }
        }, {
          start: {
            line: 147,
            column: 75
          },
          end: {
            line: 147,
            column: 102
          }
        }, {
          start: {
            line: 147,
            column: 107
          },
          end: {
            line: 147,
            column: 120
          }
        }, {
          start: {
            line: 147,
            column: 124
          },
          end: {
            line: 147,
            column: 147
          }
        }],
        line: 147
      },
      "56": {
        loc: {
          start: {
            line: 151,
            column: 9
          },
          end: {
            line: 151,
            column: 102
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 151,
            column: 9
          },
          end: {
            line: 151,
            column: 36
          }
        }, {
          start: {
            line: 151,
            column: 40
          },
          end: {
            line: 151,
            column: 72
          }
        }, {
          start: {
            line: 151,
            column: 76
          },
          end: {
            line: 151,
            column: 102
          }
        }],
        line: 151
      },
      "57": {
        loc: {
          start: {
            line: 153,
            column: 1
          },
          end: {
            line: 153,
            column: 53
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 153,
            column: 1
          },
          end: {
            line: 153,
            column: 53
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 153
      },
      "58": {
        loc: {
          start: {
            line: 153,
            column: 5
          },
          end: {
            line: 153,
            column: 44
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 153,
            column: 5
          },
          end: {
            line: 153,
            column: 18
          }
        }, {
          start: {
            line: 153,
            column: 22
          },
          end: {
            line: 153,
            column: 44
          }
        }],
        line: 153
      },
      "59": {
        loc: {
          start: {
            line: 158,
            column: 2
          },
          end: {
            line: 165,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 158,
            column: 2
          },
          end: {
            line: 165,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 158
      },
      "60": {
        loc: {
          start: {
            line: 161,
            column: 3
          },
          end: {
            line: 163,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 161,
            column: 3
          },
          end: {
            line: 163,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 161
      },
      "61": {
        loc: {
          start: {
            line: 161,
            column: 7
          },
          end: {
            line: 161,
            column: 63
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 161,
            column: 7
          },
          end: {
            line: 161,
            column: 28
          }
        }, {
          start: {
            line: 161,
            column: 32
          },
          end: {
            line: 161,
            column: 63
          }
        }],
        line: 161
      },
      "62": {
        loc: {
          start: {
            line: 166,
            column: 2
          },
          end: {
            line: 173,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 166,
            column: 2
          },
          end: {
            line: 173,
            column: 3
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 166
      },
      "63": {
        loc: {
          start: {
            line: 169,
            column: 3
          },
          end: {
            line: 171,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 169,
            column: 3
          },
          end: {
            line: 171,
            column: 4
          }
        }, {
          start: {
            line: undefined,
            column: undefined
          },
          end: {
            line: undefined,
            column: undefined
          }
        }],
        line: 169
      },
      "64": {
        loc: {
          start: {
            line: 169,
            column: 7
          },
          end: {
            line: 169,
            column: 63
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 169,
            column: 7
          },
          end: {
            line: 169,
            column: 28
          }
        }, {
          start: {
            line: 169,
            column: 32
          },
          end: {
            line: 169,
            column: 63
          }
        }],
        line: 169
      },
      "65": {
        loc: {
          start: {
            line: 175,
            column: 57
          },
          end: {
            line: 175,
            column: 107
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 175,
            column: 93
          },
          end: {
            line: 175,
            column: 102
          }
        }, {
          start: {
            line: 175,
            column: 105
          },
          end: {
            line: 175,
            column: 107
          }
        }],
        line: 175
      },
      "66": {
        loc: {
          start: {
            line: 175,
            column: 57
          },
          end: {
            line: 175,
            column: 90
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 175,
            column: 57
          },
          end: {
            line: 175,
            column: 66
          }
        }, {
          start: {
            line: 175,
            column: 70
          },
          end: {
            line: 175,
            column: 90
          }
        }],
        line: 175
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0,
      "81": 0,
      "82": 0,
      "83": 0,
      "84": 0,
      "85": 0,
      "86": 0,
      "87": 0,
      "88": 0,
      "89": 0,
      "90": 0,
      "91": 0,
      "92": 0,
      "93": 0,
      "94": 0,
      "95": 0,
      "96": 0,
      "97": 0,
      "98": 0,
      "99": 0,
      "100": 0,
      "101": 0,
      "102": 0,
      "103": 0,
      "104": 0,
      "105": 0,
      "106": 0,
      "107": 0,
      "108": 0,
      "109": 0,
      "110": 0,
      "111": 0,
      "112": 0,
      "113": 0,
      "114": 0,
      "115": 0,
      "116": 0,
      "117": 0,
      "118": 0,
      "119": 0,
      "120": 0,
      "121": 0,
      "122": 0,
      "123": 0,
      "124": 0,
      "125": 0,
      "126": 0,
      "127": 0,
      "128": 0,
      "129": 0,
      "130": 0,
      "131": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0
    },
    b: {
      "0": [0],
      "1": [0],
      "2": [0, 0],
      "3": [0, 0],
      "4": [0, 0],
      "5": [0, 0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0],
      "10": [0, 0],
      "11": [0, 0],
      "12": [0, 0],
      "13": [0, 0],
      "14": [0, 0],
      "15": [0, 0],
      "16": [0, 0, 0, 0, 0, 0, 0],
      "17": [0, 0, 0, 0, 0, 0, 0],
      "18": [0, 0],
      "19": [0, 0, 0, 0, 0],
      "20": [0, 0],
      "21": [0, 0],
      "22": [0, 0, 0, 0, 0, 0],
      "23": [0, 0],
      "24": [0, 0],
      "25": [0, 0],
      "26": [0, 0, 0, 0, 0, 0, 0, 0, 0],
      "27": [0, 0],
      "28": [0, 0],
      "29": [0, 0, 0, 0],
      "30": [0, 0, 0, 0, 0],
      "31": [0, 0],
      "32": [0, 0, 0],
      "33": [0, 0],
      "34": [0, 0],
      "35": [0, 0],
      "36": [0, 0],
      "37": [0, 0],
      "38": [0, 0],
      "39": [0, 0],
      "40": [0, 0],
      "41": [0, 0],
      "42": [0, 0],
      "43": [0, 0],
      "44": [0, 0],
      "45": [0, 0],
      "46": [0, 0],
      "47": [0, 0],
      "48": [0, 0],
      "49": [0, 0, 0, 0, 0, 0],
      "50": [0, 0, 0],
      "51": [0, 0],
      "52": [0, 0],
      "53": [0, 0],
      "54": [0, 0],
      "55": [0, 0, 0, 0, 0, 0],
      "56": [0, 0, 0],
      "57": [0, 0],
      "58": [0, 0],
      "59": [0, 0],
      "60": [0, 0],
      "61": [0, 0],
      "62": [0, 0],
      "63": [0, 0],
      "64": [0, 0],
      "65": [0, 0],
      "66": [0, 0]
    },
    inputSourceMap: {
      mappings: "AAAA,SAAS,4BAA4B;AAErC,SAAS,eAAe;AACxB,SAAS,YAAY;AAErB,OAAO,SAAS,iBACd,YACA,YACA,SACA,aAAa,WAAW,YACxB,YAAY,WAAW,WACvB;CACA,IAAI,CAAC,cAAc,CAAC,WAAW;CAC/B,MAAM,WAAW,MAAM,KAAK,WAAW,QAAQ;CAC/C,MAAM,gBAAgB,MAAM,KAAK,WAAW,UAAU,CAAC,CAAC,MACrD,UAAU,MAAM,aAAa,KAAK,aAAa,MAAM,aAAa,KAAK,CAC1E;CACA,MAAM,YAAY,SAAS,MAAM,UAC9B,MAAsB,MAAM,QAAQ,WAAW,QAAQ,CAC1D;CACA,MAAM,OAAO,QAAQ,OAAO;CAC5B,MAAM,cAAc,MAAM,KAAK,WAAW,iBAAiB,GAAG,CAAC;CAC/D,MAAM,aAAa,YAAY,QAAQ,UACrC,CAAC,SAAS,UAAU,CAAC,CAAC,SAAU,MAAsB,OAAO,QAAQ,CACvE;CACA,MAAM,QAAQ,WAAW,QACtB,UAAU,MAAM,MAAM,aAAa,OACtC;CACA,MAAM,WAAW,MAAM,eAAe,UAAU,KAAK;CACrD,MAAM,YAAY,YAAY,MAC3B,UAAW,MAAsB,OAAO,aAAa,QACxD;CACA,MAAM,gBAAgB,SAAsB,MAAc,QAAgB;EACxE,MAAM,EAAE,UAAU;EAClB,MAAM,UAAU;GACd,CAAC,eAAe,CAAC,IAAI;GACrB,CAAC,gBAAgB,IAAI;GACrB,CAAC,cAAc,CAAC,GAAG;GACnB,CAAC,iBAAiB,GAAG;EACvB;EACA,QAAQ,SAAS,CAAC,UAAU,WAAW;GACrC,IAAI,CAAC,OAAO;GACZ,MAAM,QAAQ,MAAM,iBAAiB,QAAQ,KAAK;GAClD,MAAM,YACJ,UACA,QAAQ,MAAM,GAAG,QAAQ,IAAI,MAAM,IAAI,GAAG,KAAK,IAAI,KAAK,EAAE,MAC1D,WACF;EACF,CAAC;CACH;CACA,MAAM,mBAAmB,YAAyB;EAChD,MAAM,SAAS,MAAM,eAAe,OAAO;EAC3C,IAAI,QAAQ,iBAAiB,UAAU;;;;EAIvC,MAAM,EAAE,UAAU;EAClB,MAAM,SAAS,OAAe,KAAa,WAAmB;GAC5D,IAAI,CAAC,QAAQ;GACb,MAAM,QAAQ,MAAM,iBAAiB,KAAK;GAC1C,MAAM,WAAW,MAAM,iBAAiB,GAAG;GAC3C,IAAI,SAAS,UAAU,QAAQ;IAC7B,MAAM,YAAY,OAAO,QAAQ,MAAM,KAAK,OAAO,MAAM,WAAW;IACpE,MAAM,YAAY,KAAK,QAAQ,WAAW;GAC5C,OAAO,IAAI,YAAY,aAAa,QAAQ;IAC1C,MAAM,YAAY,KAAK,QAAQ,SAAS,KAAK,OAAO,MAAM,WAAW;GACvE;EACF;EACA,MAAM,QAAQ,SAAS,UAAU;EACjC,MAAM,OAAO,UAAU,SAAS;CAClC;CACA,IACE,QACA,WAAW,UACX,CAAC,iBACD,CAAC,QAAQ,aAAa,CAAC,CAAC,SAAS,WAAW,MAAM,OAAO,KACzD,WAAW,MAAM,gBAAgB,mBACjC,CAAC,aACD,SAAS,OAAO,UAAU;EACxB,MAAM,QAAS,MAAsB;EACrC,OACE,MAAM,YAAY,eACjB,CAAC,cACC,MAAM,eAAe,UAAU,MAAM,gBAAgB,YACvD,CAAC,aACC,MAAM,cAAc,UAAU,MAAM,iBAAiB;CAE5D,CAAC,GACD;;;;;EAKA,SAAS,SAAS,UAAU;GAC1B,MAAM,EAAE,UAAU;GAClB,IAAI,CAAC,SAAS,UAAU,CAAC,CAAC,SAAS,MAAM,QAAQ,GAAG;GACpD,aAAa,OAAsB,YAAY,SAAS;EAC1D,CAAC;EACD,WAAW,QAAQ,eAAe;EAClC,WAAW,MAAM,WAAW;EAC5B;CACF;CACA,MAAM,iBACJ,CAAC,cACA,CAAC,iBACA,CAAC,aACD,CAAC,aACD,SAAS,OAAO,UAAU;EACxB,MAAM,EAAE,UAAU;;;EAGlB,IAAI,MAAM,YAAY,WAAW,CAAC,MAAM,SAAS,OAAO;EACxD,OACE,CAAC,SAAS,UAAU,CAAC,CAAC,SAAS,MAAM,QAAQ,KAC5C;GAAC;GAAS;GAAa;GAAQ;GAAQ;GAAS;EAAM,CAAC,CAAC,SACvD,MAAM,OACR,MACG,CAAC,MAAM,YAAY,MAAM,aAAa,WACvC,MAAM,eAAe,UACrB,MAAM,gBAAgB;CAE5B,CAAC;CACL,MAAM,sBAAsB,WAAW,MAAM,YAAY;EACvD,IAAI,QAAQ,MAAM,aAAa,YAAY,OAAO;EAClD,MAAM,SAAS,MAAM,eAAe,OAAO;EAC3C,MAAM,SAAS,QAAQ;;;EAGvB,OAAO,CAAC,UAAU,CAAC,MAAM,gBAAgB,MAAM;CACjD,CAAC;CACD,IACE,SACC,iBAAiB,aAAa,WAAW,WAC1C,kBACA,CAAC,uBACD,aAAa,KACb,WAAW,MAAM,YAAY,WAC7B,WAAW,MAAM,gBAAgB,iBACjC;EACA,MAAM,OACJ,qBAAqB,SAAS,eAAe,aAAa,KAAK;EACjE,MAAM,SAAS,KAAK,iBAAiB,UAAU,UAAU;EACzD,MAAM,QAAQ,aACV,KAAK,iBAAiB,UAAU,SAAS,IACzC;EACJ,MAAM,SAAS,UACb,CAAC,MAAM,WACP,MAAM,YAAY,UAClB,MAAM,YAAY,YAClB,MAAM,YAAY;EACpB,MAAM,aAAa,UACjB,MAAM,KAAK,KACV;GAAC;GAAS;GAAa;GAAQ;EAAM,CAAC,CAAC,SAAS,MAAM,OAAO,MAC3D,CAAC,cACC,MAAM,eAAe,UAAU,MAAM,gBAAgB;EAC5D,IAAI,UAAU,MAAM,MAAM,CAAC,SAAS,UAAU,KAAK,IAAI;GACrD,IAAI,qBAAqB;GACzB,IAAI,WAAW;IACb,MAAM,SACJ,OAAO,cAAc,SAAS,QAAQ,OAAO,aAAa;;;IAG5D,qBAAqB,MAAM,MAAM,IAC7B,kGAAkG,CAAC,YAAY,EAAE,+CACjH,mBAAmB,OAAO,KAAK,UAAU;GAC/C;GACA,MAAM,WAAW,UACf,cAAc,CAAC,MAAM,KAAK,IACtB,oBAAoB,MAAM,cAAc,MAAM,KAAK,WAAW,kCAAkC,MAAM,eAAe,MAAM,KAAK,WAAW,kBAC3I;GACN,sBAAsB,QAAQ,MAAM;GACpC,MAAM,oBAAoB,QAAQ,QAAQ,KAAK,IAAI;GACnD,IAAI,sBAAsB,mBAAmB;IAC3C,MAAM,YAAY,KAAK;IACvB,WAAW,UAAU,IAAI,SAAS;IAClC,IAAI,oBACF,KAAK,eAAe,IAAI,UAAU,aAAa,mBAAmB,GAAG;IACvE,IAAI,mBACF,KAAK,eAAe,IAAI,UAAU,YAAY,kBAAkB,GAAG;GACvE;GACA,IAAI,YACF,SAAS,SAAS,UAAU;IAC1B,MAAM,UAAU;IAChB,IAAI,CAAC,CAAC,SAAS,UAAU,CAAC,CAAC,SAAS,QAAQ,MAAM,QAAQ,GACxD,aAAa,SAAS,YAAY,CAAC;GACvC,CAAC;GACH,WAAW,QAAQ,eAAe;GAClC,WAAW,MAAM,WAAW;GAC5B;EACF;CACF;;;;CAIA,IACE,eAAe,KACf,YAAY,KACZ,WAAW,MAAM,YAAY,WAC7B,CAAC,iBACD,SAAS,MACN,UAAW,MAAsB,MAAM,aAAa,QACvD,KACA,SAAS,OAAO,UAAU;EACxB,MAAM,EAAE,SAAS,aAAc,MAAsB;EACrD,OACE,CAAC,QAAQ,WAAW,QAAQ,KAC5B,YAAY,cACZ,aAAa;CAEjB,CAAC,GACD;EACA,MAAM,iBAAiB,SAAS,MAAM,UAAU;GAC9C,MAAM,QAAS,MAAsB;GACrC,OAAO,MAAM,YAAY,UAAU,MAAM,aAAa;EACxD,CAAC;EACD,MAAM,SAAS,gBAAgB,MAAM,aAAa;EAClD,IAAI,kBAAkB,WAAW,QAAQ;GACvC,eAAe,MAAM,YAAY,QAAQ,OAAO,KAAK,UAAU;GAC/D,MAAM,QAAQ,eAAe;GAC7B,WAAW,MAAM,WAAW;GAC5B;EACF;CACF;CACA,MAAM,qBAAqB,OAAgB,UAAkB;EAC3D,MAAM,QAAS,MAAsB;EACrC,OACE,UAAU,KACV,eAAe,KACf,MAAM,aAAa,YACnB,WAAW,MAAM,GAAG,MAAM,MACzB,CAAC,MAAM,UAAU,MAAM,WAAW;CAEvC;CACA,MAAM,yBAAyB,SAAS,MAAM,OAAO,UAAU;EAC7D,MAAM,QAAS,MAAsB;EACrC,OACG,MAAM,aAAa,YAAY,CAAC,kBAAkB,OAAO,KAAK,KAC/D,MAAM,YAAY;CAEtB,CAAC;CACD,IAAI,iBAAiB,wBAAwB;CAC7C,MAAM,IAAI,CAAC;CACX,MAAM,IAAI,CAAC;CACX,SAAS,SAAS,OAAO,UAAU;EACjC,MAAM,UAAU;EAChB,IAAI,QAAQ,MAAM,aAAa,SAAS;GACtC,gBAAgB,OAAO;;GAEvB,IAAI,CAAC,QAAQ,MAAM,UAAU,QAAQ,MAAM,WAAW,QAAQ;IAC5D,QAAQ,MAAM,SAAS;GACzB;GACA;EACF;EACA,IAAI,kBAAkB,OAAO,KAAK,GAAG;;;GAGnC,IAAI,CAAC,QAAQ,MAAM,UAAU,QAAQ,MAAM,WAAW,QAAQ;IAC5D,QAAQ,MAAM,SAAS;GACzB;GACA;EACF;EACA,MAAM,YAAY,QAAQ,MAAM;EAChC,QAAQ,MAAM,YAAY,aAAa,EAAE,MAAM,EAAE,MAC/C,aAAa,cAAc,SAAS,YAAY,KAC/C,KAAK;CACV,CAAC;;;CAGD,WAAW,MAAM,WAAW;AAC9B",
      names: [],
      sources: ["/work/src/clone-scroll.ts"],
      version: 3,
      sourcesContent: ["import { readDocumentProperty } from './document.js'\nimport type { Options } from './types.js'\nimport { getTask } from './task.js'\nimport { uuid } from './util.js'\n\nexport function cloneScrollState<T extends HTMLElement>(\n  nativeNode: T,\n  clonedNode: T,\n  options: Options,\n  scrollLeft = nativeNode.scrollLeft,\n  scrollTop = nativeNode.scrollTop,\n) {\n  if (!scrollLeft && !scrollTop) return\n  const children = Array.from(clonedNode.children)\n  const hasDirectText = Array.from(clonedNode.childNodes).some(\n    (child) => child.nodeType === Node.TEXT_NODE && child.textContent?.trim(),\n  )\n  const hasInline = children.some((child) =>\n    (child as HTMLElement).style.display.startsWith('inline'),\n  )\n  const task = getTask(options)\n  const descendants = Array.from(clonedNode.querySelectorAll('*'))\n  const positioned = descendants.filter((child) =>\n    ['fixed', 'absolute'].includes((child as HTMLElement).style?.position),\n  ) as HTMLElement[]\n  const fixed = positioned.filter(\n    (child) => child.style.position === 'fixed',\n  ) as HTMLElement[]\n  const original = task?.getCloneSource(clonedNode) || nativeNode\n  const hasSticky = descendants.some(\n    (child) => (child as HTMLElement).style?.position === 'sticky',\n  )\n  const shiftMargins = (element: HTMLElement, left: number, top: number) => {\n    const { style } = element\n    const margins = [\n      ['margin-left', -left],\n      ['margin-right', left],\n      ['margin-top', -top],\n      ['margin-bottom', top],\n    ] as const\n    margins.forEach(([property, delta]) => {\n      if (!delta) return\n      const value = style.getPropertyValue(property) || '0px'\n      style.setProperty(\n        property,\n        `calc(${value} ${delta < 0 ? '-' : '+'} ${Math.abs(delta)}px)`,\n        'important',\n      )\n    })\n  }\n  const shiftPositioned = (element: HTMLElement) => {\n    const source = task?.getCloneSource(element) as HTMLElement | undefined\n    if (source?.offsetParent !== original) return\n    // Use the source browser's containing block, rather than guessing from a\n    // subset of CSS properties. Insets do not create another containing block\n    // for nested fixed descendants, as an added transform would.\n    const { style } = element\n    const shift = (start: string, end: string, amount: number) => {\n      if (!amount) return\n      const value = style.getPropertyValue(start)\n      const opposite = style.getPropertyValue(end)\n      if (value && value !== 'auto') {\n        style.setProperty(start, `calc(${value} - ${amount}px)`, 'important')\n        style.setProperty(end, 'auto', 'important')\n      } else if (opposite && opposite !== 'auto') {\n        style.setProperty(end, `calc(${opposite} + ${amount}px)`, 'important')\n      }\n    }\n    shift('left', 'right', scrollLeft)\n    shift('top', 'bottom', scrollTop)\n  }\n  if (\n    task &&\n    positioned.length &&\n    !hasDirectText &&\n    ['flex', 'inline-flex'].includes(clonedNode.style.display) &&\n    clonedNode.style.writingMode === 'horizontal-tb' &&\n    !hasSticky &&\n    children.every((child) => {\n      const style = (child as HTMLElement).style\n      return (\n        style.display !== 'contents' &&\n        (!scrollLeft ||\n          (style.marginLeft !== 'auto' && style.marginRight !== 'auto')) &&\n        (!scrollTop ||\n          (style.marginTop !== 'auto' && style.marginBottom !== 'auto'))\n      )\n    })\n  ) {\n    // Opposite margins translate each flex item on both axes without changing\n    // its outer size, flex lines or containing blocks. Unlike block margins,\n    // flex-item margins cannot collapse. Added transforms would re-anchor\n    // positioned descendants of ordinary wrappers.\n    children.forEach((child) => {\n      const { style } = child as HTMLElement\n      if (['fixed', 'absolute'].includes(style.position)) return\n      shiftMargins(child as HTMLElement, scrollLeft, scrollTop)\n    })\n    positioned.forEach(shiftPositioned)\n    clonedNode.style.overflow = 'hidden'\n    return\n  }\n  const canShiftBlockX =\n    !scrollLeft ||\n    (!hasDirectText &&\n      !hasInline &&\n      !hasSticky &&\n      children.every((child) => {\n        const { style } = child as HTMLElement\n        // Pseudo cloning appends stylesheet nodes with no inline box styles.\n        // They do not participate in the source content flow.\n        if (child.tagName === 'STYLE' && !style.display) return true\n        return (\n          ['fixed', 'absolute'].includes(style.position) ||\n          (['block', 'flow-root', 'flex', 'grid', 'table', 'none'].includes(\n            style.display,\n          ) &&\n            (!style.cssFloat || style.cssFloat === 'none') &&\n            style.marginLeft !== 'auto' &&\n            style.marginRight !== 'auto')\n        )\n      }))\n  const hasExternalAbsolute = positioned.some((element) => {\n    if (element.style.position !== 'absolute') return false\n    const source = task?.getCloneSource(element) as HTMLElement | undefined\n    const anchor = source?.offsetParent\n    // A containing block outside the captured tree has another coordinate\n    // origin. Keep its existing fallback until that origin is reconstructed.\n    return !anchor || !task?.hasClonedSource(anchor)\n  })\n  if (\n    task &&\n    (hasDirectText || hasInline || positioned.length) &&\n    canShiftBlockX &&\n    !hasExternalAbsolute &&\n    scrollTop >= 0 &&\n    clonedNode.style.display === 'block' &&\n    clonedNode.style.writingMode === 'horizontal-tb'\n  ) {\n    const view =\n      readDocumentProperty(original.ownerDocument, 'defaultView') || window\n    const before = view.getComputedStyle(original, '::before')\n    const after = scrollLeft\n      ? view.getComputedStyle(original, '::after')\n      : undefined\n    const empty = (style: CSSStyleDeclaration) =>\n      !style.content ||\n      style.content === 'none' ||\n      style.content === 'normal' ||\n      style.display === 'none'\n    const supported = (style: CSSStyleDeclaration) =>\n      empty(style) ||\n      (['block', 'flow-root', 'flex', 'grid'].includes(style.display) &&\n        (!scrollLeft ||\n          (style.marginLeft !== 'auto' && style.marginRight !== 'auto')))\n    if (supported(before) && (!after || supported(after))) {\n      let beforeDeclarations = ''\n      if (scrollTop) {\n        const margin =\n          before.marginTop === 'auto' ? '0px' : before.marginTop || '0px'\n        // The nonzero box prevents collapse with a following negative margin.\n        // Its height plus margin still totals -scrollTop.\n        beforeDeclarations = empty(before)\n          ? `all:initial!important;content:\"\"!important;display:block!important;height:1px!important;margin:${-scrollTop - 1}px 0 0!important;overflow:hidden!important;`\n          : `margin-top:calc(${margin} - ${scrollTop}px)!important;`\n      }\n      const pseudoX = (style: CSSStyleDeclaration) =>\n        scrollLeft && !empty(style)\n          ? `margin-left:calc(${style.marginLeft || '0px'} - ${scrollLeft}px)!important;margin-right:calc(${style.marginRight || '0px'} + ${scrollLeft}px)!important;`\n          : ''\n      beforeDeclarations += pseudoX(before)\n      const afterDeclarations = after ? pseudoX(after) : ''\n      if (beforeDeclarations || afterDeclarations) {\n        const className = uuid()\n        clonedNode.classList.add(className)\n        if (beforeDeclarations)\n          task.addClonedStyle(`.${className}::before { ${beforeDeclarations} }`)\n        if (afterDeclarations)\n          task.addClonedStyle(`.${className}::after { ${afterDeclarations} }`)\n      }\n      if (scrollLeft)\n        children.forEach((child) => {\n          const element = child as HTMLElement\n          if (!['fixed', 'absolute'].includes(element.style.position))\n            shiftMargins(element, scrollLeft, 0)\n        })\n      positioned.forEach(shiftPositioned)\n      clonedNode.style.overflow = 'hidden'\n      return\n    }\n  }\n  // Moving every child with a transform prevents sticky positioning from\n  // using the scrollport. In a block scroller, shifting the first in-flow\n  // child's margin moves the flow while leaving sticky layout to the browser.\n  if (\n    scrollLeft === 0 &&\n    scrollTop > 0 &&\n    clonedNode.style.display === 'block' &&\n    !hasDirectText &&\n    children.some(\n      (child) => (child as HTMLElement).style.position === 'sticky',\n    ) &&\n    children.every((child) => {\n      const { display, position } = (child as HTMLElement).style\n      return (\n        !display.startsWith('inline') &&\n        display !== 'contents' &&\n        position !== 'absolute'\n      )\n    })\n  ) {\n    const firstFlowChild = children.find((child) => {\n      const style = (child as HTMLElement).style\n      return style.display !== 'none' && style.position !== 'fixed'\n    }) as HTMLElement | undefined\n    const margin = firstFlowChild?.style.marginTop || '0px'\n    if (firstFlowChild && margin !== 'auto') {\n      firstFlowChild.style.marginTop = `calc(${margin} - ${scrollTop}px)`\n      fixed.forEach(shiftPositioned)\n      clonedNode.style.overflow = 'hidden'\n      return\n    }\n  }\n  const isSupportedSticky = (child: Element, index: number) => {\n    const style = (child as HTMLElement).style\n    return (\n      index === 0 &&\n      scrollLeft === 0 &&\n      style.position === 'sticky' &&\n      parseFloat(style.top) === 0 &&\n      (!style.bottom || style.bottom === 'auto')\n    )\n  }\n  const hasUnsupportedPosition = children.some((child, index) => {\n    const style = (child as HTMLElement).style\n    return (\n      (style.position === 'sticky' && !isSupportedSticky(child, index)) ||\n      style.display === 'inline'\n    )\n  })\n  if (hasDirectText || hasUnsupportedPosition) return\n  const x = -scrollLeft\n  const y = -scrollTop\n  children.forEach((child, index) => {\n    const element = child as HTMLElement\n    if (element.style.position === 'fixed') {\n      shiftPositioned(element)\n      // Translated siblings create stacking contexts above an auto-z fixed child.\n      if (!element.style.zIndex || element.style.zIndex === 'auto') {\n        element.style.zIndex = '1'\n      }\n      return\n    }\n    if (isSupportedSticky(child, index)) {\n      // Transformed siblings become stacking contexts; keep the sticky header\n      // above the normal-flow content as it appears in the live scroller.\n      if (!element.style.zIndex || element.style.zIndex === 'auto') {\n        element.style.zIndex = '1'\n      }\n      return\n    }\n    const transform = element.style.transform\n    element.style.transform = `translate(${x}px, ${y}px) ${\n      transform && transform !== 'none' ? transform : ''\n    }`.trim()\n  })\n  // SVG foreignObject serialization loses the live scroll offset. Preserve\n  // the source viewport by clipping the shifted copy instead.\n  clonedNode.style.overflow = 'hidden'\n}\n"]
    },
    _coverageSchema: "de0df54ae17f6b36de740b46d31f7cdddb68e251",
    hash: "09b6176d4e743119f751aee947998492b8f1a22a"
  };
  var coverage = global[gcv] || (global[gcv] = {});
  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }
  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_1z9mh2782k = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}
cov_1z9mh2782k();
import { readDocumentProperty } from "/src/document.ts";
import { getTask } from "/src/task.ts";
import { uuid } from "/src/util.ts";
export function cloneScrollState(nativeNode, clonedNode, options, scrollLeft = (cov_1z9mh2782k().b[0][0]++, nativeNode.scrollLeft), scrollTop = (cov_1z9mh2782k().b[1][0]++, nativeNode.scrollTop)) {
  cov_1z9mh2782k().f[0]++;
  cov_1z9mh2782k().s[0]++;
  if ((cov_1z9mh2782k().b[3][0]++, !scrollLeft) && (cov_1z9mh2782k().b[3][1]++, !scrollTop)) {
    cov_1z9mh2782k().b[2][0]++;
    cov_1z9mh2782k().s[1]++;
    return;
  } else {
    cov_1z9mh2782k().b[2][1]++;
  }
  const children = (cov_1z9mh2782k().s[2]++, Array.from(clonedNode.children));
  const hasDirectText = (cov_1z9mh2782k().s[3]++, Array.from(clonedNode.childNodes).some(child => {
    cov_1z9mh2782k().f[1]++;
    cov_1z9mh2782k().s[4]++;
    return (cov_1z9mh2782k().b[4][0]++, child.nodeType === Node.TEXT_NODE) && (cov_1z9mh2782k().b[4][1]++, child.textContent?.trim());
  }));
  const hasInline = (cov_1z9mh2782k().s[5]++, children.some(child => {
    cov_1z9mh2782k().f[2]++;
    cov_1z9mh2782k().s[6]++;
    return child.style.display.startsWith("inline");
  }));
  const task = (cov_1z9mh2782k().s[7]++, getTask(options));
  const descendants = (cov_1z9mh2782k().s[8]++, Array.from(clonedNode.querySelectorAll("*")));
  const positioned = (cov_1z9mh2782k().s[9]++, descendants.filter(child => {
    cov_1z9mh2782k().f[3]++;
    cov_1z9mh2782k().s[10]++;
    return ["fixed", "absolute"].includes(child.style?.position);
  }));
  const fixed = (cov_1z9mh2782k().s[11]++, positioned.filter(child => {
    cov_1z9mh2782k().f[4]++;
    cov_1z9mh2782k().s[12]++;
    return child.style.position === "fixed";
  }));
  const original = (cov_1z9mh2782k().s[13]++, (cov_1z9mh2782k().b[5][0]++, task?.getCloneSource(clonedNode)) || (cov_1z9mh2782k().b[5][1]++, nativeNode));
  const hasSticky = (cov_1z9mh2782k().s[14]++, descendants.some(child => {
    cov_1z9mh2782k().f[5]++;
    cov_1z9mh2782k().s[15]++;
    return child.style?.position === "sticky";
  }));
  cov_1z9mh2782k().s[16]++;
  const shiftMargins = (element, left, top) => {
    cov_1z9mh2782k().f[6]++;
    const {
      style
    } = (cov_1z9mh2782k().s[17]++, element);
    const margins = (cov_1z9mh2782k().s[18]++, [["margin-left", -left], ["margin-right", left], ["margin-top", -top], ["margin-bottom", top]]);
    cov_1z9mh2782k().s[19]++;
    margins.forEach(([property, delta]) => {
      cov_1z9mh2782k().f[7]++;
      cov_1z9mh2782k().s[20]++;
      if (!delta) {
        cov_1z9mh2782k().b[6][0]++;
        cov_1z9mh2782k().s[21]++;
        return;
      } else {
        cov_1z9mh2782k().b[6][1]++;
      }
      const value = (cov_1z9mh2782k().s[22]++, (cov_1z9mh2782k().b[7][0]++, style.getPropertyValue(property)) || (cov_1z9mh2782k().b[7][1]++, "0px"));
      cov_1z9mh2782k().s[23]++;
      style.setProperty(property, `calc(${value} ${delta < 0 ? (cov_1z9mh2782k().b[8][0]++, "-") : (cov_1z9mh2782k().b[8][1]++, "+")} ${Math.abs(delta)}px)`, "important");
    });
  };
  cov_1z9mh2782k().s[24]++;
  const shiftPositioned = element => {
    cov_1z9mh2782k().f[8]++;
    const source = (cov_1z9mh2782k().s[25]++, task?.getCloneSource(element));
    cov_1z9mh2782k().s[26]++;
    if (source?.offsetParent !== original) {
      cov_1z9mh2782k().b[9][0]++;
      cov_1z9mh2782k().s[27]++;
      return;
    } else {
      cov_1z9mh2782k().b[9][1]++;
    }
    // Use the source browser's containing block, rather than guessing from a
    // subset of CSS properties. Insets do not create another containing block
    // for nested fixed descendants, as an added transform would.
    const {
      style
    } = (cov_1z9mh2782k().s[28]++, element);
    cov_1z9mh2782k().s[29]++;
    const shift = (start, end, amount) => {
      cov_1z9mh2782k().f[9]++;
      cov_1z9mh2782k().s[30]++;
      if (!amount) {
        cov_1z9mh2782k().b[10][0]++;
        cov_1z9mh2782k().s[31]++;
        return;
      } else {
        cov_1z9mh2782k().b[10][1]++;
      }
      const value = (cov_1z9mh2782k().s[32]++, style.getPropertyValue(start));
      const opposite = (cov_1z9mh2782k().s[33]++, style.getPropertyValue(end));
      cov_1z9mh2782k().s[34]++;
      if ((cov_1z9mh2782k().b[12][0]++, value) && (cov_1z9mh2782k().b[12][1]++, value !== "auto")) {
        cov_1z9mh2782k().b[11][0]++;
        cov_1z9mh2782k().s[35]++;
        style.setProperty(start, `calc(${value} - ${amount}px)`, "important");
        cov_1z9mh2782k().s[36]++;
        style.setProperty(end, "auto", "important");
      } else {
        cov_1z9mh2782k().b[11][1]++;
        cov_1z9mh2782k().s[37]++;
        if ((cov_1z9mh2782k().b[14][0]++, opposite) && (cov_1z9mh2782k().b[14][1]++, opposite !== "auto")) {
          cov_1z9mh2782k().b[13][0]++;
          cov_1z9mh2782k().s[38]++;
          style.setProperty(end, `calc(${opposite} + ${amount}px)`, "important");
        } else {
          cov_1z9mh2782k().b[13][1]++;
        }
      }
    };
    cov_1z9mh2782k().s[39]++;
    shift("left", "right", scrollLeft);
    cov_1z9mh2782k().s[40]++;
    shift("top", "bottom", scrollTop);
  };
  cov_1z9mh2782k().s[41]++;
  if ((cov_1z9mh2782k().b[16][0]++, task) && (cov_1z9mh2782k().b[16][1]++, positioned.length) && (cov_1z9mh2782k().b[16][2]++, !hasDirectText) && (cov_1z9mh2782k().b[16][3]++, ["flex", "inline-flex"].includes(clonedNode.style.display)) && (cov_1z9mh2782k().b[16][4]++, clonedNode.style.writingMode === "horizontal-tb") && (cov_1z9mh2782k().b[16][5]++, !hasSticky) && (cov_1z9mh2782k().b[16][6]++, children.every(child => {
    cov_1z9mh2782k().f[10]++;
    const style = (cov_1z9mh2782k().s[42]++, child.style);
    cov_1z9mh2782k().s[43]++;
    return (cov_1z9mh2782k().b[17][0]++, style.display !== "contents") && ((cov_1z9mh2782k().b[17][1]++, !scrollLeft) || (cov_1z9mh2782k().b[17][2]++, style.marginLeft !== "auto") && (cov_1z9mh2782k().b[17][3]++, style.marginRight !== "auto")) && ((cov_1z9mh2782k().b[17][4]++, !scrollTop) || (cov_1z9mh2782k().b[17][5]++, style.marginTop !== "auto") && (cov_1z9mh2782k().b[17][6]++, style.marginBottom !== "auto"));
  }))) {
    cov_1z9mh2782k().b[15][0]++;
    cov_1z9mh2782k().s[44]++;
    // Opposite margins translate each flex item on both axes without changing
    // its outer size, flex lines or containing blocks. Unlike block margins,
    // flex-item margins cannot collapse. Added transforms would re-anchor
    // positioned descendants of ordinary wrappers.
    children.forEach(child => {
      cov_1z9mh2782k().f[11]++;
      const {
        style
      } = (cov_1z9mh2782k().s[45]++, child);
      cov_1z9mh2782k().s[46]++;
      if (["fixed", "absolute"].includes(style.position)) {
        cov_1z9mh2782k().b[18][0]++;
        cov_1z9mh2782k().s[47]++;
        return;
      } else {
        cov_1z9mh2782k().b[18][1]++;
      }
      cov_1z9mh2782k().s[48]++;
      shiftMargins(child, scrollLeft, scrollTop);
    });
    cov_1z9mh2782k().s[49]++;
    positioned.forEach(shiftPositioned);
    cov_1z9mh2782k().s[50]++;
    clonedNode.style.overflow = "hidden";
    cov_1z9mh2782k().s[51]++;
    return;
  } else {
    cov_1z9mh2782k().b[15][1]++;
  }
  const canShiftBlockX = (cov_1z9mh2782k().s[52]++, (cov_1z9mh2782k().b[19][0]++, !scrollLeft) || (cov_1z9mh2782k().b[19][1]++, !hasDirectText) && (cov_1z9mh2782k().b[19][2]++, !hasInline) && (cov_1z9mh2782k().b[19][3]++, !hasSticky) && (cov_1z9mh2782k().b[19][4]++, children.every(child => {
    cov_1z9mh2782k().f[12]++;
    const {
      style
    } = (cov_1z9mh2782k().s[53]++, child);
    // Pseudo cloning appends stylesheet nodes with no inline box styles.
    // They do not participate in the source content flow.
    cov_1z9mh2782k().s[54]++;
    if ((cov_1z9mh2782k().b[21][0]++, child.tagName === "STYLE") && (cov_1z9mh2782k().b[21][1]++, !style.display)) {
      cov_1z9mh2782k().b[20][0]++;
      cov_1z9mh2782k().s[55]++;
      return true;
    } else {
      cov_1z9mh2782k().b[20][1]++;
    }
    cov_1z9mh2782k().s[56]++;
    return (cov_1z9mh2782k().b[22][0]++, ["fixed", "absolute"].includes(style.position)) || (cov_1z9mh2782k().b[22][1]++, ["block", "flow-root", "flex", "grid", "table", "none"].includes(style.display)) && ((cov_1z9mh2782k().b[22][2]++, !style.cssFloat) || (cov_1z9mh2782k().b[22][3]++, style.cssFloat === "none")) && (cov_1z9mh2782k().b[22][4]++, style.marginLeft !== "auto") && (cov_1z9mh2782k().b[22][5]++, style.marginRight !== "auto");
  })));
  const hasExternalAbsolute = (cov_1z9mh2782k().s[57]++, positioned.some(element => {
    cov_1z9mh2782k().f[13]++;
    cov_1z9mh2782k().s[58]++;
    if (element.style.position !== "absolute") {
      cov_1z9mh2782k().b[23][0]++;
      cov_1z9mh2782k().s[59]++;
      return false;
    } else {
      cov_1z9mh2782k().b[23][1]++;
    }
    const source = (cov_1z9mh2782k().s[60]++, task?.getCloneSource(element));
    const anchor = (cov_1z9mh2782k().s[61]++, source?.offsetParent);
    // A containing block outside the captured tree has another coordinate
    // origin. Keep its existing fallback until that origin is reconstructed.
    cov_1z9mh2782k().s[62]++;
    return (cov_1z9mh2782k().b[24][0]++, !anchor) || (cov_1z9mh2782k().b[24][1]++, !task?.hasClonedSource(anchor));
  }));
  cov_1z9mh2782k().s[63]++;
  if ((cov_1z9mh2782k().b[26][0]++, task) && ((cov_1z9mh2782k().b[26][1]++, hasDirectText) || (cov_1z9mh2782k().b[26][2]++, hasInline) || (cov_1z9mh2782k().b[26][3]++, positioned.length)) && (cov_1z9mh2782k().b[26][4]++, canShiftBlockX) && (cov_1z9mh2782k().b[26][5]++, !hasExternalAbsolute) && (cov_1z9mh2782k().b[26][6]++, scrollTop >= 0) && (cov_1z9mh2782k().b[26][7]++, clonedNode.style.display === "block") && (cov_1z9mh2782k().b[26][8]++, clonedNode.style.writingMode === "horizontal-tb")) {
    cov_1z9mh2782k().b[25][0]++;
    const view = (cov_1z9mh2782k().s[64]++, (cov_1z9mh2782k().b[27][0]++, readDocumentProperty(original.ownerDocument, "defaultView")) || (cov_1z9mh2782k().b[27][1]++, window));
    const before = (cov_1z9mh2782k().s[65]++, view.getComputedStyle(original, "::before"));
    const after = (cov_1z9mh2782k().s[66]++, scrollLeft ? (cov_1z9mh2782k().b[28][0]++, view.getComputedStyle(original, "::after")) : (cov_1z9mh2782k().b[28][1]++, undefined));
    cov_1z9mh2782k().s[67]++;
    const empty = style => {
      cov_1z9mh2782k().f[14]++;
      cov_1z9mh2782k().s[68]++;
      return (cov_1z9mh2782k().b[29][0]++, !style.content) || (cov_1z9mh2782k().b[29][1]++, style.content === "none") || (cov_1z9mh2782k().b[29][2]++, style.content === "normal") || (cov_1z9mh2782k().b[29][3]++, style.display === "none");
    };
    cov_1z9mh2782k().s[69]++;
    const supported = style => {
      cov_1z9mh2782k().f[15]++;
      cov_1z9mh2782k().s[70]++;
      return (cov_1z9mh2782k().b[30][0]++, empty(style)) || (cov_1z9mh2782k().b[30][1]++, ["block", "flow-root", "flex", "grid"].includes(style.display)) && ((cov_1z9mh2782k().b[30][2]++, !scrollLeft) || (cov_1z9mh2782k().b[30][3]++, style.marginLeft !== "auto") && (cov_1z9mh2782k().b[30][4]++, style.marginRight !== "auto"));
    };
    cov_1z9mh2782k().s[71]++;
    if ((cov_1z9mh2782k().b[32][0]++, supported(before)) && ((cov_1z9mh2782k().b[32][1]++, !after) || (cov_1z9mh2782k().b[32][2]++, supported(after)))) {
      cov_1z9mh2782k().b[31][0]++;
      let beforeDeclarations = (cov_1z9mh2782k().s[72]++, "");
      cov_1z9mh2782k().s[73]++;
      if (scrollTop) {
        cov_1z9mh2782k().b[33][0]++;
        const margin = (cov_1z9mh2782k().s[74]++, before.marginTop === "auto" ? (cov_1z9mh2782k().b[34][0]++, "0px") : (cov_1z9mh2782k().b[34][1]++, (cov_1z9mh2782k().b[35][0]++, before.marginTop) || (cov_1z9mh2782k().b[35][1]++, "0px")));
        // The nonzero box prevents collapse with a following negative margin.
        // Its height plus margin still totals -scrollTop.
        cov_1z9mh2782k().s[75]++;
        beforeDeclarations = empty(before) ? (cov_1z9mh2782k().b[36][0]++, `all:initial!important;content:""!important;display:block!important;height:1px!important;margin:${-scrollTop - 1}px 0 0!important;overflow:hidden!important;`) : (cov_1z9mh2782k().b[36][1]++, `margin-top:calc(${margin} - ${scrollTop}px)!important;`);
      } else {
        cov_1z9mh2782k().b[33][1]++;
      }
      cov_1z9mh2782k().s[76]++;
      const pseudoX = style => {
        cov_1z9mh2782k().f[16]++;
        cov_1z9mh2782k().s[77]++;
        return (cov_1z9mh2782k().b[38][0]++, scrollLeft) && (cov_1z9mh2782k().b[38][1]++, !empty(style)) ? (cov_1z9mh2782k().b[37][0]++, `margin-left:calc(${(cov_1z9mh2782k().b[39][0]++, style.marginLeft) || (cov_1z9mh2782k().b[39][1]++, "0px")} - ${scrollLeft}px)!important;margin-right:calc(${(cov_1z9mh2782k().b[40][0]++, style.marginRight) || (cov_1z9mh2782k().b[40][1]++, "0px")} + ${scrollLeft}px)!important;`) : (cov_1z9mh2782k().b[37][1]++, "");
      };
      cov_1z9mh2782k().s[78]++;
      beforeDeclarations += pseudoX(before);
      const afterDeclarations = (cov_1z9mh2782k().s[79]++, after ? (cov_1z9mh2782k().b[41][0]++, pseudoX(after)) : (cov_1z9mh2782k().b[41][1]++, ""));
      cov_1z9mh2782k().s[80]++;
      if ((cov_1z9mh2782k().b[43][0]++, beforeDeclarations) || (cov_1z9mh2782k().b[43][1]++, afterDeclarations)) {
        cov_1z9mh2782k().b[42][0]++;
        const className = (cov_1z9mh2782k().s[81]++, uuid());
        cov_1z9mh2782k().s[82]++;
        clonedNode.classList.add(className);
        cov_1z9mh2782k().s[83]++;
        if (beforeDeclarations) {
          cov_1z9mh2782k().b[44][0]++;
          cov_1z9mh2782k().s[84]++;
          task.addClonedStyle(`.${className}::before { ${beforeDeclarations} }`);
        } else {
          cov_1z9mh2782k().b[44][1]++;
        }
        cov_1z9mh2782k().s[85]++;
        if (afterDeclarations) {
          cov_1z9mh2782k().b[45][0]++;
          cov_1z9mh2782k().s[86]++;
          task.addClonedStyle(`.${className}::after { ${afterDeclarations} }`);
        } else {
          cov_1z9mh2782k().b[45][1]++;
        }
      } else {
        cov_1z9mh2782k().b[42][1]++;
      }
      cov_1z9mh2782k().s[87]++;
      if (scrollLeft) {
        cov_1z9mh2782k().b[46][0]++;
        cov_1z9mh2782k().s[88]++;
        children.forEach(child => {
          cov_1z9mh2782k().f[17]++;
          const element = (cov_1z9mh2782k().s[89]++, child);
          cov_1z9mh2782k().s[90]++;
          if (!["fixed", "absolute"].includes(element.style.position)) {
            cov_1z9mh2782k().b[47][0]++;
            cov_1z9mh2782k().s[91]++;
            shiftMargins(element, scrollLeft, 0);
          } else {
            cov_1z9mh2782k().b[47][1]++;
          }
        });
      } else {
        cov_1z9mh2782k().b[46][1]++;
      }
      cov_1z9mh2782k().s[92]++;
      positioned.forEach(shiftPositioned);
      cov_1z9mh2782k().s[93]++;
      clonedNode.style.overflow = "hidden";
      cov_1z9mh2782k().s[94]++;
      return;
    } else {
      cov_1z9mh2782k().b[31][1]++;
    }
  } else {
    cov_1z9mh2782k().b[25][1]++;
  }
  // Moving every child with a transform prevents sticky positioning from
  // using the scrollport. In a block scroller, shifting the first in-flow
  // child's margin moves the flow while leaving sticky layout to the browser.
  cov_1z9mh2782k().s[95]++;
  if ((cov_1z9mh2782k().b[49][0]++, scrollLeft === 0) && (cov_1z9mh2782k().b[49][1]++, scrollTop > 0) && (cov_1z9mh2782k().b[49][2]++, clonedNode.style.display === "block") && (cov_1z9mh2782k().b[49][3]++, !hasDirectText) && (cov_1z9mh2782k().b[49][4]++, children.some(child => {
    cov_1z9mh2782k().f[18]++;
    cov_1z9mh2782k().s[96]++;
    return child.style.position === "sticky";
  })) && (cov_1z9mh2782k().b[49][5]++, children.every(child => {
    cov_1z9mh2782k().f[19]++;
    const {
      display,
      position
    } = (cov_1z9mh2782k().s[97]++, child.style);
    cov_1z9mh2782k().s[98]++;
    return (cov_1z9mh2782k().b[50][0]++, !display.startsWith("inline")) && (cov_1z9mh2782k().b[50][1]++, display !== "contents") && (cov_1z9mh2782k().b[50][2]++, position !== "absolute");
  }))) {
    cov_1z9mh2782k().b[48][0]++;
    const firstFlowChild = (cov_1z9mh2782k().s[99]++, children.find(child => {
      cov_1z9mh2782k().f[20]++;
      const style = (cov_1z9mh2782k().s[100]++, child.style);
      cov_1z9mh2782k().s[101]++;
      return (cov_1z9mh2782k().b[51][0]++, style.display !== "none") && (cov_1z9mh2782k().b[51][1]++, style.position !== "fixed");
    }));
    const margin = (cov_1z9mh2782k().s[102]++, (cov_1z9mh2782k().b[52][0]++, firstFlowChild?.style.marginTop) || (cov_1z9mh2782k().b[52][1]++, "0px"));
    cov_1z9mh2782k().s[103]++;
    if ((cov_1z9mh2782k().b[54][0]++, firstFlowChild) && (cov_1z9mh2782k().b[54][1]++, margin !== "auto")) {
      cov_1z9mh2782k().b[53][0]++;
      cov_1z9mh2782k().s[104]++;
      firstFlowChild.style.marginTop = `calc(${margin} - ${scrollTop}px)`;
      cov_1z9mh2782k().s[105]++;
      fixed.forEach(shiftPositioned);
      cov_1z9mh2782k().s[106]++;
      clonedNode.style.overflow = "hidden";
      cov_1z9mh2782k().s[107]++;
      return;
    } else {
      cov_1z9mh2782k().b[53][1]++;
    }
  } else {
    cov_1z9mh2782k().b[48][1]++;
  }
  cov_1z9mh2782k().s[108]++;
  const isSupportedSticky = (child, index) => {
    cov_1z9mh2782k().f[21]++;
    const style = (cov_1z9mh2782k().s[109]++, child.style);
    cov_1z9mh2782k().s[110]++;
    return (cov_1z9mh2782k().b[55][0]++, index === 0) && (cov_1z9mh2782k().b[55][1]++, scrollLeft === 0) && (cov_1z9mh2782k().b[55][2]++, style.position === "sticky") && (cov_1z9mh2782k().b[55][3]++, parseFloat(style.top) === 0) && ((cov_1z9mh2782k().b[55][4]++, !style.bottom) || (cov_1z9mh2782k().b[55][5]++, style.bottom === "auto"));
  };
  const hasUnsupportedPosition = (cov_1z9mh2782k().s[111]++, children.some((child, index) => {
    cov_1z9mh2782k().f[22]++;
    const style = (cov_1z9mh2782k().s[112]++, child.style);
    cov_1z9mh2782k().s[113]++;
    return (cov_1z9mh2782k().b[56][0]++, style.position === "sticky") && (cov_1z9mh2782k().b[56][1]++, !isSupportedSticky(child, index)) || (cov_1z9mh2782k().b[56][2]++, style.display === "inline");
  }));
  cov_1z9mh2782k().s[114]++;
  if ((cov_1z9mh2782k().b[58][0]++, hasDirectText) || (cov_1z9mh2782k().b[58][1]++, hasUnsupportedPosition)) {
    cov_1z9mh2782k().b[57][0]++;
    cov_1z9mh2782k().s[115]++;
    return;
  } else {
    cov_1z9mh2782k().b[57][1]++;
  }
  const x = (cov_1z9mh2782k().s[116]++, -scrollLeft);
  const y = (cov_1z9mh2782k().s[117]++, -scrollTop);
  cov_1z9mh2782k().s[118]++;
  children.forEach((child, index) => {
    cov_1z9mh2782k().f[23]++;
    const element = (cov_1z9mh2782k().s[119]++, child);
    cov_1z9mh2782k().s[120]++;
    if (element.style.position === "fixed") {
      cov_1z9mh2782k().b[59][0]++;
      cov_1z9mh2782k().s[121]++;
      shiftPositioned(element);
      // Translated siblings create stacking contexts above an auto-z fixed child.
      cov_1z9mh2782k().s[122]++;
      if ((cov_1z9mh2782k().b[61][0]++, !element.style.zIndex) || (cov_1z9mh2782k().b[61][1]++, element.style.zIndex === "auto")) {
        cov_1z9mh2782k().b[60][0]++;
        cov_1z9mh2782k().s[123]++;
        element.style.zIndex = "1";
      } else {
        cov_1z9mh2782k().b[60][1]++;
      }
      cov_1z9mh2782k().s[124]++;
      return;
    } else {
      cov_1z9mh2782k().b[59][1]++;
    }
    cov_1z9mh2782k().s[125]++;
    if (isSupportedSticky(child, index)) {
      cov_1z9mh2782k().b[62][0]++;
      cov_1z9mh2782k().s[126]++;
      // Transformed siblings become stacking contexts; keep the sticky header
      // above the normal-flow content as it appears in the live scroller.
      if ((cov_1z9mh2782k().b[64][0]++, !element.style.zIndex) || (cov_1z9mh2782k().b[64][1]++, element.style.zIndex === "auto")) {
        cov_1z9mh2782k().b[63][0]++;
        cov_1z9mh2782k().s[127]++;
        element.style.zIndex = "1";
      } else {
        cov_1z9mh2782k().b[63][1]++;
      }
      cov_1z9mh2782k().s[128]++;
      return;
    } else {
      cov_1z9mh2782k().b[62][1]++;
    }
    const transform = (cov_1z9mh2782k().s[129]++, element.style.transform);
    cov_1z9mh2782k().s[130]++;
    element.style.transform = `translate(${x}px, ${y}px) ${(cov_1z9mh2782k().b[66][0]++, transform) && (cov_1z9mh2782k().b[66][1]++, transform !== "none") ? (cov_1z9mh2782k().b[65][0]++, transform) : (cov_1z9mh2782k().b[65][1]++, "")}`.trim();
  });
  // SVG foreignObject serialization loses the live scroll offset. Preserve
  // the source viewport by clipping the shifted copy instead.
  cov_1z9mh2782k().s[131]++;
  clonedNode.style.overflow = "hidden";
}