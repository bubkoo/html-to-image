import { mkdirSync, writeFileSync, appendFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
const folder = '/work/.codex-linux-control/holder-code-map/served'
mkdirSync(folder, { recursive: true })
const wanted = /\/src\/(util|clone-node|clone-scroll|clone-pseudos|embed-images|document)\.ts$/
function save(stage, code, id, map) {
 const match = id.split('?')[0].match(wanted)
 if (!match || !code) return
 writeFileSync(folder+'/'+match[1]+'.'+stage+'.js', code)
 if(map)writeFileSync(folder+'/'+match[1]+'.'+stage+'.map.json',JSON.stringify(map))
 appendFileSync(folder+'/records.jsonl',JSON.stringify({stage,id,lines:code.split('\n').length,sha256:createHash('sha256').update(code).digest('hex'),instrumented:code.includes('function cov_')})+'\n')
}
export default {
 name:'capture-observed-module-code', enforce:'post',
 transform(code,id){ save('post',code,id) },
 configureServer(server){
  server.middlewares.use((request,response,next)=>{
   const url=request.url || ''
   response.once('finish',()=>{
    if(!/util|clone-node|clone-scroll|clone-pseudos|embed-images|document/.test(url))return
    const graph=server.environments.client.moduleGraph
    graph.getModuleByUrl(url).then(node=>{
     if(node?.file && node.transformResult)save('served',node.transformResult.code,node.file,node.transformResult.map)
    }).catch(error=>appendFileSync(folder+'/errors.log',String(error)+'\n'))
   })
   next()
  })
 }
}
