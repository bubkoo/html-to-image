import { beforeEach } from 'vitest'
import { commands, server } from 'vitest/browser'
import { installRegistry } from './registry.js'

if (server.browser === 'firefox') {
  installRegistry()
  beforeEach((context) => {
    if (!context.task.name.startsWith('disposed SVG owner releases source'))
      return
    const registry = Reflect.get(
      globalThis,
      '__codexWeakReferenceRegistry',
    ) as {
      reference: WeakRef<Document>
      stack: string
    }[]
    registry.length = 0
    context.onTestFailed(async (failed) => {
      const references = registry.filter((entry) =>
        entry.stack.includes('svg-style-source-lifetime.test.ts'),
      )
      const errors = failed.task.result?.errors?.map((error) => ({
        message: String(error.message),
        stack: String(error.stack),
        actual:
          typeof error.actual === 'boolean'
            ? error.actual
            : typeof error.actual,
        expected:
          typeof error.expected === 'boolean'
            ? error.expected
            : typeof error.expected,
      }))
      for (let index = 0; index < references.length; index += 1) {
        const entry = references[index]
        Reflect.set(globalThis, '__codex_ref_probe', {
          __codexHeap: true,
          reference: entry.reference,
        })
        try {
          await (
            commands as unknown as {
              recordReferenceOnlyLifetime(record: string): Promise<void>
            }
          ).recordReferenceOnlyLifetime(
            JSON.stringify({
              kind: `registry-${failed.task.name}-ref-${index}`,
              originalFailureState: failed.task.result?.state,
              originalErrors: errors,
              references: references.length,
              referenceIndex: index,
              referenceConstructorStack: entry.stack,
              originalFixtureBytesUnchanged: true,
              originalCollectionRequests: 3,
              observation:
                'after original test failure; weak wrapper registry only, target not dereferenced',
            }),
          )
        } finally {
          Reflect.deleteProperty(globalThis, '__codex_ref_probe')
        }
      }
    })
  })
}
