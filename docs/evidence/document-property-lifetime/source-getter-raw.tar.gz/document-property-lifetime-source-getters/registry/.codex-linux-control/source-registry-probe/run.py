from pathlib import Path
import subprocess, json, hashlib, os, sys

folder = Path(__file__).parent
tools = Path('.codex-linux-control/source-holder-e/tooling')
installation = folder / 'installation'
command = ['python3', str(tools / 'firefox-gc-reference-probe.py')]
config = Path('vitest.browser.config.mts')
original = (folder / 'original-config.mts').read_bytes()
assert config.read_bytes() == original
text = original.decode().replace(
    "import { mkdir, readFile, writeFile } from 'node:fs/promises'",
    "import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises'",
)
reference_command = (tools / 'reference-command.txt').read_text()
needle = '          try {\n            const target = await frame()'
assert reference_command.count(needle) == 1
reference_command = reference_command.replace(needle,
    '          if (primary.metadataOnly) return\n' + needle)
text = text.replace('        async startSVGStyleResourceTrace(',
                    reference_command + '        async startSVGStyleResourceTrace(')
text = text.replace('    globals: true,',
                    "    globals: true,\n    setupFiles: ['.codex-linux-control/source-registry-probe/setup.ts'],")
config.write_text(text)
control = (tools / 'firefox-gc-reference-controls.cjs').read_text().replace(
    "const folder = '.vitest/attachments/gc-reference-probe/controls'",
    "const folder = '.codex-linux-control/source-registry-probe/controls'",
)
control = control.replace('    const page = await browser.newPage()',
    '''    const page = await browser.newPage()
    await page.evaluate(source => (0, eval)(source), fs.readFileSync('.codex-linux-control/source-registry-probe/registry.js','utf8').replace('export function installRegistry()', 'function installRegistry()')+'\\ninstallRegistry()')''')
(folder / 'controls.cjs').write_text(control)
subprocess.run(command + ['install', '--output', str(installation)], check=True)
status = None
before = None
try:
    with (folder / 'controls.log').open('wb') as log:
        control_status = subprocess.run(['node', str(folder / 'controls.cjs')],
            stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, DEBUG='pw:browser')).returncode
    assert control_status == 0, 'Registry weak/strong control failed'
    cache = Path('node_modules/.vite/vitest')
    receipt = []
    for p in sorted(cache.rglob('results.json')):
        relative = p.relative_to(cache)
        data = p.read_bytes()
        out = folder / 'cache-before' / relative
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        receipt.append({'path': str(relative), 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
        p.unlink()
    (folder / 'cache-receipt.json').write_text(json.dumps({
        'action': 'save and remove results.json only; keep optimized bundles',
        'files': receipt}, indent=2) + '\n')
    tooling = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
               for p in folder.iterdir()
               if p.name in ['setup.ts', 'registry.js', 'controls.cjs',
                             'original-config.mts', 'run.py']}
    (folder / 'tooling-inputs.json').write_text(json.dumps(tooling, indent=2) + '\n')
    subprocess.run(['node', '/tmp/hash-reflective-inputs.mjs', 'source-registry-before'], check=True)
    before = json.loads(Path('.codex-linux-control/source-registry-before-inputs.json').read_text())
    baseline = json.loads(Path('.codex-linux-control/access-full-before-inputs.json').read_text())['files']
    changes = [p for p in sorted(set(baseline) | set(before['files']))
               if baseline.get(p) != before['files'].get(p)]
    assert changes == ['vitest.browser.config.mts'], changes
    (folder / 'diagnostic-only-changes.json').write_text(json.dumps({
        'changedOnly': changes, 'productionAllTestsAndBuildUnchanged': True,
        'extraFiles': tooling, 'limits': [
            'WeakRef constructor proxy stores weak wrappers and creation-stack strings; constructor identity changes',
            'Original fixture, assertion conditions, collection count and deadlines unchanged',
            'Sampling follows original assertion failure and async test unwind; targets may collect before inspection',
            'Snapshots are sequential; first diagnostic collection can affect the second reference',
            'Default DEBUG disabled for full run; controls alone log browser metadata',
        ]}, indent=2) + '\n')
    env = dict(os.environ, GC_REFERENCE_PROBE='1', GC_OBSERVER_PHASE='source-registry')
    env.pop('DEBUG', None)
    print('Registry canaries valid; original test files unchanged; sampling after original failure', flush=True)
    with (folder / 'normal.log').open('wb') as log:
        status = subprocess.run(['pnpm', 'run', 'test'], stdout=log,
                                stderr=subprocess.STDOUT, env=env).returncode
finally:
    stable = None
    if before is not None:
        subprocess.run(['node', '/tmp/hash-reflective-inputs.mjs', 'source-registry-after'], check=True)
        after = json.loads(Path('.codex-linux-control/source-registry-after-inputs.json').read_text())
        stable = before == after
    restore = subprocess.run(command + ['restore', '--output', str(installation)]).returncode
    config.write_bytes(original)
    subprocess.run(['node', '/tmp/hash-reflective-inputs.mjs', 'source-registry-restored'], check=True)
    baseline = json.loads(Path('.codex-linux-control/access-full-before-inputs.json').read_text())['files']
    final = json.loads(Path('.codex-linux-control/source-registry-restored-inputs.json').read_text())['files']
    result = {'normalExitCode': status, 'allDiagnosticHashesUnchanged': stable,
              'restoreExitCode': restore,
              'productionTestsConfigurationBuildRestored': final == baseline,
              'inputs': len(final), 'packages': 'not run; observer does not replace acceptance'}
    (folder / 'execution.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    assert restore == 0 and final == baseline and stable is not False
sys.exit(status or 0)
