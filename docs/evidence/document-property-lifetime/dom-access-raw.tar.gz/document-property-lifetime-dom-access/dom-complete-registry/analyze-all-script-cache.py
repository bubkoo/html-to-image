from pathlib import Path
import json,re,collections
folder=Path(__file__).parent/'graphs'
record=json.loads(next(folder.glob('*ref-1.json')).read_text());target=hex(record['graph']['ids']['target'])
nodes={};edges=collections.defaultdict(list);incoming=collections.defaultdict(list);roots={};excluded=collections.Counter();after=False;current=None
weak=re.compile(r'\[weak\]|WeakRefObject::target|WeakMap entry|cacheir-weak-')
for line in next(folder.glob('*ref-1.gc.log')).read_text().splitlines():
 if line.startswith('=========='):after=True;continue
 if not line or line.startswith(('#','WeakMapEntry ')):continue
 m=re.match(r'^(0x[0-9a-f]+) ([A-Z]) (.*)$',line)
 if m:
  address,color,desc=m.groups()
  if after:nodes[address]={'description':desc,'color':color};current=address
  else:roots.setdefault(address,[]).append(desc)
  continue
 m=re.match(r'^> (0x[0-9a-f]+) ([A-Z]) (.*)$',line)
 if not m:raise ValueError(line)
 if not after:continue
 to,color,label=m.groups()
 if weak.search(label) or label in ['realm debugger','Debugger.Object referent','JSFunction script']:
  excluded[label]+=1;continue
 edges[current].append((to,label));incoming[to].append((current,label))
# Each stored step is independently auditable.
seen={target};toward={};queue=collections.deque([target])
while queue:
 child=queue.popleft()
 for parent,label in incoming[child]:
  if parent not in seen:seen.add(parent);toward[parent]={'from':parent,'edge':label,'to':child};queue.append(parent)
def path(start):
 result=[]
 while start!=target:
  step=toward[start];result.append({**step,'fromDescription':nodes[start]['description'],'toDescription':nodes[step['to']]['description']});start=step['to']
 return result
rows=[]
for address,node in nodes.items():
 if not node['description'].startswith('script '):continue
 for to,label in edges[address]:
  if 'cacheir-' in label and to in seen:
   rows.append({'scriptAddress':address,'script':node['description'],'cacheField':label,'cachedObject':nodes[to]['description'],'cachedAddress':to,'path':path(to)})
source=[r for r in rows if '/src/' in r['script']];other=[r for r in rows if '/src/' not in r['script']]
out={'target':target,'targetDescription':nodes[target]['description'],'scope':'Complete emitted ordinary JS graph; excludes explicit weak/WeakMap, every cacheir-weak name, debugger boundaries, and crossing another JSFunction script. Post-failure/cleanup inspection; not unique pre-inspection or native ownership proof.','sourceCacheFields':source,'nonSourceCacheFields':other,'sourceScripts':len(set(r['script'] for r in source)),'sourceFiles':sorted(set(r['script'].rsplit(':',1)[0] for r in source)),'excluded':dict(excluded)}
(folder/'all-script-cache-paths.json').write_text(json.dumps(out,indent=2)+'\n')
print({'target':target,'sourceFields':len(source),'scripts':out['sourceScripts'],'otherFields':len(other),'objects':dict(collections.Counter(r['cachedObject'] for r in source))})
