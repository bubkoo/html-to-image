import { beforeEach } from 'vitest'
import { commands, server } from 'vitest/browser'
import { installRegistry } from './registry.js'

if (server.browser === 'firefox') {
  installRegistry()
  beforeEach((context) => {
    const file = context.task.file.filepath.split('/').pop()!
    if (![
      'capture-lifetime.test.ts',
      'svg-style-source-lifetime.test.ts',
      'svg-fragment-lifetime.test.ts',
      'resource-resolver-cancellation.test.ts',
    ].includes(file)) return
    const registry = Reflect.get(globalThis, '__codexWeakReferenceRegistry') as {
      reference: WeakRef<Document>
      stack: string
    }[]
    registry.length = 0
    context.onTestFailed(async (failed) => {
      const references = registry.filter((entry) =>
        entry.stack.includes(file),
      )
      const errors = failed.task.result?.errors?.map((error) => ({
        message: String(error.message),
        stack: String(error.stack),
        actual: typeof error.actual === 'boolean' ? error.actual : typeof error.actual,
        expected: typeof error.expected === 'boolean' ? error.expected : typeof error.expected,
      }))
      await (commands as unknown as {
        recordReferenceOnlyLifetime(record: string): Promise<void>
      }).recordReferenceOnlyLifetime(JSON.stringify({
        kind: `registry-${failed.task.name}-failure`,
        metadataOnly: true,
        originalFailureState: failed.task.result?.state,
        originalErrors: errors,
        references: references.length,
        originalFixtureBytesUnchanged: true,
        originalCollectionRequests: 3,
      }))
      for (let index = 0; index < references.length; index += 1) {
        const entry = references[index]
        Reflect.set(globalThis, '__codex_ref_probe', {
          __codexHeap: true,
          reference: entry.reference,
        })
        try {
          await (commands as unknown as {
            recordReferenceOnlyLifetime(record: string): Promise<void>
          }).recordReferenceOnlyLifetime(JSON.stringify({
            kind: `registry-${failed.task.name}-ref-${index}`,
            originalFailureState: failed.task.result?.state,
            originalErrors: errors,
            references: references.length,
            referenceIndex: index,
            referenceConstructorStack: entry.stack,
            originalFixtureBytesUnchanged: true,
            originalCollectionRequests: 3,
            observation: 'after original test failure; weak wrapper registry only, target not dereferenced',
          }))
        } finally {
          Reflect.deleteProperty(globalThis, '__codex_ref_probe')
        }
      }
    })
  })
}
