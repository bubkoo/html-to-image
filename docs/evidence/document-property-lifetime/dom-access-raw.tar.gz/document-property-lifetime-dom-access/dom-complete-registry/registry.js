export function installRegistry() {
  if (globalThis.__codexWeakReferenceRegistry) return
  const references = []
  const NativeWeakRef = globalThis.WeakRef
  globalThis.WeakRef = new Proxy(NativeWeakRef, {
    construct(target, args, newTarget) {
      const reference = Reflect.construct(target, args, newTarget)
      references.push({ reference, stack: String(new Error().stack) })
      return reference
    },
  })
  globalThis.__codexWeakReferenceRegistry = references
}
