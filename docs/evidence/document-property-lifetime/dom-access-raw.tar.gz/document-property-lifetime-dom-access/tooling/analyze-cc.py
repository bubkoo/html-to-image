"""Read native CC ownership around the exact preserved-wrapper holder.

All incoming edges are retained. WeakMap entry records are not ordinary edges.
Marked JS nodes and RC roots are diagnostic boundaries, not application causes.
"""
from pathlib import Path
import collections, json, re, sys

heap_path, cc_path, out_path = map(Path, sys.argv[1:])
heap = json.loads(heap_path.read_text())
nodes, incoming, results, weak_maps = {}, collections.defaultdict(list), {}, []
current, after = None, False
for line in cc_path.read_text().splitlines():
    if line.startswith('=========='):
        after = True
        continue
    if line.startswith('WeakMapEntry '):
        weak_maps.append(line)
        continue
    m = re.match(r'^(0x[0-9a-f]+) (.*)$', line)
    if m:
        address, description = m.groups()
        if after:
            results[address] = description
        else:
            nodes[address] = description
            current = address
        continue
    m = re.match(r'^> (0x[0-9a-f]+) (.*)$', line)
    if m and not after:
        assert current
        to, label = m.groups()
        incoming[to].append({'from': current, 'edge': label})

holders = sorted({m.group(1) for _, paths in heap['paths']['gcRoot']
    for path in paths for edge in path
    if (m := re.search(r'Preserved wrapper, holder (0x[0-9a-f]+)', edge['edge']))})
def node(address):
    return {'address': address, 'description': nodes.get(address),
            'result': results.get(address), 'incoming': incoming.get(address, [])}

report = {'heap': str(heap_path), 'cc': str(cc_path),
    'wantAllTraces': cc_path.read_text().startswith('# WantAllTraces=true'),
    'nodes': len(nodes), 'edges': sum(map(len, incoming.values())),
    'weakMapRecords': len(weak_maps), 'targetJSAddress': hex(heap['ids']['target']),
    'target': node(hex(heap['ids']['target'])), 'holders': []}
for holder in holders:
    seen = {holder}
    queue = collections.deque([(holder, 0)])
    neighborhood = []
    while queue:
        address, depth = queue.popleft()
        entry = node(address)
        entry['depth'] = depth
        neighborhood.append(entry)
        if depth == 4 or '[gc' in nodes.get(address, ''):
            continue
        for edge in incoming.get(address, []):
            if edge['from'] not in seen:
                seen.add(edge['from'])
                queue.append((edge['from'], depth+1))
    report['holders'].append({'holder': node(holder), 'incomingNeighborhood': neighborhood})
report['limits'] = 'After cached primary and JS heap; explicit raw wrapper/debugger roots remain. Bounded depth-4 incoming neighborhood; weak-map records separate. Marked JS roots do not uniquely identify application ownership.'
weak = re.compile(r'\[weak\]|WeakRefObject::target|WeakMap entry')
seen, toward, boundaries = {report['targetJSAddress']}, {}, []
queue = collections.deque([report['targetJSAddress']])
while queue:
    address = queue.popleft()
    if '[gc.marked]' in nodes.get(address, '') or '[known=' in results.get(address, ''):
        steps, step = [], address
        while step != report['targetJSAddress']:
            edge = toward[step]
            steps.append(edge)
            step = edge['to']
        boundaries.append({'root':node(address),'path':steps})
        continue
    for edge in incoming.get(address, []):
        parent = edge['from']
        if not weak.search(edge['edge']) and parent not in seen:
            seen.add(parent)
            toward[parent] = {'from':parent,'edge':edge['edge'],'to':address}
            queue.append(parent)
report['conditionalBoundarySearch'] = {'visited':len(seen),'boundaries':boundaries,
    'limits':'Stops at black JS or RC known roots; explicit weak/WeakRef/WeakMap edges excluded, WeakMap records not modeled as unconditional ownership. Root paths are post-verdict evidence, not a pre-inspection cause.'}
conditional = []
for record in weak_maps:
    fields = dict(re.findall(r'(map|key|keyDelegate|value)=((?:0x[0-9a-f]+)|(?:\(nil\)))',record))
    if fields.get('value') in seen or fields.get('key') in seen:
        conditional.append({'record':record, 'nodes':{k:node(v) for k,v in fields.items() if v!='(nil)'}})
report['conditionalBoundarySearch']['relevantWeakMapRecords'] = conditional
out_path.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['nodes','edges','weakMapRecords','targetJSAddress']}))
for h in report['holders']:
    print(json.dumps(h['holder']))
for b in boundaries[:8]:
    print('boundary',json.dumps(b))
