import { checkCaptureLifetime } from "/Users/bytedance/.codex/worktrees/gc-native-release-controls/html-to-image/test/browser/fixtures/capture-lifetime.mjs";
import { checkMixedScroll, mixedScrollCases } from "/Users/bytedance/.codex/worktrees/gc-native-release-controls/html-to-image/test/browser/fixtures/mixed-scroll.mjs";
import { checkFixedScroll, fixedScrollCases } from "/Users/bytedance/.codex/worktrees/gc-native-release-controls/html-to-image/test/browser/fixtures/fixed-scroll.mjs";
import { checkPositionedScroll, positionedScrollCases } from "/Users/bytedance/.codex/worktrees/gc-native-release-controls/html-to-image/test/browser/fixtures/positioned-scroll.mjs";
import { checkScrollbarBox, scrollbarBoxCases } from "/Users/bytedance/.codex/worktrees/gc-native-release-controls/html-to-image/test/browser/fixtures/scrollbar-box.mjs";

window.runHTIUSBOffline = async function () {
  const api = window.htmlToImage;
  const cases = [['capture source document lifetime', () => checkCaptureLifetime(api)]];
  for (const [group, names, check] of [
    ['mixed scroll', mixedScrollCases, checkMixedScroll],
    ['fixed scroll', fixedScrollCases, checkFixedScroll],
    ['positioned scroll', positionedScrollCases, checkPositionedScroll],
    ['scrollbar box', scrollbarBoxCases, checkScrollbarBox],
  ]) for (const name of names) cases.push([group + ': ' + name, () => check(api, name)]);
  const result = window.__htiUSBOffline = {
    complete: false, format: 'unaltered built UMD', total: cases.length,
    userAgent: navigator.userAgent, dpr: devicePixelRatio,
    viewport: { width: innerWidth, height: innerHeight },
    delivery: 'page and bundle provided through automation, no HTTP server',
    gcAcceptance: false, nativeSourceScreenshots: false,
    verdicts: [], startedAt: new Date().toISOString(),
  };
  for (const [name, run] of cases) {
    result.currentCase = name;
    try { await run(); result.verdicts.push({name, status: 'PASS'}); }
    catch (error) { result.verdicts.push({name, status: 'FAIL', error: String(error.stack || error)}); }
    document.getElementById('results').textContent = JSON.stringify(result, null, 2);
  }
  result.httpResources = performance.getEntriesByType('resource').filter(entry => /^https?:/.test(entry.name)).map(entry => entry.name);
  result.complete = true;
  result.finishedAt = new Date().toISOString();
  document.getElementById('results').textContent = JSON.stringify(result, null, 2);
  return result;
};
