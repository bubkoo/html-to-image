(function () {
  'use strict';

  async function checkCaptureLifetime({ createRenderer }) {
    const frame = document.createElement('iframe');
    frame.srcdoc =
      '<body style="margin:0;width:20px;height:20px;background:green"></body>';
    const loaded = new Promise((resolve) => {
      frame.onload = resolve;
    });
    document.body.append(frame);
    const renderer = createRenderer({ pixelRatio: 1, skipFonts: true });
    try {
      await loaded;
      const capture = await renderer.capture(frame.contentDocument.body);
      frame.remove();
      const first = await capture.toCanvas();
      if (first.ownerDocument !== document)
        throw new Error('Canvas still belongs to the removed source document')
      if (first.width !== 20 || first.height !== 20)
        throw new Error(`Canvas dimensions ${first.width}x${first.height}`)
      first.getContext('2d').clearRect(0, 0, 20, 20);
      const second = await capture.toCanvas();
      const color = Array.from(
        second.getContext('2d').getImageData(10, 10, 1, 1).data,
      );
      if (second.ownerDocument !== document || color.join(',') !== '0,128,0,255')
        throw new Error(`Independent canvas document/pixel mismatch: ${color}`)
      capture.dispose();
      let rejected = false;
      try {
        await capture.toSvg();
      } catch (error) {
        rejected = /disposed/.test(error.message);
      }
      if (!rejected) throw new Error('Disposed capture remained usable')
    } finally {
      frame.remove();
      renderer.dispose();
    }
  }

  let sequence$3 = 0;
  const mixedScrollCases = [
    'direct',
    'wrapped',
    'padding',
    'negative-margin',
    'structural',
    'layered-structural',
    'before-block',
    'sticky',
    'fixed-inside',
    'nested',
    'rtl',
    'after',
    'inline-elements',
    'iframe',
  ];

  async function createMixedScrollScene(kind) {
    const root = document.createElement('div');
    root.id = `mixed-scroll-${++sequence$3}`;
    root.style.cssText = 'width:40px;height:20px;margin:0;padding:0';
    const panel = document.createElement('div');
    panel.id = root.id + '-panel';
    panel.style.cssText =
      'width:40px;height:20px;overflow:auto;scrollbar-width:none;line-height:20px;font:10px/20px monospace;background:red;margin:0;padding:0';
    panel.innerHTML = `${kind === 'wrapped' ? 'X X X X X X X X X X X X' : 'X'}<br><span class="mixed-marker" style="display:inline-block;width:40px;height:20px;background:green"></span><div style="height:80px;background:blue"></div>`;
    if (kind === 'rtl') panel.style.direction = 'rtl';
    if (kind === 'inline-elements')
      panel.firstChild.replaceWith(
        Object.assign(document.createElement('span'), { textContent: 'X' }),
      );
    const target = panel.querySelector('.mixed-marker');
    let overlay;
    if (kind === 'padding') {
      panel.style.padding = '3px';
      panel.style.border = '1px solid red';
      root.style.width = '48px';
      root.style.height = '28px';
    }
    if (kind === 'negative-margin') {
      const margin = document.createElement('div');
      margin.style.cssText = 'height:20px;margin-top:-7px;background:red';
      panel.prepend(margin);
    }
    if (
      kind === 'structural' ||
      kind === 'layered-structural' ||
      kind === 'before-block' ||
      kind === 'after'
    ) {
      const style = document.createElement('style');
      const rule =
        kind === 'after'
          ? `#${panel.id}::after{content:"";display:block;height:80px;background:blue}`
          : kind === 'before-block'
            ? `#${panel.id}::before{content:"";display:block;width:40px;height:20px;margin-top:-3px;background:red}`
            : `#${panel.id}::before{content:none!important} #${panel.id}>.mixed-marker:nth-child(2){background:green!important} #${panel.id}>.mixed-marker:nth-child(3){background:red!important}`;
      style.textContent =
        kind === 'layered-structural' ? `@layer source {${rule}}` : rule;
      panel.append(style);
    }
    if (kind === 'sticky' || kind === 'fixed-inside') {
      overlay = document.createElement('div');
      overlay.style.cssText = `position:${kind === 'sticky' ? 'sticky' : 'fixed'};top:0;left:0;width:40px;height:4px;background:blue;z-index:10`;
      if (kind === 'sticky') target.before(overlay);
      else {
        panel.style.transform = 'translate(0,0)';
        panel.prepend(overlay);
      }
    }
    root.append(panel);
    document.body.append(root);
    const align = (scroller, marker) => {
      const top =
        marker.getBoundingClientRect().top -
        scroller.getBoundingClientRect().top -
        scroller.clientTop;
      scroller.scrollTop += top;
    };
    align(panel, target);
    let outer;
    if (kind === 'nested') {
      outer = document.createElement('div');
      outer.style.cssText =
        'width:40px;height:20px;overflow:auto;scrollbar-width:none;font:10px/20px monospace;background:red';
      root.replaceChildren(outer);
      outer.append('X', document.createElement('br'), panel);
      const tail = document.createElement('div');
      tail.style.height = '80px';
      outer.append(tail);
      align(panel, target);
      align(outer, panel);
    }
    if (kind === 'iframe') {
      const frame = document.createElement('iframe');
      frame.style.cssText = 'display:block;width:40px;height:20px;border:0';
      root.replaceChildren(frame);
      const loaded = new Promise((resolve, reject) => {
        const timer = setTimeout(
          () => reject(new Error('iframe fixture timeout')),
          5000,
        );
        frame.onload = () => {
          clearTimeout(timer);
          resolve();
        };
      });
      frame.srcdoc =
        '<body style="margin:0;padding:0;width:40px;background:red;font:10px/20px monospace">X<br><span id="target" style="display:inline-block;width:40px;height:20px;background:green"></span><div style="height:80px;background:blue"></div></body>';
      try {
        await loaded;
      } catch (error) {
        root.remove();
        throw error
      }
      const target = frame.contentDocument.querySelector('#target');
      frame.contentWindow.scrollTo(0, target.getBoundingClientRect().top);
      const scrollY = frame.contentWindow.scrollY;
      return {
        root,
        panel: frame.contentDocument.body,
        frame,
        points: [
          {
            x: Math.min(
              30,
              Math.floor(frame.contentDocument.documentElement.clientWidth / 2),
            ),
            y: Math.min(
              10,
              Math.floor(frame.contentDocument.documentElement.clientHeight / 2),
            ),
            expected: '0,128,0,255',
          },
        ],
        source: root.outerHTML,
        scroll: [frame.contentDocument.body.scrollTop, 0],
        frameScroll: scrollY,
        cleanup: () => root.remove(),
      }
    }
    const rootBox = root.getBoundingClientRect();
    const targetBox = target.getBoundingClientRect();
    const points = [
      {
        x: Math.round(targetBox.left - rootBox.left + 30),
        y: Math.round(targetBox.top - rootBox.top + 10),
        expected: '0,128,0,255',
      },
    ];
    if (kind === 'negative-margin')
      points.push({ x: 30, y: 2, expected: '0,128,0,255' });
    if (overlay) {
      const x = 30,
        y = 2;
      const box = overlay.getBoundingClientRect();
      const visible =
        box.left <= rootBox.left + x &&
        box.right > rootBox.left + x &&
        box.top <= rootBox.top + y &&
        box.bottom > rootBox.top + y;
      points.push({ x, y, expected: visible ? '0,0,255,255' : '0,128,0,255' });
    }
    return {
      root,
      panel,
      outer,
      points,
      source: root.outerHTML,
      scroll: [panel.scrollTop, outer?.scrollTop || 0],
      cleanup: () => root.remove(),
    }
  }

  async function checkMixedScroll(api, kind, readNative) {
    const scene = await createMixedScrollScene(kind);
    const renderer = api.createRenderer({ pixelRatio: 1, skipFonts: true });
    try {
      if (readNative) {
        const native = await readNative(scene.root.id);
        scene.points.forEach(({ x, y, expected }) => {
          const offset = 4 * (y * native.width + x);
          const actual = Array.from(native.data.slice(offset, offset + 4)).join(
            ',',
          );
          if (actual !== expected)
            throw new Error(
              `${kind} native control ${x},${y}: ${actual}, expected ${expected}`,
            )
        });
      }
      const capture = await renderer.capture(scene.root);
      const image = await capture.toImageData();
      scene.points.forEach(({ x, y, expected }) => {
        const offset = 4 * (y * image.width + x);
        const actual = Array.from(image.data.slice(offset, offset + 4)).join(',');
        if (actual !== expected)
          throw new Error(
            `${kind} captured ${x},${y}: ${actual}, expected ${expected}`,
          )
      });
      if (
        scene.root.outerHTML !== scene.source ||
        scene.panel.scrollTop !== scene.scroll[0] ||
        (scene.outer?.scrollTop || 0) !== scene.scroll[1] ||
        (scene.frame && scene.frame.contentWindow.scrollY !== scene.frameScroll)
      )
        throw new Error('Source scroll or DOM changed')
      capture.dispose();
      return true
    } finally {
      renderer.dispose();
      scene.cleanup();
    }
  }

  let sequence$2 = 0;

  const fixedScrollCases = [
    'transform-block',
    'transform-sticky-first',
    'transform-sticky-last',
    'transform-horizontal',
    'transform-diagonal',
    'filter-block',
    'perspective-block',
    'contain-block',
    'will-change-block',
    'translate-block',
    'transform-mixed',
    'filter-mixed',
    'viewport-block',
    'viewport-mixed',
    'transform-nested',
    'viewport-nested',
    'transform-visible',
    'transform-bottom',
    'transform-auto',
    'transform-right-horizontal',
    'transform-rtl-horizontal',
    'transform-chain',
    'transform-transformed-chain',
    'transform-inner',
    'ancestor-block',
    'relative-block',
    'transform-important',
    'transform-selected-bottom',
    'transform-selected-auto',
    'transform-selected-right-horizontal',
  ];

  async function createFixedScrollScene(kind) {
    const root = document.createElement('div');
    root.id = `fixed-scroll-${++sequence$2}`;
    root.style.cssText =
      'position:absolute;left:0;top:0;width:40px;height:40px;overflow:hidden;margin:0;padding:0';
    const panel = document.createElement('div');
    panel.style.cssText =
      'width:40px;height:40px;overflow:auto;scrollbar-width:none;margin:0;padding:0;font:10px/20px monospace';
    const mode = kind.split('-')[0];
    const properties = {
      transform: 'transform:translate(0,0)',
      filter: 'filter:opacity(1)',
      perspective: 'perspective:100px',
      contain: 'contain:paint',
      will: 'will-change:transform',
      translate: 'translate:0px',
      relative: 'position:relative',
    };
    panel.style.cssText += ';' + (properties[mode] || '');
    const fixed = document.createElement('div');
    fixed.style.cssText =
      'position:fixed;left:0;top:0;width:40px;height:4px;background:blue;z-index:10';
    fixed.id = root.id + '-fixed';
    const red = document.createElement('div');
    red.style.cssText = 'width:40px;height:40px;background:red;flex:none';
    const green = document.createElement('div');
    green.style.cssText = 'width:40px;height:80px;background:green;flex:none';
    const mixed = kind.endsWith('mixed');
    if (mixed) panel.append('X', document.createElement('br'));
    const nested = kind.endsWith('nested');
    if (nested) {
      if (mode === 'viewport') red.style.height = '60px';
      else fixed.style.top = '44px';
      green.append(fixed);
      panel.append(red, green);
    } else panel.append(fixed, red, green);
    if (kind.endsWith('inner')) {
      green.style.transform = 'translate(0,0)';
      fixed.style.top = '4px';
      green.append(fixed);
    }
    if (kind.endsWith('chain')) {
      fixed.style.top = '44px';
      const inner = document.createElement('div');
      inner.style.cssText =
        'position:fixed;top:52px;left:0;width:40px;height:4px;background:blue';
      if (kind.includes('transformed')) {
        fixed.style.transform = 'translate(2px,1px)';
        inner.style.top = '8px';
      }
      fixed.append(inner);
    }
    if (kind.endsWith('important')) {
      const style = document.createElement('style');
      style.textContent = `#${fixed.id}{top:44px!important}`;
      panel.append(style);
    }
    if (kind.endsWith('bottom')) {
      fixed.style.top = 'auto';
      fixed.style.bottom = '0';
    }
    if (kind.endsWith('auto')) {
      fixed.style.top = 'auto';
      fixed.style.left = 'auto';
    }
    if (mode === 'ancestor') root.style.transform = 'translate(0,0)';
    const sticky = kind.includes('sticky');
    if (sticky) {
      const header = document.createElement('div');
      header.style.cssText =
        'position:sticky;top:8px;width:40px;height:10px;background:red';
      panel.insertBefore(header, green);
      if (kind.endsWith('last')) panel.append(fixed);
    }
    const horizontal = kind.endsWith('horizontal');
    const diagonal = kind.endsWith('diagonal');
    if (horizontal) {
      panel.style.display = 'flex';
      green.style.height = '40px';
      fixed.style.width = '4px';
      fixed.style.height = '40px';
      if (kind.includes('right')) {
        fixed.style.left = 'auto';
        fixed.style.right = '0';
      }
      if (kind.includes('rtl')) panel.style.direction = 'rtl';
    }
    if (diagonal) {
      red.style.width = '80px';
      green.style.width = '80px';
    }
    if (kind.endsWith('visible')) {
      fixed.style.top = '44px';
      fixed.style.transform = 'translate(2px,1px)';
    }
    root.append(panel);
    document.body.append(root);
    panel.scrollTop = horizontal ? 0 : sticky ? 50 : mixed ? 60 : 40;
    panel.scrollLeft = kind.includes('rtl')
      ? -40
      : horizontal || diagonal
        ? 40
        : 0;
    const points = [{ x: 20, y: 25, expected: '0,128,0,255' }];
    points.push({
      x: horizontal ? 2 : 20,
      y: horizontal ? 20 : 2,
      expected: ['viewport', 'ancestor', 'relative'].includes(mode)
        ? '0,0,255,255'
        : '0,128,0,255',
    });
    if (sticky) points.push({ x: 20, y: 13, expected: '255,0,0,255' });
    if (nested && mode !== 'viewport')
      points.push({ x: 20, y: 6, expected: '0,0,255,255' });
    if (kind.endsWith('visible'))
      points.push({ x: 20, y: 7, expected: '0,0,255,255' });
    if (kind.endsWith('bottom'))
      points.push({ x: 20, y: 38, expected: '0,128,0,255' });
    if (kind.includes('right') && horizontal)
      points.push({ x: 38, y: 20, expected: '0,128,0,255' });
    if (kind.endsWith('important') || kind.endsWith('inner'))
      points.push({ x: 20, y: 6, expected: '0,0,255,255' });
    if (kind.endsWith('chain')) {
      points.push({ x: 20, y: 6, expected: '0,0,255,255' });
      points.push({ x: 20, y: 14, expected: '0,0,255,255' });
    }
    return {
      root,
      panel,
      points,
      source: root.outerHTML,
      scroll: [panel.scrollLeft, panel.scrollTop],
      options: kind.includes('selected')
        ? {
            stylePropertiesForNode: (source) =>
              source.id.endsWith('-fixed') ? [] : undefined,
          }
        : {},
      cleanup: () => root.remove(),
    }
  }

  async function checkFixedScroll(api, kind, readNative) {
    const scene = await createFixedScrollScene(kind);
    const renderer = api.createRenderer({
      pixelRatio: 1,
      skipFonts: true,
      ...scene.options,
    });
    const check = (image, label) => {
      scene.points.forEach(({ x, y, expected }) => {
        const offset = 4 * (y * image.width + x);
        const actual = Array.from(image.data.slice(offset, offset + 4)).join(',');
        if (actual !== expected)
          throw new Error(
            `${kind} ${label} ${x},${y}: ${actual}, expected ${expected}`,
          )
      });
    };
    try {
      if (readNative) check(await readNative(scene.root.id), 'native control');
      const capture = await renderer.capture(scene.root);
      check(await capture.toImageData(), 'capture');
      if (
        scene.root.outerHTML !== scene.source ||
        scene.panel.scrollLeft !== scene.scroll[0] ||
        scene.panel.scrollTop !== scene.scroll[1]
      )
        throw new Error('Source DOM or scroll changed')
      capture.dispose();
      return true
    } finally {
      renderer.dispose();
      scene.cleanup();
    }
  }

  let sequence$1 = 0;

  const positionedScrollCases = [
    'local-nested',
    'local-deep',
    'viewport-nested',
    'ancestor-nested',
    'wrapper-nested',
    'local-rtl',
    'local-reverse',
    'local-relative',
    'local-absolute',
    'local-margin',
    'local-important',
    'local-selected',
    'local-diagonal',
    'viewport-diagonal',
    'ancestor-diagonal',
    'wrapper-diagonal',
    'local-diagonal-deep',
    'local-diagonal-absolute',
    'local-diagonal-important',
    'local-diagonal-selected',
    'local-diagonal-rtl',
    'local-column',
    'local-column-reverse',
    'local-column-diagonal',
    'local-column-diagonal-rtl',
    'local-wrap',
    'local-wrap-reverse',
    'local-center-diagonal',
    'local-baseline-diagonal',
    'local-absolute-only',
    'local-absolute-only-diagonal',
    'local-relative-absolute-only-diagonal',
    'ancestor-absolute-only-diagonal',
    'wrapper-absolute-only-diagonal',
    'local-block-horizontal',
    'viewport-block-horizontal',
    'ancestor-block-horizontal',
    'wrapper-block-horizontal',
    'local-block-diagonal',
    'viewport-block-diagonal',
    'ancestor-block-diagonal',
    'wrapper-block-diagonal',
    'local-block-diagonal-absolute',
    'local-block-diagonal-rtl',
    'local-block-diagonal-deep',
    'local-block-diagonal-important',
    'local-block-diagonal-selected',
    'local-block-absolute-only-diagonal',
    'local-block-relative-absolute-only-diagonal',
    'local-block-vertical',
    'local-block-absolute-only-vertical',
    'relative-block-absolute-only-diagonal',
    'local-block-before-diagonal',
    'local-block-after-diagonal',
    'local-block-absolute-only-sticky-vertical',
  ];

  async function createPositionedScrollScene(kind) {
    const root = document.createElement('div');
    root.id = `positioned-scroll-${++sequence$1}`;
    root.style.cssText =
      'position:absolute;left:0;top:0;width:40px;height:40px;overflow:hidden;margin:0;padding:0;background:white';
    const panel = document.createElement('div');
    panel.id = root.id + '-panel';
    panel.style.cssText =
      'width:40px;height:40px;overflow:auto;scrollbar-width:none;display:flex;flex-wrap:nowrap;align-items:flex-start;margin:0;padding:0';
    if (kind.startsWith('local')) panel.style.transform = 'translate(0,0)';
    if (kind.startsWith('ancestor')) root.style.transform = 'translate(0,0)';
    if (kind.startsWith('relative')) panel.style.position = 'relative';
    if (kind.endsWith('rtl')) panel.style.direction = 'rtl';
    if (kind === 'local-reverse') panel.style.flexDirection = 'row-reverse';
    const column = kind.includes('column');
    const wrapped = kind.includes('wrap') && !kind.startsWith('wrapper');
    if (column)
      panel.style.flexDirection = kind.includes('column-reverse')
        ? 'column-reverse'
        : 'column';
    if (wrapped)
      panel.style.flexWrap = kind.endsWith('wrap-reverse')
        ? 'wrap-reverse'
        : 'wrap';
    if (kind.includes('center')) panel.style.alignItems = 'center';
    if (kind.includes('baseline')) panel.style.alignItems = 'baseline';
    const red = document.createElement('div');
    red.style.cssText = 'width:48px;height:40px;background:red;flex:none';
    const green = document.createElement('div');
    green.style.cssText = 'width:80px;height:40px;background:green;flex:none';
    if (kind.includes('diagonal')) red.style.height = green.style.height = '80px';
    if (column) {
      red.style.height = '48px';
      green.style.height = '80px';
      red.style.width = green.style.width = kind.includes('diagonal')
        ? '80px'
        : '40px';
    }
    const block = kind.includes('block');
    if (block) {
      panel.style.display = 'block';
      red.style.width = '88px';
      red.style.height = kind.includes('horizontal') ? '0' : '48px';
      green.style.width = '80px';
      green.style.height = kind.includes('horizontal') ? '40px' : '80px';
      green.style.marginLeft = '8px';
    }
    if (kind.startsWith('wrapper')) green.style.transform = 'translate(0,0)';
    if (kind.includes('-relative')) green.style.position = 'relative';
    if (kind.endsWith('margin')) {
      red.style.marginLeft = '3px';
      green.style.marginRight = '5px';
    }
    const fixed = document.createElement('div');
    fixed.id = root.id + '-fixed';
    fixed.style.cssText =
      'position:fixed;left:0;top:0;width:4px;height:40px;background:blue;z-index:10';
    if (kind.includes('absolute-only')) fixed.style.position = 'absolute';
    if (kind.endsWith('deep')) {
      const inner = document.createElement('div');
      inner.style.cssText = 'width:80px;height:40px';
      inner.append(fixed);
      green.append(inner);
    } else green.append(fixed);
    panel.append(red, green);
    if (block && kind.includes('sticky')) {
      const header = document.createElement('div');
      header.style.cssText =
        'position:sticky;top:0;height:4px;width:88px;background:red;z-index:1';
      green.before(header);
    }
    root.append(panel);
    if (block && /before|after/.test(kind)) {
      red.style.height = green.style.height = '0';
      const sheet = document.createElement('style');
      const pseudo = kind.includes('before') ? 'before' : 'after';
      sheet.textContent = `#${panel.id}::${pseudo}{content:"";display:block;width:88px;height:88px;background:green;box-shadow:inset 40px 0 0 red}`;
      root.append(sheet);
    }
    document.body.append(root);
    panel.scrollLeft =
      (column && !kind.includes('diagonal')) || kind.endsWith('vertical')
        ? 0
        : kind.endsWith('rtl') || kind === 'local-reverse'
          ? -40
          : 40;
    panel.scrollTop = kind.includes('sticky')
      ? 60
      : kind.includes('column-reverse') || kind.endsWith('wrap-reverse')
        ? -40
        : kind.includes('diagonal') ||
            column ||
            wrapped ||
            kind.endsWith('vertical')
          ? 40
          : 0;
    // Place the source's blue stripe at x=4, y=0 regardless of its containing
    // block. Native screenshots independently assert this setup before capture.
    const container = fixed.offsetParent;
    const left =
      4 -
      (container?.getBoundingClientRect().left || 0) +
      (container?.scrollLeft || 0);
    fixed.style.setProperty(
      'left',
      `${left}px`,
      kind.endsWith('important') ? 'important' : '',
    );
    const top =
      -(container?.getBoundingClientRect().top || 0) + (container?.scrollTop || 0);
    fixed.style.setProperty(
      'top',
      `${top}px`,
      kind.endsWith('important') ? 'important' : '',
    );
    if (kind.endsWith('absolute')) {
      const absolute = document.createElement('div');
      absolute.style.cssText =
        'position:absolute;left:52px;top:0;width:4px;height:40px;background:purple;z-index:11';
      green.append(absolute);
      const anchor = absolute.offsetParent;
      absolute.style.left = `${12 - (anchor?.getBoundingClientRect().left || 0) + (anchor?.scrollLeft || 0)}px`;
      absolute.style.top = `${-(anchor?.getBoundingClientRect().top || 0) + (anchor?.scrollTop || 0)}px`;
    }
    const points = [
      { x: 6, y: 20, expected: '0,0,255,255' },
      { x: 20, y: 20, expected: '0,128,0,255' },
    ];
    if (kind.endsWith('absolute'))
      points.push({ x: 14, y: 20, expected: '128,0,128,255' });
    return {
      root,
      panel,
      points,
      source: root.outerHTML,
      scroll: [panel.scrollLeft, panel.scrollTop],
      options: kind.endsWith('selected')
        ? {
            stylePropertiesForNode: (source) =>
              source === fixed ? [] : undefined,
          }
        : {},
      cleanup: () => root.remove(),
    }
  }

  async function checkPositionedScroll(api, kind, readNative) {
    const scene = await createPositionedScrollScene(kind);
    const renderer = api.createRenderer({
      pixelRatio: 1,
      skipFonts: true,
      ...scene.options,
    });
    const check = (image, label) => {
      scene.points.forEach(({ x, y, expected }) => {
        const start = 4 * (y * image.width + x);
        const actual = Array.from(image.data.slice(start, start + 4)).join(',');
        if (actual !== expected)
          throw new Error(
            `${kind} ${label} ${x},${y}: ${actual}, expected ${expected}`,
          )
      });
    };
    try {
      if (
        (kind.includes('diagonal') || wrappedKind(kind)) &&
        (!scene.scroll[0] || !scene.scroll[1])
      )
        throw new Error(
          `${kind} source did not scroll on both axes: ${scene.scroll}`,
        )
      if (kind.endsWith('horizontal') && !scene.scroll[0])
        throw new Error(`${kind} source did not scroll horizontally`)
      if (
        (kind.includes('column') || kind.endsWith('vertical')) &&
        !scene.scroll[1]
      )
        throw new Error(`${kind} source did not scroll vertically`)
      const native = readNative ? await readNative(scene.root.id) : undefined;
      if (native) check(native, 'native control');
      const capture = await renderer.capture(scene.root);
      const image = await capture.toImageData();
      check(image, 'capture');
      if (native) {
        if (image.width !== native.width || image.height !== native.height)
          throw new Error(`${kind} native/capture dimensions differ`)
        const different = image.data.findIndex(
          (value, index) => value !== native.data[index],
        );
        if (different !== -1)
          throw new Error(
            `${kind} native/capture pixel channel ${different}: ${image.data[different]}, expected ${native.data[different]}`,
          )
      }
      capture.dispose();
      if (
        scene.source !== scene.root.outerHTML ||
        scene.scroll[0] !== scene.panel.scrollLeft ||
        scene.scroll[1] !== scene.panel.scrollTop
      )
        throw new Error('Source DOM or scroll changed')
      return true
    } finally {
      renderer.dispose();
      scene.cleanup();
    }
  }

  function wrappedKind(kind) {
    return kind.includes('wrap') && !kind.startsWith('wrapper')
  }

  let sequence = 0;
  const scrollbarBoxCases = [
    'content',
    'border',
    'padding',
    'fractional',
    'gutter',
    'vertical',
    'legacy-fractional',
    'legacy-gutter',
    'selected-empty',
    'selected-logical',
    'scrolled',
    'scrolled-gutter',
  ];

  async function checkScrollbarBox(api, kind, readNative, record) {
    const root = document.createElement('div');
    root.id = `scrollbar-box-${++sequence}`;
    root.style.cssText =
      'position:absolute;left:0;top:0;overflow:hidden;background:white;margin:0;padding:0';
    const panel = document.createElement('div');
    panel.id = root.id + '-panel';
    panel.style.cssText =
      'width:100px;height:100px;overflow:scroll;background:green;scrollbar-color:black red;scrollbar-width:thin';
    panel.style.colorScheme = 'light';
    if (kind === 'border') panel.style.boxSizing = 'border-box';
    if (kind === 'padding')
      panel.style.cssText += ';padding:3px;border:1px solid blue';
    if (kind === 'fractional' || kind.startsWith('legacy'))
      panel.style.width = panel.style.height = '100.5px';
    if (
      kind === 'gutter' ||
      kind === 'legacy-gutter' ||
      kind === 'scrolled-gutter'
    )
      panel.style.scrollbarGutter = 'stable both-edges';
    if (kind === 'vertical') panel.style.writingMode = 'vertical-rl';
    panel.innerHTML =
      '<div style="position:relative;width:200px;height:300px;background:green"><div style="position:absolute;left:44px;top:54px;width:4px;height:4px;background:blue"></div></div>';
    root.append(panel);
    if (kind.startsWith('legacy')) {
      panel.style.scrollbarColor = 'auto';
      panel.style.scrollbarWidth = 'auto';
      const sheet = document.createElement('style');
      sheet.textContent = `#${panel.id}::-webkit-scrollbar{width:10.5px;height:10.5px;background:red}#${panel.id}::-webkit-scrollbar-track{background:red}#${panel.id}::-webkit-scrollbar-thumb{background:black;border-radius:0}#${panel.id}::-webkit-scrollbar-corner{background:blue}`;
      root.append(sheet);
    }
    document.body.append(root);
    const bounds = panel.getBoundingClientRect();
    root.style.width = `${Math.ceil(bounds.width)}px`;
    root.style.height = `${Math.ceil(bounds.height)}px`;
    const options = { pixelRatio: 1, skipFonts: true };
    if (kind.startsWith('selected'))
      options.stylePropertiesForNode = (node) =>
        node === panel
          ? kind === 'selected-empty'
            ? []
            : ['inline-size', 'block-size']
          : undefined;
    if (kind.startsWith('scrolled')) {
      panel.scrollLeft = 40;
      panel.scrollTop = 50;
    }
    const renderer = api.createRenderer(options);
    try {
      const source = root.outerHTML,
        offsets = [panel.scrollLeft, panel.scrollTop];
      const css = getComputedStyle(panel);
      const metrics = {
        kind,
        boxSizing: css.boxSizing,
        resolved: [css.width, css.height],
        client: [panel.clientWidth, panel.clientHeight],
        outer: [bounds.width, bounds.height],
        offsets,
        clientOrigin: [panel.clientLeft, panel.clientTop],
        engine: /Firefox/.test(navigator.userAgent)
          ? 'firefox'
          : /Chrome/.test(navigator.userAgent)
            ? 'chromium'
            : 'webkit',
        userAgent: navigator.userAgent,
      };
      const native = readNative ? await readNative(root.id) : undefined;
      const capture = await renderer.capture(root);
      try {
        const frozen = new DOMParser().parseFromString(
          decodeURIComponent(
            (await capture.toSvg()).split(',').slice(1).join(','),
          ),
          'image/svg+xml',
        );
        const frame = document.createElement('iframe');
        frame.style.cssText =
          'position:absolute;left:200px;top:0;width:160px;height:160px;border:0';
        const loaded = new Promise((resolve) => {
          frame.onload = resolve;
        });
        frame.srcdoc =
          '<!doctype html><body style="margin:0">' +
          [...frozen.querySelectorAll('style')].map((s) => s.outerHTML).join('') +
          frozen.querySelector('foreignObject').innerHTML +
          '</body>';
        document.body.append(frame);
        try {
          await loaded;
          const copy = frame.contentDocument.getElementById(panel.id);
          const rect = copy.getBoundingClientRect();
          metrics.serializedOuter = [rect.width, rect.height];
          metrics.serializedViewport = [copy.clientWidth, copy.clientHeight];
          const expected = kind.startsWith('scrolled')
            ? metrics.client
            : metrics.outer;
          const actual = kind.startsWith('scrolled')
            ? metrics.serializedViewport
            : metrics.serializedOuter;
          if (actual.some((value, i) => value !== expected[i]))
            throw new Error(`${kind}: source box ${expected} became ${actual}`)
        } finally {
          frame.remove();
        }
        const image = await capture.toImageData();
        const png = (data) => {
          const canvas = document.createElement('canvas');
          canvas.width = data.width;
          canvas.height = data.height;
          canvas.getContext('2d').putImageData(data, 0, 0);
          return canvas.toDataURL().split(',')[1]
        };
        if (
          image.width !== Math.ceil(bounds.width) ||
          image.height !== Math.ceil(bounds.height)
        )
          throw new Error(`${kind}: captured outer size changed`)
        if (kind.startsWith('scrolled')) {
          if (native) {
            let different = 0;
            for (let y = 0; y < panel.clientHeight; y++)
              for (let x = 0; x < panel.clientWidth; x++)
                for (let c = 0; c < 4; c++)
                  if (
                    image.data[
                      4 *
                        ((y + panel.clientTop) * image.width +
                          x +
                          panel.clientLeft) +
                        c
                    ] !==
                    native.data[
                      4 *
                        ((y + panel.clientTop) * native.width +
                          x +
                          panel.clientLeft) +
                        c
                    ]
                  )
                    different++;
            if (record)
              await record({
                ...metrics,
                native: png(native),
                capture: png(image),
                nativeContentDifferentChannels: different,
              });
            if (different)
              throw new Error(
                `${kind}: native content viewport differs in ${different} channels`,
              )
            metrics.nativeContentDifferentChannels = different;
          } else {
            const start =
              4 * ((5 + panel.clientTop) * image.width + 5 + panel.clientLeft);
            if (
              Array.from(image.data.slice(start, start + 4)).join() !==
              '0,0,255,255'
            )
              throw new Error('Scrolled blue marker lost')
          }
        } else {
          const html = root.outerHTML.replace(
            '<div',
            '<div xmlns="http://www.w3.org/1999/xhtml"',
          );
          const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${image.width}" height="${image.height}"><foreignObject width="100%" height="100%">${html}</foreignObject></svg>`;
          const manual = new Image();
          manual.src =
            'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
          await manual.decode();
          const c = document.createElement('canvas');
          c.width = image.width;
          c.height = image.height;
          const ctx = c.getContext('2d');
          ctx.drawImage(manual, 0, 0);
          const authored = ctx.getImageData(0, 0, c.width, c.height);
          const difference = (a, b) =>
            a.data.reduce((n, v, i) => n + (v !== b.data[i] ? 1 : 0), 0);
          const libraryAuthored = difference(image, authored);
          metrics.libraryAuthoredDifferentChannels = libraryAuthored;
          if (native) {
            if (native.width !== image.width || native.height !== image.height)
              throw new Error(`${kind}: source/capture dimensions differ`)
            metrics.nativeDifferentChannels = difference(image, native);
            metrics.nativeAuthoredDifferentChannels = difference(authored, native);
            metrics.nativeHorizontalScrollbarDifferentChannels =
              image.data.reduce(
                (count, value, i) =>
                  count +
                  (value !== native.data[i] &&
                  Math.floor(i / 4 / image.width) >=
                    panel.clientTop + panel.clientHeight
                    ? 1
                    : 0),
                0,
              );
          }
          if (record)
            await record({
              ...metrics,
              native: native && png(native),
              capture: png(image),
              authored: png(authored),
              authoredSvg:
                native && metrics.nativeDifferentChannels ? svg : undefined,
              frozenSvg:
                native && metrics.nativeDifferentChannels
                  ? frozen.documentElement.outerHTML
                  : undefined,
            });
          if (libraryAuthored)
            throw new Error(
              `${kind}: frozen box differs from the original authored SVG in ${libraryAuthored} channels; metrics=${JSON.stringify(metrics)}`,
            )
          if (!native) {
            const x = kind === 'vertical' ? 30 : 5,
              y = 5,
              k = 4 * (y * image.width + x);
            if (Array.from(image.data.slice(k, k + 4)).join() !== '0,128,0,255')
              throw new Error(`${kind}: capture lost the green content`)
          }
        }
        if (
          root.outerHTML !== source ||
          offsets[0] !== panel.scrollLeft ||
          offsets[1] !== panel.scrollTop
        )
          throw new Error(`${kind}: source mutated`)
        return metrics
      } finally {
        capture.dispose();
      }
    } finally {
      renderer.dispose();
      root.remove();
    }
  }

  window.runHTIUSBOffline = async function () {
    const api = window.htmlToImage;
    const cases = [['capture source document lifetime', () => checkCaptureLifetime(api)]];
    for (const [group, names, check] of [
      ['mixed scroll', mixedScrollCases, checkMixedScroll],
      ['fixed scroll', fixedScrollCases, checkFixedScroll],
      ['positioned scroll', positionedScrollCases, checkPositionedScroll],
      ['scrollbar box', scrollbarBoxCases, checkScrollbarBox],
    ]) for (const name of names) cases.push([group + ': ' + name, () => check(api, name)]);
    const result = window.__htiUSBOffline = {
      complete: false, format: 'unaltered built UMD', total: cases.length,
      userAgent: navigator.userAgent, dpr: devicePixelRatio,
      viewport: { width: innerWidth, height: innerHeight },
      delivery: 'page and bundle provided through automation, no HTTP server',
      gcAcceptance: false, nativeSourceScreenshots: false,
      verdicts: [], startedAt: new Date().toISOString(),
    };
    for (const [name, run] of cases) {
      result.currentCase = name;
      try { await run(); result.verdicts.push({name, status: 'PASS'}); }
      catch (error) { result.verdicts.push({name, status: 'FAIL', error: String(error.stack || error)}); }
      document.getElementById('results').textContent = JSON.stringify(result, null, 2);
    }
    result.httpResources = performance.getEntriesByType('resource').filter(entry => /^https?:/.test(entry.name)).map(entry => entry.name);
    result.complete = true;
    result.finishedAt = new Date().toISOString();
    document.getElementById('results').textContent = JSON.stringify(result, null, 2);
    return result;
  };

})();
