/* Explicitly held root-class counterfactual; this does not replace original GC acceptance. */
const {firefox}=require('playwright'),http=require('node:http'),fs=require('node:fs'),path=require('node:path')
const folder='.codex-linux-control/dom-paired-cache-positivefirst';fs.mkdirSync(folder,{recursive:true})
const roots={baseline:path.resolve('.codex-linux-control/dom-pair-baseline'),candidate:process.cwd()}
const server=http.createServer((request,response)=>{
 try{const url=new URL(request.url,'http://localhost'),parts=url.pathname.split('/').filter(Boolean),root=roots[parts.shift()];if(url.pathname==='/'){response.setHeader('Content-Type','text/html');response.end('<!doctype html><body></body>');return}if(!root)throw Error('unknown root');const file=path.resolve(root,...parts);if(!file.startsWith(root+path.sep))throw Error('path outside root');const body=fs.readFileSync(file);response.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'application/octet-stream');response.setHeader('Cache-Control','no-store');response.end(body)}catch{response.writeHead(404).end()}
})
;(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port,browser=await firefox.launch()
 try{
  const page=await browser.newPage();await page.goto(origin)
  await page.evaluate(async()=>{globalThis.__pairLibraries=[];for(const label of ['baseline','candidate'])globalThis.__pairLibraries.push({label:label+'-esm',library:await import('/'+label+'/es/index.js')})})
  for(const label of ['baseline','candidate']){await page.addScriptTag({url:origin+'/'+label+'/dist/html-to-image.js'});await page.evaluate(label=>{globalThis.__pairLibraries.push({label:label+'-umd',library:globalThis.htmlToImage})},label)}
  const outputs=await page.evaluate(async()=>{
   const frame=document.createElement('iframe');frame.srcdoc='<body style="margin:0;width:20px;height:20px;background:green"></body>';const loaded=new Promise(resolve=>frame.onload=resolve);document.body.append(frame);await loaded
   const source=frame.contentDocument;globalThis.__codexKnownOwner={knownOwnedDocument:source};globalThis.__codexPositiveRef=new WeakRef(source);globalThis.__codexNegativeRef=new WeakRef(document.implementation.createHTMLDocument());globalThis.__pairCaptures=[]
   try{for(const {label,library} of globalThis.__pairLibraries){const renderer=library.createRenderer({pixelRatio:1,skipFonts:true});let capture;for(let i=0;i<8;i++){capture?.dispose();capture=await renderer.capture(source.body)}const image=await capture.toImageData();globalThis.__pairCaptures.push({label,renderer,capture,width:image.width,height:image.height,pixel:Array.from(image.data.slice(0,4))})}return globalThis.__pairCaptures.map(({label,width,height,pixel})=>({label,width,height,pixel}))}
   finally{frame.remove()}
  })
  for(const row of outputs)if(row.width!==20||row.height!==20||JSON.stringify(row.pixel)!=='[0,128,0,255]')throw Error('Paired output mismatch '+JSON.stringify(row))
  for(let i=0;i<3;i++){await page.requestGC();await page.evaluate(()=>undefined)}
  const primary=await page.evaluate(()=>({positiveHeld:globalThis.__codexPositiveRef.deref()!==undefined,negativeCollected:globalThis.__codexNegativeRef.deref()===undefined}))
  fs.writeFileSync(folder+'/primary.json',JSON.stringify({scope:'Positive known-owner root-class counterfactual, four built public APIs share one source iframe. Three GC requests. Deliberate knownOwnedDocument edge must be excluded from analysis. Not original GC gate.',capturesPerAPI:8,outputs,...primary},null,2));if(!primary.positiveHeld||!primary.negativeCollected)throw Error('Canaries invalid')
  for(const [label,key]of [['positive','__codexPositiveRef'],['negative','__codexNegativeRef']]){
   const handle=await page.evaluateHandle(key=>({__codexHeap:true,reference:globalThis[key],checkContentRead:true}),key)
   try{const props=await handle.getProperties(),graph=JSON.parse(await props.get('__codex_heap_paths').jsonValue());fs.writeFileSync(folder+'/'+label+'.json',JSON.stringify({primary,graph},null,2));if(graph.file)fs.copyFileSync(graph.file,folder+'/'+label+'.fxsnapshot');if(graph.cc?.file)fs.copyFileSync(graph.cc.file,folder+'/'+label+'.cc.log');if(graph.cc?.gcFile)fs.copyFileSync(graph.cc.gcFile,folder+'/'+label+'.gc.log');if(graph.opened?.length!==1||graph.opened[0].before!==false||graph.opened[0].after!==true||graph.closed?.length!==1||graph.closed[0].before!==true||graph.closed[0].after!==false)throw Error('Registration unbalanced');if(graph.errors?.length)throw Error('Graph errors '+JSON.stringify(graph.errors));if(label==='positive'&&(!graph.ids.target||!fs.readFileSync(folder+'/positive.gc.log','utf8').includes('knownOwnedDocument')))throw Error('Positive identity/member missing');if(label==='negative'&&(graph.ids.target||graph.observedDirectTargets!==0))throw Error('Negative identity invalid');console.log(JSON.stringify({label,ids:graph.ids,errors:graph.errors}))}finally{await handle.dispose()}
  }
  await page.evaluate(()=>{for(const {renderer,capture}of globalThis.__pairCaptures){capture.dispose();renderer.dispose()}delete globalThis.__codexKnownOwner})
 }finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
})().catch(error=>{console.error(error);process.exitCode=1;server.close()})
