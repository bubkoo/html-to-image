from pathlib import Path
import subprocess,hashlib,json,sys
folder=Path('.codex-linux-control/dom-paired-cache-positivefirst');folder.mkdir(exist_ok=True)
cmd=['python3','.codex-linux-control/source-holder-e/tooling/firefox-gc-reference-probe.py']
with (folder/'baseline-build.log').open('wb') as log:
 result=subprocess.run(['pnpm','run','build'],cwd='.codex-linux-control/dom-pair-baseline',stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,'Baseline build failed'
# Symlinked dependencies change only tslib's relative SourceMap location.
# Preserve the original map, canonicalize that one metadata path, then require
# every source/build byte (including the map) to match the failed candidate.
mapfile=Path('.codex-linux-control/dom-pair-baseline/dist/html-to-image.js.map')
mapbytes=mapfile.read_bytes();(folder/'baseline-symlink-path-map.json').write_bytes(mapbytes)
assert mapbytes.count(b'"../../../node_modules/')==1
mapfile.write_bytes(mapbytes.replace(b'"../../../node_modules/',b'"../node_modules/'))
old=json.loads(Path('.codex-linux-control/dom-full-before-inputs.json').read_text())['files']
base=Path('.codex-linux-control/dom-pair-baseline');checked={}
for name,sha in old.items():
 if name.startswith(('src/','es/','lib/','dist/')):
  digest=hashlib.sha256((base/name).read_bytes()).hexdigest();assert digest==sha,(name,digest,sha);checked[name]=digest
(folder/'baseline-byte-match.json').write_text(json.dumps({'scope':'All source and built es/lib/dist bytes equal the first failed Node/Window-only candidate','files':checked},indent=2)+'\n')
subprocess.run(['node','/tmp/hash-reflective-inputs.mjs','dom-pair-before'],check=True)
status=None
try:
 subprocess.run(cmd+['install','--output',str(folder/'installation')],check=True)
 with (folder/'pair.log').open('wb') as log:
  status=subprocess.run(['node','.codex-linux-control/paired-cache-positivefirst.cjs'],stdout=log,stderr=subprocess.STDOUT).returncode
finally:
 restored=subprocess.run(cmd+['restore','--output',str(folder/'installation')]).returncode
 subprocess.run(['node','/tmp/hash-reflective-inputs.mjs','dom-pair-after'],check=True)
 before=json.loads(Path('.codex-linux-control/dom-pair-before-inputs.json').read_text());after=json.loads(Path('.codex-linux-control/dom-pair-after-inputs.json').read_text());stable=before==after
 result={'pairExitCode':status,'browserRestoreExitCode':restored,'allCurrentInputHashesStable':stable,'baselineSourceAndBuildFilesMatched':len(checked)}
 (folder/'execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert restored==0 and stable
sys.exit(status or 0)
