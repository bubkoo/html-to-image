const fs=require('node:fs'),ts=require('typescript'),path=require('node:path')
const cfg=ts.readConfigFile('tsconfig.json',ts.sys.readFile),p=ts.parseJsonConfigFileContent(cfg.config,ts.sys,process.cwd()),program=ts.createProgram(p.fileNames,p.options),c=program.getTypeChecker(),lib=program.getSourceFiles().find(f=>f.fileName.endsWith('/lib.dom.d.ts'))
const bases=['Node','Window'].map(name=>c.getTypeAtLocation(lib.statements.find(n=>ts.isInterfaceDeclaration(n)&&n.name.text===name).name))
function dom(t){t=c.getNonNullableType(t);if(t.flags&(ts.TypeFlags.Any|ts.TypeFlags.Unknown|ts.TypeFlags.Never))return false;return t.isUnion()?t.types.some(dom):bases.some(base=>c.isTypeAssignableTo(t,base))}
const remaining=[],otherForms=[]
for(const sf of program.getSourceFiles().filter(s=>s.fileName.startsWith(process.cwd()+'/src/'))){
 function entry(n,kind){const at=sf.getLineAndCharacterOfPosition(n.getStart(sf));return {file:path.relative(process.cwd(),sf.fileName),line:at.line+1,kind,expression:n.getText(sf)}}
 function visit(n){
  if((ts.isPropertyAccessExpression(n)||ts.isElementAccessExpression(n))&&dom(c.getTypeAtLocation(n.expression)))remaining.push(entry(n,'property'))
  if(ts.isVariableDeclaration(n)&&n.initializer&&ts.isObjectBindingPattern(n.name)&&dom(c.getTypeAtLocation(n.initializer)))otherForms.push(entry(n,'binding'))
  if(ts.isBinaryExpression(n)&&n.operatorToken.kind===ts.SyntaxKind.InKeyword&&dom(c.getTypeAtLocation(n.right)))otherForms.push(entry(n,'in'))
  if(ts.isSpreadAssignment(n)&&dom(c.getTypeAtLocation(n.expression)))otherForms.push(entry(n,'spread'))
  ts.forEachChild(n,visit)
 }visit(sf)
}
const out={remaining,otherForms,scope:'Static Node/Window receivers and unions containing them, plus Node/Window destructuring, in and object spread; excludes any/unknown/never, broader object types, other DOM interfaces and user code'}
fs.writeFileSync('output/playwright/gc-native-controls/dom-access-prototype/after-audit.json',JSON.stringify(out,null,2)+'\n');console.log(out)
