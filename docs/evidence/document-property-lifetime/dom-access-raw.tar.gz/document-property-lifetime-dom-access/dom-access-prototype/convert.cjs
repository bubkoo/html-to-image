const fs=require('node:fs'),ts=require('typescript'),path=require('node:path')
const cfg=ts.readConfigFile('tsconfig.json',ts.sys.readFile),p=ts.parseJsonConfigFileContent(cfg.config,ts.sys,process.cwd()),program=ts.createProgram(p.fileNames,p.options),c=program.getTypeChecker(),lib=program.getSourceFiles().find(f=>f.fileName.endsWith('/lib.dom.d.ts'))
const types=['Node','Window'].map(name=>c.getTypeAtLocation(lib.statements.find(n=>ts.isInterfaceDeclaration(n)&&n.name.text===name).name))
function dom(t){t=c.getNonNullableType(t);if(t.flags&(ts.TypeFlags.Any|ts.TypeFlags.Unknown|ts.TypeFlags.Never))return false;return t.isUnion()?t.types.some(dom):types.some(base=>c.isTypeAssignableTo(t,base))}
const audit=[],writes=[]
for(const sf of program.getSourceFiles().filter(s=>s.fileName.startsWith(process.cwd()+'/src/'))){const used=new Set(),text=sf.text,memo=new Map();let changes=0
 function record(n,role){audit.push({file:path.relative(process.cwd(),sf.fileName),expression:n.getText(sf),role});changes++}
 function render(n){if(memo.has(n))return memo.get(n);const value=compute(n);memo.set(n,value);return value}
 function compute(n){
  const subs=[];ts.forEachChild(n,child=>{subs.push(child)});let base='',pos=n.getStart(sf);for(const child of subs){const start=child.getStart(sf);if(start<pos)throw Error('Overlapping children');base+=text.slice(pos,start)+render(child);pos=child.end}base+=text.slice(pos,n.end)
  if(ts.isBinaryExpression(n)&&(ts.isPropertyAccessExpression(n.left)||ts.isElementAccessExpression(n.left))&&dom(c.getTypeAtLocation(n.left.expression))&&n.operatorToken.kind>=ts.SyntaxKind.FirstAssignment&&n.operatorToken.kind<=ts.SyntaxKind.LastAssignment){
   const left=n.left,target=render(left.expression),key=ts.isPropertyAccessExpression(left)?JSON.stringify(left.name.text):render(left.argumentExpression),right=render(n.right);let value=right
   if(n.operatorToken.kind!==ts.SyntaxKind.EqualsToken){if(!ts.isIdentifier(left.expression)||left.expression.text!=='canvas'||n.operatorToken.kind!==ts.SyntaxKind.AsteriskEqualsToken)throw Error('Unreviewed compound write '+n.getText(sf));used.add('readDOMProperty');value=`readDOMProperty(${target}, ${key}) * (${right})`}
   used.add('writeDOMProperty');record(n,'write');return`writeDOMProperty(${target}, ${key}, ${value})`
  }
  if(ts.isVariableDeclaration(n)&&n.initializer&&ts.isObjectBindingPattern(n.name)&&dom(c.getTypeAtLocation(n.initializer))){
   const elements=n.name.elements;if(elements.length!==1||elements[0].dotDotDotToken||elements[0].initializer||elements[0].propertyName||!ts.isIdentifier(elements[0].name)||elements[0].name.text!=='style')throw Error('Unreviewed DOM binding '+n.getText(sf));used.add('readDOMProperty');record(n,'binding');return`style = readDOMProperty(${render(n.initializer)}, 'style')`
  }
  if(!(ts.isPropertyAccessExpression(n)||ts.isElementAccessExpression(n))||!dom(c.getTypeAtLocation(n.expression)))return base
  const parent=n.parent
  if(ts.isBinaryExpression(parent)&&parent.left===n&&parent.operatorToken.kind>=ts.SyntaxKind.FirstAssignment&&parent.operatorToken.kind<=ts.SyntaxKind.LastAssignment)return base
  if(n.questionDotToken)return base
  if(ts.isCallExpression(parent)&&parent.expression===n&&parent.questionDotToken)throw Error('Unreviewed optional method value')
  const method=ts.isCallExpression(parent)&&parent.expression===n,helper=method?'readDOMMethod':'readDOMProperty';used.add(helper)
  const target=render(n.expression),key=ts.isPropertyAccessExpression(n)?JSON.stringify(n.name.text):render(n.argumentExpression),result=`${helper}(${target}, ${key})`
  record(n,method?'method':'read');return ts.isNewExpression(parent)&&parent.expression===n?`(${result})`:result
 }
 const result=text.slice(0,sf.getStart(sf))+render(sf)
 if(changes){writes.push([sf.fileName,`import { ${[...used].sort().join(', ')} } from './dom.js'\n`+result]);console.log(path.relative(process.cwd(),sf.fileName),changes)}
}
if(audit.length!==445)throw Error('Unexpected mechanical rewrite count '+audit.length)
for(const [file,value] of writes)fs.writeFileSync(file,value)
fs.writeFileSync('output/playwright/gc-native-controls/dom-access-prototype/rewrites.json',JSON.stringify(audit,null,2)+'\n')
console.log('Recorded rewrites',audit.length)
