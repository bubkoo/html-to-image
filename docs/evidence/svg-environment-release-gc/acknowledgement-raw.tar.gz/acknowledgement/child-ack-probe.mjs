import {firefox} from 'playwright'
import {mkdir,readdir,writeFile} from 'node:fs/promises'
import {resolve} from 'node:path'
const directory=resolve('output/playwright/svg-environment-release-gc/ack-graphs');await mkdir(directory,{recursive:true})
const browser=await firefox.launch({env:{...process.env,MOZ_CC_LOG_DIRECTORY:directory,MOZ_CC_LOG_ALL:'1',MOZ_CC_LOG_PROCESS:'content',MOZ_CC_LOG_THREAD:'main',MOZ_DISABLE_CONTENT_SANDBOX:'t'}}),rows=[]
const writing=async()=>(await readdir(directory)).filter(x=>x.startsWith('incomplete-'))
try{
 const page=await browser.newPage()
 for(let iteration=0;iteration<10;iteration++){
  await page.evaluate(()=>{const frame=document.createElement('iframe');document.body.append(frame);frame.contentDocument.body.innerHTML='<div>owned diagnostic</div>'.repeat(6000);window.ownedAckReference=new WeakRef(frame.contentDocument);frame.remove()})
  const prior=await writing();await page.requestGC();const returned=await writing()
  await page.evaluate(()=>true);const barrier=await writing()
  rows.push({iteration,prior,returned,barrier})
 }
}finally{await browser.close()}
await writeFile('output/playwright/svg-environment-release-gc/child-ack-probe.json',JSON.stringify({platform:process.platform,version:browser.version(),rows},null,2))
console.log(JSON.stringify({incompleteAtProtocolReturn:rows.filter(r=>r.returned.length).length,incompleteAfterContentBarrier:rows.filter(r=>r.barrier.length).length,rows}))
