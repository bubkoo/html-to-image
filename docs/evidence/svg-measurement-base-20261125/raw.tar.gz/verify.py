from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
i=json.loads((p/'index.json').read_text())
actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f.name!='index.json'}
assert actual=={f['path'] for f in i['files']},'file membership differs'
for f in i['files']:
 b=(p/f['path']).read_bytes();assert len(b)==f['bytes'];assert hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
r=json.loads((p/'results.json').read_text());a=json.loads((p/'assessment.json').read_text())
assert r['cleanup']=={'serverClosed':True,'browsersClosed':True}
assert len(r['engines'])==3
assert [m['totalDifferentChannels'] for e in r['engines'] for m in e['modes']]==[1200,7200,8400,8400,12000,12000]
for e in r['engines']:
 assert e['browserClosed'];assert len(e['modes'])==2
 assert e['modes'][0]['nativeBeforeSHA256']==e['modes'][1]['nativeBeforeSHA256']
 for m in e['modes']:
  assert 'error' not in m;assert len(m['columns'])==12
  assert m['sourceScreenshotUnchanged'] and m['fixtureSubtreeUnchanged']
  assert m['pageClosed'] and m['iframesAfter']==0
  assert m['totalDifferentChannels']==sum(c['differentChannels']for c in m['columns'])
  for kind in ['native-before','native-after']:
   b=(p/(e['engine']+'-'+m['mode']+'-'+kind+'.png')).read_bytes()
   assert hashlib.sha256(b).hexdigest()==m['nativeBeforeSHA256']
assert a['execution']['copiesSourceOriginalStillByteEqualToRoot']
assert sorted(a['execution']['changedCopiedSourceFiles'])==['svg-references.ts','svg-style-scope.ts']
print('verified',len(i['files']),'files; all failures/control/cleanup retained')
