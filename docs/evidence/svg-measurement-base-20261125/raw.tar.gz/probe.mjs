import {createServer} from 'node:http'
import {mkdir,readFile,writeFile} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
import {createHash} from 'node:crypto'
import {chromium,firefox,webkit} from 'playwright'
const own=p=>new URL(p,import.meta.url)
const hash=b=>createHash('sha256').update(b).digest('hex')
const folder=fileURLToPath(new URL('.',import.meta.url))
const ids=['relative-attribute','relative-inline','page-rule-winner','file-rule-winner','literal-attribute-important','literal-inline-important','inline-priority','inherited-custom-property','authored-absolute-page','authored-absolute-file','redirect-relative','redirect-xml-base']
const relative='url(sprite.svg?different#paint) purple'
let origin,stage={engine:'setup',mode:'setup',step:'setup'}
const trace=[]
const commonCSS=`.literal-attribute[fill="${relative}"]{fill:orange!important;stroke:orange!important}.literal-inline[style="fill:${relative}"]{fill:cyan!important;stroke:cyan!important}.inline-priority{fill:orange}`
const rect=attr=>`<rect width="20" height="20" ${attr}/>`
function externalSVG(color){
 const absPage=`url(${origin}/paint/sprite.svg?different#paint) purple`
 const absFile=`url(${origin}/paint/assets/sprite.svg?different#paint) purple`
 const symbols={
  'relative-attribute':rect(`fill="${relative}"`),
  'relative-inline':rect(`style="fill:${relative}"`),
  'page-rule-winner':rect(`class="page-rule" fill="${relative}"`),
  'file-rule-winner':rect(`class="file-rule" fill="${relative}"`),
  'literal-attribute-important':rect(`class="literal-attribute" fill="${relative}"`),
  'literal-inline-important':rect(`class="literal-inline" style="fill:${relative}"`),
  'inline-priority':rect(`class="inline-priority" style="fill:${relative}"`),
  'inherited-custom-property':`<g style="--paint:${relative}">${rect('style="fill:var(--paint)"')}</g>`,
  'authored-absolute-page':rect(`fill="${absPage}"`),
  'authored-absolute-file':rect(`style="fill:${absFile}"`),
  'xml-relative':rect(`fill="${relative}"`),
 }
 return `<svg xmlns="http://www.w3.org/2000/svg"><style>${commonCSS}.file-rule{fill:cyan!important}</style><defs><pattern id="paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="${color}"/></pattern></defs>${Object.entries(symbols).map(([id,body])=>`<symbol id="${id}" viewBox="0 0 20 20"${id==='xml-relative'?' xml:base="../xml/"':''}>${body}</symbol>`).join('')}</svg>`
}
function pageHTML(){return `<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:white}#matrix{display:flex;width:240px;height:20px;background:white}#matrix>svg{display:block;flex:none;overflow:hidden}${commonCSS}.page-rule{fill:orange!important}</style><div id="matrix">${ids.map(id=>`<svg xmlns="http://www.w3.org/2000/svg" data-case="${id}" width="20" height="20"><use href="${id.startsWith('redirect')?'/paint/request/sprite.svg':'/paint/assets/sprite.svg'}#${id==='redirect-relative'?'relative-attribute':id==='redirect-xml-base'?'xml-relative':id}" width="20" height="20"/></svg>`).join('')}</div>`}
function colorFor(url){
 if(url.pathname==='/paint/assets/sprite.svg')return url.searchParams.has('different')?'yellow':'green'
 if(url.pathname==='/paint/sprite.svg')return url.searchParams.has('different')?'blue':'red'
 if(url.pathname==='/paint/xml/sprite.svg')return url.searchParams.has('different')?'lime':'olive'
 if(url.pathname==='/xml/sprite.svg')return url.searchParams.has('different')?'magenta':'maroon'
 return 'black'
}
const server=createServer((req,res)=>{
 const url=new URL(req.url,'http://localhost')
 const entry={at:new Date().toISOString(),...stage,path:url.pathname+url.search};trace.push(entry)
 res.setHeader('Cache-Control','no-store')
 if(url.pathname==='/paint/page.html'){res.setHeader('Content-Type','text/html');res.end(pageHTML());return}
 if(url.pathname==='/paint/request/sprite.svg'){entry.redirect='/paint/assets/sprite.svg'+url.search;res.writeHead(302,{Location:entry.redirect});res.end();return}
 if(url.pathname.endsWith('/sprite.svg')){entry.color=colorFor(url);res.setHeader('Content-Type','image/svg+xml');res.end(externalSVG(entry.color));return}
 res.writeHead(404).end()
})
const results={startedAt:new Date().toISOString(),scope:'Bounded HTTP SVG paint source provenance / private measurement Document base hypothesis; no production changes',ids,engines:[],cleanup:{},trace}
let serverOpen=false
try{
 await new Promise((r,j)=>{server.once('error',j);server.listen(0,'127.0.0.1',r)});serverOpen=true
 origin='http://127.0.0.1:'+server.address().port
 results.origin=origin
 await writeFile(own('./fixture-page.html'),pageHTML())
 await writeFile(own('./fixture-assets-default.svg'),externalSVG('green'))
 await writeFile(own('./fixture-assets-query.svg'),externalSVG('yellow'))
 for(const [engine,type] of Object.entries({chromium,firefox,webkit})){
  const browser=await type.launch({headless:true})
  const er={engine,version:browser.version(),startedAt:new Date().toISOString(),modes:[]};results.engines.push(er)
  try{
   for(const mode of ['current','candidate']){
    const page=await browser.newPage({deviceScaleFactor:1,viewport:{width:640,height:240}})
    const mr={mode,startedAt:new Date().toISOString(),console:[],pageErrors:[]};er.modes.push(mr)
    page.on('console',m=>mr.console.push({type:m.type(),text:m.text()}));page.on('pageerror',e=>mr.pageErrors.push(String(e)))
    try{
     stage={engine,mode,step:'native-load'}
     await page.goto(origin+'/paint/page.html',{waitUntil:'load'})
     await page.waitForFunction(()=>Array.from(document.querySelectorAll('use')).every(x=>x.getBBox().width===20),{timeout:10000})
     await page.waitForLoadState('networkidle')
     mr.sourceBefore=await page.evaluate(()=>({html:document.documentElement.outerHTML,frameCount:document.querySelectorAll('iframe').length,href:location.href}))
     const before=await page.locator('#matrix').screenshot({scale:'css'});mr.nativeBeforeSHA256=hash(before);await writeFile(own(`./${engine}-${mode}-native-before.png`),before)
     await page.addScriptTag({path:fileURLToPath(own(`./${mode}.umd.js`))})
     await page.evaluate(()=>{window.__paintProbe=[]})
     stage={engine,mode,step:'capture'}
     const capture=await page.evaluate(async nativeB64=>{
      const node=document.querySelector('#matrix');const uri=await htmlToImage.toSvg(node)
      const xml=decodeURIComponent(uri.slice(uri.indexOf(',')+1))
      const view=(await new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(new Error('Capture SVG image failed to load'));i.src=uri}))
      const canvas=document.createElement('canvas');canvas.width=240;canvas.height=20;const context=canvas.getContext('2d');context.drawImage(view,0,0)
      const actual=context.getImageData(0,0,240,20).data
      const native=new Image();native.src='data:image/png;base64,'+nativeB64;await native.decode();context.clearRect(0,0,240,20);context.drawImage(native,0,0);const expected=context.getImageData(0,0,240,20).data
      const columns=Array.from({length:12},(_,col)=>{let differentChannels=0,differentPixels=0;for(let y=0;y<20;y++)for(let x=col*20;x<(col+1)*20;x++){let changed=false;for(let c=0;c<4;c++){const i=4*(y*240+x)+c;if(expected[i]!==actual[i]){differentChannels++;changed=true}}if(changed)differentPixels++}const at=4*(10*240+col*20+10);return{differentChannels,differentPixels,nativeCenter:Array.from(expected.slice(at,at+4)),captureCenter:Array.from(actual.slice(at,at+4))}})
      context.clearRect(0,0,240,20);context.putImageData(new ImageData(actual,240,20),0,0)
      const parsed=new DOMParser().parseFromString(xml,'image/svg+xml')
      const frozen=Array.from(parsed.querySelectorAll('[style]')).filter(x=>x.style?.fill?.includes('url(')).map(x=>({tag:x.localName,id:x.id,fill:x.style.fill,priority:x.style.getPropertyPriority('fill')}))
      return{xml,png:canvas.toDataURL('image/png').split(',')[1],columns,policy:window.__paintProbe,frozen,iframesAfter:document.querySelectorAll('iframe').length}
     },before.toString('base64'))
     mr.columns=capture.columns.map((c,i)=>({id:ids[i],...c}));mr.policy=capture.policy;mr.frozen=capture.frozen;mr.iframesAfter=capture.iframesAfter
     await writeFile(own(`./${engine}-${mode}-capture.svg`),capture.xml);await writeFile(own(`./${engine}-${mode}-capture.png`),Buffer.from(capture.png,'base64'))
     stage={engine,mode,step:'source-after'}
     const after=await page.locator('#matrix').screenshot({scale:'css'});await writeFile(own(`./${engine}-${mode}-native-after.png`),after);mr.nativeAfterSHA256=hash(after);mr.sourceScreenshotUnchanged=before.equals(after)
     mr.sourceAfter=await page.evaluate(()=>({html:document.documentElement.outerHTML,frameCount:document.querySelectorAll('iframe').length,href:location.href}))
     // Ignore the script node added by our harness when comparing the original fixture subtree and CSS.
     mr.fixtureSubtreeUnchanged=await page.evaluate(beforeHTML=>{const d=new DOMParser().parseFromString(beforeHTML,'text/html');return d.querySelector('#matrix').outerHTML===document.querySelector('#matrix').outerHTML && d.querySelector('style').textContent===document.querySelector('style').textContent},mr.sourceBefore.html)
     mr.totalDifferentChannels=mr.columns.reduce((n,c)=>n+c.differentChannels,0)
     console.log(engine,mode,JSON.stringify({different:mr.totalDifferentChannels,columns:mr.columns.filter(x=>x.differentChannels),policy:mr.policy,unchanged:mr.sourceScreenshotUnchanged,iframesAfter:mr.iframesAfter}))
    }catch(error){mr.error=String(error?.stack||error);console.log(engine,mode,'ERROR',mr.error)}
    finally{await page.close();mr.pageClosed=true;mr.endedAt=new Date().toISOString()}
    await writeFile(own('./results.partial.json'),JSON.stringify(results,null,2)+'\n')
   }
  }finally{await browser.close();er.browserClosed=true;er.endedAt=new Date().toISOString()}
 }
}finally{
 if(serverOpen)await new Promise(r=>server.close(r));results.cleanup.serverClosed=!server.listening;results.cleanup.browsersClosed=results.engines.every(e=>e.browserClosed);results.endedAt=new Date().toISOString();await writeFile(own('./results.json'),JSON.stringify(results,null,2)+'\n')
}
