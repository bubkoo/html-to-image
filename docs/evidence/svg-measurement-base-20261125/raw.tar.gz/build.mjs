import {rollup} from 'rollup';
import typescript from '@rollup/plugin-typescript';
import replace from '@rollup/plugin-replace';
import terser from '@rollup/plugin-terser';
import {fileURLToPath} from 'node:url';
const own=p=>fileURLToPath(new URL(p,import.meta.url));
const b=await rollup({input:own('./source-candidate/index.ts'),plugins:[typescript({tsconfig:own('./tsconfig.json')}),replace({preventAssignment:true,'process.env.NODE_ENV':JSON.stringify('production')}),terser()]});
try{await b.write({file:own('./candidate.umd.js'),format:'umd',name:'htmlToImage',sourcemap:false})}finally{await b.close()}
