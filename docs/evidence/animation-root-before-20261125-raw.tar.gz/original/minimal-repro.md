# CSS animation snapshot reproduction

Use the exact frozen UMD9c090fc25401c32b55c80dce3acaa71c6a8e0dc538046b4abad67c584dccee1a. Executed driver: probe.mjs. No server required.

```html
<div id="capture" style="margin:0;padding:0;border:0;width:40px;height:20px;position:relative;overflow:hidden;background:white">
  <style>
    @keyframes shift { from { transform:translateX(0px) } to { transform:translateX(20px) } }
    #box { animation:shift 1s linear }
  </style>
  <div id="box" style="width:20px;height:20px;background:red"></div>
</div>
```

```js
const root = document.getElementById('capture')
const box = document.getElementById('box')
const animation = box.getAnimations()[0]
animation.pause()
animation.currentTime = 500
await animation.ready
// Native rectangle x=10..29. Computed transform matrix(...,10,0).
// WA playState=paused; computed animationPlayState=running.
const renderer = htmlToImage.createRenderer({width:40,height:20,pixelRatio:1,skipFonts:true})
try {
  const direct = await renderer.toImageData(root)
  const snapshot = await renderer.capture(root)
  try { const frozen = await snapshot.toImageData() } finally { snapshot.dispose() }
  // Both exported rectangles x=0..19,800 channels differ from native screenshot.
} finally { renderer.dispose() }
```

In the executed driver, native oracle is a locator screenshot at scale css with animations allowed, not a hand-authored image. Root/body margin is zero. All source markup and recorded CSS/WA states are compared before/after capture.

Move the same keyframe style to document.head outside capture: exact match. Replace CSS animation with Element.animate and the same pause/currentTime: exact match. Keep keyframes inside but use CSS animation-play-state:paused and delay:-0.5s (currentTime0): exact match. All controls were run in Chromium/Firefox/WebKit with no tolerance or delay workaround.
