import {createServer} from 'node:http'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {resolve} from 'node:path'
import {chromium,firefox,webkit} from 'playwright'
const out=resolve('output/playwright/svg-resource-timing/native');await mkdir(out,{recursive:true})
const trace=[]
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname;trace.push(req.url)
 if(path.endsWith('/performance-positive.txt')){res.setHeader('Content-Type','text/plain');res.end('owned timing positive');return}
 if(path.endsWith('/page.html')){res.setHeader('Content-Type','text/html');res.end('<!doctype html><style>body{margin:0}</style>');return}
 if(path.endsWith('/sprite.svg') || path.endsWith('/other.svg')){
  const imported='data:text/css,'+encodeURIComponent('.viaImport{fill:url("sprite.svg#paint") purple!important}')
  const color=path.endsWith('/other.svg')?'orange':path.includes('/assets/')?'green':'red'
  const ids=['attr','inline','other','parent','query','missing','foreign','fragment','absolute','control']
  const nodes=ids.map(id=>`<symbol id="${id}" viewBox="0 0 20 20"><rect width="20" height="20" ${id==='attr'?'fill="url(sprite.svg#paint) purple"':id==='inline'?'style="fill:url(sprite.svg#paint) purple"':id==='other'?'fill="url(other.svg#paint) purple"':id==='parent'?'fill="url(../sprite.svg#paint) purple"':id==='query'?'fill="url(sprite.svg?different#paint) purple"':id==='missing'?'fill="url(sprite.svg#absent) purple"':id==='foreign'?'fill="url(http://127.0.0.1:4496/foreign/sprite.svg#paint) purple"':id==='fragment'?'fill="url(#paint) purple"':id==='absolute'?`fill="url(http://127.0.0.1:4496${path}#paint) purple"`:'fill="green"'}/></symbol>`).join('')
  res.setHeader('Content-Type','image/svg+xml');res.setHeader('Cache-Control','no-store');res.end(`<svg xmlns="http://www.w3.org/2000/svg"><defs><pattern id="paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="${color}"/></pattern></defs><style>@import url('${imported}');.viaFile{fill:url(sprite.svg#paint) purple!important}</style>${nodes}</svg>`);return
 }
 if(path.startsWith('/es/')){try{res.setHeader('Content-Type','text/javascript');res.end(await readFile(resolve('.'+path)));return}catch{}}
 res.writeHead(404).end()
})
await new Promise(r=>server.listen(4496,'127.0.0.1',r))
const results={meaning:'Native HTTP external-use performance observation only; no library capture or production fix',engines:{}}
try{
 for(const [name,engine] of Object.entries({chromium,firefox,webkit})){
  const binary=name==='firefox'?'/Users/bytedance/Library/Caches/ms-playwright/firefox-1578/firefox/Nightly.app/Contents/MacOS/firefox':engine.executablePath();const browser=await engine.launch({executablePath:binary})
  try{
   const page=await browser.newPage({deviceScaleFactor:1});const prefix='/probe/'+crypto.randomUUID()
   await page.goto('http://127.0.0.1:4496'+prefix+'/page.html');const start=trace.length
   await page.evaluate(async prefix=>{
    performance.setResourceTimingBufferSize(1000);window.__timingEntries=[];
    window.__timingObserver=new PerformanceObserver(list=>window.__timingEntries.push(...list.getEntries().map(entry=>entry.toJSON())));
    window.__timingObserver.observe({type:'resource',buffered:true});
    const response=await fetch(prefix+'/performance-positive.txt');if(await response.text()!=='owned timing positive')throw Error('Positive resource invalid');
    const root=document.createElement('div');root.id='source';root.style.cssText='display:flex;width:220px;height:20px;background:white';
    for(const id of ['attr','inline','other','parent','query','missing','foreign','fragment','absolute','control']){
     const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('width','20');svg.setAttribute('height','20');svg.style.flex='none';const use=document.createElementNS(svg.namespaceURI,'use');use.setAttribute('href',prefix+'/assets/sprite.svg#'+id);use.setAttribute('width','20');use.setAttribute('height','20');svg.append(use);root.append(svg);
    }
    const yellow=document.createElement('div');yellow.style.cssText='width:20px;height:20px;background:yellow;flex:none';root.append(yellow);document.body.append(root);window.__sourceMarkup=root.outerHTML;
   },prefix)
   await page.waitForFunction(()=>Array.from(document.querySelectorAll('use')).every(x=>x.getBBox().width===20))
   await page.waitForLoadState('networkidle');await page.locator('#source').screenshot({path:resolve(out,name+'-before.png'),scale:'css'})
   const record=await page.evaluate(()=>({entries:performance.getEntriesByType('resource').map(entry=>entry.toJSON()),observed:window.__timingEntries,sourceUnchanged:document.getElementById('source').outerHTML===window.__sourceMarkup}));
   if(!record.entries.some(entry=>entry.name.endsWith('/performance-positive.txt')))throw Error('Missing resource timing positive');
   await page.locator('#source').screenshot({path:resolve(out,name+'-after.png'),scale:'css'});
   const before=await readFile(resolve(out,name+'-before.png')),after=await readFile(resolve(out,name+'-after.png'));
   if(!before.equals(after))throw Error('Native source changed');
   results.engines[name]={...record,version:browser.version(),binaryPath:binary,sdkVersion:"1.64.1",node:process.version,platform:process.platform,scope:"read-only observation; explicit installed Firefox differs from historical pinned binary",prefix,serverRequests:trace.slice(start),nativeBeforeAfterExact:true};
   await writeFile(resolve(out,'observation.json'),JSON.stringify(results,null,2)+'\n');
  }finally{await browser.close()}
 }
}finally{await new Promise(r=>server.close(r))}
await writeFile(resolve(out,'observation.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(Object.fromEntries(Object.entries(results.engines).map(([name,row])=>[name,{version:row.version,server:row.serverRequests.length,entries:row.entries.map(x=>x.name),observed:row.observed.length,nativeExact:row.nativeBeforeAfterExact}]))));
