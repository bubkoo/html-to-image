import { execFileSync } from 'node:child_process'
import { readFile, readdir, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim()
const tracked=execFileSync('git',['ls-files','--cached','--others','--exclude-standard','-z'],{encoding:'utf8'}).split('\0').filter(Boolean)
const top=new Set(['package.json','pnpm-lock.yaml','vitest.browser.config.mts','playwright.config.ts','rollup.config.js','eslint.config.mjs','tsconfig.json','tsconfig.browser-tests.json'])
const files=tracked.filter(p=>/^(src|test|scripts)\//.test(p)||top.has(p))
async function walk(folder){
 const entries=await readdir(folder,{withFileTypes:true})
 for(const entry of entries){const path=folder+'/'+entry.name;if(entry.isDirectory())await walk(path);else if(entry.isFile())files.push(path)}
}
for(const folder of ['es','lib','dist'])await walk(folder)
const hashes={}
for(const file of [...new Set(files)].sort())hashes[file]=createHash('sha256').update(await readFile(file)).digest('hex')
await writeFile('.codex-linux-control/'+process.argv[2]+'-inputs.json',JSON.stringify({head,node:process.version,scope:'tracked and new src/test/scripts and selected configuration plus all built es/lib/dist bytes',files:hashes},null,2)+'\n')
