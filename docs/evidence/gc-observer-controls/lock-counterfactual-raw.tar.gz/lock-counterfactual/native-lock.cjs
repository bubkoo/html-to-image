const {firefox}=require('/work/node_modules/playwright')
const {createServer}=require('node:http')
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto')
const folder='/work/.codex-linux-control/dom-access-counterfactual'
fs.mkdirSync(folder,{recursive:true})
const direct=`export function lockResources(doc) {
 const policy=doc.createElement('meta');
 policy.httpEquiv='Content-Security-Policy';
 policy.content="img-src 'none'; style-src 'unsafe-inline'";
 doc.head.append(policy);
}`
const borrowed=`const create=Document.prototype.createElement;
const head=Object.getOwnPropertyDescriptor(Document.prototype,'head').get;
const append=Element.prototype.append;
const equiv=Object.getOwnPropertyDescriptor(HTMLMetaElement.prototype,'httpEquiv').set;
const content=Object.getOwnPropertyDescriptor(HTMLMetaElement.prototype,'content').set;
export function lockResources(doc) {
 const policy=Reflect.apply(create,doc,['meta']);
 Reflect.apply(equiv,policy,['Content-Security-Policy']);
 Reflect.apply(content,policy,["img-src 'none'; style-src 'unsafe-inline'"]);
 Reflect.apply(append,Reflect.apply(head,doc,[]),[policy]);
}`
let source=''
const server=createServer((req,res)=>{
 res.writeHead(200,{'Content-Type':req.url==='/lock.mjs'?'text/javascript':'text/html','Cache-Control':'no-store'})
 res.end(req.url==='/lock.mjs'?source:`<script type="module">import {lockResources} from '/lock.mjs';globalThis.__lock=lockResources;</script>`)
})
const matrix=[
 {name:'direct-cold',mode:'direct',warm:0},
 {name:'direct-warm',mode:'direct',warm:20000},
 {name:'borrowed-warm',mode:'borrowed',warm:20000},
 {name:'borrowed-cold',mode:'borrowed',warm:0},
 {name:'direct-warm-repeat',mode:'direct',warm:20000},
]
;(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
 const url='http://127.0.0.1:'+server.address().port
 const results=[]
 try{
 for(const entry of matrix){
  source=entry.mode==='direct'?direct:borrowed
  const prefix=path.join(folder,entry.name)
  fs.writeFileSync(prefix+'.mjs',source)
  const browser=await firefox.launch()
  try{
   const page=await browser.newPage()
   await page.goto(url);await page.waitForFunction(()=>typeof globalThis.__lock==='function')
   const setup=await page.evaluate(async ({warm})=>{
    const warming=document.implementation.createHTMLDocument()
    for(let i=0;i<warm;i++)globalThis.__lock(warming)
    async function removed(read){
     const frame=document.createElement('iframe')
     frame.setAttribute('sandbox','allow-same-origin')
     frame.style.cssText='position:fixed;left:-99999px;top:0;width:1024px;height:768px;opacity:0;border:0;pointer-events:none'
     frame.srcdoc=`<!doctype html><meta data-svg-style-policy http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'none'; style-src 'unsafe-inline' data:; img-src blob:; font-src data:; base-uri 'none'; form-action 'none'"><style>html,body{margin:0;overflow:hidden}</style><body></body>`
     const loaded=new Promise(resolve=>{frame.onload=()=>resolve()})
     document.documentElement.append(frame)
     try{await loaded;const doc=frame.contentDocument;if(read)globalThis.__lock(doc);return new WeakRef(doc)}
     finally{frame.onload=null;frame.remove()}
    }
    globalThis.__nativeRef=await removed(false)
    globalThis.__readRef=await removed(true)
    globalThis.__canaryRef=new WeakRef({})
    globalThis.__strongOwner={held:true};globalThis.__strongRef=new WeakRef(globalThis.__strongOwner)
    return {warmElements:warming.head.children.length,framesRemaining:document.querySelectorAll('iframe').length}
   },entry)
   for(let i=0;i<3;i++){await page.requestGC();await page.evaluate(()=>undefined)}
   const primary=await page.evaluate(()=>({nativeCollected:__nativeRef.deref()===undefined,readCollected:__readRef.deref()===undefined,canaryCollected:__canaryRef.deref()===undefined,strongAlive:__strongRef.deref()===__strongOwner}))
   const row={entry,browser:browser.version(),setup,primary,collectionRequests:3,libraryLoaded:false,moduleSHA256:crypto.createHash('sha256').update(source).digest('hex')}
   fs.writeFileSync(prefix+'.primary.json',JSON.stringify(row,null,2))
   if(!primary.readCollected){
    const handle=await page.evaluateHandle(()=>({__codexHeap:true,reference:__readRef}))
    try{
     const properties=await handle.getProperties();const value=await properties.get('__codex_heap_paths')?.jsonValue()
     if(typeof value!=='string')throw Error('Probe response missing')
     const graph=JSON.parse(value);fs.writeFileSync(prefix+'.json',JSON.stringify({primary,graph},null,2))
     if(graph.file)fs.copyFileSync(graph.file,prefix+'.fxsnapshot')
     if(graph.cc?.file)fs.copyFileSync(graph.cc.file,prefix+'.cc.log')
     if(graph.cc?.gcFile)fs.copyFileSync(graph.cc.gcFile,prefix+'.gc.log')
    }catch(error){row.inspectionError=String(error)}finally{await handle.dispose()}
   }
   results.push(row);console.log(JSON.stringify(row))
  }finally{await browser.close()}
 }
 }finally{await new Promise(resolve=>server.close(resolve))}
 fs.writeFileSync(path.join(folder,'results.json'),JSON.stringify(results,null,2))
})().catch(error=>{console.error(error);server.close();process.exitCode=1})
