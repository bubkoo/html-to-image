const create=Document.prototype.createElement;
const head=Object.getOwnPropertyDescriptor(Document.prototype,'head').get;
const append=Element.prototype.append;
const equiv=Object.getOwnPropertyDescriptor(HTMLMetaElement.prototype,'httpEquiv').set;
const content=Object.getOwnPropertyDescriptor(HTMLMetaElement.prototype,'content').set;
export function lockResources(doc) {
 const policy=Reflect.apply(create,doc,['meta']);
 Reflect.apply(equiv,policy,['Content-Security-Policy']);
 Reflect.apply(content,policy,["img-src 'none'; style-src 'unsafe-inline'"]);
 Reflect.apply(append,Reflect.apply(head,doc,[]),[policy]);
}