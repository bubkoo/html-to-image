export function lockResources(doc) {
 const policy=doc.createElement('meta');
 policy.httpEquiv='Content-Security-Policy';
 policy.content="img-src 'none'; style-src 'unsafe-inline'";
 doc.head.append(policy);
}