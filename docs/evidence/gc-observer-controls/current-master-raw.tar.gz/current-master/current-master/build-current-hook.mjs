import {execFileSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
import ts from '../../../../node_modules/typescript/lib/typescript.js'
import {transformSync} from '../../../../node_modules/.pnpm/esbuild@0.28.2/node_modules/esbuild/lib/main.js'
const dir=new URL('./',import.meta.url)
const original=execFileSync('git',['show','f8d1c4b:test/browser-unit/resource-resolver-cancellation.test.ts'],{encoding:'utf8'})
const envNeedle='      expect(diagnosis.ownerCollected, JSON.stringify(diagnosis)).toBe(true)'
const pendingNeedle='      const collected = reference!.deref() === undefined'
if(!original.includes(envNeedle)||!original.includes(pendingNeedle))throw Error('Primary sample/expect anchors missing')
const envHook=`      if (server.browser === 'firefox' && !diagnosis.ownerCollected) {
        Reflect.set(globalThis, '__codex_ref_probe', {__codexHeap:true, reference})
        try { await commands.recordReferenceOnlyLifetime(JSON.stringify({kind:'environment-'+probed,...diagnosis})) }
        finally { Reflect.deleteProperty(globalThis, '__codex_ref_probe') }
      }
`
const pendingHook=`
      if (server.browser === 'firefox' && !collected) {
        Reflect.set(globalThis, '__codex_ref_probe', {__codexHeap:true, reference})
        try { await commands.recordReferenceOnlyLifetime(JSON.stringify({kind:'pending-font',collected})) }
        finally { Reflect.deleteProperty(globalThis, '__codex_ref_probe') }
      }
`
const source=original.replace(envNeedle,envHook+envNeedle).replace(pendingNeedle,pendingNeedle+pendingHook)+`
declare module 'vitest/browser' { interface BrowserCommands { recordReferenceOnlyLifetime: (record:string)=>Promise<void> } }
`
if((original.match(/commands.collectGarbage\(/g)||[]).length!==(source.match(/commands.collectGarbage\(/g)||[]).length)throw Error('Original request count changed')
writeFileSync(new URL('resource-hook-source.ts',dir),source)
const ast=ts.createSourceFile('fixture.ts',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS)
if(ast.parseDiagnostics.length)throw Error('Original TS parse failed')
const printed=ts.createPrinter({removeComments:true}).printFile(ast)
const scanner=ts.createScanner(ts.ScriptTarget.Latest,true,ts.LanguageVariant.Standard,printed)
let code='',previous=''
const pairs=new Set(['++','--','//','/*','>>','<<','&&','||','??','?.','>=','<=','!=','==','=>','**','+=','-=','/=','%='])
while(scanner.scan()!==ts.SyntaxKind.EndOfFileToken){
 const token=scanner.getTokenText()
 if(previous&&((/[A-Za-z0-9_$]$/.test(previous)&&/^[A-Za-z0-9_$]/.test(token))||pairs.has(previous.slice(-1)+token[0])))code+=' '
 code+=token;previous=token
}
code='/// <reference lib="es2021.weakref" />\n'+code+'\n'
const emit=text=>ts.transpileModule(text,{fileName:'fixture.ts',compilerOptions:{target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,removeComments:true},reportDiagnostics:true})
const before=emit(source),after=emit(code)
writeFileSync(new URL('hook-before.js',dir),before.outputText);writeFileSync(new URL('hook-after.js',dir),after.outputText);writeFileSync(new URL('hook-parse-diagnostics.json',dir),JSON.stringify({before:before.diagnostics.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' ')),after:after.diagnostics.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' '))},null,2));
const normalize=text=>transformSync(text,{loader:'js',target:'esnext',minifyWhitespace:true,minifyIdentifiers:false,minifySyntax:false}).code
if(before.diagnostics.length||after.diagnostics.length||normalize(before.outputText)!==normalize(after.outputText))throw Error('Compact TS changes emitted runtime')
const size=Buffer.byteLength(original)
if(Buffer.byteLength(code)+5>size)throw Error('Hook does not fit original test size')
code+='/*'+' '.repeat(size-Buffer.byteLength(code)-5)+'*/\n'
writeFileSync(new URL('resource-hook.test.ts',dir),code)
