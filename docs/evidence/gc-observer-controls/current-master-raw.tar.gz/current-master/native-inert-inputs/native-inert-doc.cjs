const { firefox } = require('/work/node_modules/playwright')
const fs = require('node:fs')
const path = require('node:path')
const folder = '/work/.codex-linux-control/native-inert-doc'
fs.mkdirSync(folder, { recursive: true })
const matrix = [
 {name:'source-creator',disabled:false,warm:2000,foreign:2000,main:false},
 {name:'main-creator',disabled:false,warm:2000,foreign:2000,main:true},
 {name:'disabled-source',disabled:true,warm:2000,foreign:2000,main:false},
 {name:'source-repeat',disabled:false,warm:2000,foreign:2000,main:false},
]
const {createServer} = require('node:http')
let activeMain=false
const readerModule = () => `export function createNativeCopy(node) {
 const owner=${activeMain ? 'document' : 'node.ownerDocument'};
 const copy=owner.implementation.createHTMLDocument();
 return copy.importNode(node,false).outerHTML.length;
}
globalThis.__nativeReader=createNativeCopy;`
const html = '<body style="margin:0;width:20px;height:20px;background:green"><script type="module" src="/reader.mjs"></script></body>'
const server=createServer((request,response)=>{
 const module=request.url==='/reader.mjs';response.writeHead(200,{'Content-Type':module?'text/javascript':'text/html','Cache-Control':'no-store'});response.end(module?readerModule():html)
})
;(async () => {
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
  const address='http://127.0.0.1:'+server.address().port
  const results = []
  for (const entry of matrix) {
    activeMain=entry.main
    const options = entry.disabled ? { firefoxUserPrefs: {
      'javascript.options.blinterp': false,
      'javascript.options.baselinejit': false,
      'javascript.options.ion': false,
    } } : {}
    const browser = await firefox.launch(options)
    try {
      const page = await browser.newPage()
      await page.goto(address); await page.waitForFunction(()=>typeof globalThis.__nativeReader==='function')
      const setup = await page.evaluate(async ({ warm, foreign }) => {
        let sum = 0
        for (let i = 0; i < warm; i++) sum += globalThis.__nativeReader(document.body)
        await new Promise(resolve => setTimeout(resolve, 0))
        async function removed(read) {
          const frame = document.createElement('iframe')
          frame.srcdoc = '<body style="margin:0;width:20px;height:20px;background:green"></body>'
          const loaded = new Promise(resolve => { frame.onload = () => resolve() })
          document.body.append(frame)
          try {
            await loaded
            if (read) for (let i = 0; i < foreign; i++) sum += globalThis.__nativeReader(frame.contentDocument.body)
            return new WeakRef(frame.contentDocument)
          } finally { frame.remove() }
        }
        globalThis.__nativeReference = await removed(false)
        globalThis.__readReference = await removed(true)
        globalThis.__canaryReference = new WeakRef({ simple: true })
        globalThis.__strongCanary = { held: true }
        globalThis.__strongReference = new WeakRef(globalThis.__strongCanary)
        return { sum, framesRemaining: document.querySelectorAll('iframe').length }
      }, entry)
      for (let i = 0; i < 3; i++) {
        await page.requestGC()
        await page.evaluate(() => undefined)
      }
      const primary = await page.evaluate(() => ({
        nativeCollected: globalThis.__nativeReference.deref() === undefined,
        readCollected: globalThis.__readReference.deref() === undefined,
        canaryCollected: globalThis.__canaryReference.deref() === undefined,
        strongAlive: globalThis.__strongReference.deref() === globalThis.__strongCanary,
      }))
      const result = { entry, browser: browser.version(), setup, primary,
        libraryLoaded: false, collectionRequests: 3, heapInspection: 'only after cached result' }
      const prefix = path.join(folder, entry.name)
      fs.writeFileSync(prefix + '.primary.json', JSON.stringify(result, null, 2))
      if (!primary.readCollected) {
        const handle = await page.evaluateHandle(() => ({ __codexHeap: true,
          reference: globalThis.__readReference, capture: globalThis.__nativeReader,
          negative: { independent: true } }))
        try {
          const properties = await handle.getProperties()
          const graph = JSON.parse(await properties.get('__codex_heap_paths').jsonValue())
          result.graph = graph
          fs.writeFileSync(prefix + '.heap.json', JSON.stringify(graph, null, 2))
          if (graph.file) fs.copyFileSync(graph.file, prefix + '.fxsnapshot')
          if (graph.cc?.file) fs.copyFileSync(graph.cc.file, prefix + '.cc.log')
          if (graph.cc?.gcFile) fs.copyFileSync(graph.cc.gcFile, prefix + '.gc.log')
        } catch (error) { result.inspectionError = String(error) }
        finally { await handle.dispose() }
      }
      results.push(result)
      console.log(JSON.stringify({ name: entry.name, primary, inspectionError: result.inspectionError }))
    } finally { await browser.close() }
  }
  fs.writeFileSync(path.join(folder, 'results.json'), JSON.stringify(results, null, 2))
  await new Promise(resolve=>server.close(resolve))
})().catch(error => { console.error(error); server.close(); process.exitCode = 1 })
