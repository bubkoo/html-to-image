Large PRs make the patch-size check fail with HTTP 406 because the old action downloads a diff beyond GitHub's 20,000-line limit. [The failure on #646](https://github.com/bubkoo/html-to-image/actions/runs/45322882060) is reproducible on its current head.

Count changes from paginated file metadata instead, preserving the existing size thresholds, lockfile exclusion, .gitignore inclusion and rename behavior. Compare the returned file count with `changed_files` before updating labels so GitHub's 3,000-file cap cannot silently produce a smaller label. The workflow reads fresh PR metadata, preserves unrelated labels and avoids checking out repository code in the label job.

Validation: the exact embedded script passes regression checks for later-page files, >20,000 changed lines, ignored/renamed paths, stale/idempotent labels and incomplete listings; these checks now run in CI. Full project lint passes. A read-only replay on #646 at f267e03 reads all 106 files, counts 25,590 lines and selects `size/XXL`; the old diff request returns 406 on the same PR. The replay stubs label writes and does not claim GitHub activation.

`pull_request_target` uses the base workflow, so this PR's normal size check still runs the old action until merge. After full CI/CodeQL pass and merge, verify the updated workflow on #646. No renderer runtime, browser defaults or npm release behavior changes.
