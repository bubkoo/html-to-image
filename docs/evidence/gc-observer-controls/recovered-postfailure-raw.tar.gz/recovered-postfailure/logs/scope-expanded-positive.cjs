const {firefox}=require('/work/node_modules/playwright')
const {writeFileSync}=require('node:fs')
;(async()=>{
 const browser=await firefox.launch()
 try{
  const page=await browser.newPage()
  const handle=await page.evaluateHandle(()=>{
   const target=document.implementation.createHTMLDocument()
   return {__codexInspect:true,target,capture:{closure:(()=>{const held=target;return()=>held})(),bound:(function(value){return value}).bind(null,target),negative:new Function('return 1'), listener:(()=>{const held=target, controller=new AbortController();controller.signal.addEventListener('abort',()=>held);return controller.signal})(), weak:(()=>{const key={};return {key,map:new WeakMap([[key,target]]),set:new WeakSet([key])}})()},renderer:new Map([['owned',target]])}
  })
  try{
   const props=await handle.getProperties();const field=props.get('__codex_scope_graph')
   if(!field)throw Error('Scope diagnostic protocol marker was not returned')
   const graph=JSON.parse(await field.jsonValue());writeFileSync('/work/.codex-linux-control/scope-patch-positive-controls.json',JSON.stringify(graph,null,2))
   const target=new Set(graph.targetMatches)
   for(const prefix of ['scope:','boundArgument:','mapValue:','EPHEMERON-value:'])if(!graph.edges.some(e=>e.label.startsWith(prefix)&&target.has(e.to)))throw Error('Missing positive ownership control '+prefix)
   const negative=graph.edges.find(e=>e.label==='property:negative')?.to
   if(negative===undefined||graph.edges.some(e=>e.from===negative&&target.has(e.to)))throw Error('Negative scope control failed')
   if(!graph.edges.some(e=>e.label==='native-listener:abort'))throw Error('Missing native listener control');
   console.log(JSON.stringify({browser:browser.version(),nodes:graph.nodes.length,targetMatches:graph.targetMatches.length,errors:graph.errors,positiveControls:true,negativeControl:true}))
  }finally{await handle.dispose()}
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1})
