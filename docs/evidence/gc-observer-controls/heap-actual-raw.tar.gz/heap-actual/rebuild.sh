#!/bin/sh
set -eu
name=html-to-image-gc-linux-9a391dc
image=mcr.microsoft.com/playwright@sha256:ee15712262f017b8157421b212b12099146645f44b1bc5c0514cbbe6a229b1d0
docker image inspect "$image" >/dev/null
if docker container inspect "$name" >/dev/null 2>&1; then
  echo 'Owned container already exists; inspect before changing it.' >&2
  exit 1
fi
docker run -d --pull=never --platform linux/amd64 --name "$name" \
  --cpus=4 --memory=6g --shm-size=1g --init --workdir /work \
  --label codex.thread=01a1c6f5-024e-7a03-b9ba-4aba9ec736ea \
  --label codex.purpose=gc-native-controls "$image" sleep infinity
docker exec "$name" mkdir -p /work/.git
docker cp output/playwright/gc-native-controls/heap-actual/source-seed.git/. "$name":/work/.git
docker exec "$name" sh -ec '
  git config core.bare false
  git remote add origin https://github.com/bubkoo/html-to-image.git
  git checkout --detach 9a391dc5639ab80085d73e411ffea5738279d201
  test "$(git rev-parse HEAD)" = 9a391dc5639ab80085d73e411ffea5738279d201
  npm install -g pnpm@10.34.9
  npm install --prefix /opt/codex-node24 node@24.22.2
  test -x /opt/codex-node24/node_modules/node/bin/node
  mkdir -p .codex-linux-control
'
docker exec -e PATH=/opt/codex-node24/node_modules/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin "$name" sh -ec '
  test "$(node --version)" = v24.22.2
  test "$(pnpm --version)" = 10.34.9
  pnpm install --frozen-lockfile --ignore-scripts
'
