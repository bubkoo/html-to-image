import {execFileSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
import ts from '../../../../node_modules/typescript/lib/typescript.js'
import {transformSync} from '../../../../node_modules/.pnpm/esbuild@0.28.2/node_modules/esbuild/lib/main.js'
const dir=new URL('./',import.meta.url)
const original=execFileSync('git',['show','9a391dc:test/browser-unit/capture-lifetime.test.ts'],{encoding:'utf8'})
const needle='      expect(diagnosis.capturedCollected, JSON.stringify(diagnosis)).toBe(true)'
if(!original.includes(needle))throw Error('Original assertion missing')
const hook=`      if (!diagnosis.capturedCollected && server.browser === 'firefox') {
        Reflect.set(globalThis, '__codex_heap_probe', {__codexHeap:true, target:reference.deref(), capture, negative:Object.create(null)})
        try { await commands.recordGCObserverEvidence('__heapPaths:'+JSON.stringify(diagnosis)) }
        finally { Reflect.deleteProperty(globalThis, '__codex_heap_probe') }
      }
`
const source=original.replace(needle,hook+needle)
writeFileSync(new URL('capture-lifetime-hook-source.ts',dir),source)
const ast=ts.createSourceFile('fixture.ts',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS)
if(ast.parseDiagnostics.length)throw Error('Original TS parse failed')
const printed=ts.createPrinter({removeComments:true}).printFile(ast)
const scanner=ts.createScanner(ts.ScriptTarget.Latest,true,ts.LanguageVariant.Standard,printed)
let code='',previous=''
const pairs=new Set(['++','--','//','/*','>>','<<','&&','||','??','?.','>=','<=','!=','==','=>','**','+=','-=','/=','%='])
while(scanner.scan()!==ts.SyntaxKind.EndOfFileToken){
 const token=scanner.getTokenText()
 if(previous&&((/[A-Za-z0-9_$]$/.test(previous)&&/^[A-Za-z0-9_$]/.test(token))||pairs.has(previous.slice(-1)+token[0])))code+=' '
 code+=token;previous=token
}
code='/// <reference lib="es2021.weakref" />\n'+code+'\n'
const emit=text=>ts.transpileModule(text,{fileName:'fixture.ts',compilerOptions:{target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,removeComments:true},reportDiagnostics:true})
const before=emit(source),after=emit(code)
writeFileSync(new URL('hook-before.js',dir),before.outputText);writeFileSync(new URL('hook-after.js',dir),after.outputText);writeFileSync(new URL('hook-parse-diagnostics.json',dir),JSON.stringify({before:before.diagnostics.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' ')),after:after.diagnostics.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' '))},null,2));
const normalize=text=>transformSync(text,{loader:'js',target:'esnext',minifyWhitespace:true,minifyIdentifiers:false,minifySyntax:false}).code
if(before.diagnostics.length||after.diagnostics.length||normalize(before.outputText)!==normalize(after.outputText))throw Error('Compact TS changes emitted runtime')
const size=Buffer.byteLength(original)
if(Buffer.byteLength(code)+5>size)throw Error('Hook does not fit original test size')
code+='/*'+' '.repeat(size-Buffer.byteLength(code)-5)+'*/\n'
writeFileSync(new URL('capture-lifetime-hook.test.ts',dir),code)
let config=execFileSync('git',['show','9a391dc:vitest.browser.config.mts'],{encoding:'utf8'})
config=config.replace("import { mkdir, readFile, readdir, writeFile }", "import { copyFile, mkdir, readFile, readdir, writeFile }")
const key='async recordGCObserverEvidence(_, record: string) {'
if(!config.includes(key))throw Error('Original command missing')
const handler=`async recordGCObserverEvidence({page,frame}, record: string) {
          if(record.startsWith('__heapPaths:')) {
            const primary=JSON.parse(record.slice('__heapPaths:'.length))
            const folder='.vitest/attachments/heap-path'
            await mkdir(folder,{recursive:true})
            const name=folder+'/'+suite+'-'+page.context().browser()!.browserType().name()
            await writeFile(name+'.json',JSON.stringify({primary,phase:'before-heap'},null,2))
            try {
              const f=await frame()
              const handle=await f.evaluateHandle(()=>Reflect.get(globalThis,'__codex_heap_probe'))
              try {
                const properties=await handle.getProperties()
                const result=properties.get('__codex_heap_paths')
                if(!result)throw Error('Heap marker result missing')
                const graph=JSON.parse(await result.jsonValue())
                await writeFile(name+'.json',JSON.stringify({primary,...graph},null,2))
                await copyFile(graph.file,name+'.fxsnapshot')
              } finally { await handle.dispose() }
            } catch(error) {
              await writeFile(name+'.json',JSON.stringify({primary,inspectionError:String(error)},null,2))
            }
            return
          }
`
config=config.replace(key,handler)
writeFileSync(new URL('vitest-heap-hook.config.mts',dir),config)
console.log({originalBytes:size,hookBytes:Buffer.byteLength(code),originalAssertions:true,hook:'after cached primary, no added GC'})
