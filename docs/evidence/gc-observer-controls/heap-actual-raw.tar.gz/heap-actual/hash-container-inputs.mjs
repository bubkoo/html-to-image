import {readdir,readFile,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
const paths=[]
async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=dir+'/'+e.name;if(e.isDirectory())await walk(p);else if(/\.(?:ts|js)$/.test(p))paths.push(p)}}
for(const dir of ['src','es','lib','dist'])await walk(dir)
paths.push('vitest.browser.config.mts','test/browser-unit/capture-lifetime.test.ts','test/browser-unit/resource-resolver-cancellation.test.ts','test/browser-unit/svg-fragment-lifetime.test.ts','test/browser/fixtures/gc-observer-controls.mjs','package.json','pnpm-lock.yaml')
const hashes={};for(const p of paths.sort())hashes[p]=createHash('sha256').update(await readFile(p)).digest('hex')
await writeFile('.codex-linux-control/final-input-sha256.json',JSON.stringify(hashes,null,2))
