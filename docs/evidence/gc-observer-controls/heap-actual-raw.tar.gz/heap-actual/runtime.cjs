const {writeFileSync,readFileSync}=require('node:fs')
const os=require('node:os')
const {chromium,firefox,webkit}=require('/work/node_modules/playwright')
;(async()=>{
 const data={node:process.version,platform:process.platform,architecture:process.arch,
  cpus:os.cpus().length,parallelism:os.availableParallelism(),memory:os.totalmem(),
  cpuMax:readFileSync('/sys/fs/cgroup/cpu.max','utf8').trim(),
  sdk:require('/work/node_modules/playwright/package.json').version,browsers:{}}
 for(const [name,engine]of Object.entries({chromium,firefox,webkit})){
  const browser=await engine.launch()
  try{data.browsers[name]={version:browser.version(),executable:engine.executablePath()}}
  finally{await browser.close()}
 }
 writeFileSync('/work/.codex-linux-control/rebuilt-runtime.json',JSON.stringify(data,null,2))
 console.log(JSON.stringify(data))
})().catch(error=>{console.error(error);process.exitCode=1})
