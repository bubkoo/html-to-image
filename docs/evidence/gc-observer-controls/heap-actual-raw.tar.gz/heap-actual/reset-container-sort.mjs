import {readFile,writeFile,unlink} from 'node:fs/promises'
import {createHash} from 'node:crypto'
const label=process.argv[2]
if(!/^[a-z0-9-]+$/.test(label))throw Error('Invalid control label')
const path='node_modules/.vite/vitest/da39a3ee5e6b4b0d3255bfef95601890afd80709/results.json'
const previous=await readFile(path)
await writeFile('.codex-linux-control/'+label+'-previous-results.json',previous)
await unlink(path)
const config=await readFile('vitest.browser.config.mts')
await writeFile('.codex-linux-control/'+label+'-input.json',JSON.stringify({boundary:process.env.GC_OBSERVER_BOUNDARY||'none',previousSortSHA256:createHash('sha256').update(previous).digest('hex'),configSHA256:createHash('sha256').update(config).digest('hex'),sortingInput:'results.json intentionally absent; optimized bundles retained',primaryAssertionsAndGCCount:'unchanged, three requests'},null,2))
