from pathlib import Path
from zipfile import ZipFile
import json,hashlib
r=Path(__file__).parent
s=(r/'original-Runtime.js').read_text()
needle='  getObjectProperties(objectId) {'
assert s.count(needle)==1
s=s.replace(needle,(r/'heap-method.js').read_text()+'\n'+needle)
needle='    const obj = this._remoteObjects.get(objectId);\n    for (const propertyName'
replacement='''    const obj = this._remoteObjects.get(objectId);
    if (obj instanceof Debugger.Object) {
      let marked = false;
      try { marked = obj.getOwnPropertyDescriptor('__codexHeap')?.value === true; } catch (_) {}
      if (marked) return [{name:'__codex_heap_paths',value:{value:JSON.stringify(this._codexHeapPaths(obj))}}];
    }
    for (const propertyName'''
assert s.count(needle)==1
s=s.replace(needle,replacement)
(r/'patched-Runtime.js').write_text(s)
entry='chrome/juggler/content/content/Runtime.js'
parentEntry='chrome/juggler/content/components/Juggler.js'
parent=(r/'original-Juggler.js').read_text()
parent+="\nServices.ppmm.addMessageListener('codex-heap-state', ({data}) => { const before=ChromeUtils.isDevToolsOpened(); if(data.action==='open')ChromeUtils.notifyDevToolsOpened();else if(data.action==='close')ChromeUtils.notifyDevToolsClosed(); return {before,after:ChromeUtils.isDevToolsOpened()}; });\n"
(r/'patched-Juggler.js').write_text(parent)
with ZipFile(r/'original-omni.ja') as source,ZipFile(r/'patched-omni.ja','w') as target:
 for item in source.infolist():target.writestr(item,s.encode() if item.filename==entry else parent.encode() if item.filename==parentEntry else source.read(item.filename))
with ZipFile(r/'patched-omni.ja') as z:assert z.testzip() is None and z.read(entry)==s.encode()
(r/'patched-manifest.json').write_text(json.dumps({key:hashlib.sha256((r/key).read_bytes()).hexdigest() for key in ['original-omni.ja','patched-omni.ja','original-Runtime.js','patched-Runtime.js']},indent=2)+'\n')
