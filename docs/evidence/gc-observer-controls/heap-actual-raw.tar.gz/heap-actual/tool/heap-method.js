  _codexHeapPaths(root) {
    dump("codex heap begin\n");
    const ids = {}, rawHolds = {};
    for (const key of ['capture', 'negative', 'target']) {
      const object = root.getOwnPropertyDescriptor(key)?.value;
      if (object instanceof Debugger.Object)
        ids[key] = ChromeUtils.getObjectNodeId(rawHolds[key] = object.unsafeDereference());
    }
    dump("codex heap ids "+JSON.stringify(ids)+"\n");
    const opened = Services.cpmm.sendSyncMessage('codex-heap-state', {action:'open'});
    let file, closed;
    try { file = ChromeUtils.saveHeapSnapshot({runtime: true}); }
    finally { closed = Services.cpmm.sendSyncMessage('codex-heap-state', {action:'close'}); }
    const beforeIDs = {...ids};
    for (const key of Object.keys(rawHolds)) ids[key] = ChromeUtils.getObjectNodeId(rawHolds[key]);
    dump("codex heap file "+file+"\n");
    const snapshot = ChromeUtils.readHeapSnapshot(file);
    dump("codex heap read\n");
    const tree = snapshot.computeDominatorTree();
    dump("codex heap tree\n");
    const census = snapshot.takeCensus({breakdown:{by:'coarseType',objects:{by:'objectClass',then:{by:'bucket'}},other:{by:'count'},strings:{by:'count'},scripts:{by:'count'},symbols:{by:'count'},bigInts:{by:'count'}}});
    const documentBuckets = Object.fromEntries(Object.entries(census.objects).filter(([name]) => /Document/.test(name)));
    const documents = Object.values(documentBuckets).flat();
    const targetCandidates = [...snapshot.computeShortestPaths(ids.target, documents, 20)];
    const direct = targetCandidates.filter(([id, paths]) => paths.some(path => path.length === 1));
    if (direct.length !== 1) throw new Error('Expected one direct wrapped document: '+JSON.stringify({documentBuckets,targetCandidates}));
    const wrappedTargetID = ids.target;
    ids.target = direct[0][0];
    const paths = {}, errors = [];
    for (const [name, start] of Object.entries({...ids, gcRoot: tree.root})) {
      if (name === 'target') continue;
      try {
        paths[name] = [...snapshot.computeShortestPaths(start, [ids.target], 20)];
      } catch (error) { errors.push({name, error: String(error)}); }
    }
    return {version: 3, file, ids, beforeIDs, wrappedTargetID, documentBuckets, targetCandidates, opened, closed, root: tree.root, paths, errors,
      limits: {maxPathsPerStart: 20, runtimeSnapshot: true,
        introducedTargetHold: true, introducedAllRootWrapperHolds: true, snapshotIsAfterPrimaryOnly: true,
        rootPathsIncludeInspectorReferences: true}};
  }
