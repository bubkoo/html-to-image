const {firefox}=require('/work/node_modules/playwright')
const {writeFileSync}=require('node:fs')
;(async()=>{
 const browser=await firefox.launch()
 try{
  const page=await browser.newPage()
  const handle=await page.evaluateHandle(()=>{
   const target=document.implementation.createHTMLDocument()
   return {__codexHeap:true,target,capture:{knownOwnedDocument:target},negative:{independent:42}}
  })
  try{
   const props=await handle.getProperties()
   const graph=JSON.parse(await props.get('__codex_heap_paths').jsonValue())
   const unqualified=path=>!path.some(edge=>/\[weak\]|WeakMap entry|Debugger\.Object referent/.test(edge.edge||''));
   graph.controlClassification={weakOrInspectorLabels:['[weak]','WeakMap entry','Debugger.Object referent'],negativeRawPaths:graph.paths.negative.flatMap(([id,paths])=>paths).length,negativeUnqualifiedPaths:graph.paths.negative.flatMap(([id,paths])=>paths).filter(unqualified).length,limits:'Only returned paths (cap20); absence of an unqualified path is not complete unreachability proof'};
   writeFileSync('/work/.codex-linux-control/heap-positive.json',JSON.stringify(graph,null,2))
   if(graph.errors.length)throw Error(JSON.stringify(graph.errors))
   const paths=graph.paths.capture.flatMap(([id,paths])=>paths)
   if(!paths.some(path=>unqualified(path)&&path.some(edge=>edge.edge==='knownOwnedDocument')))throw Error('Known native ownership path missing')
   if(graph.paths.negative.some(([id,paths])=>paths.some(unqualified)))throw Error('Independent negative reaches target')
   console.log(JSON.stringify({browser:browser.version(),file:graph.file,positive:true,negativeReturnedPathsQualified:true,negativeRawPaths:graph.controlClassification.negativeRawPaths,rootPathCount:graph.paths.gcRoot.flatMap(([id,paths])=>paths).length}))
  }finally{await handle.dispose()}
 }finally{await browser.close()}
})().catch(error=>{console.error(error);process.exitCode=1})
