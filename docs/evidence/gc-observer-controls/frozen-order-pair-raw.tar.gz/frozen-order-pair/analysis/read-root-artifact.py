from pathlib import Path
import urllib.request,urllib.error,subprocess,json,zipfile,hashlib,sys
folder=Path(__file__).parent
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
class RemoteZip:
 def __init__(self,url,size):self.url=url;self.size=size;self.pos=0;self.bytes=0;self.cache={}
 def seekable(self):return True
 def tell(self):return self.pos
 def seek(self,offset,whence=0):
  self.pos=offset if whence==0 else self.pos+offset if whence==1 else self.size+offset
  return self.pos
 def read(self,size=-1):
  if size<0:size=self.size-self.pos
  size=min(size,self.size-self.pos)
  if size<=0:return b''
  parts=[]
  while size:
   start=(self.pos//65536)*65536
   if start not in self.cache:
    end=min(start+65536,self.size)
    req=urllib.request.Request(self.url,headers={'Range':f'bytes={start}-{end-1}'})
    with urllib.request.urlopen(req,timeout=30) as r:
     assert r.status==206,'range unavailable'
     data=r.read();assert len(data)==end-start
    self.bytes+=len(data);self.cache[start]=data
   block=self.cache[start];offset=self.pos-start;length=min(size,len(block)-offset)
   parts.append(block[offset:offset+length]);self.pos+=length;size-=length
  return b''.join(parts)
try:
 ident=int(sys.argv[1]);out=folder/sys.argv[2];out.mkdir(exist_ok=True)
 token=subprocess.check_output(['gh','auth','token'],text=True).strip()
 request=urllib.request.Request(f'https://api.github.com/repos/bubkoo/html-to-image/actions/artifacts/{ident}/zip',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'})
 try:urllib.request.build_opener(NoRedirect).open(request,timeout=30);raise RuntimeError('missing redirect')
 except urllib.error.HTTPError as e:
  assert e.code==302
  url=e.headers['Location']
 token=None
 with urllib.request.urlopen(urllib.request.Request(url,method='HEAD'),timeout=30) as r:size=int(r.headers['Content-Length'])
 remote=RemoteZip(url,size);selected=[]
 with zipfile.ZipFile(remote) as z:
  entries=[dict(path=x.filename,bytes=x.file_size,compressedBytes=x.compress_size,crc32=x.CRC) for x in z.infolist()]
  for name in z.namelist():
   if name.endswith('/') or name.endswith('.tar.gz'):continue
   relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
   data=z.read(name);target=out/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
   selected.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 metadata=dict(artifactId=ident,zipBytes=size,networkRangeBytes=remote.bytes,entries=entries,selected=selected,fullGraphArchiveDownloaded=False)
 (out/'zip-entry-index.json').write_text(json.dumps(metadata,indent=2)+'\n')
 print(json.dumps(dict(artifactId=ident,selected=len(selected),rangeBytes=remote.bytes,zipBytes=size)))
except Exception as e:
 print(json.dumps(dict(errorType=type(e).__name__,httpStatus=getattr(e,'code',None))));raise SystemExit(1)
