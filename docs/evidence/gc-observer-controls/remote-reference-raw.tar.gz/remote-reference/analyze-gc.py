"""Search the complete emitted JS graph after excluding explicit weak edges.

Raw logs are authoritative. Debugger edges are kept and labelled, not silently
dropped; native preserved-wrapper roots need the companion native CC graph.
"""
from pathlib import Path
import collections, json, re, sys

heap_path, gc_path, out_path = map(Path, sys.argv[1:])
record = json.loads(heap_path.read_text())
heap = record.get('graph', record)
roots, nodes, incoming = collections.defaultdict(list), {}, collections.defaultdict(list)
proxy_targets = {}
current, after = None, False
weak = re.compile(r'\[weak\]|WeakRefObject::target|WeakMap entry')
excluded = collections.Counter()
weak_maps, unknown = [], []
for line in gc_path.read_text().splitlines():
    if line.startswith('=========='):
        after = True
        continue
    if not line or line.startswith('#'):
        continue
    if line.startswith('WeakMapEntry '):
        weak_maps.append(line)
        continue
    m = re.match(r'^(0x[0-9a-f]+) ([A-Z]) (.*)$', line)
    if m:
        address, color, description = m.groups()
        if after:
            nodes[address] = {'color': color, 'description': description}
            current = address
        else:
            roots[address].append({'color': color, 'description': description})
        continue
    m = re.match(r'^> (0x[0-9a-f]+) ([A-Z]) (.*)$', line)
    if m and after:
        assert current
        address, color, label = m.groups()
        if label == 'proxy target':
            proxy_targets[current] = address
        if weak.search(label):
            excluded[label] += 1
        else:
            incoming[address].append((current, label))
        continue
    unknown.append(line)

assert not unknown, unknown[:5]
assert all(hex(address) in nodes for address in heap['ids'].values())

target = hex(heap['ids']['target'])
seen, toward = {target}, {}
queue = collections.deque([target])
while queue:
    address = queue.popleft()
    for parent, label in incoming.get(address, []):
        if parent not in seen:
            seen.add(parent)
            toward[parent] = {'from': parent, 'edge': label, 'to': address}
            queue.append(parent)
def path(start):
    if start not in seen:
        return None
    result = []
    while start != target:
        step = toward[start]
        result.append(step)
        start = step['to']
    return result

# A second, explicitly qualified view excludes instrumentation boundaries.
# Keep the conservative raw paths above, including undecorated CacheIR edges.
observer_labels = {'realm debugger', 'Debugger.Object referent'}
app_seen, app_toward = {target}, {}
queue = collections.deque([target])
while queue:
    address = queue.popleft()
    for parent, label in incoming.get(address, []):
        if label not in observer_labels and parent not in app_seen:
            app_seen.add(parent)
            app_toward[parent] = {'from':parent,'edge':label,'to':address}
            queue.append(parent)
def application_path(start):
    if start not in app_seen:
        return None
    result = []
    while start != target:
        step = app_toward[start]
        result.append(step)
        start = step['to']
    return result

reaching = [{'address': a, 'roots': descriptions, 'node': nodes.get(a), 'path': path(a)}
    for a, descriptions in roots.items() if a in seen]
reaching.sort(key=lambda row: len(row['path']))
report = {'heap': str(heap_path), 'gc': str(gc_path), 'target': target,
    'nodeCount': len(nodes), 'rootAddressCount': len(roots),
    'excludedWeakEdgeCounts': dict(excluded), 'reverseReachableNodes': len(seen),
    'conditionalWeakMapRecords': weak_maps, 'unparsedRows': len(unknown),
    'reachingRoots': reaching,
    'applicationObjectStarts':'not inspected or unwrapped',
    'explicitMemberOwners':[{'from':parent,'edge':label,'to':target} for parent,label in incoming.get(target,[]) if label=='knownOwnedDocument'],
    'moduleRootWitnesses':[row for row in reaching if any(root['description'].startswith('mModuleRecord') for root in row['roots'])],
    'observerExcludedModuleWitnesses':[{'address':a,'roots':descriptions,'node':nodes.get(a),'path':application_path(a)} for a,descriptions in roots.items() if a in app_seen and any(root['description'].startswith('mModuleRecord') for root in descriptions)],
    'cacheIRPolicy':'Keep undecorated cacheir-weak-* edges: pinned ShouldTraceWeakEdgeInStub traces them strongly for IonICStub; names alone are insufficient. Privileged wrapper and content proxy-target starts are reported separately.',
    'limits': 'Complete emitted ordinary-edge graph search under listed weak-edge exclusions; conditional WeakMap records preserved but not modeled as unconditional edges. Not complete runtime heap or native CC reachability. Debugger references retained. Native preserved-wrapper roots require CC ownership analysis. After cached primary; not proof of original pre-inspection root.'}
out_path.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['nodeCount','rootAddressCount','reverseReachableNodes']}))
print('reaching roots', len(reaching), 'module witnesses',len(report['moduleRootWitnesses']))
for row in reaching[:8]:
    print(json.dumps({'address': row['address'], 'rootLabels': row['roots'], 'pathLength': len(row['path']), 'path':row['path'][:4]}))
