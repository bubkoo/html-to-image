"""Decode all saved Firefox graph bytes; no live heap access or new collection.

Schema: Mozilla CoreDump.proto; interning order follows HeapSnapshot::saveNode.
Raw snapshot and Firefox's own path/census output remain authoritative controls.
"""
from pathlib import Path
from collections import defaultdict, deque, Counter
import gzip,json,re,sys
snapshot_path, graph_path, out_path = map(Path,sys.argv[1:])
record=json.loads(graph_path.read_text()); graph=record.get('graph',record)
data=gzip.decompress(snapshot_path.read_bytes())

def varint(buf,pos):
    value=0
    for shift in range(0,70,7):
        assert pos<len(buf),'Truncated varint'
        byte=buf[pos];pos+=1;value|=(byte&127)<<shift
        if byte<128:return value,pos
    raise AssertionError('Oversized varint')

def fields(buf,allowed):
    result=defaultdict(list);pos=0
    while pos<len(buf):
        key,pos=varint(buf,pos);number,wire=key>>3,key&7
        assert number in allowed,(number,allowed)
        if wire==0:value,pos=varint(buf,pos)
        elif wire==2:
            size,pos=varint(buf,pos);end=pos+size
            assert end<=len(buf),'Truncated length field'
            value=buf[pos:end];pos=end
        else:raise AssertionError(('Unexpected wire type',wire))
        result[number].append(value)
    return result

def one(f,k,default=None):
    if k not in f:return default
    assert len(f[k])==1,k
    return f[k][0]

strings8=[];strings16=[];frames={}
def string(f,literal,reference,width):
    assert not(literal in f and reference in f)
    table=strings16 if width==16 else strings8
    if literal in f:
        raw=one(f,literal)
        if width==16:assert len(raw)%2==0
        value=raw.decode('utf-16-le' if width==16 else 'utf-8',errors='surrogatepass')
        table.append(value);return value
    if reference in f:
        index=one(f,reference);assert index<len(table),(index,len(table))
        return table[index]
    return None

def stack(buf):
    f=fields(buf,{1,2})
    if 2 in f:assert one(f,2) in frames;return
    d=fields(one(f,1),set(range(1,11)))
    identifier=one(d,1);assert identifier not in frames
    source=string(d,5,6,16);name=string(d,7,8,16)
    if 2 in d:stack(one(d,2))
    frames[identifier]={'source':source,'function':name}

pos=0;messages=[]
while pos<len(data):
    size,pos=varint(data,pos);assert size>0 and pos+size<=len(data)
    messages.append(data[pos:pos+size]);pos+=size
assert pos==len(data)
metadata=fields(messages[0],{1});nodes={};incoming=defaultdict(list)
for buf in messages[1:]:
    f=fields(buf,set(range(1,14)));identifier=one(f,1)
    assert identifier is not None and identifier not in nodes
    typename=string(f,2,3,16);assert typename is not None
    assert 4 in f
    edges=[]
    for b in f.get(5,[]):
        e=fields(b,{1,2,3});target=one(e,1);assert target is not None
        label=string(e,2,3,16);edges.append((target,label));incoming[target].append((identifier,label))
    if 6 in f:stack(one(f,6))
    cls=string(f,7,8,8);filename=string(f,10,11,8)
    description=string(f,12,13,16)
    nodes[identifier]={'type':typename,'class':cls,'script':filename,'description':description,'edges':edges}
root=next(iter(nodes))
assert all(t in nodes for n in nodes.values() for t,_ in n['edges'])
if 'root' in graph:assert root==graph['root']
assert all(value in nodes for value in graph['ids'].values())
for cls,ids in graph.get('documentBuckets',{}).items():
    assert set(ids)=={i for i,n in nodes.items() if n['class']==cls},cls
api_paths=0
for mapped in [*graph.get('paths',{}).values(),graph.get('targetCandidates',[])]:
    for target,paths in mapped:
        for path in paths:
            for i,step in enumerate(path):
                next_id=path[i+1]['predecessor'] if i+1<len(path) else target
                assert (next_id,step['edge']) in nodes[step['predecessor']]['edges']
            api_paths+=1
weak=re.compile(r'\[weak\]|WeakRefObject::target|WeakMap entry')
observer={'realm debugger','Debugger.Object referent'}
target=graph['ids'].get('target');root_edges=nodes[root]['edges']

def reverse(skip_observer=False):
    if target is None:return set(),{}
    seen={target};toward={};queue=deque([target])
    while queue:
        address=queue.popleft()
        for parent,label in incoming.get(address,[]):
            if weak.search(label or '') or (skip_observer and label in observer):continue
            if parent not in seen:
                seen.add(parent);toward[parent]=(address,label);queue.append(parent)
    return seen,toward

def witnesses(skip_observer=False):
    seen,toward=reverse(skip_observer);result=[]
    for start,label in root_edges:
        if start not in seen or weak.search(label or '') or (skip_observer and label in observer):continue
        path=[{'from':root,'edge':label,'to':start}];current=start
        while current!=target:
            nxt,edge=toward[current];path.append({'from':current,'edge':edge,'to':nxt});current=nxt
        result.append({'rootEdge':label,'start':start,'path':path,'nodes':[{'id':step['to'],**{k:v for k,v in nodes[step['to']].items() if k!='edges'}} for step in path]})
    return result
raw=witnesses();qualified=witnesses(True)
summary={'snapshot':str(snapshot_path),'graph':str(graph_path),'metadata':dict(metadata),'nodeCount':len(nodes),'edgeCount':sum(len(n['edges']) for n in nodes.values()),'root':root,'target':target,'rootEdgeCount':len(root_edges),'nativeAPIPathsVerified':api_paths,'documentCensusVerified':True,'unparsedBytes':0,'explicitMemberOwners':[{'from':p,'edge':l,'to':target} for p,l in incoming.get(target,[]) if l=='knownOwnedDocument'],'rootWitnesses':raw,'observerExcludedRootWitnesses':qualified,'moduleWitnesses':[p for p in qualified if (p['rootEdge'] or '').startswith('mModuleRecord')],'cacheIRWitnesses':[p for p in qualified if any('cacheir' in (s['edge'] or '').lower() for s in p['path'])],'excludedWeakNames':dict(Counter(l for n in nodes.values() for _,l in n['edges'] if weak.search(l or ''))),'limits':'Complete serialized graph, not whole runtime/native ownership; candidate paths are not all proven strong. Explicit weak/WeakMap exclusions only; undocumented CacheIR fields conservative. Observer boundaries separately excluded. After cached primary and snapshot; no unique pre-verdict cause asserted.'}
out_path.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['nodeCount','edgeCount','rootEdgeCount','nativeAPIPathsVerified','explicitMemberOwners']}))
print('reaching roots',len(raw),'observer-excluded',len(qualified),'module',len(summary['moduleWitnesses']),'cacheIR',len(summary['cacheIRWitnesses']))
