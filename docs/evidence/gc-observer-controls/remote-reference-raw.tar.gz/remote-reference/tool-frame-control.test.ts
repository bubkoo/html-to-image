/// <reference lib="es2021.weakref" />
import {test,expect} from 'vitest'
import {commands} from 'vitest/browser'
import {recordReferenceFailure} from '../browser/fixtures/reference-lifetime-probe'

test('tool control resolves the existing WeakRef through the test frame',async()=>{
 const owner={knownOwnedDocument:document.implementation.createHTMLDocument()}
 const reference=new WeakRef(owner.knownOwnedDocument)
 Reflect.set(globalThis,'__referenceKnownOwner',owner)
 try{
  await commands.collectGarbage()
  await commands.collectGarbage()
  await commands.collectGarbage()
  const held=reference.deref()!==undefined
  expect(held).toBe(true)
  await recordReferenceFailure('tool-frame-control',reference,{held,toolControl:true})
 }finally{Reflect.deleteProperty(globalThis,'__referenceKnownOwner')}
})
