  _codexHeapPaths(root) {
    dump("codex heap begin\n");
    const ids = {}, rawHolds = {};
    for (const key of ['capture', 'negative', 'target']) {
      const object = root.getOwnPropertyDescriptor(key)?.value;
      if (object instanceof Debugger.Object)
        ids[key] = ChromeUtils.getObjectNodeId(rawHolds[key] = object.unsafeDereference());
    }
    dump("codex heap ids "+JSON.stringify(ids)+"\n");
    const opened = Services.cpmm.sendSyncMessage('codex-heap-state', {action:'open'});
    let file, closed;
    try { file = ChromeUtils.saveHeapSnapshot({runtime: true}); }
    finally { closed = Services.cpmm.sendSyncMessage('codex-heap-state', {action:'close'}); }
    const beforeIDs = {...ids};
    for (const key of Object.keys(rawHolds)) ids[key] = ChromeUtils.getObjectNodeId(rawHolds[key]);
    dump("codex heap file "+file+"\n");
    const snapshot = ChromeUtils.readHeapSnapshot(file);
    dump("codex heap read\n");
    const tree = snapshot.computeDominatorTree();
    dump("codex heap tree\n");
    const paths = {}, errors = [];
    for (const [name, start] of Object.entries({...ids, gcRoot: tree.root})) {
      if (name === 'target') continue;
      try {
        paths[name] = [...snapshot.computeShortestPaths(start, [ids.target], 20)];
      } catch (error) { errors.push({name, error: String(error)}); }
    }
    return {version: 2, file, ids, beforeIDs, opened, closed, root: tree.root, paths, errors,
      limits: {maxPathsPerStart: 20, runtimeSnapshot: true,
        introducedTargetHold: true, introducedAllRootWrapperHolds: true, snapshotIsAfterPrimaryOnly: true,
        rootPathsIncludeInspectorReferences: true}};
  }
