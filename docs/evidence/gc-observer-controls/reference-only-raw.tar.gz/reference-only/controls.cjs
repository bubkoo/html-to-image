const {firefox}=require('/work/node_modules/playwright')
const fs=require('node:fs')
const path=require('node:path')
const folder='/work/.codex-linux-control/reference-only-controls'
fs.mkdirSync(folder,{recursive:true})
;(async()=>{
 const browser=await firefox.launch()
 try{
  const page=await browser.newPage()
  await page.evaluate(()=>{
   const held=document.implementation.createHTMLDocument()
   const negative=document.implementation.createHTMLDocument()
   globalThis.__codexKnownOwner={knownOwnedDocument:held}
   globalThis.__codexPositiveRef=new WeakRef(held)
   globalThis.__codexNegativeRef=new WeakRef(negative)
  })
  for(let i=0;i<3;i++){
   await page.requestGC()
   await page.evaluate(()=>undefined)
  }
  const primary=await page.evaluate(()=>({
   positiveHeld:globalThis.__codexPositiveRef.deref()!==undefined,
   negativeCollected:globalThis.__codexNegativeRef.deref()===undefined,
  }))
  fs.writeFileSync(path.join(folder,'primary.json'),JSON.stringify(primary,null,2))
  if(!primary.positiveHeld||!primary.negativeCollected)throw Error('Control primary invalid: '+JSON.stringify(primary))
  for(const [label,key]of [['positive','__codexPositiveRef'],['negative','__codexNegativeRef']]){
   const handle=await page.evaluateHandle(key=>({__codexHeap:true,reference:globalThis[key]}),key)
   try{
    const props=await handle.getProperties()
    const graph=JSON.parse(await props.get('__codex_heap_paths').jsonValue())
    fs.writeFileSync(path.join(folder,label+'.json'),JSON.stringify({primary,...graph},null,2))
    if(graph.file)fs.copyFileSync(graph.file,path.join(folder,label+'.fxsnapshot'))
    if(graph.cc?.file)fs.copyFileSync(graph.cc.file,path.join(folder,label+'.cc.log'))
    if(graph.cc?.gcFile)fs.copyFileSync(graph.cc.gcFile,path.join(folder,label+'.gc.log'))
    if(label==='positive' && (!graph.ids.target||graph.errors.length||graph.cc?.wantAllTraces!==false))throw Error('Held identity control failed')
    if(label==='negative' && (graph.ids.target||graph.observedDirectTargets!==0))throw Error('Collected reference unexpectedly has a direct document target')
    console.log(JSON.stringify({label,primary,targetPresent:!!graph.ids.target,errors:graph.errors,targetState:graph.targetState}))
   }finally{await handle.dispose()}
  }
 }finally{await browser.close()}
})().catch(error=>{console.error(error);process.exitCode=1})
