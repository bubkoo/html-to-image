from pathlib import Path
import json,re
out=Path('output/playwright/gc-native-controls');result={}
strip=lambda s:re.sub(r'(?:\x1b|\^\[)\[[0-9;]*m','',s)
for event in ['pr','push']:
 b=out/('linux-'+event+'-artifacts');records=[]
 for f in b.rglob('*.json'):
  if f.parent.name not in ['gc-observers','same-configuration-control']:continue
  try:d=json.loads(f.read_text())
  except Exception:continue
  if 'observers' in d:records.append(d)
 phases={}
 for phase in ['normal','same-configuration-control']:
  rr=[d for d in records if d.get('phase','normal')==phase];rows=[r for d in rr for r in d['observers']['rows']];native=[r for r in rows if r.get('configuration')]
  phases[phase]=dict(records=len(rr),retainedPrimary=[d['engine']+'-'+d['kind'] for d in rr if not d['primary']['ownerCollected']],newNativeRows=len(native),newNativeRetained=sum(x.get('documentCollected') is False for x in native),newNativeErrors=sum(bool(x.get('error')) for x in native),retainedSupplemental=[dict(engine=d['engine'],kind=d['kind'],owner=r.get('owner'),helper=r['helper']) for d in rr for r in d['observers']['rows'] if r.get('documentCollected') is False],noCollectionCheckpoints={d['engine']+'-'+d['kind']:d['observers'].get('noCollectionCheckpoint') for d in rr if not d['primary']['ownerCollected']})
 cache=next(b.rglob('gc-order-cache/manifest.json'));manifest=json.loads(cache.read_text());restored=json.loads((cache.parent/'same-configuration-control-restored.json').read_text());assert restored['files']==manifest['files'];assert len(manifest['files'])==1
 for f in manifest['files']:
  from hashlib import sha256
  assert sha256((cache.parent/'initial'/f['path']).read_bytes()).hexdigest()==f['sha256']
 s=strip((out/('linux-'+event+'-ci.log')).read_text());ordinary=[]
 for line in s.splitlines():
  if '\t🧪' not in line:continue
  payload=re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s+', '', line.split('\t')[-1]).strip()
  if re.match(r'^(Test Files|Tests)\b',payload):ordinary.append(payload)
 log=next(b.rglob('gc-same-configuration-control.log'));s=strip(log.read_text());repeat=[l.strip() for l in s.splitlines() if re.match(r'^\s*(Test Files|Tests)\b',l)]
 result[event]=dict(run=43677392127 if event=='pr' else 43677387222,ordinary=ordinary,repeat=repeat,sortingRestorationVerified=True,phases=phases)
result['head']='9a391dc5639ab80085d73e411ffea5738279d201';result['conclusion']='All new native sandbox/policy-document/reaction/lock rows collect without errors. Those differences alone do not reproduce the retained original. Ordinary source still fails in both events; the identical-sort repeat fails in PR and passes in push. No production fix or unique cause established.'
(out/'linux-native-controls-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for event in ['pr','push']:
 s=result[event];print(event,s['ordinary'],s['repeat']);print({p:dict(primary=x['retainedPrimary'],newNativeRows=x['newNativeRows'],newNativeRetained=x['newNativeRetained'],retainedSupplemental=len(x['retainedSupplemental'])) for p,x in s['phases'].items()})
