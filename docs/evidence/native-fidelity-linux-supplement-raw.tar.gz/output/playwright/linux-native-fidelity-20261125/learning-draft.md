# Draft: fixed-head Linux checks need both platform and fixture identity boundaries

The complete source and built-package phases omitted by #651's earlier coverage stop were measured for exact head `08d35a13aee74a6188b3250585256a222c05717b` in the existing container. Source is 1343/1/45; corrected complete package is 174/4/2. Strict pixel failures remain.

Chromium DPR1 `visible-text` differs by 214 channels/max88. Linux WebKit DPR1 passes the two Mac source gates, while the DesktopSafari DPR2 package fails `visible-text` and `fractional` in both ESM and UMD. Platform, backend and DPR boundaries must be retained separately.

An archive alone cannot run the full mobile report fixture: both server and assertion read `git rev-parse HEAD`. Preserve the initial failed/terminated harness result, then add the actual commit and complete current tree/blob objects, detached HEAD, index and a legal shallow boundary in the private checkout. Verify all 936 blobs before a new package attempt. Do not fake the report identity, modify assertions or reclassify the first run as product failure.

The supplied amd64 container executes through Rosetta and uses Node 26.13.0 rather than CI's Node 24. Actual runner/PW worker/server cmdlines include `--no-opt -r /proc/.reset`; the small preload slices these from `process.execArgv`. Thus `execArgv` alone is insufficient platform evidence. Read the actual runner and browser `/proc/<pid>/cmdline` from a non-Node observer and distinguish PID1. Keep the wrapper unchanged and do not call the result default Node or native Ubuntu CI acceptance.

Complete source and corrected package used identical 1083 measured inputs; original `/work` tracked files and Vite caches remained unchanged. Full dependency copying avoids cache writes through a shared node_modules symlink. No installs, image pulls, network changes, runtime patches, timeout/retry/skip changes or browser flag changes were made. The container is retained after owned browsers/servers exit.

Publish only exact failure assets, logs, identity/manifests, raw verdicts, environment arguments and construction scripts. Public source commits are recoverable; repeating a whole source tar, Git object pack or dependency tree in documentation archives creates unnecessary growth.
