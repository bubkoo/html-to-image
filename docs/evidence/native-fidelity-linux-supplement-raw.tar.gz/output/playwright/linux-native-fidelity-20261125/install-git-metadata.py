from pathlib import Path
import json,subprocess

folder=Path(__file__).resolve().parent
container='html-to-image-gc-linux-9a391dc'
subprocess.run(['docker','cp',str(folder/'fixed-head-snapshot.pack'),container+':/tmp/hti-651-fixed-head-snapshot.pack'],check=True)
code=r'''
import pathlib,subprocess,json,hashlib
root=pathlib.Path('/tmp/html-to-image-651-source-package-08d35a1');head='08d35a13aee74a6188b3250585256a222c05717b'
def git(*args,**kwargs):return subprocess.run(['git','-C',str(root),*args],check=True,capture_output=True,**kwargs)
git('init','--quiet')
with open('/tmp/hti-651-fixed-head-snapshot.pack','rb') as stream:git('unpack-objects','-q',stdin=stream)
commit=git('cat-file','-p',head).stdout.decode();parents=[line.split()[1] for line in commit.splitlines() if line.startswith('parent ')]
missing=[oid for oid in parents if subprocess.run(['git','-C',str(root),'cat-file','-e',oid],capture_output=True).returncode]
if missing:(root/'.git/shallow').write_text(head+'\n')
git('update-ref','--no-deref','HEAD',head);git('read-tree',head)
expected=json.loads((root/'git-tracked-inputs.json').read_text());actual={}
for row in git('ls-files','--stage','-z').stdout.split(b'\0'):
 if not row:continue
 metadata,name=row.split(b'\t',1);mode,oid,stage=metadata.decode().split();actual[name.decode()]={'mode':mode,'oid':oid,'stage':stage}
wrong=[]
for item in expected['files']:
 data=(root/item['path']).read_bytes();index=actual.get(item['path']);oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if index!={'mode':item['gitMode'],'oid':item['gitBlob'],'stage':'0'} or oid!=item['gitBlob']:wrong.append(item['path'])
assert len(actual)==expected['count'] and not wrong,(len(actual),wrong)
git('diff','--quiet','HEAD','--')
result={'head':git('rev-parse','HEAD').stdout.decode().strip(),'tree':git('rev-parse','HEAD^{tree}').stdout.decode().strip(),'detached':subprocess.run(['git','-C',str(root),'symbolic-ref','-q','HEAD'],capture_output=True).returncode==1,'shallow':git('rev-parse','--is-shallow-repository').stdout.decode().strip(),'shallowBoundaryHead':head if missing else None,'absentParentObjects':missing,'indexCount':len(actual),'all936IndexAndWorkingTreeBlobsMatch':not wrong,'trackedGitDiffEmpty':True,'onlyFixtureGitMetadataAdded':True,'sourceOrAssertionsChanged':False}
print(json.dumps(result))
'''
result=json.loads(subprocess.check_output(['docker','exec',container,'python3','-c',code],text=True))
(folder/'git-metadata-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
