from pathlib import Path
import subprocess,json,hashlib

folder=Path(__file__).resolve().parent
head='08d35a13aee74a6188b3250585256a222c05717b'
tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],text=True).strip()
objects={head,tree}
for raw in subprocess.check_output(['git','ls-tree','-r','-t','-z',head]).split(b'\0'):
    if raw:objects.add(raw.split(b'\t',1)[0].decode().split()[2])
pack=folder/'fixed-head-snapshot.pack'
with pack.open('wb') as stream:
    subprocess.run(['git','pack-objects','--stdout'],input=('\n'.join(sorted(objects))+'\n').encode(),stdout=stream,check=True)
(folder/'fixed-head-snapshot-pack.json').write_text(json.dumps({'head':head,'tree':tree,'objectCount':len(objects),'packSha256':hashlib.sha256(pack.read_bytes()).hexdigest(),'packBytes':pack.stat().st_size,'scope':'Exact commit and complete current tree/blob objects, without parent history. Ignored local input; publish construction command/SHA only, never this pack.'},indent=2)+'\n')
