from pathlib import Path
import json,subprocess,sys

folder=Path(__file__).resolve().parent
code=r'''
import os,json,time
rows=[]
for pid in os.listdir('/proc'):
 if not pid.isdigit():continue
 try:
  args=[a.decode(errors='replace') for a in open('/proc/'+pid+'/cmdline','rb').read().split(b'\0') if a]
  status=open('/proc/'+pid+'/status').read()
  ppid=int(next(x for x in status.splitlines() if x.startswith('PPid:')).split()[1])
  rows.append({'pid':int(pid),'ppid':ppid,'cwd':os.readlink('/proc/'+pid+'/cwd'),'exe':os.readlink('/proc/'+pid+'/exe'),'args':args})
 except (OSError,StopIteration):pass
roots=[r['pid'] for r in rows if 'run-package-only.mjs' in r['args'] and r['cwd']=='/tmp/html-to-image-651-source-package-08d35a1']
owned=set(roots)
while True:
 more={r['pid'] for r in rows if r['ppid'] in owned}
 if more.issubset(owned):break
 owned|=more
print(json.dumps({'at':time.time(),'observer':'Python3 /proc reads; no Node preload','rootRunnerPids':roots,'pid1':[r for r in rows if r['pid']==1],'runnerAndDescendants':[r for r in rows if r['pid'] in owned]}))
'''
data=json.loads(subprocess.check_output(['docker','exec','html-to-image-gc-linux-9a391dc','python3','-c',code],text=True))
(folder/('corrected-process-'+sys.argv[1]+'.json')).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'roots':data['rootRunnerPids'],'count':len(data['runnerAndDescendants']),'engines':[r['exe'] for r in data['runnerAndDescendants'] if r['exe'].startswith('/ms-playwright/')]}))
