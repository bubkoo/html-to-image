import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import net from 'node:net'
import { spawn, execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const root = path.dirname(fileURLToPath(import.meta.url)), output = root + '-package-with-git-evidence'
fs.mkdirSync(output)
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
const write = (name, value) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n')
const identity = JSON.parse(fs.readFileSync(path.join(root, 'git-tracked-inputs.json')))
const walk = (dir, prefix = '') => {
  if (!fs.existsSync(dir)) return {}
  const result = {}
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const relative = prefix + entry.name, absolute = path.join(dir, entry.name)
    if (entry.isDirectory()) Object.assign(result, walk(absolute, relative + '/'))
    else if (entry.isFile()) result[relative] = hash(fs.readFileSync(absolute))
    else if (entry.isSymbolicLink()) result[relative] = 'symlink:' + fs.readlinkSync(absolute)
  }
  return result
}
const manifest = () => {
  const result = Object.fromEntries(identity.files.map(item => [item.path, hash(fs.readFileSync(path.join(root, item.path)))]))
  for (const folder of ['es', 'lib', 'dist']) for (const [file, sha] of Object.entries(walk(path.join(root, folder)))) result[folder + '/' + file] = sha
  return result
}
const originalWork = () => ({ tracked: Object.fromEntries(identity.files.filter(item => fs.existsSync('/work/' + item.path)).map(item => [item.path, hash(fs.readFileSync('/work/' + item.path))])), viteCache: walk('/work/node_modules/.vite'), viteTemp: walk('/work/node_modules/.vite-temp') })
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b)
const gitState = () => Object.fromEntries(['HEAD', 'index', 'config', 'shallow'].map(file => [file, fs.existsSync(path.join(root, '.git', file)) ? hash(fs.readFileSync(path.join(root, '.git', file))) : null]))
const original = JSON.parse(fs.readFileSync(root + '-evidence/original-work-before.json'))
const workBefore = originalWork(), before = manifest(), gitBefore = gitState()
write('original-work-before.json', workBefore); write('inputs-before.json', before); write('git-before.json', gitBefore)
const ports = []
for (const port of [4197, 4198]) await new Promise((resolve, reject) => {
  const server = net.createServer(); server.once('error', reject)
  server.listen(port, '127.0.0.1', () => server.close(() => { ports.push({ port, freeBeforeLaunch: true }); resolve() }))
})
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim()
const tree = execFileSync('git', ['rev-parse', 'HEAD^{tree}'], { cwd: root, encoding: 'utf8' }).trim()
const precondition = { head, tree, headMatchesFixedTarget: head === identity.head && tree === identity.tree, trackedInputsExact: identity.files.every(item => before[item.path] === item.sha256), originalWorkMatchesInitialBaseline: equal(original, workBefore), ports, sourceNotRerun: true, buildNotRerun: true, browserFlagsUnmodified: true, packageConfigurationSha256: before['playwright.config.ts'], node: process.version, originalNodeWrapperRetained: true }
write('preconditions.json', precondition)
if (!precondition.headMatchesFixedTarget || !precondition.trackedInputsExact || !precondition.originalWorkMatchesInitialBaseline) throw new Error('Corrected package preconditions failed')
const command = ['pnpm', 'run', 'test:browser:package'], env = { CI: 'true', HTML_TO_IMAGE_SMOKE_PORT: '4197' }
const fd = fs.openSync(path.join(output, 'run.log'), 'w'), started = Date.now()
console.log('START corrected-complete-package', JSON.stringify({ command, env, head, tree }))
const child = spawn(command[0], command.slice(1), { cwd: root, env: { ...process.env, ...env }, stdio: ['ignore', fd, fd] })
let result
try { result = await new Promise((resolve, reject) => { child.on('error', reject); child.on('exit', (code, signal) => resolve({ code, signal })) }) }
finally { fs.closeSync(fd) }
const after = manifest(), workAfter = originalWork(), gitAfter = gitState()
write('inputs-after.json', after); write('original-work-after.json', workAfter); write('git-after.json', gitAfter)
for (const [source, target] of [['test-results', 'test-results'], ['playwright-report', 'playwright-report']]) if (fs.existsSync(path.join(root, source))) fs.cpSync(path.join(root, source), path.join(output, target), { recursive: true })
const receipt = { command, environment: env, exitCode: result.code, signal: result.signal, durationSeconds: (Date.now() - started) / 1000, head, tree, node: process.version, ciNode: '24 (not this run)', measuredInputCount: Object.keys(before).length, inputsStable: equal(before, after), trackedExactAfter: identity.files.every(item => after[item.path] === item.sha256), originalWorkMatchesInitialBaselineBefore: equal(original, workBefore), originalWorkUnchangedAfter: equal(workBefore, workAfter), gitMetadataStable: equal(gitBefore, gitAfter), previousIncompleteHarnessAttemptPreserved: true, retriesAssertionsTimeoutsAndBrowserFlagsUnchanged: true, sourceOrBuildRerun: false }
write('receipt.json', receipt); console.log('END corrected-complete-package', JSON.stringify(receipt))
process.exitCode = result.code || 0
