from pathlib import Path
import hashlib,json,subprocess,tarfile,time

folder=Path(__file__).resolve().parent
head='08d35a13aee74a6188b3250585256a222c05717b'
container='html-to-image-gc-linux-9a391dc'
temporary='/tmp/html-to-image-651-source-package-08d35a1'
archive=folder/'source-08d35a1.tar'
subprocess.run(['git','archive','--format=tar','--output='+str(archive),head],check=True)
tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],text=True).strip()
entries={}
for raw in subprocess.check_output(['git','ls-tree','-r','-z',head]).split(b'\0'):
    if not raw:continue
    metadata,path=raw.split(b'\t',1)
    mode,kind,blob=metadata.decode().split()
    entries[path.decode()]={'path':path.decode(),'gitMode':mode,'gitType':kind,'gitBlob':blob}
with tarfile.open(archive) as tar:
    for member in tar.getmembers():
        if member.isfile():
            data=tar.extractfile(member).read()
            if member.name not in entries:raise RuntimeError('Unexpected archive file '+member.name)
            item=entries[member.name];item['sha256']=hashlib.sha256(data).hexdigest();item['bytes']=len(data)
            item['gitBlobMatches']=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['gitBlob']
        elif member.issym():entries[member.name]['symlinkTarget']=member.linkname
missing=[p for p,r in entries.items() if r['gitType']=='blob' and 'sha256' not in r and 'symlinkTarget' not in r]
if missing:raise RuntimeError('Tracked archive files absent: '+str(missing))
if any(r.get('gitBlobMatches') is False for r in entries.values()):raise RuntimeError('Archive bytes differ from Git blob')
manifest={'head':head,'tree':tree,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'count':len(entries),'files':list(entries.values())}
(folder/'git-tracked-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['docker','cp',str(archive),container+':/tmp/hti-651-source-08d35a1.tar'],check=True)
subprocess.run(['docker','exec',container,'mkdir',temporary],check=True)
subprocess.run(['docker','exec',container,'tar','-xf','/tmp/hti-651-source-08d35a1.tar','-C',temporary],check=True)
start=time.monotonic()
subprocess.run(['docker','exec',container,'cp','-a','/work/node_modules',temporary+'/node_modules'],check=True)
subprocess.run(['docker','cp',str(folder/'git-tracked-inputs.json'),container+':'+temporary+'/git-tracked-inputs.json'],check=True)
receipt={'head':head,'tree':tree,'container':container,'temporary':temporary,'archiveSha256':manifest['archiveSha256'],'trackedCount':len(entries),'allGitBlobBytesMatch':True,'dependencyCopySeconds':time.monotonic()-start,'copiedNodeModules':True,'nodeModulesSymlinkToWork':False,'hostMainlineModified':False}
(folder/'setup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
