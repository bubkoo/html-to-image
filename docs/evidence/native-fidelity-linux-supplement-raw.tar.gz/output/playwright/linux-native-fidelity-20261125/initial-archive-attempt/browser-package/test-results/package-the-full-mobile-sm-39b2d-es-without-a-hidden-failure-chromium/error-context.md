# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: package.test.ts >> the full mobile smoke page completes without a hidden failure
- Location: test/browser/package.test.ts:187:5

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#results')
- Expected substring  -  1
+ Received string     + 42

- REPORT SAVED
+ INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
+ PASS ESM import and basic PNG
+ PASS UMD global and pixels
+ PASS empty video preserves background and border
+ PASS canvas snapshot pixels
+ PASS explicit dimensions and pixel ratio
+ PASS fractional fonts and tight last word
+ PASS SVG font-family glyph pixels
+ PASS SVG references after clone transforms
+ PASS iframe fonts and document scope
+ PASS capture source document lifetime
+ PASS pseudo background and injected mask resources
+ PASS SVG dependency graphs and reference precedence
+ PASS external SVG use cycles preserve scoped identities
+ PASS external SVG preserves native stylesheet scope
+ PASS external SVG font units retain loaded metrics
+ PASS external SVG data stylesheet imports preserve native scope
+ PASS external SVG fragments preserve native paint scope
+ PASS external SVG redirects preserve file CSS bases
+ PASS resource cache lifetime
+ PASS native HTTP cache policy
+ PASS per-URL resource credentials
+ PASS relative clone resources and callback errors
+ PASS per-node customization
+ PASS shadow slot fallback and assignment
+ PASS same-origin iframe viewport
+ PASS nested visible scroll position
+ PASS mixed text and inline scroll positions
+ PASS fixed positioning follows its source containing block
+ PASS scroll preserves positioned containing blocks
+ PASS scrollbar box preserves native space
+ PASS sticky child after spacer
+ PASS same-document clip path
+ PASS SVG use local and external symbols
+ PASS cross-origin stylesheet fallback
+ PASS repeated Content-Type embeds image and CSS
+ PASS asynchronous image error recovery
+ PASS snapshot retries preserve frozen pixels
+ INFO large-image first=0,255,0,255 stabilized=0,255,0,255
+ PASS large embedded data image
+ DONE
+ REPORT FAILED HTTP 400

Call log:
  - Expect "toContainText" locator('#results') with timeout 90000ms
  - waiting for locator('#results')
    3 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels"
    2 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime"
    3 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources"
    19 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
       - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities"
    2 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope"
    15 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
       - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics"
    32 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
       - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope"
    2 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials
PASS relative clone resources and callback errors
PASS per-node customization
PASS shadow slot fallback and assignment
PASS same-origin iframe viewport
PASS nested visible scroll position"
    3 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials
PASS relative clone resources and callback errors
PASS per-node customization
PASS shadow slot fallback and assignment
PASS same-origin iframe viewport
PASS nested visible scroll position
PASS mixed text and inline scroll positions"
    3 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials
PASS relative clone resources and callback errors
PASS per-node customization
PASS shadow slot fallback and assignment
PASS same-origin iframe viewport
PASS nested visible scroll position
PASS mixed text and inline scroll positions
PASS fixed positioning follows its source containing block"
    2 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
      - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials
PASS relative clone resources and callback errors
PASS per-node customization
PASS shadow slot fallback and assignment
PASS same-origin iframe viewport
PASS nested visible scroll position
PASS mixed text and inline scroll positions
PASS fixed positioning follows its source containing block
PASS scroll preserves positioned containing blocks"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials
PASS relative clone resources and callback errors
PASS per-node customization
PASS shadow slot fallback and assignment
PASS same-origin iframe viewport
PASS nested visible scroll position
PASS mixed text and inline scroll positions
PASS fixed positioning follows its source containing block
PASS scroll preserves positioned containing blocks
PASS scrollbar box preserves native space
PASS sticky child after spacer
PASS same-document clip path"
    - locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
    - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials
PASS relative clone resources and callback errors
PASS per-node customization
PASS shadow slot fallback and assignment
PASS same-origin iframe viewport
PASS nested visible scroll position
PASS mixed text and inline scroll positions
PASS fixed positioning follows its source containing block
PASS scroll preserves positioned containing blocks
PASS scrollbar box preserves native space
PASS sticky child after spacer
PASS same-document clip path
PASS SVG use local and external symbols
PASS cross-origin stylesheet fallback
PASS repeated Content-Type embeds image and CSS
PASS asynchronous image error recovery
PASS snapshot retries preserve frozen pixels"
    80 × locator resolved to <pre id="results">INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) Ap…</pre>
       - unexpected value "INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1
PASS ESM import and basic PNG
PASS UMD global and pixels
PASS empty video preserves background and border
PASS canvas snapshot pixels
PASS explicit dimensions and pixel ratio
PASS fractional fonts and tight last word
PASS SVG font-family glyph pixels
PASS SVG references after clone transforms
PASS iframe fonts and document scope
PASS capture source document lifetime
PASS pseudo background and injected mask resources
PASS SVG dependency graphs and reference precedence
PASS external SVG use cycles preserve scoped identities
PASS external SVG preserves native stylesheet scope
PASS external SVG font units retain loaded metrics
PASS external SVG data stylesheet imports preserve native scope
PASS external SVG fragments preserve native paint scope
PASS external SVG redirects preserve file CSS bases
PASS resource cache lifetime
PASS native HTTP cache policy
PASS per-URL resource credentials
PASS relative clone resources and callback errors
PASS per-node customization
PASS shadow slot fallback and assignment
PASS same-origin iframe viewport
PASS nested visible scroll position
PASS mixed text and inline scroll positions
PASS fixed positioning follows its source containing block
PASS scroll preserves positioned containing blocks
PASS scrollbar box preserves native space
PASS sticky child after spacer
PASS same-document clip path
PASS SVG use local and external symbols
PASS cross-origin stylesheet fallback
PASS repeated Content-Type embeds image and CSS
PASS asynchronous image error recovery
PASS snapshot retries preserve frozen pixels
INFO large-image first=0,255,0,255 stabilized=0,255,0,255
PASS large embedded data image
DONE
REPORT FAILED HTTP 400"
  - Test timeout of 90000ms exceeded.

```

```yaml
- text: INFO Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.4 Safari/537.36 DPR=1 PASS ESM import and basic PNG PASS UMD global and pixels PASS empty video preserves background and border PASS canvas snapshot pixels PASS explicit dimensions and pixel ratio PASS fractional fonts and tight last word PASS SVG font-family glyph pixels PASS SVG references after clone transforms PASS iframe fonts and document scope PASS capture source document lifetime PASS pseudo background and injected mask resources PASS SVG dependency graphs and reference precedence PASS external SVG use cycles preserve scoped identities PASS external SVG preserves native stylesheet scope PASS external SVG font units retain loaded metrics PASS external SVG data stylesheet imports preserve native scope PASS external SVG fragments preserve native paint scope PASS external SVG redirects preserve file CSS bases PASS resource cache lifetime PASS native HTTP cache policy PASS per-URL resource credentials PASS relative clone resources and callback errors PASS per-node customization PASS shadow slot fallback and assignment PASS same-origin iframe viewport PASS nested visible scroll position PASS mixed text and inline scroll positions PASS fixed positioning follows its source containing block PASS scroll preserves positioned containing blocks PASS scrollbar box preserves native space PASS sticky child after spacer PASS same-document clip path PASS SVG use local and external symbols PASS cross-origin stylesheet fallback PASS repeated Content-Type embeds image and CSS PASS asynchronous image error recovery PASS snapshot retries preserve frozen pixels INFO large-image first=0,255,0,255 stabilized=0,255,0,255 PASS large embedded data image DONE REPORT FAILED HTTP 400
```

# Test source

```ts
  92  |               : group === 'scrollbars'
  93  |                 ? fixture.nativeScrollbarCases
  94  |                 : fixture.scrollbarStyleResourceCases
  95  |           const check =
  96  |             group === 'scroll'
  97  |               ? fixture.checkNativeScroll
  98  |               : group === 'scrollbars'
  99  |                 ? fixture.checkNativeScrollbars
  100 |                 : fixture.checkScrollbarStyleResources
  101 |           const readNative = async (id: string) => {
  102 |             const png = await scope.__nativeScrollSourcePNG(id)
  103 |             const image = new Image()
  104 |             image.src = 'data:image/png;base64,' + png
  105 |             await image.decode()
  106 |             const canvas = document.createElement('canvas')
  107 |             canvas.width = image.naturalWidth
  108 |             canvas.height = image.naturalHeight
  109 |             const context = canvas.getContext('2d')!
  110 |             context.drawImage(image, 0, 0)
  111 |             return context.getImageData(0, 0, canvas.width, canvas.height)
  112 |           }
  113 |           const supportsLegacy = CSS.supports('selector(::-webkit-scrollbar)')
  114 |           const report = {
  115 |             format,
  116 |             group,
  117 |             userAgent: navigator.userAgent,
  118 |             dpr: devicePixelRatio,
  119 |             listed: kinds.length,
  120 |             executed: [] as string[],
  121 |             passed: [] as string[],
  122 |             failed: [] as { kind: string; error: string }[],
  123 |             unsupported: [] as { kind: string; reason: string }[],
  124 |           }
  125 |           for (let index = 0; index < kinds.length; index += 1) {
  126 |             const kind = kinds[index]
  127 |             if (
  128 |               (group === 'style-resources' ||
  129 |                 (group === 'scrollbars' && kind.startsWith('legacy'))) &&
  130 |               !supportsLegacy
  131 |             ) {
  132 |               report.unsupported.push({
  133 |                 kind,
  134 |                 reason: 'CSS.supports(selector(::-webkit-scrollbar)) is false',
  135 |               })
  136 |               continue
  137 |             }
  138 |             report.executed.push(kind)
  139 |             try {
  140 |               // Run every supported case even if another case fails. A warmed
  141 |               // replay or a successful later case never replaces its verdict.
  142 |               // eslint-disable-next-line no-await-in-loop
  143 |               await check(api, kind, readNative)
  144 |               report.passed.push(kind)
  145 |             } catch (error) {
  146 |               report.failed.push({
  147 |                 kind,
  148 |                 error:
  149 |                   ((error as Error).message || String(error)) +
  150 |                   '\n' +
  151 |                   ((error as Error).stack || ''),
  152 |               })
  153 |             }
  154 |           }
  155 |           return report
  156 |         },
  157 |         { format, group },
  158 |       )
  159 |       await testInfo.attach('native-source-pixel-verdicts', {
  160 |         body: JSON.stringify(report, null, 2),
  161 |         contentType: 'application/json',
  162 |       })
  163 |       report.unsupported.forEach(({ kind, reason }) => {
  164 |         testInfo.annotations.push({
  165 |           type: 'unsupported fixture',
  166 |           description: `${kind}: ${reason}`,
  167 |         })
  168 |       })
  169 |       expect(report.listed).toBeGreaterThan(0)
  170 |       if (
  171 |         !report.executed.length &&
  172 |         report.unsupported.length === report.listed
  173 |       )
  174 |         test.skip(true, 'Native scrollbar styling is not supported')
  175 |       expect(report.executed.length).toBeGreaterThan(0)
  176 |       expect(report.executed.length + report.unsupported.length).toBe(
  177 |         report.listed,
  178 |       )
  179 |       expect(report.passed.length + report.failed.length).toBe(
  180 |         report.executed.length,
  181 |       )
  182 |       expect(report.failed).toEqual([])
  183 |     })
  184 |   })
  185 | })
  186 | 
  187 | test('the full mobile smoke page completes without a hidden failure', async ({
  188 |   page,
  189 | }) => {
  190 |   await page.goto('/test/browser/smoke.html')
  191 |   const results = page.locator('#results')
> 192 |   await expect(results).toContainText('REPORT SAVED', { timeout: 90000 })
      |                         ^ Error: expect(locator).toContainText(expected) failed
  193 |   const text = await results.textContent()
  194 |   cases.forEach((name) => expect(text).toContain(`PASS ${name}`))
  195 |   expect(text).not.toContain('FAIL')
  196 |   expect(text).toContain('DPR=')
  197 |   const id = text?.match(/REPORT SAVED ([a-f0-9-]{36})/)?.[1]
  198 |   expect(id).toBeDefined()
  199 |   const report = JSON.parse(
  200 |     await readFile(`test-results/mobile-smoke-reports/${id}.json`, 'utf8'),
  201 |   )
  202 |   expect(report.id).toBe(id)
  203 |   expect(report.complete).toBe(true)
  204 |   expect(report.userAgent).toBeTruthy()
  205 |   expect(report.gitHead).toBe(
  206 |     execFileSync('git', ['rev-parse', 'HEAD']).toString().trim(),
  207 |   )
  208 |   expect(report.verdicts).toHaveLength(cases.length + 2)
  209 |   const rejected = await page.request.post(
  210 |     '/test/browser/mobile-smoke-report',
  211 |     { data: { complete: true } },
  212 |   )
  213 |   expect(rejected.status()).toBe(403)
  214 | })
  215 | 
  216 | test('built UMD global renders pixels in a browser', async ({ page }) => {
  217 |   await page.goto('/test/browser/umd.html')
  218 |   await page.addScriptTag({ url: '/dist/html-to-image.js' })
  219 |   const result = await page.evaluate(async () => {
  220 |     const node = document.getElementById('capture')!
  221 |     const api = (
  222 |       window as typeof window & {
  223 |         htmlToImage?: {
  224 |           toImageData: (
  225 |             node: HTMLElement,
  226 |             options: { pixelRatio: number; skipFonts: boolean },
  227 |           ) => Promise<ImageData>
  228 |         }
  229 |       }
  230 |     ).htmlToImage
  231 |     if (!api) throw new Error('UMD global missing')
  232 |     const image = await api.toImageData(node, {
  233 |       pixelRatio: 1,
  234 |       skipFonts: true,
  235 |     })
  236 |     const offset = 4 * (16 * image.width + 16)
  237 |     return {
  238 |       width: image.width,
  239 |       height: image.height,
  240 |       pixel: Array.from(image.data.slice(offset, offset + 4)),
  241 |     }
  242 |   })
  243 |   expect(result).toEqual({ width: 32, height: 32, pixel: [255, 0, 0, 255] })
  244 | })
  245 | 
  246 | test('built UMD validates explicit dimensions and preserves the scaled pixel buffer', async ({
  247 |   page,
  248 | }) => {
  249 |   await page.goto('/test/browser/umd.html')
  250 |   await page.addScriptTag({ url: '/dist/html-to-image.js' })
  251 |   const result = await page.evaluate(async () => {
  252 |     const api = (
  253 |       window as typeof window & {
  254 |         htmlToImage: typeof import('../../src')
  255 |       }
  256 |     ).htmlToImage
  257 |     const node = document.createElement('div')
  258 |     node.style.cssText = 'width:16px;height:12px;background:red'
  259 |     document.body.append(node)
  260 |     const renderer = api.createRenderer({ skipFonts: true, pixelRatio: 2 })
  261 |     try {
  262 |       const canvas = await renderer.toCanvas(node, {
  263 |         width: 24,
  264 |         height: 18,
  265 |         canvasWidth: 40,
  266 |         canvasHeight: 30,
  267 |       })
  268 |       const zeros = []
  269 |       const invalid = []
  270 |       const dimensions = ['width', 'height'] as const
  271 |       for (let i = 0; i < dimensions.length; i += 1) {
  272 |         const dimension = dimensions[i]
  273 |         // eslint-disable-next-line no-await-in-loop
  274 |         const capture = await renderer.capture(node, { [dimension]: 0 })
  275 |         let rasterError = ''
  276 |         try {
  277 |           // eslint-disable-next-line no-await-in-loop
  278 |           await capture.toCanvas()
  279 |         } catch (error) {
  280 |           rasterError = (error as Error).message
  281 |         }
  282 |         // eslint-disable-next-line no-await-in-loop
  283 |         const svgURL = await capture.toSvg()
  284 |         const svg = new DOMParser().parseFromString(
  285 |           decodeURIComponent(svgURL.split(',')[1]),
  286 |           'image/svg+xml',
  287 |         )
  288 |         zeros.push({
  289 |           size: capture[dimension],
  290 |           svgSize: svg.documentElement.getAttribute(dimension),
  291 |           copySize: (svg.querySelector('foreignObject > div') as HTMLElement)
  292 |             .style[dimension],
```