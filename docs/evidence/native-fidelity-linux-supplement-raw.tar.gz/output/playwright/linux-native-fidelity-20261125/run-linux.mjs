import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { createRequire } from 'node:module'
import { spawn, execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const root = path.dirname(fileURLToPath(import.meta.url))
const out = root + '-evidence'
fs.mkdirSync(out)
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
const json = (name, value) => fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2) + '\n')
const identity = JSON.parse(fs.readFileSync(path.join(root, 'git-tracked-inputs.json')))
const tracked = () => Object.fromEntries(identity.files.map(item => [item.path, fs.existsSync(path.join(root, item.path)) ? hash(fs.readFileSync(path.join(root, item.path))) : null]))
const walk = (dir, prefix = '') => {
  if (!fs.existsSync(dir)) return {}
  const result = {}
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const relative = prefix + entry.name, absolute = path.join(dir, entry.name)
    if (entry.isDirectory()) Object.assign(result, walk(absolute, relative + '/'))
    else if (entry.isFile()) result[relative] = hash(fs.readFileSync(absolute))
    else if (entry.isSymbolicLink()) result[relative] = 'symlink:' + fs.readlinkSync(absolute)
  }
  return result
}
const inputs = () => {
  const result = tracked()
  for (const folder of ['es', 'lib', 'dist']) for (const [name, digest] of Object.entries(walk(path.join(root, folder)))) result[folder + '/' + name] = digest
  return result
}
const originalWork = () => ({ tracked: Object.fromEntries(identity.files.filter(item => fs.existsSync('/work/' + item.path)).map(item => [item.path, hash(fs.readFileSync('/work/' + item.path))])), viteCache: walk('/work/node_modules/.vite'), viteTemp: walk('/work/node_modules/.vite-temp') })
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b)
const workBefore = originalWork(); json('original-work-before.json', workBefore)
const trackedBefore = tracked()
json('tracked-before.json', trackedBefore)
const wrong = identity.files.filter(item => trackedBefore[item.path] !== item.sha256)
if (wrong.length) throw new Error('Archive tracked bytes differ: ' + wrong.map(item => item.path))
const require = createRequire(path.join(root, 'package.json'))
const packageJSON = JSON.parse(fs.readFileSync(path.join(root, 'package.json')))
const lockfile = fs.readFileSync(path.join(root, 'pnpm-lock.yaml'), 'utf8')
const importer = lockfile.split('\nimporters:\n')[1].split('\npackages:\n')[0]
const versions = {}, expected = {}
let current
for (const line of importer.split('\n')) {
  const key = line.match(/^      (.+):$/)
  if (key) current = key[1].replace(/^['"]|['"]$/g, '')
  const value = line.match(/^        version: (.+)$/)
  if (value && current) expected[current] = value[1].split('(')[0].replace(/^.*@(?=\d)/, '')
}
for (const name of Object.keys(packageJSON.devDependencies)) {
  const real = fs.realpathSync(path.join(root, 'node_modules', name))
  const pkg = JSON.parse(fs.readFileSync(path.join(real, 'package.json')))
  versions[name] = { version: pkg.version, locked: expected[name], lockMatch: pkg.version === expected[name], realpath: real, insideCopy: real.startsWith(root + '/node_modules/') }
}
const pnpm = execFileSync('pnpm', ['--version'], { cwd: root, encoding: 'utf8' }).trim()
const contract = { head: identity.head, tree: identity.tree, node: process.version, ciNode: '24 (not this run)', platform: process.platform, arch: process.arch, pnpm, requestedPackageManager: packageJSON.packageManager, lockfileSha256: hash(lockfile), originalWorkLockSha256: hash(fs.readFileSync('/work/pnpm-lock.yaml')), installedPackages: versions, browsersPath: process.env.PLAYWRIGHT_BROWSERS_PATH, engines: fs.readdirSync(process.env.PLAYWRIGHT_BROWSERS_PATH), browserFlags: 'Unmodified checked-in configuration', environment: { CI: 'true', HTML_TO_IMAGE_SMOKE_PORT: '4197 for browser package only' }, mountBoundary: 'Existing container retained, no mounts, source archived at exact head and full node_modules copied to this independent tmp directory.', binNodePath: 'Copied pnpm .bin scripts retain their original /work NODE_PATH fallback; all direct declared modules realpath to this copy. No original /work source/dependency/cache writes are requested.' }
json('dependency-contract.json', contract)
if (Object.values(versions).some(item => !item.lockMatch || !item.insideCopy) || contract.lockfileSha256 !== contract.originalWorkLockSha256 || packageJSON.packageManager !== 'pnpm@' + pnpm) throw new Error('Dependency/lockfile contract mismatch')
const removedPrivateCaches = []
for (const folder of ['.vite', '.vite-temp']) if (fs.existsSync(path.join(root, 'node_modules', folder))) { fs.rmSync(path.join(root, 'node_modules', folder), { recursive: true }); removedPrivateCaches.push(folder) }
json('private-cache-preparation.json', { removedPrivateCaches, source: 'Copied node_modules caches only; original /work untouched, no dependency install or download.' })
const receipts = []
async function stage(name, command, env = {}) {
  const directory = path.join(out, name); fs.mkdirSync(directory)
  const before = inputs(); fs.writeFileSync(path.join(directory, 'inputs-before.json'), JSON.stringify(before, null, 2) + '\n')
  const fd = fs.openSync(path.join(directory, 'run.log'), 'w'), started = Date.now()
  console.log('START', name, JSON.stringify(command), new Date().toISOString())
  const child = spawn(command[0], command.slice(1), { cwd: root, env: { ...process.env, CI: 'true', ...env }, stdio: ['ignore', fd, fd] })
  const result = await new Promise((resolve, reject) => { child.on('error', reject); child.on('exit', (code, signal) => resolve({ code, signal })) })
  fs.closeSync(fd)
  const after = inputs(); fs.writeFileSync(path.join(directory, 'inputs-after.json'), JSON.stringify(after, null, 2) + '\n')
  const receipt = { name, command, environment: { CI: 'true', ...env }, exitCode: result.code, signal: result.signal, durationSeconds: (Date.now() - started) / 1000, head: identity.head, tree: identity.tree, node: process.version, trackedInputsStable: same(Object.fromEntries(identity.files.map(item => [item.path, before[item.path]])), tracked()), measuredInputsStable: same(before, after), measuredInputCount: Object.keys(before).length }
  fs.writeFileSync(path.join(directory, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n')
  for (const [source, destination] of [['.vitest/attachments', 'vitest-attachments'], ['test-results', 'test-results'], ['playwright-report', 'playwright-report']]) if (fs.existsSync(path.join(root, source))) fs.cpSync(path.join(root, source), path.join(directory, destination), { recursive: true })
  receipts.push(receipt); json('stage-receipts.json', receipts); console.log('END', name, JSON.stringify(receipt))
  return receipt
}
try {
  const build = await stage('build', ['pnpm', 'run', 'build'])
  if (build.exitCode === 0) await stage('package-contract', ['pnpm', 'run', 'test:package'])
  await stage('source', ['pnpm', 'run', 'test:browser:source'])
  if (build.exitCode === 0) await stage('browser-package', ['pnpm', 'run', 'test:browser:package'], { HTML_TO_IMAGE_SMOKE_PORT: '4197' })
} finally {
  const after = tracked(), workAfter = originalWork(); json('tracked-after.json', after); json('original-work-after.json', workAfter)
  json('final-receipt.json', { head: identity.head, tree: identity.tree, node: process.version, ciNode: '24', platformValidationOnly: true, trackedInputsStable: identity.files.every(item => after[item.path] === item.sha256), originalWorkTrackedAndViteCachesUnchanged: same(workBefore, workAfter), phases: receipts })
}
