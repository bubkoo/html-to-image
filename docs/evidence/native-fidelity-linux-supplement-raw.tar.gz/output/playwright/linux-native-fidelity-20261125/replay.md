# #651 fixed-head Linux container supplementation

Measured head: `08d35a13aee74a6188b3250585256a222c05717b`; tree: `f1ecc768d52179e71e12566d42b439a135daf3b8`. The 936 tracked files were checked against their Git blob identities. The container is the already existing `html-to-image-gc-linux-9a391dc`, with no mounts. Its `/work` source and Vite caches were observed unchanged.

Results are platform supplementation, not remote CI acceptance. This environment uses Node 26.13.0; CI specifies Node 24. Actual Node runner processes retain `--no-opt -r /proc/.reset`, and the 58-byte preload removes those arguments from `process.execArgv`. Python `/proc` snapshots retain the actual arguments. Node and browser processes execute through Rosetta in the supplied amd64 container. Linux WebKit is WPE MiniBrowser. Device user-agent strings do not identify the real operating system.

The build and published-entry contract passed. Complete uninstrumented source: **1343 passed, 1 failed, 45 skipped**, exit 1. Its only failure is Chromium DPR1 `visible-text`: 214 different channels, max delta 88. The raw PNGs and frozen/authored/replay SVGs are retained.

Complete browser package after restoring the fixture's required Git metadata: **174 passed, 4 failed, 2 skipped**, exit 1. Chromium ESM and UMD each fail `visible-text` at DPR1. WebKit ESM and UMD each fail `visible-text` and `fractional` at DPR2. WebKit source DPR1 and package `padding-shadow` pass. Do not transfer a DPR1 conclusion to DPR2. The two whole skipped package tests are Firefox legacy style-resource groups; their internal capability skips remain unchanged.

The native package table contains 18 groups: 12 pass, 4 fail, 2 skip. Its 366 listed cases resolve to 284 executed, 278 pass, 6 fail and 82 unsupported. `package-native-verdicts/` contains the exact bodies of all 18 attachments extracted from the final HTML report. Failed traces provide the same raw verdicts. Package fixtures do not save a frozen SVG/raw pixel buffer for each failure; screencast JPEGs are not substitutes. No new capture is represented as an original failed package frame.

An initial package attempt was stopped with SIGINT, actual exit 130: 96 pass, 3 fail, 1 interrupted, 80 not run. Two failures were the Chromium pixel cases; the third was the confirmed missing `.git` prerequisite for the full mobile report. That attempt is preserved and is invalid as complete package acceptance. The correction added only real fixed-head commit/tree/blob objects, a legal shallow boundary and detached HEAD/index metadata in the private directory. All 936 index/working-tree blobs matched; no product, test or assertion changed. Only complete package was rerun. All three complete mobile reports then saved 40 verdicts under the exact fixed head.

Both complete source and corrected package preserved the same 1083 tracked-plus-generated inputs. Git metadata and original `/work` tracked files/Vite caches remained stable across the corrected package. `cleanup.json` records no owned processes and no listeners on 4197/4198; the container itself is retained.

The construction scripts retain the actual commands and use a private `/tmp/html-to-image-651-source-package-08d35a1` directory. Choose fresh private labels before replaying; do not overlap an active measurement. The correct preparation order is archive/copy dependencies, prepare and install real fixed-head Git metadata, then build and test:

```sh
python3 output/playwright/linux-native-fidelity-20261125/setup.py
python3 output/playwright/linux-native-fidelity-20261125/prepare-git-snapshot.py
python3 output/playwright/linux-native-fidelity-20261125/install-git-metadata.py
```

Copy the appropriate recorded runner to the private checkout with `docker cp` and execute it there. `run-linux.mjs` runs build, published-entry check, complete source and complete package sequentially. Its controller status is informational; the child exit codes in individual stage receipts are the gates. `run-package-only.mjs` was used for the corrected complete package without rerunning build/source. Environment: `CI=true`, package loopback port `HTML_TO_IMAGE_SMOKE_PORT=4197`. All test timeouts, assertions, retries, skips and browser flags are the checked-in defaults.

The whole source tar, snapshot object pack and copied dependencies are ignored local inputs. **Do not publish them or recursively archive this whole directory.** `public-evidence-files.json` is the explicit public selection; it omits those payloads, duplicated HTML reports and transient trace resources while retaining identity hashes, construction scripts, logs, original failure assets, verdicts and actual argument snapshots.
