import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { pathToFileURL, fileURLToPath } from 'node:url'
import assert from 'node:assert/strict'

const out = path.dirname(fileURLToPath(import.meta.url))
const repo = path.resolve(out, '../../..')
const require = createRequire(path.join(repo, 'package.json'))
const base = 'f8d1c4b1abb7decf143fdf418ad08fa8b22bd309'
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex')
const providerPath = require.resolve('@vitest/browser-playwright')
const { PlaywrightBrowserProvider } = await import(pathToFileURL(providerPath))
const pw = await import(pathToFileURL(require.resolve('playwright')))
const { chromium } = pw.default ?? pw
const { getGCRunnerFrame } = await import(pathToFileURL(path.join(repo, 'test/browser/gc-frame.mjs')))
const oldConfig = execFileSync('git', ['show', `${base}:vitest.browser.config.mts`], { cwd: repo, encoding: 'utf8' })
const newConfig = fs.readFileSync(path.join(repo, 'vitest.browser.config.mts'), 'utf8')
function adapter(source) {
  const a = source.indexOf('        async collectGarbage(')
  const b = source.indexOf('\n        },\n        async screenshotScrollSource', a)
  assert.ok(a >= 0 && b >= 0)
  return source.slice(a, b + '\n        }'.length).trim()
}
const oldAdapter = adapter(oldConfig)
const newAdapter = adapter(newConfig)
fs.writeFileSync(path.join(out, 'original-adapter.js'), oldAdapter + '\n')
fs.writeFileSync(path.join(out, 'candidate-adapter.js'), newAdapter + '\n')
fs.copyFileSync(providerPath, path.join(out, 'installed-provider.js'))
const registered = []
const provider = new PlaywrightBrowserProvider({
  config: { browser: { name: 'chromium' } },
  browser: { registerCommand(name) { registered.push(name) } },
}, {})
const report = {
  startedUTC: new Date().toISOString(), base,
  inputs: {
    provider: { path: providerPath, sha256: sha(fs.readFileSync(providerPath)) },
    originalMethod: sha(PlaywrightBrowserProvider.prototype.getCommandsContext.toString()),
    originalAdapter: sha(oldAdapter), candidateAdapter: sha(newAdapter),
    helper: sha(fs.readFileSync(path.join(repo, 'test/browser/gc-frame.mjs'))),
  },
  cases: [], events: [],
  limits: ['Controlled iframe schedules establish adapter behavior, not the unrecorded frame identity of security 20:53.', 'One original requestGC per selected target; no GC is performed when runner selection rejects.', 'Real private iframe controls are independent of production capture.'],
}
const frameIds = new WeakMap()
let nextFrameId = 0
function identity(frame) {
  if (!frameIds.has(frame)) frameIds.set(frame, ++nextFrameId)
  return { id: frameIds.get(frame), name: frame.name(), url: frame.url(), detached: frame.isDetached() }
}
const deferred = () => { let resolve; const promise = new Promise((r) => { resolve = r }); return { resolve, promise } }
async function append(page, id, runner = false) {
  const nav = page.waitForEvent('framenavigated', { predicate: (f) => f.url() === 'about:srcdoc' && (!runner || f.name() === 'vitest-iframe') })
  await page.evaluate(({ id, runner }) => {
    const f = document.createElement('iframe')
    f.id = id
    f.sandbox = 'allow-same-origin'
    if (runner) { f.name = 'vitest-iframe'; f.dataset.vitest = 'true' }
    f.srcdoc = '<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src \'none\'"><body>frame control</body>'
    document.body.append(f)
  }, { id, runner })
  return nav
}
async function remove(page, id) { await page.locator(`#${id}`).evaluate((f) => f.remove()) }
let browser
try {
  report.launchRequestedUTC = new Date().toISOString()
  browser = await chromium.launch({ headless: true })
  report.launchResolvedUTC = new Date().toISOString()
  report.browser = browser.version()
  for (const kind of ['named-present', 'private-removed-then-runner', 'private-retained-then-runner', 'private-only-no-runner', 'selected-runner-removed']) {
    for (const variant of ['original', 'candidate']) {
      const context = await browser.newContext()
      const page = await context.newPage()
      const rec = { kind, variant, startedUTC: new Date().toISOString(), gcCalls: 0, helperHandles: 0, helperDisposals: 0, gcHandleSnapshots: [] }
      report.cases.push(rec)
      const session = `${kind}-${variant}`
      provider.pages.set(session, page)
      provider.contexts.set(session, context)
      for (const event of ['frameattached', 'framenavigated', 'framedetached']) page.on(event, (f) => report.events.push({ at: new Date().toISOString(), kind, variant, event, frame: identity(f) }))
      try {
        await page.setContent('<!doctype html><body>real GC runner control</body>')
        if (kind === 'named-present' || kind === 'selected-runner-removed') await append(page, 'runner', true)
        const originalWait = page.waitForSelector.bind(page)
        page.waitForSelector = async (...args) => {
          rec.waitForSelectorArguments = args
          const handle = await originalWait(...args)
          if (handle) {
            rec.helperHandles++
            const dispose = handle.dispose.bind(handle)
            handle.dispose = async () => { await dispose(); rec.helperDisposals++; rec.lastDisposalUTC = new Date().toISOString() }
          }
          return handle
        }
        const nativeGC = page.requestGC.bind(page)
        page.requestGC = async () => {
          rec.gcCalls++
          rec.gcHandleSnapshots.push({ at: new Date().toISOString(), created: rec.helperHandles, disposed: rec.helperDisposals })
          return nativeGC()
        }
        const selected = deferred(), gate = deferred()
        const observe = async (target) => { rec.selected = identity(target); selected.resolve(target); await gate.promise; rec.beforeGC = identity(target); return target }
        const commands = provider.getCommandsContext(session)
        const collect = variant === 'original'
          ? new Function(`return ({${oldAdapter}}).collectGarbage`)()
          : new Function('getGCRunnerFrame', `return ({${newAdapter}}).collectGarbage`)(async (p) => observe(await getGCRunnerFrame(p)))
        const start = performance.now()
        const operation = collect({ page, frame: async () => observe(await commands.frame()) }).then(
          () => ({ status: 'fulfilled' }),
          (e) => ({ status: 'rejected', name: e.name, message: e.message, stack: e.stack }),
        )
        if (kind.startsWith('private-')) await append(page, 'private')
        if (kind === 'private-removed-then-runner') await remove(page, 'private')
        if (kind === 'private-removed-then-runner' || kind === 'private-retained-then-runner') await append(page, 'runner', true)
        let target
        if (kind !== 'private-only-no-runner' || variant === 'original') target = await selected.promise
        if (kind === 'selected-runner-removed') await remove(page, 'runner')
        // Independent DOM identity control; all control handles are released too.
        const domElement = await page.$('iframe[data-vitest="true"]')
        if (domElement) {
          try {
            const frame = await domElement.contentFrame()
            rec.actualRunnerDOMFrame = identity(frame)
            rec.selectedEqualsActualRunnerDOMFrame = target === frame
          } finally { await domElement.dispose() }
        } else rec.actualRunnerDOMFrame = null
        gate.resolve()
        rec.operation = await operation
        rec.elapsedMs = performance.now() - start
        rec.after = target ? identity(target) : null
        if (variant === 'candidate') {
          assert.equal(rec.helperHandles, rec.helperDisposals)
          assert.ok(rec.gcHandleSnapshots.every((s) => s.created === s.disposed))
          if (kind === 'private-only-no-runner') {
            assert.equal(rec.gcCalls, 0)
            assert.equal(rec.operation.name, 'TimeoutError')
            assert.match(rec.operation.message, /1000ms/)
            assert.ok(rec.elapsedMs >= 900)
          } else if (kind === 'selected-runner-removed') {
            assert.equal(rec.gcCalls, 1)
            assert.match(rec.operation.message, /Frame was detached/)
          } else {
            assert.equal(rec.gcCalls, 1)
            assert.equal(rec.selectedEqualsActualRunnerDOMFrame, true)
            assert.equal(rec.operation.status, 'fulfilled')
          }
        } else {
          assert.equal(rec.gcCalls, 1)
          const fail = kind === 'private-removed-then-runner' || kind === 'selected-runner-removed'
          assert.equal(rec.operation.status, fail ? 'rejected' : 'fulfilled')
          if (fail) assert.match(rec.operation.message, /Frame was detached/)
          if (kind === 'private-retained-then-runner') assert.equal(rec.selectedEqualsActualRunnerDOMFrame, false)
        }
        rec.expectedControlPassed = true
      } catch (e) {
        rec.harnessError = { name: e.name, message: e.message, stack: e.stack }
        throw e
      } finally {
        provider.pages.delete(session); provider.contexts.delete(session)
        await context.close()
        rec.contextClosedUTC = new Date().toISOString()
        fs.writeFileSync(path.join(out, 'controls.json'), JSON.stringify(report, null, 2) + '\n')
      }
    }
  }
} catch (e) { report.terminalError = { name: e.name, message: e.message, stack: e.stack }; process.exitCode = 1 }
finally {
  if (browser) { report.closeRequestedUTC = new Date().toISOString(); await browser.close(); report.closeResolvedUTC = new Date().toISOString() }
  process.removeListener('SIGTERM', provider.onSIGTERM)
  report.finishedUTC = new Date().toISOString()
  fs.writeFileSync(path.join(out, 'controls.json'), JSON.stringify(report, null, 2) + '\n')
}
