import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const dir = path.dirname(fileURLToPath(import.meta.url))
const [label, command, ...args] = process.argv.slice(2)
if (!label || !command) throw Error('label and command required')
const log = fs.createWriteStream(path.join(dir, `${label}.log`), { flags: 'wx' })
const receipt = { label, command: [command, ...args], cwd: process.cwd(), startedUTC: new Date().toISOString() }
const child = spawn(command, args, { cwd: process.cwd(), env: process.env, stdio: ['ignore', 'pipe', 'pipe'] })
child.stdout.on('data', (b) => log.write(b))
child.stderr.on('data', (b) => log.write(b))
child.on('error', (e) => { receipt.spawnError = e.message })
child.on('close', (code, signal) => {
  Object.assign(receipt, { finishedUTC: new Date().toISOString(), code, signal })
  log.end(() => {
    fs.writeFileSync(path.join(dir, `${label}-receipt.json`), JSON.stringify(receipt, null, 2) + '\n')
    console.log(JSON.stringify(receipt))
    const text = fs.readFileSync(path.join(dir, `${label}.log`), 'utf8')
    console.log(text.slice(-1800))
    process.exitCode = code ?? 1
  })
})
