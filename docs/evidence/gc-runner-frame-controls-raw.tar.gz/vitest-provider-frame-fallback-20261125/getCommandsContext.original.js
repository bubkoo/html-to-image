getCommandsContext(sessionId) {
		const page = this.getPage(sessionId);
		return {
			page,
			context: this.contexts.get(sessionId),
			frame() {
				return new Promise((resolve, reject) => {
					const frame = page.frame("vitest-iframe");
					if (frame) {
						return resolve(frame);
					}
					const timeout = setTimeout(() => {
						const err = new Error(`Cannot find "vitest-iframe" on the page. This is a bug in Vitest, please report it.`);
						reject(err);
					}, 1e3).unref();
					page.on("frameattached", (frame) => {
						clearTimeout(timeout);
						resolve(frame);
					});
				});
			},
			get iframe() {
				return page.frameLocator("[data-vitest=\"true\"]");
			}
		};
	}
