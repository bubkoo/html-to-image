import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { createRequire } from 'node:module'
import { pathToFileURL, fileURLToPath } from 'node:url'
import assert from 'node:assert/strict'

const dir = path.dirname(fileURLToPath(import.meta.url))
const inputs = JSON.parse(fs.readFileSync(path.join(dir, 'prepared-inputs.json')))
const require = createRequire(path.join(inputs.repo, 'package.json'))
const sha = (value) => crypto.createHash('sha256').update(value).digest('hex')
assert.equal(sha(fs.readFileSync(inputs.provider.path)), inputs.provider.sha256)
const { PlaywrightBrowserProvider } = await import(pathToFileURL(inputs.provider.path))
const playwrightModule = await import(pathToFileURL(require.resolve('playwright')))
const { chromium } = playwrightModule.default ?? playwrightModule
assert.equal(
  sha(PlaywrightBrowserProvider.prototype.getCommandsContext.toString().trim()),
  inputs.provider.methodSHA256,
)
const adapterText = fs.readFileSync(path.join(dir, 'collectGarbage.original.js'), 'utf8').trim()
assert.equal(sha(adapterText), inputs.adapter.fragmentSHA256)
// Execute the exact captured adapter method body, without rewriting its operations.
const collectGarbage = new Function(`return ({ ${adapterText} }).collectGarbage`)()
const registeredCommands = []
const project = {
  config: { browser: { name: 'chromium' } },
  browser: { registerCommand(name) { registeredCommands.push(name) } },
}
const provider = new PlaywrightBrowserProvider(project, {})
const result = {
  at: new Date().toISOString(),
  installedProviderSHA256: inputs.provider.sha256,
  actualProviderInstance: provider instanceof PlaywrightBrowserProvider,
  exactMethodBody: true,
  exactOriginalGCAdapter: true,
  registeredCommandCount: registeredCommands.length,
  cases: [],
  events: [],
  limits: inputs.limits,
}
const ids = new WeakMap()
let sequence = 0
const identify = (frame) => {
  if (!ids.has(frame)) ids.set(frame, ++sequence)
  return { id: ids.get(frame), name: frame.name(), url: frame.url(), detached: frame.isDetached() }
}
const deferred = () => {
  let resolve
  const promise = new Promise((r) => { resolve = r })
  return { promise, resolve }
}
const attach = async (page, id, named = false) => {
  const loaded = page.waitForEvent('framenavigated', {
    predicate: (frame) => frame.url() === 'about:srcdoc' && (!named || frame.name() === 'vitest-iframe'),
  })
  await page.evaluate(({ id, named }) => {
    const frame = document.createElement('iframe')
    frame.id = id
    if (named) frame.name = 'vitest-iframe'
    frame.sandbox = 'allow-same-origin'
    frame.srcdoc = '<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src \'none\'"><body>frame control</body>'
    document.body.append(frame)
  }, { id, named })
  return loaded
}

let browser
try {
  result.launchRequestedUTC = new Date().toISOString()
  browser = await chromium.launch({ headless: true })
  result.launchResolvedUTC = new Date().toISOString()
  result.browserVersion = browser.version()
  for (const kind of ['named-runner-present', 'private-detached-before-gc', 'private-before-named']) {
    const context = await browser.newContext()
    const page = await context.newPage()
    const record = { kind, startedUTC: new Date().toISOString() }
    result.cases.push(record)
    const event = (type, frame) => result.events.push({ at: new Date().toISOString(), kind, type, frame: identify(frame) })
    page.on('frameattached', (frame) => event('frameattached', frame))
    page.on('framenavigated', (frame) => event('framenavigated', frame))
    page.on('framedetached', (frame) => event('framedetached', frame))
    const session = `probe-${kind}`
    provider.pages.set(session, page)
    provider.contexts.set(session, context)
    try {
      await page.setContent('<!doctype html><body>provider frame control</body>')
      if (kind === 'named-runner-present') await attach(page, 'runner', true)
      const commands = provider.getCommandsContext(session)
      const selected = deferred()
      const continueAfterSelection = deferred()
      record.attachedListenersBefore = page.listenerCount('frameattached')
      // This wrapper only records and schedules the controlled race. The provider's
      // frame selection and original GC/evaluate adapter remain unmodified.
      const operation = collectGarbage({
        page,
        frame: async () => {
          const target = await commands.frame()
          record.selected = identify(target)
          selected.resolve(target)
          await continueAfterSelection.promise
          record.beforeOriginalGC = identify(target)
          return target
        },
      }).then(
        () => ({ status: 'fulfilled' }),
        (error) => ({ status: 'rejected', name: error.name, message: error.message, stack: error.stack }),
      )
      if (kind !== 'named-runner-present') await attach(page, 'private')
      const target = await selected.promise
      if (kind === 'private-detached-before-gc') {
        const detached = page.waitForEvent('framedetached', { predicate: (frame) => frame === target })
        await page.evaluate(() => document.querySelector('#private').remove())
        await detached
      } else if (kind === 'private-before-named') {
        await attach(page, 'runner', true)
      }
      record.runnerAtGC = page.frame('vitest-iframe') ? identify(page.frame('vitest-iframe')) : null
      record.selectedEqualsRunnerAtGC = target === page.frame('vitest-iframe')
      continueAfterSelection.resolve()
      record.operation = await operation
      record.afterOriginalAdapter = identify(target)
      record.attachedListenersAfter = page.listenerCount('frameattached')
      if (kind === 'named-runner-present') {
        assert.equal(record.selectedEqualsRunnerAtGC, true)
        assert.equal(record.operation.status, 'fulfilled')
      } else if (kind === 'private-detached-before-gc') {
        assert.equal(record.beforeOriginalGC.detached, true)
        assert.equal(record.operation.status, 'rejected')
        assert.match(record.operation.message, /detached/i)
      } else {
        assert.equal(record.selectedEqualsRunnerAtGC, false)
        assert.equal(record.selected.name, '')
        assert.equal(record.runnerAtGC.name, 'vitest-iframe')
        assert.equal(record.operation.status, 'fulfilled')
      }
      record.expectedControlPassed = true
    } catch (error) {
      record.harnessError = { name: error.name, message: error.message, stack: error.stack }
      throw error
    } finally {
      provider.pages.delete(session)
      provider.contexts.delete(session)
      await context.close()
      record.contextClosedUTC = new Date().toISOString()
      fs.writeFileSync(path.join(dir, 'results.json'), JSON.stringify(result, null, 2) + '\n')
    }
  }
} catch (error) {
  result.terminalError = { name: error.name, message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  if (browser) {
    result.closeRequestedUTC = new Date().toISOString()
    await browser.close()
    result.closeResolvedUTC = new Date().toISOString()
  }
  process.removeListener('SIGTERM', provider.onSIGTERM)
  result.finishedUTC = new Date().toISOString()
  fs.writeFileSync(path.join(dir, 'results.json'), JSON.stringify(result, null, 2) + '\n')
}
