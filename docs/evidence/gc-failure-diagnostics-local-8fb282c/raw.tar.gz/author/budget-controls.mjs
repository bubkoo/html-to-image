import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { captureGCFailureHeap } from '../../../test/browser/gc-failure.mjs'
import { withinGCFailureBudget } from '../../../test/browser/gc-failure-budget.mjs'
const out=new URL('./budget-results.json',import.meta.url),rows=[],unhandled=[]
const onUnhandled=e=>unhandled.push(String(e));process.on('unhandledRejection',onUnhandled)
const record=(id,browser,deadline)=>({id,browser,deadline,caseName:id,phase:'snapshot',originalCollected:false,alive:true,marker:'__test_marker',markerAttached:false})
try{
 const a=Date.now();await assert.rejects(withinGCFailureBudget(()=>new Promise(()=>{}),a+30),/budget exhausted/);rows.push({case:'never-settling primitive',bounded:true,elapsedMs:Date.now()-a})
 let lateReject;const pending=new Promise((_,reject)=>{lateReject=reject});await assert.rejects(withinGCFailureBudget(()=>pending,Date.now()+20),/budget exhausted/);lateReject(new Error('deliberate late rejection'));await new Promise(resolve=>setImmediate(resolve));rows.push({case:'late primitive rejection',unhandled:unhandled.length})
 for(const stuck of ['Heap.enable','Heap.snapshot','Heap.disable']){
  const calls=[];const session={send(method){calls.push(method);if(method===stuck)return new Promise(()=>{});return Promise.resolve(method==='Heap.snapshot'?{snapshotData:'{}'}:{})}};const page={url:()=> 'controlled://page',frames:()=>[],_connection:{toImpl:()=>({delegate:{_session:session}})}};const id='budget-'+stuck.toLowerCase().replaceAll('.','-'),start=Date.now();await captureGCFailureHeap(page,record(id,'webkit',start+50)).catch(error=>{assert.match(String(error),/budget exhausted/)});assert(calls.includes('Heap.disable'));rows.push({case:stuck+' never settles',calls,elapsedMs:Date.now()-start,disableRequested:true})
 }
 const r=record('unsupported-control','firefox',Date.now()+1000);await captureGCFailureHeap({},r);await captureGCFailureHeap({},{...r,phase:'after',alive:false});const transport=JSON.parse(await readFile('.vitest/attachments/gc-heap/unsupported-control/transport.json')),after=JSON.parse(await readFile('.vitest/attachments/gc-heap/unsupported-control/after.json'));assert.equal(transport.status,'unsupported');assert.equal(after.alive,false);rows.push({case:'unsupported engine',transport:transport.status,afterWritten:true})
 assert.equal(unhandled.length,0)
}finally{process.off('unhandledRejection',onUnhandled);await writeFile(out,JSON.stringify({atUTC:new Date().toISOString(),scope:'Node-only controlled protocol/primitive pending tests; no browser launch or GC, artificial bounds are not browser stabilization waits.',rows,unhandled},null,2)+'\n')}
