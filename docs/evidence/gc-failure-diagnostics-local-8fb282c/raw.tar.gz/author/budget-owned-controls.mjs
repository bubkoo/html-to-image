import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { captureGCFailureHeap } from '../../../test/browser/gc-failure.mjs'
import { withinGCFailureBudget } from '../../../test/browser/gc-failure-budget.mjs'
const rows=[],unhandled=[],prefix='owned-'+Date.now()+'-',onUnhandled=e=>unhandled.push(String(e));process.on('unhandledRejection',onUnhandled)
const record=(id,ms=500,browser='webkit')=>({id:prefix+id,browser,deadline:Date.now()+ms,caseName:id,phase:'snapshot',originalCollected:false,alive:true,marker:'__test_marker',markerAttached:false})
const file=(r,name)=>'.vitest/attachments/gc-heap/'+r.id+'/'+name+'.json'
const page=session=>({url:()=> 'controlled://page',frames:()=>[],_connection:{toImpl:()=>({delegate:{_session:session}})}})
let result
try{
 const start=Date.now();await assert.rejects(withinGCFailureBudget(()=>new Promise(()=>{}),start+25),/budget exhausted/);rows.push({case:'never-settling primitive',elapsedMs:Date.now()-start})
 let reject;const promise=new Promise((_,r)=>{reject=r});await assert.rejects(withinGCFailureBudget(()=>promise,Date.now()+20),/budget exhausted/);reject(new Error('deliberate late rejection'));await new Promise(r=>setImmediate(r));rows.push({case:'late rejection consumed',unhandled:unhandled.length})
 {
  const calls=[],p=page({send(m){calls.push(m);return m==='Heap.enable'?Promise.reject(new Error('deliberate enable rejection')):Promise.resolve({})}}),r=record('enable-reject');await captureGCFailureHeap(p,r);assert.deepEqual(calls,['Heap.enable']);rows.push({case:'failed enable does not disable another session',calls})
 }
 {
  let enable;const gate=new Promise(r=>{enable=r}),calls=[];let n=0;const p=page({send(m){calls.push(m);if(m==='Heap.enable'&&n++===0)return gate;return Promise.resolve(m==='Heap.snapshot'?{snapshotData:'{}'}:{})}}),r=record('late-enable',35)
  await assert.rejects(captureGCFailureHeap(p,r),/budget exhausted/);assert.deepEqual(calls,['Heap.enable']);const busy=record('busy-before-late-enable');await captureGCFailureHeap(p,busy);assert.equal(JSON.parse(await readFile(file(busy,'transport'))).status,'busy');assert.deepEqual(calls,['Heap.enable']);enable({});await new Promise(r=>setImmediate(r));assert.deepEqual(calls,['Heap.enable','Heap.disable']);rows.push({case:'late successful enable requests exactly one disable and releases owner only after acknowledgement',calls:[...calls]});const next=record('new-owner-after-ack');await captureGCFailureHeap(p,next);assert.equal(JSON.parse(await readFile(file(next,'transport'))).status,'saved')
 }
 {
  const calls=[],p=page({send(m){calls.push(m);return m==='Heap.snapshot'?new Promise(()=>{}):Promise.resolve({})}}),r=record('snapshot-pending',35);await assert.rejects(captureGCFailureHeap(p,r),/budget exhausted/);assert.deepEqual(calls,['Heap.enable','Heap.snapshot','Heap.disable']);rows.push({case:'pending snapshot bounded with owned disable',calls})
 }
 {
  let stop;const stopped=new Promise(r=>{stop=r}),calls=[],p=page({send(m){calls.push(m);return m==='Heap.disable'?stopped:Promise.resolve(m==='Heap.snapshot'?{snapshotData:'{}'}:{})}}),r=record('disable-pending',35);await assert.rejects(captureGCFailureHeap(p,r),/budget exhausted/);const busy=record('busy-before-disable-ack');await captureGCFailureHeap(p,busy);assert.equal(JSON.parse(await readFile(file(busy,'transport'))).status,'busy');assert.deepEqual(calls,['Heap.enable','Heap.snapshot','Heap.disable']);stop({});await new Promise(r=>setImmediate(r));rows.push({case:'pending disable consumes no fresh budget and prevents competing owner',calls})
 }
 {
  let enable;const gate=new Promise(r=>{enable=r}),p=page({send(m){return m==='Heap.enable'?gate:Promise.resolve(m==='Heap.snapshot'?{snapshotData:'{}'}:{})}}),r=record('after-race');const task=captureGCFailureHeap(p,r);while(true){try{await readFile(file(r,'after-pending'));break}catch{await new Promise(r=>setImmediate(r))}}await captureGCFailureHeap(p,{...r,phase:'after',alive:false,markerRemoved:true});enable({});await task;const after=JSON.parse(await readFile(file(r,'after')));assert.equal(after.alive,false);rows.push({case:'late snapshot cannot overwrite actual after sample',afterAlive:after.alive,pendingFileSeparate:true})
 }
 {
  const r=record('unsupported',500,'firefox');await captureGCFailureHeap({},r);await captureGCFailureHeap({},{...r,phase:'after',alive:false});assert.equal(JSON.parse(await readFile(file(r,'transport'))).status,'unsupported');assert.equal(JSON.parse(await readFile(file(r,'after'))).alive,false);rows.push({case:'unsupported explicitly recorded and after persists'})
 }
 assert.equal(unhandled.length,0);result='all passed'
} catch(error){result={message:error.message,stack:error.stack};throw error}
finally{process.off('unhandledRejection',onUnhandled);await writeFile(new URL('budget-owned-results.json',import.meta.url),JSON.stringify({atUTC:new Date().toISOString(),scope:'Node-only controlled pending/rejection/ownership tests. No browser, original GC, production capture or remote execution.',result,rows,unhandled},null,2)+'\n')}
