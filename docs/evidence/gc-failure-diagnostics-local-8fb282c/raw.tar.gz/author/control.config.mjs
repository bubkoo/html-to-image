import { mergeConfig } from 'vitest/config'
import { writeFile } from 'node:fs/promises'
import base from '../../../vitest.browser.config.mts'
const original=base.test.browser.commands,calls=[]
const log=()=>writeFile(new URL('./command-calls.json',import.meta.url),JSON.stringify(calls,null,2)+'\n')
export default mergeConfig(base,{test:{include:[new URL('./control.test.ts',import.meta.url).pathname],browser:{api:{port:4277,strictPort:true},commands:{
async collectGarbage(ctx){calls.push({command:'collectGarbage',atUTC:new Date().toISOString()});await log();await original.collectGarbage(ctx)},
async captureGCFailureHeap(ctx,record){calls.push({command:'captureGCFailureHeap',phase:record.phase,caseName:record.caseName,id:record.id,atUTC:new Date().toISOString()});await log();await original.captureGCFailureHeap(ctx,record)}
}}}})
