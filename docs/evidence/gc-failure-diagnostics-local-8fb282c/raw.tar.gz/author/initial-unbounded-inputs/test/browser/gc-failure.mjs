import { mkdir, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { createHash } from 'node:crypto'

/**
 * Test-only, post-failure diagnostics. No source DOM object crosses this API.
 * @param {unknown} page
 * @param {import('./gc-failure.mjs').GCFailureRecord} record
 */
export async function captureGCFailureHeap(page, record) {
  if (!/^[a-z0-9-]{1,80}$/.test(record.id))
    throw new Error('Invalid GC diagnostic artifact ID')
  if (record.phase !== 'snapshot' && record.phase !== 'after')
    throw new Error('Invalid GC diagnostic phase')
  const folder = resolve('.vitest/attachments/gc-heap', record.id)
  await mkdir(folder, { recursive: true })
  const write = (name, value) =>
    writeFile(
      resolve(folder, name + '.json'),
      JSON.stringify(value, null, 2) + '\n',
    )
  if (record.phase === 'after') {
    await write('after', { ...record, atUTC: new Date().toISOString() })
    return
  }
  await write('before', { ...record, atUTC: new Date().toISOString() })
  const result = { startedUTC: new Date().toISOString() }
  if (record.browser !== 'webkit') {
    await write('transport', {
      ...result,
      status: 'unsupported',
      reason: 'Native Heap protocol is WebKit-only',
    })
    return
  }
  let session
  try {
    // Playwright 1.64.1's in-process WebKit provider; feature detect the private API.
    session = page?._connection?.toImpl?.(page)?.delegate?._session
    if (!session)
      throw new Error('Playwright WebKit native Heap session unavailable')
    await session.send('Heap.enable')
    const snapshot = await session.send('Heap.snapshot')
    const raw = JSON.stringify(snapshot, null, 2) + '\n'
    await writeFile(resolve(folder, 'heap.json'), raw)
    result.status = 'saved'
    result.bytes = Buffer.byteLength(raw)
    result.sha256 = createHash('sha256').update(raw).digest('hex')
  } catch (error) {
    result.status = 'error'
    result.error = { message: String(error), stack: error?.stack }
  } finally {
    if (session) {
      try {
        await session.send('Heap.disable')
      } catch (error) {
        result.disableError = { message: String(error), stack: error?.stack }
      }
    }
    await write('transport', {
      ...result,
      completedUTC: new Date().toISOString(),
    })
  }
}
