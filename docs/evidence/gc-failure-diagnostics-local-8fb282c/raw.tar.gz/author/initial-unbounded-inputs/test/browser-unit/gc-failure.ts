/// <reference lib="es2021.weakref" />
import { commands, server } from 'vitest/browser'
import type { GCFailureRecord } from '../browser/gc-failure.mjs'

declare module 'vitest/browser' {
  interface BrowserCommands {
    captureGCFailureHeap(record: GCFailureRecord): Promise<void>
  }
}

// Run synchronously and return only a boolean: no strong DOM reference survives
// into the command await. The marker is diagnostic instrumentation added only
// after the original failure, and its edges must be labeled as such in analysis.
function mark(reference: WeakRef<Document>, marker: string) {
  const source = reference.deref()
  if (!source) return false
  return Reflect.defineProperty(source, marker, {
    value: { marker },
    configurable: true,
  })
}

function unmark(reference: WeakRef<Document>, marker: string) {
  const source = reference.deref()
  return !source || Reflect.deleteProperty(source, marker)
}

export async function recordGCFailure(
  reference: WeakRef<Document>,
  originalCollected: boolean,
  caseName: string,
) {
  if (originalCollected) return
  const id = crypto.randomUUID()
  const marker = '__hti_gc_failure_' + id.replace(/-/g, '_')
  const record: GCFailureRecord = {
    id,
    caseName,
    browser: server.browser,
    phase: 'snapshot',
    originalCollected,
    alive: reference.deref() !== undefined,
    marker,
    markerAttached: false,
  }
  try {
    record.markerAttached = mark(reference, marker)
    await commands.captureGCFailureHeap(record)
  } catch (error) {
    // Artifact/protocol failure must not replace the original GC assertion.
    record.commandError = String(error)
  } finally {
    record.phase = 'after'
    record.alive = reference.deref() !== undefined
    try {
      record.markerRemoved = unmark(reference, marker)
      await commands.captureGCFailureHeap(record)
    } catch {
      // Keep the caller's original primitive verdict authoritative.
    }
  }
}
