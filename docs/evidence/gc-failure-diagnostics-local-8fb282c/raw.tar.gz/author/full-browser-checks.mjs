import { spawn, execFileSync } from 'node:child_process'
import { readFile, writeFile, mkdir, open } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { resolve } from 'node:path'
const root=process.cwd(),dir=new URL('./full-browser-checks/',import.meta.url);await mkdir(dir,{recursive:true})
const all=execFileSync('git',['ls-files'],{encoding:'utf8'}).trim().split('\n');const extra=['test/browser/gc-failure.mjs','test/browser/gc-failure.d.mts','test/browser/gc-failure-budget.mjs','test/browser/gc-failure-budget.d.mts','test/browser-unit/gc-failure.ts'];const files=[...new Set([...all.filter(p=>/^(src|test|scripts)\//.test(p)||/^(package.json|pnpm-lock.yaml|.*config.*)$/.test(p)),...extra])].sort()
async function inputs(){const rows=[];for(const path of files)rows.push({path,sha256:createHash('sha256').update(await readFile(path)).digest('hex')});return rows}
const report={startedUTC:new Date().toISOString(),base:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),branch:execFileSync('git',['branch','--show-current'],{encoding:'utf8'}).trim(),stages:[]}
async function stage(name,args,env={}){const before=await inputs(),r={name,startedUTC:new Date().toISOString(),command:['pnpm',...args],env};await writeFile(new URL(name+'-inputs-before.json',dir),JSON.stringify(before,null,2)+'\n');report.stages.push(r);await writeFile(new URL('receipt.json',dir),JSON.stringify(report,null,2)+'\n');const log=await open(new URL(name+'.log',dir),'w');const child=spawn('pnpm',args,{cwd:root,env:{...process.env,...env},stdio:['ignore',log.fd,log.fd]});r.pid=child.pid;r.exitCode=await new Promise(resolve=>child.on('exit',resolve));await log.close();r.completedUTC=new Date().toISOString();const after=await inputs();r.inputsUnchanged=JSON.stringify(before)===JSON.stringify(after);r.inputCount=before.length;await writeFile(new URL(name+'-inputs-after.json',dir),JSON.stringify(after,null,2)+'\n');await writeFile(new URL('receipt.json',dir),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(r));return r.exitCode}

const defaultExit=await stage('default',['run','test']);
const defaultLog=await readFile(new URL('default.log',dir),'utf8');
if(defaultExit&&!/> html-to-image[^\n]* test:browser:source/.test(defaultLog)){await stage('source-first-execution',['run','test:browser:source'])}
await stage('browser-package',['run','test:browser:package'],{HTML_TO_IMAGE_SMOKE_PORT:'4213'});
report.completedUTC=new Date().toISOString();await writeFile(new URL('receipt.json',dir),JSON.stringify(report,null,2)+'\n');
