export interface GCFailureRecord {
  id: string
  caseName: string
  browser: string
  phase: 'snapshot' | 'after'
  originalCollected: boolean
  alive: boolean
  marker: string
  markerAttached: boolean
  deadline: number
  markerRemoved?: boolean
  commandError?: string
}

export function captureGCFailureHeap(
  page: unknown,
  record: GCFailureRecord,
): Promise<void>
