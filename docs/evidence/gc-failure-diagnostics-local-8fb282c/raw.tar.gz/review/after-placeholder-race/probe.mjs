import fs from 'node:fs/promises'
import {resolve} from 'node:path'
import {createHash} from 'node:crypto'
const dir=new URL('./',import.meta.url),path='/Users/bytedance/.codex/worktrees/gc-runner-frame-controls/html-to-image/test/browser/gc-failure.mjs',original=await fs.readFile(path,'utf8'),sourceSHA=createHash('sha256').update(original).digest('hex')
if(sourceSHA!=='d3f1172039dc7eb23558a71289736adcee087de65fe178c13be2f378a5afa478')throw Error('Reviewed source changed; do not silently test different source')
let releaseBefore,enteredBefore;const gate=new Promise(r=>releaseBefore=r),entered=new Promise(r=>enteredBefore=r),writes=[],files=new Map()
const mkdir=async()=>{},writeFile=async(path,data)=>{if(path.endsWith('/before.json')){enteredBefore();await gate}writes.push({name:path.split('/').at(-1),data:JSON.parse(data)});files.set(path.split('/').at(-1),JSON.parse(data))}
const budget=async operation=>await operation(),code=original.replace(/^import .*\n/gm,'').replace('export async function captureGCFailureHeap','async function captureGCFailureHeap'),helper=Function('mkdir','writeFile','resolve','createHash','withinGCFailureBudget',code+'\nreturn captureGCFailureHeap')(mkdir,writeFile,resolve,createHash,budget)
const record={id:'race-review',phase:'snapshot',browser:'chromium',originalCollected:false,alive:true,deadline:Date.now()+2000,marker:'primitive-marker',markerAttached:true},first=helper({url:()=>'',frames:()=>[]},record)
await entered
await helper({}, {...record,phase:'after',alive:false,markerRemoved:true,commandError:'browser snapshot budget exhausted'})
const afterBeforeRelease=files.get('after.json');releaseBefore();await first
const afterAfterRelease=files.get('after.json'),proof={scope:'Pure Node controlled scheduling of exact reviewed helper, injected filesystem only. No browser/Heap operation/test assertion/production mutation. Budget injected immediate to isolate write ordering; same legal concurrent snapshot/after entrypoints.',sourceSHA,control:'Hold snapshot before.json write; run real after-phase write; release old snapshot so its placeholder writes later.',afterBeforeRelease,afterAfterRelease,actualAfterOverwritten:afterBeforeRelease.alive===false&&afterAfterRelease.alive==='unknown',writes}
await fs.writeFile(new URL('results.json',dir),JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify(proof,null,2));if(!proof.actualAfterOverwritten)process.exitCode=1
