import {createServer} from 'node:http'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {resolve} from 'node:path'
import {chromium,firefox,webkit} from 'playwright'
const out=resolve('output/playwright/svg-qualified-paint-url-identity');await mkdir(out,{recursive:true})
const trace=[]
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname;trace.push(path)
 if(path.endsWith('/page.html')){res.setHeader('Content-Type','text/html');res.end('<!doctype html><style>body{margin:0}</style>');return}
 if(path.endsWith('/sprite.svg') || path.endsWith('/other.svg')){
  const imported='data:text/css,'+encodeURIComponent('.viaImport{fill:url("sprite.svg#paint") purple!important}')
  const color=path.endsWith('/other.svg')?'orange':path.includes('/assets/')?'green':'red'
  const ids=['attr','inline','other','parent','query','missing','foreign','fragment','absolute','control']
  const nodes=ids.map(id=>`<symbol id="${id}" viewBox="0 0 20 20"><rect width="20" height="20" ${id==='attr'?'fill="url(sprite.svg#paint) purple"':id==='inline'?'style="fill:url(sprite.svg#paint) purple"':id==='other'?'fill="url(other.svg#paint) purple"':id==='parent'?'fill="url(../sprite.svg#paint) purple"':id==='query'?'fill="url(sprite.svg?different#paint) purple"':id==='missing'?'fill="url(sprite.svg#absent) purple"':id==='foreign'?'fill="url(http://127.0.0.1:4496/foreign/sprite.svg#paint) purple"':id==='fragment'?'fill="url(#paint) purple"':id==='absolute'?`fill="url(http://127.0.0.1:4496${path}#paint) purple"`:'fill="green"'}/></symbol>`).join('')
  res.setHeader('Content-Type','image/svg+xml');res.setHeader('Cache-Control','no-store');res.end(`<svg xmlns="http://www.w3.org/2000/svg"><defs><pattern id="paint" patternUnits="userSpaceOnUse" width="20" height="20"><rect width="20" height="20" fill="${color}"/></pattern></defs><style>@import url('${imported}');.viaFile{fill:url(sprite.svg#paint) purple!important}</style>${nodes}</svg>`);return
 }
 if(path.startsWith('/es/')){try{res.setHeader('Content-Type','text/javascript');res.end(await readFile(resolve('.'+path)));return}catch{}}
 res.writeHead(404).end()
})
await new Promise(r=>server.listen(4496,'127.0.0.1',r))
const results={sourceHead:'ea97a25a45cb9db202d30d0f8dd704d57d7de3af',meaning:'Observation only; no runtime fix',engines:{}}
try{
 for(const [name,engine] of Object.entries({chromium,firefox,webkit})){
  const browser=await engine.launch()
  try{
   const page=await browser.newPage({deviceScaleFactor:1});const prefix='/probe/'+crypto.randomUUID()
   await page.goto('http://127.0.0.1:4496'+prefix+'/page.html');const start=trace.length
   await page.evaluate(prefix=>{
    const root=document.createElement('div');root.id='source';root.style.cssText='display:flex;width:220px;height:20px;background:white'
    for(const id of ['attr','inline','other','parent','query','missing','foreign','fragment','absolute','control']){
     const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('width','20');svg.setAttribute('height','20');svg.style.flex='none';const use=document.createElementNS(svg.namespaceURI,'use');use.setAttribute('href',prefix+'/assets/sprite.svg#'+id);use.setAttribute('width','20');use.setAttribute('height','20');svg.append(use);root.append(svg)
    }
    const yellow=document.createElement('div');yellow.style.cssText='width:20px;height:20px;background:yellow;flex:none';root.append(yellow);document.body.append(root)
   },prefix)
   await page.waitForFunction(()=>Array.from(document.querySelectorAll('use')).every(x=>x.getBBox().width===20))
   await page.waitForLoadState('networkidle');await page.locator('#source').screenshot({path:resolve(out,name+'-before.png'),scale:'css'})
   const captureStart=trace.length
   const result=await page.evaluate(async()=>{
    const {createRenderer}=await import('/es/index.js');const root=document.getElementById('source'),markup=root.outerHTML;const requests=[];const renderer=createRenderer({pixelRatio:1,skipFonts:true,resources:{resolve:({url,kind})=>{requests.push({url,kind})}}});let snapshot
    try{snapshot=await renderer.capture(root);const data=await snapshot.toImageData();return{sourceUnchanged:markup===root.outerHTML,requests,pixels:Array.from({length:11},(_,i)=>i*20+10).map(x=>Array.from(data.data.slice(4*(10*data.width+x),4*(10*data.width+x)+4))),png:await snapshot.toPng(),diagnostics:snapshot.diagnostics}}finally{snapshot?.dispose();renderer.dispose()}
   })
   await writeFile(resolve(out,name+'-capture.png'),Buffer.from(result.png.split(',')[1],'base64'));delete result.png
   await page.locator('#source').screenshot({path:resolve(out,name+'-after.png'),scale:'css'})
   results.engines[name]={...result,version:browser.version(),prefix,columns:['attribute','inline','other-file','parent-file','different-query','absent-id','absolute-other','fragment','absolute-self','flat','yellow'],nativeRequests:trace.slice(start,captureStart),captureRequests:trace.slice(captureStart)}
  }finally{await browser.close()}
 }
}finally{await new Promise(r=>server.close(r))}
await writeFile(resolve(out,'observation.json'),JSON.stringify(results,null,2)+'\n')
console.log('Owned relative-source observations saved')
