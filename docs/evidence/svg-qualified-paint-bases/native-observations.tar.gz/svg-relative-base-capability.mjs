import {createServer} from 'node:http'
import {chromium,firefox,webkit} from 'playwright'
import {mkdir,writeFile} from 'node:fs/promises'
const out='output/playwright/svg-relative-base-capability';await mkdir(out,{recursive:true});const requests=[]
const server=createServer((req,res)=>{requests.push(req.url);res.setHeader('content-type','text/html');res.end('<!doctype html><style>body{margin:0}</style>')});await new Promise(r=>server.listen(4497,'127.0.0.1',r));const rows=[]
try{for(const[name,type]of Object.entries({chromium,firefox,webkit})){
 const browser=await type.launch();try{const page=await browser.newPage({deviceScaleFactor:1});await page.goto('http://127.0.0.1:4497/path/page.html');
 for(const realm of ['page','srcdoc','history-srcdoc']){
 const record=await page.evaluate(async realm=>{let f;let doc=document;if(realm!=='page'){f=document.createElement('iframe');f.style.cssText='position:absolute;left:0;top:0;width:100px;height:100px;border:0';f.srcdoc='<!doctype html><style>body{margin:0}</style>';await new Promise(r=>{f.onload=r;document.body.append(f)});doc=f.contentDocument;if(realm==='history-srcdoc')f.contentWindow.history.replaceState(null,'',location.href)}
 const ns='http://www.w3.org/2000/svg';const svg=doc.createElementNS(ns,'svg');svg.setAttribute('width','60');svg.setAttribute('height','20');svg.innerHTML='<defs><clipPath id="ownedclip"><rect width="6" height="20"/></clipPath></defs>';
 const reference=new URL(doc.baseURI).pathname.split('/').pop()+'#ownedclip';
 const xml=`<svg xmlns="${ns}"><g id="probe"><rect width="20" height="20" fill="green" clip-path="url(${reference})"/></g><g id="local"><rect width="20" height="20" fill="green" clip-path="url(#ownedclip)"/></g><g id="flat"><rect width="20" height="20" fill="green"/></g></svg>`;const url=URL.createObjectURL(new Blob([xml],{type:'image/svg+xml'}));
 const uses=[];for(const [i,id]of ['probe','local','flat'].entries()){const u=doc.createElementNS(ns,'use');u.id='own-'+id;u.setAttribute('href',url+'#'+id);u.setAttribute('x',String(i*20));svg.append(u);uses.push(u)}doc.body.append(svg);const deadline=Date.now()+5000;while(uses.some(u=>u.getBBox().width!==20)&&Date.now()<deadline)await new Promise(r=>setTimeout(r,0));
 const result={realm,url:doc.URL,base:doc.baseURI,reference,widths:uses.map(u=>u.getBBox().width),hits:[2,10,22,30,42,50].map(x=>{const e=doc.elementFromPoint(x,10);return e?.id||e?.localName})};window.ownBaseProbeCleanup=()=>{uses.forEach(u=>u.removeAttribute('href'));svg.remove();f?.remove();URL.revokeObjectURL(url)};return result},realm);
 await page.screenshot({path:`${out}/${name}-${realm}.png`});await page.evaluate(()=>window.ownBaseProbeCleanup());rows.push({engine:name,...record});console.log(JSON.stringify({engine:name,...record}));}
 }finally{await browser.close()}
}}finally{await new Promise(r=>server.close(r));await writeFile(out+'/observations.json',JSON.stringify({rows,requests},null,2))}
