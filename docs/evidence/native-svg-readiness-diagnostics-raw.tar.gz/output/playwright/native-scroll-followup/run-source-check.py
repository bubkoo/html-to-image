from pathlib import Path
import hashlib,json,subprocess,sys,time
label=sys.argv[1]
folder=Path(__file__).parent/label
folder.mkdir(parents=True,exist_ok=True)
def manifest():
    selected={'package.json','pnpm-lock.yaml','vitest.browser.config.mts','playwright.config.ts','rollup.config.js','eslint.config.mjs','tsconfig.json','tsconfig.browser-tests.json'}
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],text=True).split('\0')
    paths=[p for p in paths if p.startswith(('src/','test/','scripts/')) or p in selected]
    for name in ('es','lib','dist'):
        paths.extend(str(p) for p in Path(name).rglob('*') if p.is_file())
    return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(set(paths))}
before=manifest()
(folder/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
for p in sorted(p for p in before if p.startswith('src/')):
    dest=folder/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(Path(p).read_bytes())
command=['pnpm','exec','vitest','run','--config','vitest.browser.config.mts',*sys.argv[2:]]
start=time.monotonic()
with (folder/'run.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
after=manifest()
(folder/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'command':command,'exitCode':result.returncode,'inputsUnchanged':before==after,'inputCount':len(before),'durationSeconds':time.monotonic()-start,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
if before!=after:raise RuntimeError('Measured source inputs changed')
raise SystemExit(result.returncode)
