import { createServer } from 'node:http'
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises'
import { extname } from 'node:path'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
import { firefox } from 'playwright'

const directory = new URL('./', import.meta.url)
await mkdir(directory, { recursive: true })
const paths = [
  'test/browser/fixtures/svg-native-styles.mjs',
  'test/browser/fixtures/svg-styles/native-policy.svg',
  'test/browser/fixtures/svg-styles/whole-style.svg',
  'test/browser/fixtures/svg-styles/other.svg',
]
const files = new Map()
const inputs = []
for (const path of paths) {
  const body = await readFile(path)
  files.set('/' + path, body)
  inputs.push({ path, sha256: createHash('sha256').update(body).digest('hex') })
  await writeFile(new URL(path.replaceAll('/', '__'), directory), body)
}
let mode
const http = []
const server = createServer((request, response) => {
  const url = new URL(request.url, 'http://localhost')
  const row = { mode, path: url.pathname, at: Date.now(), method: request.method }
  http.push(row)
  if (url.pathname === '/' || url.pathname === '/frame') {
    row.status = 200
    row.mime = 'text/html; charset=utf-8'
    response.writeHead(row.status, { 'Content-Type': row.mime }).end('<!doctype html><meta charset="utf-8"><body style="margin:0">')
  } else {
    const denied =
      (mode === 'policy-404' && url.pathname.endsWith('/native-policy.svg')) ||
      (mode === 'whole-style-404' && url.pathname.endsWith('/whole-style.svg'))
    const bytes = files.get(url.pathname)
    row.status = denied || !bytes ? 404 : 200
    row.mime = extname(url.pathname) === '.mjs' ? 'text/javascript' : 'image/svg+xml'
    row.bodySha256 = bytes && !denied ? createHash('sha256').update(bytes).digest('hex') : null
    response.writeHead(row.status, { 'Content-Type': row.mime, 'Cache-Control': 'no-store' }).end(row.status === 200 ? bytes : '')
  }
  row.ended = Date.now()
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const origin = `http://127.0.0.1:${server.address().port}`
const browser = await firefox.launch({ headless: true })
const report = {
  at: new Date().toISOString(),
  browser: browser.version(),
  inputs,
  cases: [],
  scope: 'Real Firefox and original diagnostic fixture bytes. Deliberate HTTP404 negative controls, not original failure reproduction or production capture acceptance. Original60 RAF, geometry assertions, CSS, and wait paths remain unchanged.',
}
try {
  for (const kind of ['policy-ok', 'policy-404', 'whole-style-ok', 'whole-style-404']) {
    mode = kind
    const context = await browser.newContext({ viewport: { width: 414, height: 896 }, deviceScaleFactor: 1 })
    const page = await context.newPage()
    const events = []
    page.on('request', request => events.push({ type: 'request', at: Date.now(), url: request.url() }))
    page.on('response', response => events.push({ type: 'response', at: Date.now(), url: response.url(), status: response.status(), mime: response.headers()['content-type'] || 'unknown' }))
    page.on('requestfailed', request => events.push({ type: 'requestfailed', at: Date.now(), url: request.url(), failure: request.failure() }))
    try {
      await page.goto(origin)
      await page.evaluate(() => {
        const frame = document.createElement('iframe')
        frame.src = '/frame'
        frame.style.cssText = 'display:block;border:0;width:414px;height:896px'
        document.body.append(frame)
      })
      const frame = await page.locator('iframe').contentFrame().locator('body').elementHandle().then(handle => handle.ownerFrame())
      const result = await frame.evaluate(async kind => {
        const fixture = await import('/test/browser/fixtures/svg-native-styles.mjs')
        const baseline = { body: document.body.innerHTML, styles: document.head.querySelectorAll('style').length }
        const row = { kind, start: performance.now(), creates: 0, captureCalls: 0, disposeCalls: 0, nativeCallbacks: 0 }
        const sentinel = new Error('Independent probe stopped before production capture')
        try {
          if (kind.startsWith('policy-')) {
            row.policy = await fixture.readNativeSVGFixturePolicy()
            row.status = 'native-ready'
          } else {
            await fixture.checkSVGNativeStyles({
              createRenderer() {
                row.creates++
                return {
                  dispose() { row.disposeCalls++ },
                  capture() { row.captureCalls++; throw new Error('Production capture must never run') },
                }
              },
            }, 'whole-style', async () => {
              row.nativeCallbacks++
              throw sentinel
            })
          }
        } catch (error) {
          if (error === sentinel) row.status = 'native-ready-before-capture'
          else {
            row.status = 'native-failure'
            row.message = error.message
            row.stack = error.stack
            const marker = '\nNative readiness: '
            const split = error.message.indexOf(marker)
            row.prefix = split < 0 ? error.message : error.message.slice(0, split)
            row.diagnostic = split < 0 ? null : JSON.parse(error.message.slice(split + marker.length))
          }
        }
        row.end = performance.now()
        row.cleanup = {
          bodyRestored: document.body.innerHTML === baseline.body,
          stylesRestored: document.head.querySelectorAll('style').length === baseline.styles,
          remainingSVG: document.querySelectorAll('svg').length,
          remainingUse: document.querySelectorAll('use').length,
        }
        return row
      }, kind)
      assert.equal(result.captureCalls, 0)
      assert.deepEqual(result.cleanup, { bodyRestored: true, stylesRestored: true, remainingSVG: 0, remainingUse: 0 })
      if (kind.endsWith('-404')) {
        assert.equal(result.status, 'native-failure')
        assert.equal(result.nativeCallbacks, 0)
        const diagnostic = result.diagnostic
        assert.ok(diagnostic)
        assert.ok(Number.isFinite(diagnostic.diagnosedAt))
        assert.ok(Number.isFinite(diagnostic.timeOrigin))
        assert.equal(diagnostic.visibility, 'visible')
        assert.equal(diagnostic.frameElement.isConnected, true)
        assert.equal(diagnostic.frameElement.rendered, true)
        assert.equal(diagnostic.frameElement.intersectsParentViewport, true)
        const policy = kind === 'policy-404'
        const file = policy ? 'native-policy.svg' : 'whole-style.svg'
        assert.equal(result.prefix, policy ? 'Native HTTP SVG policy fixture did not load' : 'Native external SVG did not load: /test/browser/fixtures/svg-styles/whole-style.svg#icon')
        const samples = policy ? diagnostic.samples : diagnostic.samples[0]
        assert.equal(samples.length, 60)
        samples.forEach((sample, index) => {
          assert.equal(sample.attempt, index)
          assert.ok(Number.isFinite(sample.at))
          if (policy) assert.deepEqual(sample.widths, [0, 0, 0, 0])
          else assert.equal(sample.width, 0)
        })
        for (const use of diagnostic.uses) {
          assert.equal(use.isConnected, true)
          assert.equal(use.outerSVG.isConnected, true)
          assert.equal(typeof use.url, 'string')
          assert.ok(use.resourceTiming === 'unknown' || Array.isArray(use.resourceTiming))
          if (Array.isArray(use.resourceTiming)) {
            assert.ok(use.resourceTiming.length > 0)
            assert.ok(use.resourceTiming.every(entry => entry.name === use.url && Number.isFinite(entry.responseEnd)))
          }
        }
        assert.ok(diagnostic.uses[0].outerSVG.style.includes('left: -9999px'))
        assert.ok(events.some(event => event.type === 'response' && event.url.endsWith('/' + file) && event.status === 404 && event.mime === 'image/svg+xml'))
      } else {
        assert.equal(result.status, kind === 'policy-ok' ? 'native-ready' : 'native-ready-before-capture')
        if (kind === 'whole-style-ok') assert.equal(result.nativeCallbacks, 1)
        assert.equal(events.some(event => event.type === 'response' && event.status === 404), false)
      }
      if (kind.startsWith('whole-style-')) {
        assert.equal(result.creates, 1)
        assert.equal(result.disposeCalls, 1)
      }
      const row = { ...result, events, assertionsPassed: true }
      report.cases.push(row)
      await writeFile(new URL(kind + '.json', directory), JSON.stringify(row, null, 2))
      console.log(JSON.stringify({ kind, status: row.status, elapsed: row.end - row.start, sampleCount: row.diagnostic ? (kind.startsWith('policy-') ? row.diagnostic.samples.length : row.diagnostic.samples[0].length) : null, cleanup: row.cleanup, captureCalls: row.captureCalls }))
    } finally { await context.close() }
  }
} finally {
  await browser.close()
  server.closeAllConnections()
  await new Promise(resolve => server.close(resolve))
  report.inputsUnchanged = true
  for (const input of inputs) if (createHash('sha256').update(await readFile(input.path)).digest('hex') !== input.sha256) report.inputsUnchanged = false
  report.allPassed = report.cases.length === 4 && report.cases.every(row => row.assertionsPassed) && report.inputsUnchanged
  report.cleanup = { browserClosed: true, serverClosed: true, mainlineTestsBuildRun: false, productionCaptureInvoked: false }
  await writeFile(new URL('http.json', directory), JSON.stringify(http, null, 2))
  await writeFile(new URL('results.json', directory), JSON.stringify(report, null, 2))
  const index = []
  for (const path of await readdir(directory)) {
    if (path === 'sha256-index.json') continue
    const bytes = await readFile(new URL(path, directory))
    index.push({ path, sha256: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length })
  }
  await writeFile(new URL('sha256-index.json', directory), JSON.stringify(index, null, 2))
}
assert.equal(report.allPassed, true)
